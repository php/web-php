#include <stdio.h>

enum errors {
   eusage,
     efin,
     efout,
};

/* files will be automagically cosed on exit */
 
void usage(enum errors error)
{
   switch(error)
     {
      case eusage:
	printf("Usage : dos2unix [<input file> [<output file>]]\n");
	break;
      case efin:
	printf("Error opening input file.\n");
	break;
      case efout:
	printf("Error opening output file.\n");
	break;
     }

   exit(-1);
}

int main(int argc,char *argv[])
{
   FILE *fin=stdin,*fout=stdout;
   int c,last;

   if(argc>3)
     usage(eusage);
     
   if(argc>1 && !(fin=fopen(argv[1],"r")))
     usage(efin);
   
   if(argc>2 && !(fout=fopen(argv[2],"w")))
     usage(efout);
   
   if((last=fgetc(fin))==EOF)
     return 0;

   do 
     {
	c=fgetc(fin);			

	if( (c!='\n') || (last!='\r') )
	  fputc(last,fout);
		
	last=c;					
     } 
   while(c!=EOF);
   
   return 0;
}
