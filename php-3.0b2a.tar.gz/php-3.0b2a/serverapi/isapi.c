#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <httpext.h>

#include "parser.h"
#include "language-parser.tab.h"
#include "main.h"
#include "control_structures.h"
#include "list.h"
#include "modules.h"
extern int isapi_php3_module_main(LPEXTENSION_CONTROL_BLOCK lpEcb);

extern int ini_close;

extern int tls_create(void);
extern int tls_destroy(void);
extern int tls_startup(void);
extern int tls_shutdown(void);

void *hLock; /*hash lock*/
void *aLock; /*alloc lock*/
extern void*gLock;

BOOL WINAPI DllMain(HANDLE hModule, 
                      DWORD  ul_reason_for_call, 
                      LPVOID lpReserved)
{
    switch( ul_reason_for_call ) {
    case DLL_PROCESS_ATTACH:
		/* 
		   I should be loading ini vars here 
		   and doing whatever true global inits
		   need to be done
		*/
		/*lets create our mutexes for blocking*/
		CREATE_MUTEX(gLock,"GENERAL");

		if(!tls_startup())
			return 0;
		if(!tls_create())
			return 0;
		if (php3_module_startup()==FAILURE) {
			return 0;
		}
		break;
    case DLL_THREAD_ATTACH:
		if(!tls_create())
			return 0;
		if (php3_module_startup()==FAILURE) {
			return 0;
		}
		break;
    case DLL_THREAD_DETACH:
		php3_module_shutdown();
		if(!tls_destroy())
			return 0;
		break;
    case DLL_PROCESS_DETACH:
		/*
		    close down anything down in process_attach 
		*/
		ini_close=1;
		php3_module_shutdown();
		if(!tls_destroy())
			return 0;
		if(!tls_shutdown())
			return 0;
		break;
    }
    return TRUE;
}


BOOL WINAPI GetExtensionVersion (HSE_VERSION_INFO  *version)
{
    version->dwExtensionVersion = MAKELONG( HSE_VERSION_MINOR,
                                            HSE_VERSION_MAJOR );
    strncpy( version->lpszExtensionDesc,
            "PHP v3.0 Beta 1 ISAPI Ext v1",
			HSE_MAX_EXT_DLL_NAME_LEN);

    return TRUE;
}




/* this is php3_isapi_main()!!! */
DWORD WINAPI HttpExtensionProc (LPEXTENSION_CONTROL_BLOCK lpEcb)
{
	return isapi_php3_module_main(lpEcb);
}


//
// Works like _getenv(), but uses isapi functions instead.
// 
char *isapi_getenv(LPEXTENSION_CONTROL_BLOCK lpEnvcb,LPSTR lpszEnvVar) {
	
	char var[255],dummy;
	DWORD dwLen, dummylen = 1;

	if (!lpszEnvVar)
		return "";
	
	dwLen =lpEnvcb->GetServerVariable(lpEnvcb->ConnID,lpszEnvVar,&dummy,&dummylen);

	if (dwLen == 0)
		return "";
	
	(void)lpEnvcb->GetServerVariable(lpEnvcb->ConnID,lpszEnvVar,var,&dwLen);

	return estrdup(var);
}


void isapi_puts(char *string,LPEXTENSION_CONTROL_BLOCK lpPHPcb)
{
	int n;
	n = strlen(string);
	lpPHPcb->WriteClient(lpPHPcb->ConnID,string,&n,0);
	return;
}

void isapi_putc(char character,LPEXTENSION_CONTROL_BLOCK lpPHPcb)
{
	int n = 1;
	lpPHPcb->WriteClient(lpPHPcb->ConnID,&character,&n,0);
	return;
}