/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Amitay Isaacs <amitay@cse.iitb.ernet.in>                    |
   +----------------------------------------------------------------------+
 */
 
/* $Id: ldap.c,v 1.5 1997/12/16 20:05:59 amitay Exp $ */

#ifndef MSVC5
#include "config.h"
#endif
#include "parser.h"
#include "internal_functions.h"

#if HAVE_LDAP

#if COMPILE_DL
#include "dl/phpdl.h"
#include "functions/dl.h"
#endif
#include "list.h"
#include "php3_ldap.h"

#ifdef MSVC5
#undef WINDOWS
#undef strcasecmp
#undef strncasecmp
#define WINSOCK 1
#define __STDC__ 1
#endif
#include <lber.h>
#include <ldap.h>


ldap_module php3_ldap_module;



/*
	This is just a small subset of the functionality provided by the LDAP library. All the 
	operations are synchronous. Referrals are not handled automatically.
*/

function_entry ldap_functions[] = {
	{"ldap_connect", 			php3_ldap_connect,				NULL},
	{"ldap_pconnect", 			php3_ldap_pconnect,				NULL},
	{"ldap_close", 				php3_ldap_close,				NULL},
	{"ldap_bind",				php3_ldap_bind,					NULL},
	{"ldap_unbind",				php3_ldap_unbind,				NULL},
	{"ldap_search",				php3_ldap_search,				NULL},
	{"ldap_free_result", 		php3_ldap_free_result,			NULL},
	{"ldap_count_entries", 		php3_ldap_count_entries, 		NULL},
	{"ldap_first_entry",		php3_ldap_first_entry,			NULL},
	{"ldap_next_entry",			php3_ldap_next_entry,			NULL},
	{"ldap_free_entry", 		php3_ldap_free_entry,			NULL},
/*
	{"ldap_first_attribute",	php3_ldap_first_attribute,		NULL},
	{"ldap_next_attribute",		php3_ldap_next_attribute,		NULL},
*/
	{"ldap_get_values",			php3_ldap_get_values,			NULL},
	{"ldap_count_values",		php3_ldap_get_values,			NULL},

	{"ldap_add", 				php3_ldap_add,					NULL},
	{"ldap_delete",				php3_ldap_delete,				NULL},
	{"ldap_modify",				php3_ldap_modify,				NULL},
	{NULL, NULL, NULL}
};

php3_module_entry ldap_module_entry = {
	"LDAP", ldap_functions, php3_minit_ldap, NULL, php3_rinit_ldap, NULL, php3_info_ldap, 0, 0, 0, NULL
};



#if COMPILE_DL
php3_module_entry *get_module(void ) { return &ldap_module_entry; }
#endif



static void _close_ldap_link(int link)
{
	php3_ldap_module.num_links--;
}


static void _close_ldap_plink(int link)
{
	php3_ldap_module.num_persistent--;
	php3_ldap_module.num_links--;
}


static void _free_ldap_result(int link)
{
/* have to figure out a clean way of freeing the result */
}


int php3_minit_ldap(INITFUNCARG)
{
	if (cfg_get_long("ldap.allow_persistent", &php3_ldap_module.allow_persistent) == FAILURE) {
		php3_ldap_module.allow_persistent = 1;
	}
	if (cfg_get_long("ldap.max_persistent", &php3_ldap_module.max_persistent) == FAILURE) {
		php3_ldap_module.max_persistent = -1;
	}
	if (cfg_get_long("ldap.max_links", &php3_ldap_module.max_links) == FAILURE) {
		php3_ldap_module.max_links = -1;
	}

	if(cfg_get_string("ldap.base_dn", &php3_ldap_module.base_dn) == FAILURE) {
		php3_ldap_module.base_dn = NULL;
	}

	php3_ldap_module.num_persistent = 0;
	php3_ldap_module.le_result = register_list_destructors(_free_ldap_result, NULL);
	php3_ldap_module.le_result_entry = register_list_destructors(_free_ldap_result, NULL);
	php3_ldap_module.le_link = register_list_destructors(_close_ldap_link, NULL);
	php3_ldap_module.le_plink = register_list_destructors(NULL, _close_ldap_plink);

	ldap_module_entry.type = type;

	return SUCCESS;
}


int php3_rinit_ldap(INITFUNCARG)
{
	php3_ldap_module.default_link = -1;
	php3_ldap_module.num_links = php3_ldap_module.num_persistent;

	return SUCCESS;
}


void php3_info_ldap(void)
{
	char maxp[16], maxl[16];

	if(php3_ldap_module.max_persistent == -1) {
		strcpy(maxp, "Unlimited");
	} else {
		snprintf(maxp, 15, "%ld", php3_ldap_module.max_persistent);
		maxp[15] = 0;
	}

	if(php3_ldap_module.max_links == -1) {
		strcpy(maxl, "Unlimited");
	} else {
		snprintf(maxl, 15, "%ld", php3_ldap_module.max_links);
		maxl[15] = 0;
	}

	php3_printf("<table>"
				"<tr><td>Allow persistent links:</td><td>%s</td></tr>\n"
				"<tr><td>Persistent links:</td><td>%d/%s</td></tr>\n"
				"<tr><td>Total links:</td><td>%d/%s</td></tr>\n"
				"</table>\n",
				(php3_ldap_module.allow_persistent?"Yes":"No"),
				php3_ldap_module.num_persistent,maxp,
				php3_ldap_module.num_links,maxl);
}


static void php3_ldap_do_connect(INTERNAL_FUNCTION_PARAMETERS, int persistent)
{
	char *host;
	int port;
	char *hashed_details;
	int hashed_details_length;
	LDAP *ldap;

	switch(ARG_COUNT(ht)) {
		case 0: 
			host = NULL;
			port = 0;
			hashed_details = estrndup("ldap_", 5);
			hashed_details_length = 4+1;
			break;

		case 1: {
				YYSTYPE *yyhost;

				if(getParameters(ht, 1, &yyhost) == FAILURE) {
					RETURN_FALSE;
				}

				convert_to_string(yyhost);
				host = yyhost->value.strval;
				port = 389; /* Default port */

				hashed_details_length = yyhost->strlen+4+1;
				hashed_details = emalloc(hashed_details_length+1);
				sprintf(hashed_details, "ldap_%s", yyhost->value.strval);
			}
			break;

		case 2: {
				YYSTYPE *yyhost, *yyport;

				if(getParameters(ht, 2, &yyhost, &yyport) == FAILURE) {
					RETURN_FALSE;
				}

				convert_to_string(yyhost);
				host = yyhost->value.strval;
				convert_to_long(yyport);
				port = yyport->value.lval;

			/* Do we need to take care of hosts running multiple LDAP servers ? */
				hashed_details_length = yyhost->strlen+4+1;
				hashed_details = emalloc(hashed_details_length+1);
				sprintf(hashed_details, "ldap_%s", yyhost->value.strval);
			}
			break;

		default:
			WRONG_PARAM_COUNT;
			break;
	}

	if(!php3_ldap_module.allow_persistent) {
		persistent = 0;
	}

	if (persistent) {
		list_entry *le;

		if (php3_ldap_module.max_links!=-1 && php3_ldap_module.num_links>=php3_ldap_module.max_links) {
			php3_error(E_WARNING, "LDAP: Too many open links (%d)", php3_ldap_module.num_links);
			efree(hashed_details);
			RETURN_FALSE;
		}
		if (php3_ldap_module.max_persistent!=-1 && php3_ldap_module.num_persistent>=php3_ldap_module.max_persistent) {
			php3_error(E_WARNING, "LDAP: Too many open persistent links (%d)", php3_ldap_module.num_persistent);
			efree(hashed_details);
			RETURN_FALSE;
		}	
	
		if(hash_find(plist, hashed_details, hashed_details_length+1, (void **) &le) == FAILURE) {
			list_entry new_le;

			if ((ldap = ldap_open(host, port)) == NULL) {
				php3_error(E_WARNING,"LDAP:  Unable to connect to server: %s",ldap->ld_error);
				efree(hashed_details);
				RETURN_FALSE;
			}

			new_le.type = php3_ldap_module.le_plink;
			new_le.ptr = ldap;
			if (hash_update(plist, hashed_details, hashed_details_length+1, (void *)&new_le, sizeof(list_entry), NULL) == FAILURE) {
				efree(hashed_details);
				RETURN_FALSE;
			}

			php3_ldap_module.num_persistent++;
			php3_ldap_module.num_links++;
		} else {	
			if (le->type != php3_ldap_module.le_plink) {
				efree(hashed_details);
				RETURN_FALSE;
			}

			ldap = (LDAP *) le->ptr;
		}
		return_value->value.lval = php3_list_insert(ldap, php3_ldap_module.le_plink);
		return_value->type = IS_LONG;
	} else {
		list_entry *index_ptr, new_index_ptr;

		if(hash_find(list, hashed_details, hashed_details_length+1, (void **) &index_ptr) == SUCCESS) {
			int type, link;
			void *ptr;

			if(index_ptr->type != le_index_ptr) {
				RETURN_FALSE;
			}	

			link = (int) index_ptr->ptr;
			ptr = php3_list_find(link, &type);  /* check if the link is still there */
			if (ptr && (type == php3_ldap_module.le_link || type == php3_ldap_module.le_plink)) {
				return_value->value.lval = php3_ldap_module.default_link = link;
				return_value->type = IS_LONG;
				efree(hashed_details);
				return;
			} else {
				hash_del(list, hashed_details, hashed_details_length+1);
			}
		}

		if (php3_ldap_module.max_links!=-1 && php3_ldap_module.num_links>=php3_ldap_module.max_links) {
			php3_error(E_WARNING, "LDAP: Too many open links (%d)", php3_ldap_module.num_links);
			efree(hashed_details);
			RETURN_FALSE;
		}
		if ((ldap = ldap_open(host, port)) == NULL) {
			efree(hashed_details);
			RETURN_FALSE;
		}

		return_value->value.lval = php3_list_insert((void *)ldap, php3_ldap_module.le_link);
		return_value->type = IS_LONG;

		new_index_ptr.ptr = (void *) return_value->value.lval;
		new_index_ptr.type = le_index_ptr;
		if (hash_update(list,hashed_details,hashed_details_length+1,(void *) &new_index_ptr, sizeof(list_entry), NULL) == FAILURE) {
			efree(hashed_details);
			RETURN_FALSE;
		}
		php3_ldap_module.num_links++;

	}
	efree(hashed_details);
	php3_ldap_module.default_link = return_value->value.lval;
}


static int php3_ldap_get_default_link(INTERNAL_FUNCTION_PARAMETERS)
{
	if(php3_ldap_module.default_link == -1) {
		HashTable dummy;

		hash_init(&dummy, 0, NULL, NULL, 0);
		php3_ldap_do_connect(&dummy, return_value, list, plist, 0);
		hash_destroy(&dummy);
	}

	return php3_ldap_module.default_link;
}


void php3_ldap_connect(INTERNAL_FUNCTION_PARAMETERS)
{
	php3_ldap_do_connect(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}


void php3_ldap_pconnect(INTERNAL_FUNCTION_PARAMETERS)
{
	php3_ldap_do_connect(INTERNAL_FUNCTION_PARAM_PASSTHRU, 1);
}


static LDAP * _get_ldap_link(YYSTYPE *link, HashTable *list)
{
LDAP *ldap;
int type;

	convert_to_long(link);
	ldap = (LDAP *) php3_list_find(link->value.lval, &type);

	if (!ldap && type != php3_ldap_module.le_link && type != php3_ldap_module.le_plink) {
		php3_error(E_WARNING, "%d is not a LDAP link index", link->value.lval);
		return NULL;
	}

	return ldap;
}


static LDAPMessage * _get_ldap_result(YYSTYPE *result, HashTable *list)
{
LDAPMessage *ldap_result;
int type;

	convert_to_long(result);
	ldap_result = (LDAPMessage *) php3_list_find(result->value.lval, &type);

	if(!ldap_result && type != php3_ldap_module.le_result) {
		php3_error(E_WARNING, "%d is not a LDAP result index", result->value.lval);
		return NULL;
	}

	return ldap_result;
}


static LDAPMessage * _get_ldap_result_entry(YYSTYPE *result, HashTable *list)
{
LDAPMessage *ldap_result_entry;
int type;

	convert_to_long(result);
	ldap_result_entry = (LDAPMessage *) php3_list_find(result->value.lval, &type);

	if(!ldap_result_entry && type != php3_ldap_module.le_result_entry) {
		php3_error(E_WARNING, "%d is not a LDAP result entry index", result->value.lval);
		return NULL;
	}

	return ldap_result_entry;
}


void php3_ldap_close(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *link;
int id, type;
LDAP *ldap;

	switch (ARG_COUNT(ht)) {
		case 0:
			id = php3_ldap_module.default_link;
			break;

		case 1:
			if (getParameters(ht, 1, &link) == FAILURE) {
				RETURN_FALSE;
			}
			convert_to_long(link);
			id = link->value.lval;
			break;

		default:
			WRONG_PARAM_COUNT;
			break;
	}

	ldap = (LDAP *) php3_list_find(id, &type);
	if (!ldap && type != php3_ldap_module.le_link && type != php3_ldap_module.le_plink) {
		php3_error(E_WARNING, "%d is not a LDAP link index", id);
		RETURN_FALSE;
	}

	php3_list_delete(id);
	RETURN_TRUE;
}


void php3_ldap_bind(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *link, *bind_rdn, *bind_pw;
char *ldap_bind_rdn, *ldap_bind_pw;
LDAP *ldap;

	switch(ARG_COUNT(ht)) {
		case 3 :
			if(getParameters(ht, 3, &link, &bind_rdn, &bind_pw) == FAILURE) {
				RETURN_FALSE;
			}

			convert_to_string(bind_rdn);
			convert_to_string(bind_pw);

			ldap_bind_rdn = bind_rdn->value.strval;
			ldap_bind_pw = bind_pw->value.strval;

			break;

		default:
			WRONG_PARAM_COUNT;
			break;
	}	

	ldap = _get_ldap_link(link, list);
	if(ldap == NULL) RETURN_FALSE;

	if(ldap_bind_s(ldap, ldap_bind_rdn, ldap_bind_pw, LDAP_AUTH_SIMPLE) != LDAP_SUCCESS) {
		php3_error(E_WARNING,"LDAP:  Unable to bind to server: %s",ldap_err2string(ldap->ld_errno));
		RETURN_FALSE;
	} else {
		RETURN_TRUE;
	}
}


void php3_ldap_unbind(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *link;
LDAP *ldap;

	if(ARG_COUNT(ht) != 1 || getParameters(ht, 1, &link) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap = _get_ldap_link(link, list);
	if(ldap == NULL) RETURN_FALSE;

	ldap_unbind_s(ldap);
	RETURN_TRUE;
}


void php3_ldap_search(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *link, *base_dn, *filter;
char *ldap_base_dn, *ldap_filter;
LDAP *ldap;
/* char *ldap_attrs[]; */
int scope, attrsonly;
LDAPMessage *ldap_result;

	switch(ARG_COUNT(ht)) {
		case 3 :
			if(getParameters(ht, 3, &link, &base_dn, &filter) == FAILURE) {
				RETURN_FALSE;
			}

			convert_to_string(base_dn);
			convert_to_string(filter);

			ldap_base_dn = base_dn->value.strval;
			ldap_filter = filter->value.strval;

			break;

		default:
			WRONG_PARAM_COUNT;
			break;
	}

	ldap = _get_ldap_link(link, list);
	if(ldap == NULL) RETURN_FALSE;

 	/* Searching an entry does not make sense, so we search entire subtree 
	   There are other routines to list the entires */
/*
	scope = LDAP_SCOPE_BASE;
	scope = LDAP_SCOPE_ONELEVEL;
*/
	scope = LDAP_SCOPE_SUBTREE; 
	
	/* Till I figure out how to accept the array from user, get all the 
	   attributes of the matching entry. */
/*	ldap_attrs = NULL; */

	/* Is it useful to get the attributes ? */
	attrsonly = 0;	

	/* We can possibly add the timeout value also */

	if(ldap_search_s(ldap, ldap_base_dn, scope, ldap_filter, NULL, attrsonly, &ldap_result) != LDAP_SUCCESS) {
		php3_error(E_WARNING, "LDAP: Unable to perform the search: %s", ldap_err2string(ldap->ld_errno));
		RETURN_FALSE;
	}

	RETURN_LONG(php3_list_insert(ldap_result, php3_ldap_module.le_result));
}


void php3_ldap_free_result(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *result;
LDAPMessage *ldap_result;

	if(ARG_COUNT(ht) != 1 || getParameters(ht, 1, &result) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap_result = _get_ldap_result(result, list);
	if(ldap_result == NULL) RETURN_FALSE;

	php3_list_delete(result->value.lval);
}


void php3_ldap_count_entries(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *result, *link;
LDAP *ldap;
LDAPMessage *ldap_result;

	if(ARG_COUNT(ht) != 2 || getParameters(ht, 2, &link, &result) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap = _get_ldap_link(link, list);
	if(ldap == NULL) RETURN_FALSE;

	ldap_result = _get_ldap_result(result, list);
	if(ldap_result == NULL) RETURN_FALSE;

	RETURN_LONG(ldap_count_entries(ldap, ldap_result));
}


void php3_ldap_first_entry(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *result, *link;
LDAP *ldap;
LDAPMessage *ldap_result;
LDAPMessage *ldap_result_entry;

	if(ARG_COUNT(ht) != 2 || getParameters(ht, 2, &link, &result) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap = _get_ldap_link(link, list);
	if(ldap == NULL) RETURN_FALSE;

	ldap_result = _get_ldap_result(result, list);
	if(ldap_result == NULL) RETURN_FALSE;

	if((ldap_result_entry = ldap_first_entry(ldap, ldap_result)) == NULL) {
		php3_error(E_WARNING, "LDAP: Unable to read the entries from result : %s", ldap_err2string(ldap->ld_errno));
		RETURN_FALSE;
	}

	RETURN_LONG(php3_list_insert(ldap_result_entry, php3_ldap_module.le_result_entry));
}


void php3_ldap_next_entry(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *result, *link;
LDAP *ldap;
LDAPMessage *ldap_result_entry, *ldap_result_entry_next;

	if(ARG_COUNT(ht) != 2 || getParameters(ht, 2, &link, &result) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap = _get_ldap_link(link, list);
	if(ldap == NULL) RETURN_FALSE;

	ldap_result_entry = _get_ldap_result_entry(result, list);
	if(ldap_result_entry == NULL) RETURN_FALSE;

	if((ldap_result_entry_next = ldap_next_entry(ldap, ldap_result_entry)) == NULL) {
		php3_error(E_WARNING, "LDAP: Unable to read the entries from result : %s", ldap_err2string(ldap->ld_errno));
		RETURN_FALSE;
	}

	php3_list_delete(result->value.lval);

	RETURN_LONG(php3_list_insert(ldap_result_entry_next, php3_ldap_module.le_result_entry));
}


void php3_ldap_free_entry(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *result;
LDAPMessage *ldap_result_entry;

	if(ARG_COUNT(ht) != 1 || getParameters(ht, 1, &result) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap_result_entry = _get_ldap_result_entry(result, list);
	if(ldap_result_entry == NULL) RETURN_FALSE;

	php3_list_delete(result->value.lval);
}

#if 0

void php3_ldap_first_attribute(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *result;
LDAP *ldap;
LDAPMessage *ldap_result_entry;
BerElement *ber;
char *attribute;

	if(ARG_COUNT(ht) != 2 || getParameters(ht, 2, &link, &result) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap = _get_ldap_link(link);
	if(ldap == NULL) RETURN_FALSE;

	ldap_result_entry = _get_ldap_result_entry(result);
	if(ldap_result_entry == NULL) RETURN_FALSE;

	if((attribute = ldap_first_attribute(ldap, ldap_result_entry, &ber)) == NULL) {
		php3_error(E_WARNING, "LDAP: Unable to read the attributes from entry : %s", ldap_err2string(ldap->ld_errno));
		RETURN_FALSE;
	}

	/* Have to figure out how to return data by refernce ??? */
	php3_list_insert(ber, php3_ldap_module.le_result_entry_attribute);

	RETURN_STRING(attribute);
}


void php3_ldap_next_attribute(INTERNAL_FUNCTION_PARAMETERS)
{
}

#endif

void php3_ldap_get_values(INTERNAL_FUNCTION_PARAMETERS)
{
YYSTYPE *link, *result, *attr;
LDAP *ldap;
LDAPMessage *ldap_result_entry;
char *attribute;
char **values;

	if(ARG_COUNT(ht) != 3 || getParameters(ht, 3, &link, &result, &attr) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	ldap = _get_ldap_link(link, list);
	if(ldap == NULL) RETURN_FALSE;

	ldap_result_entry = _get_ldap_result_entry(result, list);
	if(ldap_result_entry == NULL) RETURN_FALSE;

	convert_to_string(attr);
	attribute = attr->value.strval;

	if((values = ldap_get_values(ldap, ldap_result_entry, attribute)) == NULL) {
		php3_error(E_WARNING, "LDAP: Cannot get the value(s) of attribute %s", ldap_err2string(ldap->ld_errno));
		RETURN_FALSE;
	}

	/* Till I figure out how to return the array of strings to user,
	   return the first string in the array */

	RETURN_STRING(values[0]);
	ldap_value_free(values);
}


/* Problem of array specification again .. */
void php3_ldap_count_values(INTERNAL_FUNCTION_PARAMETERS)
{
	RETURN_TRUE;
}


void php3_ldap_add(INTERNAL_FUNCTION_PARAMETERS)
{
	RETURN_TRUE;
}


void php3_ldap_delete(INTERNAL_FUNCTION_PARAMETERS)
{
	RETURN_TRUE;
}


void php3_ldap_modify(INTERNAL_FUNCTION_PARAMETERS)
{
	RETURN_TRUE;
}

#endif
