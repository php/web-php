/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Shane Caraveo                                               |
   |                                                                      |
   +----------------------------------------------------------------------+
 */
#include "parser.h"
#include "modules.h"


PHP_HTTP_ENVIRONMENT php_env;

int php3_init_environ(INITFUNCARG){
#if NSAPI
	php_env.filename = NULL;
	php_env.scriptname = pblock_findval("path",nsrq->vars);
	php_env.requestmethod = pblock_findval("method",nsrq->reqpb);
	php_env.querystring = pblock_findval("query", nsrq->vars); 
	php_env.pathinfo = pblock_findval("path-info",nsrq->vars);
	php_env.pathtranslated = pblock_findval("path",nsrq->vars);
	php_env.contenttype = pblock_findval("content-type",nsrq->srvhdrs);
	php_env.contentlength = atoi(pblock_findval("content-length",nsrq->headers));
	php_env.cookies = NULL;
	php_env.authpass = NULL;
	php_env.authtype = pblock_findval("auth-type",nsrq->vars);
	php_env.gatewayinterface = NULL;
	php_env.httpaccept = pblock_findval("accept",nsrq->headers);
	php_env.remote_addr = pblock_findval("ip",nssn->client);
	php_env.remote_host = NULL;
	php_env.remote_user = pblock_findval("auth-user",nsrq->vars);
	php_env.servername = NULL;
	php_env.serverport = 0;
	php_env.serverportsecure = 0;
	php_env.serverprotocol = pblock_findval("protocol",nsrq->reqpb);
	php_env.serversoftware = NULL;
	php_env.useragent = pblock_findval("user-agent",nsrq->headers); 
	php_env.httpskeysize = pblock_findval("keysize", nssn->client); 
	php_env.httpssecretsize = pblock_findval("secret-keysize", nssn->client); 
#else
#if PHP_ISAPI
	php_env.filename = lpPHPcb->lpszPathInfo;
	php_env.scriptname = isapi_getenv(lpPHPcb,"SCRIPT_NAME");
	php_env.requestmethod = lpPHPcb->lpszMethod;
	php_env.querystring = lpPHPcb->lpszQueryString;
	php_env.pathinfo = lpPHPcb->lpszPathInfo;
	php_env.pathtranslated = lpPHPcb->lpszPathTranslated;
	php_env.contenttype = lpPHPcb->lpszContentType;
	php_env.contentlength = isapi_getenv(lpPHPcb,"CONTENT_LENGTH");
	php_env.cookies = isapi_getenv(lpPHPcb,"HTTP_COOKIE");
	php_env.authpass = isapi_getenv(lpPHPcb,"AUTH_PASS");
	php_env.authtype = isapi_getenv(lpPHPcb,"AUTH_TYPE");
	php_env.gatewayinterface = isapi_getenv(lpPHPcb,"GATEWAY_INTERFACE");
	php_env.httpaccept = isapi_getenv(lpPHPcb,"HTTP_ACCEPT");
	php_env.remote_addr = isapi_getenv(lpPHPcb,"REMOTE_ADDR");
	php_env.remote_host = isapi_getenv(lpPHPcb,"REMOTE_HOST");
	php_env.remote_user = isapi_getenv(lpPHPcb,"REMOTE_USER");
	php_env.servername = isapi_getenv(lpPHPcb,"SERVER_NAME");
	php_env.serverport = isapi_getenv(lpPHPcb,"SERVER_PORT");
	php_env.serverportsecure = isapi_getenv(lpPHPcb,"SERVER_PORT_SECURE");
	php_env.serverprotocol = isapi_getenv(lpPHPcb,"SERVER_PROTOCOL");
	php_env.serversoftware = isapi_getenv(lpPHPcb,"SERVER_SOFTWARE");
	php_env.useragent = NULL;
	php_env.httpskeysize = NULL;
	php_env.httpssecretsize = NULL;
#else
	php_env.filename = NULL;
	php_env.pathinfo = getenv("PATH_INFO");
	php_env.pathtranslated = getenv("PATH_TRANSLATED");
	php_env.contenttype = getenv("CONTENT_TYPE");
	php_env.contentlength = getenv("CONTENT_LENGTH");
	php_env.querystring = getenv("QUERY_STRING");
	php_env.cookies = getenv("HTTP_COOKIE");
	php_env.scriptname = getenv("SCRIPT_NAME");
	php_env.requestmethod = getenv("REQUEST_METHOD");
	php_env.authpass = getenv("AUTH_PASS");
	php_env.authtype = getenv("AUTH_TYPE");
	php_env.gatewayinterface = getenv("GATEWAY_INTERFACE");
	php_env.httpaccept = getenv("HTTP_ACCEPT");
	php_env.remote_addr = getenv("REMOTE_ADDR");
	php_env.remote_host = getenv("REMOTE_HOST");
	php_env.remote_user = getenv("REMOTE_USER");
	php_env.servername = getenv("SERVER_NAME");
	php_env.serverport = getenv("SERVER_PORT");
	php_env.serverportsecure = getenv("SERVER_PORT_SECURE");
	php_env.serverprotocol = getenv("SERVER_PROTOCOL");
	php_env.serversoftware = getenv("SERVER_SOFTWARE");
	php_env.useragent = getenv("USER_AGENT");
	php_env.httpskeysize = getenv("HTTPS_KEYSIZE");
	php_env.httpssecretsize = getenv("HTTPS_SECRETSIZE");
	php_env.email = getenv("EMAIL_ADDR");
	php_env.referrer = getenv("HTTP_REFERRER");
#endif
#endif
	return SUCCESS;
}


int php3_shutdown_environ(void)
{
	return SUCCESS;
}
