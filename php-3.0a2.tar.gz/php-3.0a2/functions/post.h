/* $Id: post.h,v 1.9 1997/10/30 14:05:24 jaakko Exp $ */

#ifndef _POST_H
#define _POST_H

#define PARSE_POST 0
#define PARSE_GET 1
#define PARSE_COOKIE 2
#define PARSE_STRING 3

/* extern int php3_CheckResult(char *res); XXX Not used anywhere */
extern void php3_TreatData(int arg, char *str);
extern void php3_TreatHeaders(void);
extern void php3_parse_url(char *data);
extern void _php3_parse_gpc_data(char *, char *, YYSTYPE *track_vars_array);

extern int php3_track_vars;

extern void php3_parsestr(INTERNAL_FUNCTION_PARAMETERS);

#endif
