#ifndef _SAFE_MODE_H_
#define _SAFE_MODE_H_

/* #if PHP_SAFE_MODE */
extern int _php3_checkuid(const char *filename, int mode);
/* #endif */

#endif
