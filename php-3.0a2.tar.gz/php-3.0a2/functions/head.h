#ifndef _HEAD_H
#define _HEAD_H

extern void php3_Header(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_SetCookie(INTERNAL_FUNCTION_PARAMETERS);

extern void php3_noheader(void);
extern int php3_header(int type, char *str);
extern void php3_noheader(void);

#endif
