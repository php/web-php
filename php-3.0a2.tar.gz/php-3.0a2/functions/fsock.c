/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Paul Panotzki - Bunyip Information Systems                  |
   +----------------------------------------------------------------------+
*/
/* $Id: fsock.c,v 1.13 1997/11/03 12:56:59 ssb Exp $ */
#include "parser.h"
#include "list.h"
#include "internal_functions.h"
#include <stdlib.h>
#if HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <sys/types.h>
#if HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif
#if MSVC5
#include <winsock.h>
#else
#include <netinet/in.h>
#include <netdb.h>
#endif
#if MSVC5
#undef AF_UNIX
#endif
#if defined(AF_UNIX)
#include <sys/un.h>
#endif

#include <string.h>
#include <errno.h>

#include "file.h"

/* FIXME: do something about the non-standard return codes from this function */
void php3_fsockopen(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	FILE *fp;
	int id, socketd;
#if MSVC5
	unsigned short portno;
	struct hostent FAR *hostp;
	struct hostent FAR * FAR PASCAL gethostbyname();
#else
	int portno;
	struct hostent *hostp;
#endif
	if (ARG_COUNT(ht)!=2 || getParameters(ht,2,&arg1,&arg2)==FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);
	convert_to_long(arg2);
#if MSVC5
	/* This is questionable to me */
	portno = (unsigned short) arg2->value.lval;
#else
	portno = arg2->value.lval;
#endif
	if(portno) {
		struct sockaddr_in server;
		socketd = socket(AF_INET, SOCK_STREAM, 0);
		if(socketd < 0) {
			RETURN_LONG(-3); /* FIXME */
		}
  
		server.sin_family = AF_INET;
		hostp = gethostbyname(arg1->value.strval);
		if(hostp == 0) {
			RETURN_LONG(-4); /* FIXME */
		}
  
		memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
		server.sin_port = htons(portno);
  
		if(connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
			RETURN_LONG(-5); /* FIXME */
		}
#if defined(AF_UNIX)
	} else {
		/* Unix domain socket.  s->strval is socket name. */
		struct  sockaddr_un unix_addr;
		socketd = socket(AF_UNIX,SOCK_STREAM,0);
		if (socketd < 0) {
			RETURN_LONG(-3);  /* FIXME */
		}
	  
		memset(&unix_addr,(char)0,sizeof(unix_addr));
		unix_addr.sun_family = AF_UNIX;
		strcpy(unix_addr.sun_path, arg1->value.strval);

		if (connect(socketd, (struct sockaddr *) &unix_addr, sizeof(unix_addr)) < 0) {
			RETURN_LONG(-5);  /* FIXME */
		}
#endif /* AF_UNIX */
	}
	
	if ((fp = fdopen (socketd, "r+")) == NULL){
		RETURN_LONG(-6);  /* FIXME */
	}

#ifdef HAVE_SETVBUF  
	if ((setvbuf(fp, NULL, _IONBF, 0)) != 0){
		RETURN_LONG(-7);  /* FIXME */
	}
#endif
 
	id = php3_list_insert(fp,LE_FP);
	RETURN_LONG(id);
}

/****************************************************************************  
 * This is a wrapper for fopen.                                             * 
 * If path starts with http:// or HTTP://                                   *
 * a socket is openened to a httpd and the file pointer is positioned       *
 * at the start of the body.  The http return header is read and thrown     *
 * away.  The file pointer for the http case is opened as "r+" without      *
 * reguard to mode. Does a http 1.0 request.                                *
 * Else if path starts with ftp:// or FTP://                                *
 * a pair of sockets are used to request and a file pointer pointing to     *
 * the requested file is returned.                                          *
 * username and passwd must be passwd in the ftp url.                       *
 * ex ftp://user:pass@hostname/path/to/file                                 *
 * Passive mode ftp is used.                                                *
 * Else fopen is called and the file pointer is returned                    *
 * as normal. The socket code was taken from php3_fsockopen. Returns a NULL *
 * file pointer if any problems occure.                                     *
 ****************************************************************************/
FILE *php3_fopen_url_wrapper(char *path, char *mode) 
{
	char tmp_line[256];
	char tmp_send[256];
	char *hname = NULL;
	char *user = NULL;
	char *pass = NULL;
	char *fpath = NULL;
	char *ppath = NULL;
	char *tpath = NULL;
	int body = 0;
	int reqok = 0;
	int lineone = 1;
	int i, ch = 0;
	char oldch1 = 0;
	char oldch2 = 0;
	char oldch3 = 0;
	char oldch4 = 0;
	char oldch5 = 0;
	
	FILE *fp;
	FILE *fpc;
	int socketd;
#if MSVC5
	unsigned short portno;
	struct hostent FAR *hostp;
	struct hostent FAR *FAR PASCAL gethostbyname();
#else
	int portno;
	struct hostent *hostp;
#endif

	if (!strncasecmp(path,"http://",7)) {
		fpath = path;
		fpath += 7;
		portno = 80;
		for (ppath = fpath; (*ppath != '/') && (*ppath != ':') && (*ppath != '\0'); ppath++);
		if (*ppath == ':') {
			ppath++;
			portno = atoi(ppath); /* FIXME use strtol instead of atoi */
		}
		hname = estrdup(fpath);
		for (tpath = hname; (*tpath != '/') && (*tpath != ':') && (*ppath != '\0'); tpath++);
		*tpath = '\0';
		for (; *fpath != '/' && (*fpath != '\0'); fpath++);
		if (*fpath=='\0') {
			return (NULL);
		}

		if (portno) {
			struct sockaddr_in server;
			socketd = socket(AF_INET, SOCK_STREAM, 0);
			if (socketd < 0) {
				return(NULL);
			}

			server.sin_family = AF_INET;
			hostp = gethostbyname(hname);
			if (hostp == 0) {
				return(NULL);
			}

			memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
			server.sin_port = htons(portno);
  
			if (connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0)
			{
				return(NULL);
			}
		} else {
			return(NULL);
		}

		if ((fp = fdopen (socketd, "r+")) == NULL) {
			return(NULL);
		}

#ifdef HAVE_SETVBUF  
		if ((setvbuf(fp, NULL, _IONBF, 0)) != 0) {
			return(NULL);
		}
#endif

		/* Tell remote http which file to get */
		fputs("GET ", fp);
		fputs(fpath, fp);
		fputs(" HTTP/1.0\n\n", fp);

		/* Read past http header */
		body = 0;
		while (!body && !feof(fp)) {
			ch = fgetc(fp);
			if (ch == EOF) {
				fclose(fp);
				return(NULL);
			}
			oldch5 = oldch4;
			oldch4 = oldch3;
			oldch3 = oldch2;
			oldch2 = oldch1;
			oldch1 = ch;

			if (lineone && (ch == 10 || ch == 13)) {
				lineone=0;
			}
			if (lineone && oldch5 == ' ' && oldch4 == '2' && oldch3 == '0' &&
				oldch2 == '0' && oldch1 == ' ' ) {
				reqok=1;
			}
			if (oldch4 == 13 && oldch3 == 10 && oldch2 == 13 && oldch1 == 10) {
				body=1;
			}
			if (oldch2 == 10 && oldch1 == 10) {
				body=1;
			}
			if (oldch2 == 13 && oldch1 == 13) {
				body=1;
			}
		}
		if (!reqok) {
			fclose(fp);
			return(NULL);
		}		
		return(fp);
	}
	else if (!strncasecmp(path,"ftp://",6)) {
		fpath = path;
		fpath += 6;
		user = estrdup(fpath);
		for (tpath = user; (*tpath != '@') && (*tpath != ':') && (*tpath != '\0'); tpath++);
		*tpath = '\0';
		pass = estrdup(fpath);
		for (; (*pass != '@') && (*pass != ':') && (*pass != '\0'); pass++);
        if (*pass != ':') {
			return(NULL);
		}
		pass++;
		for (tpath = pass; (*tpath != '@') && (*tpath != '\0'); tpath++);
		*tpath = '\0';
		portno = 21;
        for (ppath = fpath; (*ppath != '@') && (*ppath != '\0'); ppath++);
        if (*ppath == '\0') {
			return(NULL);
		}
        ppath++;
		hname = estrdup(ppath);
		for (; (*ppath != '/') && (*ppath != ':') && (*ppath != '\0'); ppath++);
		if (*ppath == ':') {
			ppath++;
			portno = atoi(ppath); /* FIXME use strtol instead of atoi */
		}
		for (tpath = hname; (*tpath != '/') && (*tpath != ':') && (*tpath != '\0'); tpath++);
		*tpath = '\0';
		for (; *fpath != '/' && (*fpath != '\0'); fpath++);
		if (*fpath == '\0') {
			return(NULL);
		}
		if (strlen(fpath) < 2) {
			return(NULL);
		}

		if (portno) {
			struct sockaddr_in server;
			socketd = socket(AF_INET, SOCK_STREAM, 0);
			if(socketd < 0) {
				return(NULL);
			}

			server.sin_family = AF_INET;
			hostp = gethostbyname(hname);
			if (hostp == 0) {
				return(NULL);
			}

			memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
			server.sin_port = htons(portno);
  
			if (connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
				return(NULL);
			}
		} else {
			return(NULL);
		}

		if ((fpc = fdopen (socketd, "r+")) == NULL) {
			return(NULL);
		}

#ifdef HAVE_SETVBUF  
		if ((setvbuf(fpc, NULL, _IONBF, 0)) != 0) {
			return(NULL);
		}
#endif

		/* Start talking to ftp server */
		while (fgets(tmp_line, 256, fpc) != NULL && 
			   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
				 isdigit(tmp_line[2]) && tmp_line[3] == ' '));
		if (tmp_line[0] != '2' ) {
			return(NULL);
		}
		sprintf(tmp_send, "USER %s\n", user);
		fputs(tmp_send, fpc);
		while (fgets(tmp_line, 256, fpc) != NULL && 
			   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
				 isdigit(tmp_line[2]) && tmp_line[3] == ' '));
		if (!(tmp_line[0] == '2' || tmp_line[0] == '3')) {
			return(NULL);
		}
		if (tmp_line[0] == '3') {
			sprintf(tmp_send, "PASS %s\n", pass);
			fputs(tmp_send, fpc);
			while (fgets(tmp_line, 256, fpc) != NULL && 
				   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
					 isdigit(tmp_line[2]) && tmp_line[3] == ' '));
			if (tmp_line[0] != '2') {
				return(NULL);
			}
		}
		sprintf(tmp_send, "SIZE %s\n", fpath);
		fputs(tmp_send, fpc);
		while (fgets(tmp_line, 256, fpc) != NULL && 
			   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
				 isdigit(tmp_line[2]) && tmp_line[3] == ' '));
		if (tmp_line[0] != '2' ) {
			return(NULL);
		}
		fputs("TYPE I\n", fpc);
		while (fgets(tmp_line, 256, fpc) != NULL && 
			   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
				 isdigit(tmp_line[2]) && tmp_line[3] == ' '));
		if (tmp_line[0] != '2') {
			return(NULL);
		}
		fputs("PASV\n", fpc);
		while (fgets(tmp_line, 256, fpc) != NULL && 
			   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
				 isdigit(tmp_line[2]) && tmp_line[3] == ' '));
		if (tmp_line[0] != '2' ) {
			return(NULL);
		}

		/* parse pasv command (129,80,95,25,13,221) */
		tpath = tmp_line;
		for (tpath += 4; *tpath && !isdigit(*tpath); tpath++);
		if (!*tpath) {
			return(NULL);
		}
		for (i = 0; i < 4; i++) {
			for (; isdigit(*tpath); tpath++);
			if (*tpath == ',') {
				tpath++;
			} else {
				return(NULL);
			}
		}
		portno = atoi(tpath) * 256; /* FIXME use strtol instead of atoi */
		for (; isdigit(*tpath); tpath++);
		if (*tpath == ',') {
			tpath++;
		} else {
			return(NULL);
		}
		portno += atoi(tpath); /* FIXME use strtol instead of atoi */
		sprintf(tmp_send, "RETR %s\nQUIT\n", fpath);
		fputs(tmp_send, fpc);

		/* open data channel */
		if (portno) {
			struct sockaddr_in server;
			socketd = socket(AF_INET, SOCK_STREAM, 0);
			if (socketd < 0) {
				return(NULL);
			}

			server.sin_family = AF_INET;
			hostp = gethostbyname(hname);
			if (hostp == 0) {
				return(NULL);
			}

			memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
			server.sin_port = htons(portno);
  
			if(connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
				return(NULL);
			}
		} else {
			return(NULL);
		}
		if ((fp = fdopen (socketd, "r+")) == NULL) {
			return(NULL);
		}

#ifdef HAVE_SETVBUF  
		if ((setvbuf(fpc, NULL, _IONBF, 0)) != 0) {
			return(NULL);
		}
#endif

		fclose(fpc);
		return(fp);

	} else {
		/* FIXME
		 * If secure mode is in effect we should check that the filename
		 * is within the document root here.
		 */
		/*
		if ( *path == '\\' || *path == '/' ) {
			return(NULL);
		}
		*/
		if (php3_ini.includepath) {
			fp = php3_fopen_with_path(path, mode, php3_ini.includepath);
		} else {
			fp = fopen(path, mode);
		}
		return(fp); 
	}
	/* Should never get here. */
	return(NULL);
}

int php3_isurl(char *path) 
{
	return(!strncasecmp(path,"http://",7) || !strncasecmp(path,"ftp://",6));
}

char *php3_strip_url_passwd(char *path) 
{
	char *tmppath=NULL;
	if(!strncasecmp(path,"ftp://",6)) {
		tmppath=path; 
		tmppath+=6;
		for(;*tmppath!=':' && *tmppath!='\0' ; tmppath++ );
		tmppath++ ;
		for(;*tmppath!='@' && *tmppath!='\0' ; tmppath++ ) 
			*tmppath='*';
	}
	return(path);
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
