/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors:                                                             |
   +----------------------------------------------------------------------+
 */

/* $Id: dir.c,v 1.23 1997/10/30 14:33:08 jaakko Exp $ */

#include "parser.h"
#include "internal_functions.h"
#include "list.h"

#include "phpdir.h"

#if HAVE_DIRENT_H
#include <dirent.h>
#endif

#if HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <errno.h>

#if MSVC5
#if !(APACHE)
#define NEEDRDH 1
#endif
#include "win32/readdir.h"
#endif

static int dirp_id = 0;


void php3_opendir(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg;
	DIR *dirp;
	int ret;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg);

	dirp = opendir(arg->value.strval);
	if (!dirp) {
		my_phperror(ERRTYPE_WARNING, "OpenDir: %s (errno %d)", strerror(errno),errno);
		RETURN_FALSE;
	}
	ret = php3_list_insert(dirp, LE_DIRP);
	dirp_id = ret;
	RETURN_LONG(ret);
}

void php3_closedir(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *id, *tmp;
	int id_to_find;
	DIR *dirp;
	int dirp_type;

	if (ARG_COUNT(ht) == 0) {
		if (getThis(&id) == SUCCESS) {
			if (hash_find(id->value.ht, "handle", strlen("handle"), (void **)&tmp) == FAILURE) {
				my_phperror(ERRTYPE_WARNING, "unable to find my handle property");
				RETURN_FALSE;
			}
			id_to_find = tmp->value.lval;
		} else {
			id_to_find = dirp_id;
		}
	} else if ((ARG_COUNT(ht) != 1) || getParameters(ht, 1, &id) == FAILURE) {
		WRONG_PARAM_COUNT;
	} else {
		convert_to_long(id);
		id_to_find = id->value.lval;
	}
		
	dirp = (DIR *)php3_list_find(id_to_find, &dirp_type);
	if (!dirp || dirp_type != LE_DIRP) {
		my_phperror(ERRTYPE_WARNING, "unable to find identifier (%d)", id_to_find);
		RETURN_FALSE;
	}
	php3_list_delete(id_to_find);
}

void php3_chdir(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg;
	int ret;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg);
	ret = chdir(arg->value.strval);

	if (ret < 0) {
		my_phperror(ERRTYPE_WARNING, "ChDir: %s (errno %d)", strerror(errno), errno);
		RETURN_FALSE;
	}
	RETURN_TRUE;
}

void php3_rewinddir(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *id, *tmp;
	int id_to_find;
	DIR *dirp;
	int dirp_type;

	if (ARG_COUNT(ht) == 0) {
		if (getThis(&id) == SUCCESS) {
			if (hash_find(id->value.ht, "handle", strlen("handle"), (void **)&tmp) == FAILURE) {
				my_phperror(ERRTYPE_WARNING, "unable to find my handle property");
				RETURN_FALSE;
			}
			id_to_find = tmp->value.lval;
		} else {
			id_to_find = dirp_id;
		}
	} else if ((ARG_COUNT(ht) != 1) || getParameters(ht, 1, &id) == FAILURE) {
		WRONG_PARAM_COUNT;
	} else {
		convert_to_long(id);
		id_to_find = id->value.lval;
	}
		
	dirp = (DIR *)php3_list_find(id_to_find, &dirp_type);
	if (!dirp || dirp_type != LE_DIRP) {
		my_phperror(ERRTYPE_WARNING, "unable to find identifier (%d)", id_to_find);
		RETURN_FALSE;
	}
	rewinddir(dirp);
}

void php3_readdir(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *id, *tmp;
	int id_to_find;
	DIR *dirp;
	int dirp_type;
	struct dirent *direntp;

	if (ARG_COUNT(ht) == 0) {
		if (getThis(&id) == SUCCESS) {
			if (hash_find(id->value.ht, "handle", strlen("handle"), (void **)&tmp) == FAILURE) {
				my_phperror(ERRTYPE_WARNING, "unable to find my handle property");
				RETURN_FALSE;
			}
			id_to_find = tmp->value.lval;
		} else {
			id_to_find = dirp_id;
		}
	} else if ((ARG_COUNT(ht) != 1) || getParameters(ht, 1, &id) == FAILURE) {
		WRONG_PARAM_COUNT;
	} else {
		convert_to_long(id);
		id_to_find = id->value.lval;
	}
		
	dirp = (DIR *)php3_list_find(id_to_find, &dirp_type);
	if (!dirp || dirp_type != LE_DIRP) {
		my_phperror(ERRTYPE_WARNING, "unable to find identifier (%d)", id_to_find);
		RETURN_FALSE;
	}
	direntp = readdir(dirp);
	if (direntp) {
		RETURN_STRINGL(direntp->d_name, strlen(direntp->d_name));
	}
	RETURN_FALSE;
}

void php3_getdir(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg;
	DIR *dirp;
	int ret;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg);

	dirp = opendir(arg->value.strval);
	if (!dirp) {
		my_phperror(ERRTYPE_WARNING, "OpenDir: %s (errno %d)", strerror(errno), errno);
		RETURN_FALSE;
	}
	ret = php3_list_insert(dirp, LE_DIRP);
	dirp_id = ret;

	/* construct an object with some methods */
	object_init(&return_value);
	add_property_long("handle", ret);
	add_property_stringl("path", arg->value.strval, arg->strlen);
	add_method("read", php3_readdir);
	add_method("rewind", php3_rewinddir);
	add_method("close", php3_closedir);
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
