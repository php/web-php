/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                  |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Chad Robinson <chadr@brttech.com>                           |
   +----------------------------------------------------------------------+

  filePro 4.x support developed by Chad Robinson, chadr@brttech.com
  Contact Chad Robinson at BRT Technical Services Corp. for details.
  filePro is a registered trademark by Fiserv, Inc.  This file contains
  no code or information that is not freely available from the filePro
  web site at http://www.fileproplus.com/

 */

#include "parser.h"
#include "internal_functions.h"
#include <string.h>
#if MSVC5
#include <windows.h>
#define MAXPATHLEN MAX_PATH
#else
#include <sys/param.h>
#endif

#if HAVE_FILEPRO

typedef struct fp_field {
	char *name;
	char *format;
	int width;
	struct fp_field *next;
} FP_FIELD;

static char *fp_database = NULL;			/* Database directory */
static signed int fp_fcount = -1;			/* Column count */
static signed int fp_keysize = -1;			/* Size of key records */
static FP_FIELD *fp_fieldlist = NULL;		/* List of fields */

/*
 * LONG filePro(STRING directory)
 * 
 * Read and verify the map file.  We store the field count and field info
 * internally, which means we become unstable if you modify the table while
 * a user is using it!  We cannot lock anything since Web connections don't
 * provide the ability to later unlock what we locked.  Be smart, be safe.
 */
void php3_filepro(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *dir;
	FILE *fp;
	char workbuf[256]; /* FIX - should really be the max filename length */
	char readbuf[256];
	int i;
	FP_FIELD *new_field, *tmp;
	
	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &dir) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_string(dir);

	/* FIX - we should really check and free these if they are used! */
	fp_database = NULL;
    fp_fieldlist = NULL;
	fp_fcount = -1;
    fp_keysize = -1;
	
	sprintf(workbuf, "%s/map", dir->value.strval);
	if (!(fp = fopen(workbuf, "r"))) {
		my_phperror(ERRTYPE_WARNING, "filePro: cannot open map: [%d] %s",
					errno, strerror(errno));
		RETURN_FALSE;
	}
	if (!fgets(readbuf, 250, fp)) {
		fclose(fp);
		my_phperror(ERRTYPE_WARNING, "filePro: cannot read map: [%d] %s",
					errno, strerror(errno));
		RETURN_FALSE;
	}
	
	/* Get the field count, assume the file is readable! */
	if (strcmp(strtok(readbuf, ":"), "map")) {
		my_phperror(ERRTYPE_WARNING, "filePro: map file corrupt or encrypted");
		RETURN_FALSE;
	}
	fp_keysize = atoi(strtok(NULL, ":"));
	strtok(NULL, ":");
	fp_fcount = atoi(strtok(NULL, ":"));
    
    /* Read in the fields themselves */
	for (i = 0; i < fp_fcount; i++) {
		if (!fgets(readbuf, 250, fp)) {
			fclose(fp);
			my_phperror(ERRTYPE_WARNING, "filePro: cannot read map: [%d] %s",
						errno, strerror(errno));
			RETURN_FALSE;
		}
		new_field = emalloc(sizeof(FP_FIELD));
		new_field->next = NULL;
		new_field->name = estrdup(strtok(readbuf, ":"));
		new_field->width = atoi(strtok(NULL, ":"));
		new_field->format = estrdup(strtok(NULL, ":"));
        
		/* Store in forward-order to save time later */
		if (!fp_fieldlist) {
			fp_fieldlist = new_field;
		} else {
			for (tmp = fp_fieldlist; tmp; tmp = tmp->next) {
				if (!tmp->next) {
					tmp->next = new_field;
					tmp = new_field;
				}
			}
		}
	}
	fclose(fp);
		
	fp_database = estrndup(dir->value.strval,dir->strlen);

	RETVAL_TRUE;
}


/*
 * LONG filePro_rowcount(void)
 * 
 * Count the used rows in the database.  filePro just marks deleted records
 * as deleted; they are not removed.  Since no counts are maintained we need
 * to go in and count records ourselves.  <sigh>
 * 
 * Errors return false, success returns the row count.
 */
void php3_filepro_rowcount(INTERNAL_FUNCTION_PARAMETERS)
{
	FILE *fp;
	char workbuf[MAXPATHLEN];
	char readbuf[256];
	int recsize = 0, records = 0;
	
	if (ARG_COUNT(ht) != 0) {
		WRONG_PARAM_COUNT;
	}

	if (!fp_database) {
		my_phperror(ERRTYPE_WARNING,
					"filePro: must set database directory first!\n");
		RETURN_FALSE;
	}
	
	recsize = fp_keysize + 19; /* 20 bytes system info -1 to save time later */
	
	/* Now read the records in, moving forward recsize-1 bytes each time */
	sprintf(workbuf, "%s/key", fp_database);
	if (!(fp = fopen(workbuf, "r"))) {
		my_phperror(ERRTYPE_WARNING, "filePro: cannot open key: [%d] %s",
					errno, strerror(errno));
		RETURN_FALSE;
	}
	while (!feof(fp)) {
		if (fread(readbuf, 1, 1, fp) == 1) {
			if (readbuf[0])
				records++;
			fseek(fp, recsize, SEEK_CUR);
		}
	}
    fclose(fp);
	
	RETVAL_LONG(records);
}


/*
 * STRING filePro_fieldname(LONG field_number)
 * 
 * Errors return false, success returns the name of the field.
 */
void php3_filepro_fieldname(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *fno;
	FP_FIELD *lp;
	int i;
	
	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &fno) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(fno);

	if (!fp_database) {
		my_phperror(ERRTYPE_WARNING,
					"filePro: must set database directory first!\n");
		RETURN_FALSE;
	}
	
	for (i = 0, lp = fp_fieldlist; lp; lp = lp->next, i++) {
		if (i == fno->value.lval) {
			RETURN_STRING(lp->name);
		}
	}

	my_phperror(ERRTYPE_WARNING,
				"filePro: unable to locate field number %d.\n",
				fno->value.lval);

	RETVAL_FALSE;
}


/*
 * STRING filePro_fieldtype(LONG field_number)
 * 
 * Errors return false, success returns the type (edit) of the field
 */
void php3_filepro_fieldtype(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *fno;
	FP_FIELD *lp;
	int i;
	
	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &fno) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(fno);

	if (!fp_database) {
		my_phperror(ERRTYPE_WARNING,
					"filePro: must set database directory first!\n");
		RETURN_FALSE;
	}
	
	for (i = 0, lp = fp_fieldlist; lp; lp = lp->next, i++) {
		if (i == fno->value.lval) {
			RETURN_STRING(lp->format);
		}
	}
	my_phperror(ERRTYPE_WARNING,
				"filePro: unable to locate field number %d.\n",
				fno->value.lval);
	RETVAL_FALSE;
}


/*
 * STRING filePro_fieldwidth(int field_number)
 * 
 * Errors return false, success returns the character width of the field.
 */
void php3_filepro_fieldwidth(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *fno;
	FP_FIELD *lp;
	int i;
	
	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &fno) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(fno);

	if (!fp_database) {
		my_phperror(ERRTYPE_WARNING,
					"filePro: must set database directory first!\n");
		RETURN_FALSE;
	}
	
	for (i = 0, lp = fp_fieldlist; lp; lp = lp->next, i++) {
		if (i == fno->value.lval) {
			RETURN_LONG(lp->width);
		}
	}
	my_phperror(ERRTYPE_WARNING,
				"filePro: unable to locate field number %d.\n",
				fno->value.lval);
	RETVAL_FALSE;
}


/*
 * LONG filePro_fieldcount(void)
 * 
 * Errors return false, success returns the field count.
 */
void php3_filepro_fieldcount(INTERNAL_FUNCTION_PARAMETERS)
{
	if (ARG_COUNT(ht) != 0) {
		WRONG_PARAM_COUNT;
	}

	if (!fp_database) {
		my_phperror(ERRTYPE_WARNING,
					"filePro: must set database directory first!\n");
		RETURN_FALSE;
	}
	
	/* Read in the first line from the map file */
	RETVAL_LONG(fp_fcount);
}


/*
 * STRING filePro_retrieve(int row_number, int field_number)
 * 
 * Errors return false, success returns the datum.
 */
void php3_filepro_retrieve(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *rno, *fno;
    FP_FIELD *lp;
    FILE *fp;
    char workbuf[MAXPATHLEN];
	char readbuf[1024]; /* FIX - Work out better buffering! */
    int i, fnum, rnum;
    long offset;
	
	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &rno, &fno) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	if (!fp_database) {
		my_phperror(ERRTYPE_WARNING,
					"filePro: must set database directory first!\n");
		RETURN_FALSE;
	}
	
	convert_to_long(rno);
	convert_to_long(fno);

	fnum = fno->value.lval;
	rnum = rno->value.lval;
    
    if (rnum < 0 || fnum < 0 || fnum >= fp_fcount) {
        my_phperror(ERRTYPE_WARNING, "filepro: parameters out of range");
		RETURN_FALSE;
    }
    
    offset = (rnum + 1) * (fp_keysize + 20) + 20; /* Record location */
    for (i = 0, lp = fp_fieldlist; lp && i < fnum; lp = lp->next, i++) {
        offset += lp->width;
    }
    if (!lp) {
        my_phperror(ERRTYPE_WARNING, "filePro: cannot locate field");
		RETURN_FALSE;
    }
    
	/* Now read the record in */
	sprintf(workbuf, "%s/key", fp_database);
	if (!(fp = fopen(workbuf, "r"))) {
		my_phperror(ERRTYPE_WARNING, "filePro: cannot open key: [%d] %s",
					errno, strerror(errno));
	    fclose(fp);
		RETURN_FALSE;
	}
    fseek(fp, offset, SEEK_SET);
	if (fread(readbuf, lp->width, 1, fp) != 1) {
        my_phperror(ERRTYPE_WARNING, "filePro: cannot read data: [%d] %s",
					errno, strerror(errno));
	    fclose(fp);
		RETURN_FALSE;
    }
    readbuf[lp->width] = '\0';
    fclose(fp);
	RETURN_STRING(readbuf);
}

#else

void php3_filepro(INTERNAL_FUNCTION_PARAMETERS) { }
void php3_filepro_rowcount(INTERNAL_FUNCTION_PARAMETERS) { }
void php3_filepro_fieldname(INTERNAL_FUNCTION_PARAMETERS) { }
void php3_filepro_fieldtype(INTERNAL_FUNCTION_PARAMETERS) { }
void php3_filepro_fieldwidth(INTERNAL_FUNCTION_PARAMETERS) { }
void php3_filepro_fieldcount(INTERNAL_FUNCTION_PARAMETERS) { }
void php3_filepro_retrieve(INTERNAL_FUNCTION_PARAMETERS) { }

#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
