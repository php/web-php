/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   +----------------------------------------------------------------------+
 */


/* $Id: basic_functions.c,v 1.59 1997/10/30 14:33:08 jaakko Exp $ */


#include "parser.h"
#include "modules.h"
#include "internal_functions.h"
#include "basic_functions.h"
#include "operators.h"
#include <math.h>
#include <time.h>
#include <stdio.h>
#if HAVE_STRING_H
#include <string.h>
#else
#include <strings.h>
#endif

/********************
 * System Functions *
 ********************/

void php3_getenv(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;
	char *ptr;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	if (str->type == IS_STRING &&
#if APACHE
		((ptr = table_get(php3_rqst->subprocess_env, str->value.strval)) || (ptr = getenv(str->value.strval)))
#endif
#if PHP_ISAPI
		(ptr = isapi_getenv(lpPHPcb,str->value.strval))
#endif
#if CGI_BINARY|NSAPI
		(ptr = getenv(str->value.strval))
#endif
		) {
		RETURN_STRING(ptr);
	}
	RETURN_FALSE;
}


void php3_putenv(INTERNAL_FUNCTION_PARAMETERS)
{
#if HAVE_PUTENV
	YYSTYPE *str;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);

	if (str->value.strval && *(str->value.strval)) {
		int ret;
		ret = putenv(estrndup(str->value.strval,str->strlen));
		if (!ret) {
			RETURN_TRUE;
		}
		my_phperror(ERRTYPE_WARNING, "putenv failed");
	}
	RETVAL_FALSE;
#endif
}


void php3_error_reporting(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg;
	
	if (ARG_COUNT(ht) != 1 || getParameters(ht,1,&arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	
	convert_to_long(arg);
	
	switch(arg->value.lval) {
		case 0:
			error_reporting=tmp_error_reporting=0;
			break;
		case 1:
			error_reporting=tmp_error_reporting=ERRTYPE_ALL;
			break;
		case 2:
			error_reporting=tmp_error_reporting=ERRTYPE_ERROR | ERRTYPE_PARSE;
			break;
		case 3:
			error_reporting=tmp_error_reporting=ERRTYPE_ERROR;
			break;
		case 4:
			error_reporting=tmp_error_reporting=ERRTYPE_PARSE;
			break;
		default:
			error_reporting=tmp_error_reporting=ERRTYPE_ALL;
			break;
	}
}

void php3_toggle_short_open_tag(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *value;
	int ret = php3_ini.short_open_tag;

	if (ARG_COUNT(ht)!=1 || getParameters(ht,1,&value) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(value);
	php3_ini.short_open_tag = value->value.lval;
	RETURN_LONG(ret);
}

/*******************
 * Basic Functions *
 *******************/

void int_value(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *num;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &num) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(num);
	return_value = *num;
}


void double_value(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *num;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &num) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_double(num);
	return_value = *num;
}


void string_value(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *num;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &num) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(num);
	return_value = *num;
	yystype_copy_constructor(&return_value);
}

static int array_key_compare(const void *a, const void *b)
{
	Bucket *first;
	Bucket *second;
	int min, r;

	first = *((Bucket **) a);
	second = *((Bucket **) b);

	if (first->arKey == NULL && second->arKey == NULL) {
		return (first->h - second->h);
	} else if (first->arKey == NULL) {
		return -1;
	} else if (second->arKey == NULL) {
		return 1;
	}
	min = MIN(first->nKeyLength, second->nKeyLength);
	if ((r = memcmp(first->arKey, second->arKey, min)) == 0) {
		return (first->nKeyLength - second->nKeyLength);
	} else {
		return r;
	}
}


void php3_key_sort(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Wrong datatype in ksort() call");
		return;
	}
	if (!ParameterPassedByReference(ht,1)) {
		my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to ksort()");
		return;
	}
	if (hash_sort(array->value.ht, array_key_compare,0) == FAILURE) {
		return;
	}
	RETURN_TRUE;
}

/* Numbers are always smaller than strings int this function as it
 * anyway doesn't make much sense to compare two different data types.
 * This keeps it consistant and simple.
 */
static int array_data_compare(const void *a, const void *b)
{
	Bucket *f;
	Bucket *s;
	YYSTYPE *first;
	YYSTYPE *second;
	double dfirst, dsecond;

	f = *((Bucket **) a);
	s = *((Bucket **) b);

	first = (YYSTYPE *) f->pData;
	second = (YYSTYPE *) s->pData;

	if ((first->type == IS_LONG || first->type == IS_DOUBLE) &&
		(second->type == IS_LONG || second->type == IS_DOUBLE)) {
		dfirst = first->value.dval;
		dsecond = second->value.dval;
		if (first->type == IS_LONG) {
			dfirst = (double) first->value.lval;
		}
		if (second->type == IS_LONG) {
			dsecond = (double) second->value.lval;
		}
		if (dfirst < dsecond) {
			return -1;
		} else if (dfirst == dsecond) {
			return 0;
		} else {
			return 1;
		}
	}
	if ((first->type == IS_LONG || first->type == IS_DOUBLE) &&
		second->type == IS_STRING) {
		return -1;
	} else if ((first->type == IS_STRING) &&
			   (second->type == IS_LONG || second->type == IS_DOUBLE)) {
		return 1;
	}
	if (first->type == IS_STRING && second->type == IS_STRING) {
		return strcmp(first->value.strval, second->value.strval);
	}
	return 0;					/* Anything else is equal as it can't be compared */
}


void php3_asort(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Wrong datatype in asort() call");
		return;
	}
    if (!ParameterPassedByReference(ht,1)) {
        my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to asort()");
		return;
    }
	if (hash_sort(array->value.ht, array_data_compare,0) == FAILURE) {
		return;
	}
	RETURN_TRUE;
}


void php3_sort(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Wrong datatype in sort() call");
		return;
	}
    if (!ParameterPassedByReference(ht,1)) {
        my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to sort()");
		return;
    }
	if (hash_sort(array->value.ht, array_data_compare,1) == FAILURE) {
		return;
	}
	RETURN_TRUE;
}


void array_end(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array, *entry;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Variable passed to end() is not an array");
		return;
	}
    if (!ParameterPassedByReference(ht,1)) {
        my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to end()");
    }
	hash_internal_pointer_end(array->value.ht);
	if (hash_get_current_data(array->value.ht, (void **) &entry) == FAILURE) {
		return;
	}
	return_value = *entry;
	yystype_copy_constructor(&return_value);
}


void array_prev(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array, *entry;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Variable passed to prev() is not an array");
		return;
	}
	if (!ParameterPassedByReference(ht,1)) {
		my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to prev()");
	}
	hash_move_backwards(array->value.ht);
	if (hash_get_current_data(array->value.ht, (void **) &entry) == FAILURE) {
		return;
	}
	return_value = *entry;
	yystype_copy_constructor(&return_value);
}

void array_next(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array, *entry;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Variable passed to next() is not an array");
		return;
	}
    if (!ParameterPassedByReference(ht,1)) {
        my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to next()");
    }
	hash_move_forward(array->value.ht);
	if (hash_get_current_data(array->value.ht, (void **) &entry) == FAILURE) {
		return;
	}
	return_value = *entry;
	yystype_copy_constructor(&return_value);
}

void array_reset(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array, *entry;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Variable passed to reset() is not an array");
		return;
	}
    if (!ParameterPassedByReference(ht,1)) {
        my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to reset()");
    }
	hash_internal_pointer_reset(array->value.ht);
	if (hash_get_current_data(array->value.ht, (void **) &entry) == FAILURE) {
		return;
	}
	return_value = *entry;
	yystype_copy_constructor(&return_value);
}

void array_current(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array, *entry;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Variable passed to current() is not an array");
		return;
	}
    if (!ParameterPassedByReference(ht,1)) {
        my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to current()");
    }
	if (hash_get_current_data(array->value.ht, (void **) &entry) == FAILURE) {
		return;
	}
	return_value = *entry;
	yystype_copy_constructor(&return_value);
}


void array_current_key(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *array;
	char *string_key;
	int int_key;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &array) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	if (array->type != IS_ARRAY) {
		my_phperror(ERRTYPE_WARNING, "Variable passed to key() is not an array");
		return;
	}
    if (!ParameterPassedByReference(ht,1)) {
        my_phperror(ERRTYPE_WARNING, "Array not passed by reference in call to key()");
    }
	switch (hash_get_current_key(array->value.ht, &string_key, &int_key)) {
		case HASH_KEY_IS_STRING:
			return_value.value.strval = string_key;
			return_value.strlen = strlen(string_key);
			return_value.type = IS_STRING;
			break;
		case HASH_KEY_IS_INT:
			return_value.type = IS_LONG;
			return_value.value.lval = int_key;
			break;
		case HASH_KEY_NON_EXISTANT:
			return;
	}
}

#ifdef __cplusplus
void php3_flush(HashTable *)
#else
void php3_flush(INTERNAL_FUNCTION_PARAMETERS)
#endif
{
#if APACHE
#  if MODULE_MAGIC_NUMBER > 19970110
	rflush(php3_rqst);
#  else
	bflush(php3_rqst->connection->client);
#  endif
#endif
#if PHP_ISAPI|NSAPI
	/* I don't know if this is necessary for
	   an ISAPI module, and flushall is probably
	   not good, but will get back to this later
	 */
	flushall();
#endif
#if CGI_BINARY
	fflush(stdout);
#endif
}


void php3_sleep(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *num;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &num) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(num);
	sleep(num->value.lval);
}

void php3_usleep(INTERNAL_FUNCTION_PARAMETERS)
{
#if HAVE_USLEEP
	YYSTYPE *num;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &num) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(num);
	usleep(num->value.lval);
#endif
}

void php3_gettype(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	switch (arg->type) {
		case IS_LONG:
			RETVAL_STRING("integer");
			break;
		case IS_DOUBLE:
			RETVAL_STRING("double");
			break;
		case IS_STRING:
			RETVAL_STRING("string");
			break;
		case IS_ARRAY:
			RETVAL_STRING("array");
			break;
		case IS_CLASS:
			RETVAL_STRING("class");
			break;
		case IS_OBJECT:
			RETVAL_STRING("object");
			break;
		default:
			RETVAL_STRING("unknown type");
	}
}


void php3_settype(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *var, *type;
	char *new_type;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &var, &type) ==
		FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(type);
	new_type = type->value.strval;

	if (!strcasecmp(new_type, "integer")) {
		convert_to_long(var);
	} else if (!strcasecmp(new_type, "double")) {
		convert_to_double(var);
	} else if (!strcasecmp(new_type, "string")) {
		convert_to_string(var);
	} else {
		my_phperror(ERRTYPE_WARNING, "settype: invalid type");
		RETURN_FALSE;
	}
	RETVAL_TRUE;
}


void php3_min(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE **argv;
	int argc, smallest, i;

	argc = ARG_COUNT(ht);
	if (argc < 2) {
		WRONG_PARAM_COUNT;
	}

	argv = (YYSTYPE **)emalloc(sizeof(YYSTYPE *) * argc);

	if (getParametersArray(ht, argc, argv) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(argv[0]);
	smallest = argv[0]->value.lval;

	for (i = 1; i < argc; i++) {
		convert_to_long(argv[i]);
		if (argv[i]->value.lval < smallest) {
			smallest = argv[i]->value.lval;
		}
	}

	efree(argv);
	RETVAL_LONG(smallest);
}


void php3_max(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE **argv;
	int argc, biggest, i;

	argc = ARG_COUNT(ht);
	if (argc < 2) {
		WRONG_PARAM_COUNT;
	}

	argv = (YYSTYPE **)emalloc(sizeof(YYSTYPE *) * argc);

	if (getParametersArray(ht, argc, argv) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(argv[0]);
	biggest = argv[0]->value.lval;

	for (i = 1; i < argc; i++) {
		convert_to_long(argv[i]);
		if (argv[i]->value.lval > biggest) {
			biggest = argv[i]->value.lval;
		}
	}

	efree(argv);
	RETVAL_LONG(biggest);
}


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
