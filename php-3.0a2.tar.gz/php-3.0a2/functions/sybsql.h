/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                  |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: MA_Muquit@fccc.edu                                          |
   |          Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
*/

/* $Id: sybsql.h,v 1.1 1997/10/30 14:05:25 jaakko Exp $ */

#ifndef _SYBSQL_H
#define _SYBSQL_H

void php3_sybsql_connect(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_pconnect(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_dbuse(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_query(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_checkconnect(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_isrow(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_print_a_row(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_nextrow(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_numrows(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_print_all_rows(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_result(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_seek(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_numfields(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_fieldname(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_result_all(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_getfield(INTERNAL_FUNCTION_PARAMETERS);
void php3_sybsql_exit(INTERNAL_FUNCTION_PARAMETERS);
int php3_init_sybase(INITFUNCARG);
extern char *php3_info_sybase(void);

#endif /* _SYBSQL_H */
