/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Zeev Suraski <bourbon@netvision.net.il>                     |
   +----------------------------------------------------------------------+
 */


/* $Id: phpmysql.h,v 1.1 1997/10/30 14:05:24 jaakko Exp $ */

#ifndef _PHPMYSQL_H
#define _PHPMYSQL_H

extern char *php3_info_mysql(void);
extern int php3_minit_mysql(INITFUNCARG);
extern int php3_rinit_mysql(INITFUNCARG);
extern void php3_mysql_connect(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_pconnect(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_close(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_select_db(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_create_db(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_drop_db(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_query(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_db_query(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_list_dbs(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_list_tables(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_list_fields(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_affected_rows(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_insert_id(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_result(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_num_rows(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_num_fields(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_fetch_row(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_data_seek(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_fetch_lengths(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_fetch_field(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_field_seek(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_free_result(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_field_name(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_field_table(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_field_len(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_field_type(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_mysql_field_flags(INTERNAL_FUNCTION_PARAMETERS);

#endif /* _PHPMYSQL_H */
