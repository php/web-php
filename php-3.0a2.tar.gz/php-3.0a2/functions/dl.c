/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Brian Schaffner <brian@tool.net>                            |
   |          Shane Caraveo <shane@caraveo.com>                           |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   +----------------------------------------------------------------------+
 */

#include "parser.h"
#include "internal_functions.h"
#include "dl.h"

#include <stdlib.h>
#include <stdio.h>
#if HAVE_LIBDL
#if MSVC5
#include <windows.h>
#else
#include <dlfcn.h>
#endif
#endif
#if HAVE_STRING_H
#include <string.h>
#else
#include <strings.h>
#endif

#if HAVE_LIBDL

Stack dl_handlers;

/* registers all functions in *library_functions in PHP's function hash */
PHPAPI int dl_addfunc(void *handle, dlnames * library_functions)
{
	dlnames *ptr = library_functions;
	YYSTYPE phps;
	int i = 0;

	while (ptr->fname) {
		phps.offset = i++;
		phps.value.internal_function = (void (*)(INTERNAL_FUNCTION_PARAMETERS))ptr->handler;
		if (!phps.value.internal_function) {
			return FAILURE;
		}
		phps.type = IS_INTERNAL_FUNCTION;
		if (hash_update(&function_table, ptr->fname, strlen(ptr->fname), &phps, sizeof(YYSTYPE)) == FAILURE) {
			return FAILURE;
		}
		ptr++;
	}
	return SUCCESS;
}


void dl(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *file;
	void *handle;
	int (*dlinitialize)();
	char *b, *libpath;

	/* obtain arguments */
	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &file) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(file);

	if(php3_ini.dldir){
		int dldir_len = strlen(php3_ini.dldir);
		
		b = strrchr((php3_ini.dldir + dldir_len),'/');
#if WIN32
		if(!b) {
			b = strrchr((php3_ini.dldir + strlen(php3_ini.dldir)),'\\');
		}
#endif
		if(b) {
			libpath = emalloc(dldir_len+strlen(b)+1);
			sprintf(libpath,"%s%s",php3_ini.dldir,b);  /* SAFE */
		} else {
			libpath = emalloc(dldir_len+file->strlen+1);
			sprintf(libpath,"%s/%s",php3_ini.dldir,file->value.strval);  /* SAFE */
		}
	} else {
		libpath = estrndup(file->value.strval,file->strlen);
	}

	/* load dynamic symbol */
#if MSVC5
	if ((int) (handle = LoadLibrary(libpath)) < 32) {
		my_phperror(ERRTYPE_WARNING,"Unable to load dynamic library '%s' ",file->value.strval);
		efree(libpath);
		RETURN_FALSE;
	}
	dlinitialize = (int (*)()) GetProcAddress(handle, "dl_initialize");
	if (!dlinitialize) {
		FreeLibrary(handle);
		my_phperror(ERRTYPE_WARNING,"Invalid library (maybe not a php library) '%s' ",file->value.strval);
		efree(libpath);
		RETURN_FALSE;
	}
	if (dlinitialize(handle, dl_functions) == FAILURE) {
		FreeLibrary(handle);
		my_phperror(ERRTYPE_WARNING,"Error in library functions list '%s' ",file->value.strval);
		efree(libpath);
		RETURN_FALSE;
	}
#else							/* unix system with dl library */
	handle = dlopen(libpath, RTLD_LAZY);
	if (!handle) {
		my_phperror(ERRTYPE_WARNING,"Unable to load dynamic library '%s' - %s",libpath,dlerror());
		efree(libpath);
		RETURN_FALSE;
	}
	efree(libpath);
	dlinitialize = (int (*)()) dlsym(handle, "dl_initialize");
	
	if (!dlinitialize) {
		dlclose(handle);
		RETURN_FALSE;
	}
	if (dlinitialize(handle, dl_functions) == FAILURE) {
		dlclose(handle);
		RETURN_FALSE;
	}
#endif
	stack_push(&dl_handlers, (void *) &handle, sizeof(void *));
	RETURN_TRUE;
}

int php3_init_dl(INITFUNCARG)
{
	return stack_init(&dl_handlers);
}

int php3_shutdown_dl(void)
{
	/* calling the shutdown function in the dl needs
	 * to be worked out more.  ie. what params do we
	 * need to pass to it. dl_functions?
	 */
	void *handle;
	int (*dlshutdown)(void);

	while (stack_top(&dl_handlers, (void **) &handle) != FAILURE) {
#if MSVC5
		dlshutdown = (int (*)(void)) GetProcAddress(handle, "dl_shutdown");
		if (dlshutdown) {
			dlshutdown();
		}
		FreeLibrary(handle);
#else
		dlshutdown = (int (*)(void)) dlsym(handle, "dl_shutdown");
		if (dlshutdown) {
			dlshutdown();
		}
		dlclose(handle);
#endif
		stack_del_top(&dl_handlers);
	}
	return stack_destroy(&dl_handlers);
}

#else
void dl(INTERNAL_FUNCTION_PARAMETERS)
{
}
int php3_init_dl(void *ptr)
{
	return SUCCESS;
}
int php3_shutdown_dl()
{
	return SUCCESS;
}
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
