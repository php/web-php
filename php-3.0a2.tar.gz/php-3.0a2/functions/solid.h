/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                  |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Jeroen van der Most <jvdmost@digiface.nl>                   |
   |          Stig S�ther Bakken <ssb@guardian.no>                        |
   +----------------------------------------------------------------------+
 */

#ifndef _PHP3_SOLID_H

#if HAVE_SOLID

#if MSVC5 /* Windows */
# include <windows.h>
# include <sql.h>
# include <sqlext.h>
#else /* UNIX */
# if HAVE_IODBC /* iODBC */
#  include <isql.h>
#  include <isqlext.h>
#  include <odbc_types.h>
#  include <odbc_funcs.h>
# else /* Solid */
#  include <cli0core.h>
#  include <cli0ext1.h>
# endif
#endif

uint sql_find_result_on_conn(void *, void *);

#ifndef MSVC5
# define FAR
#endif

typedef struct SQLConn {
	HDBC            hdbc;
	int             index;
} SQLConn;

typedef struct {
	char            name[32];
	char           *value;
	long int        vallen;
} SQLResultValue;

typedef struct SQLResult {
	HSTMT           stmt;
	SQLResultValue *values;
	SQLConn        *conn;
	int             numcols;
	int             fetched;
	int             index;
} SQLResult;

#endif /* HAVE_SOLID */

/* solid.c functions */
extern int php3_init_sql(INITFUNCARG);
extern int php3_shutdown_sql(void);
extern void php3_sql_closeall(void);
extern void php3_sql_exec(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_fetchrow(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_result(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_freeresult(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_connect(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_close(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_numrows(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_numfields(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_fieldname(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_sql_fieldnum(INTERNAL_FUNCTION_PARAMETERS);
extern char *php3_info_solid(void);

#endif /* _PHP3_SOLID_H */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
