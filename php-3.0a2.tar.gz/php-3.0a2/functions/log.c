/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                  |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors:                                                             |
   +----------------------------------------------------------------------+
 */

/* $Id: log.c,v 1.11 1997/11/03 00:17:23 jim Exp $ */

#include "parser.h"
#include "internal_functions.h"
#include "log.h"

#include <stdlib.h>

#if HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <time.h>
#include <errno.h>

#include "reg.h"
#include "pageinfo.h"
#include "log.h"

logging_stats log_stats;
logging_conf log_conf;

int php3_init_log(INITFUNCARG) {
#if LOGGING
	log_stats.filled = 0;
	log_stats.logfile = NULL;

	/* FIXME: this stuff should be coming out of some general
	   configuration-management thing */

#if LOG_MSQL || LOG_MYSQL
	log_conf.sql_log_db =
		estrdup(conf->SQLLogDB ? conf->SQLLogDB : LOG_SQL_DB);
	log_conf.sql_log_host =
		estrdup(conf->SQLLogHost ? conf->SQLLogDB : LOG_SQL_HOST);
#endif

#if APACHE
	log_conf.dbm_log_dir =
		estrdup(conf->dbmLogDir ? conf->dbmLogDir : LOG_DBM_DIR);
#else
	log_conf.dbm_log_dir = estrdup(php3_ini.logdbmdir);
#endif
#endif
	return SUCCESS;
}

static void _php3_flushlogstats(void) {
	if (log_stats.filled) {
		if (log_stats.last_host) efree(log_stats.last_host);
		if (log_stats.last_email) efree(log_stats.last_email);
		if (log_stats.last_ref) efree(log_stats.last_ref);
		if (log_stats.last_browser) efree(log_stats.last_browser);
	}
	log_stats.filled = 0;
}

int php3_shutdown_log(void)
{
#if LOGGING
	_php3_flushlogstats();
	if (log_stats.logfile) {
		efree(log_stats.logfile);
		log_stats.logfile = NULL;
	}

#if LOG_MSQL || LOG_MYSQL
	efree(log_conf.sql_log_db);
	efree(log_conf.sql_log_host);
#else
	efree(log_conf.dbm_log_dir);
#endif

#endif
	return SUCCESS;
}

char *_php3_filename_to_logfn(char *filename) {
	char *lfn, *lp, *ret;

	lfn = estrdup(filename);
	lp = lfn;
	while(*lp == '/') lp++;
	if(*lp=='~') {
		while(*lp =='~') lp++;
		if(strchr(lp,'/')) {
			while(*lp!='/') lp++;
			lp++;
		}
	}
	ret = _php3_regreplace("/","_",lp, 0, 0);
	efree(lfn);
	return(ret);
}

static void _php3_log_setfilename(void) {
	/* construct the filename for the log */
	log_stats.logfile = _php3_filename_to_logfn(php_env.filename);
}


void _php3_log(void) {
#if LOGGING
	/* construct the logfile name if it wasn't set by logas()
	   or because we already read the log once) */
	if (!log_stats.logfile)
		_php3_log_setfilename();

#if LOG_MYSQL
	_php3_log_mysql();
#endif
#if LOG_MSQL
	_php3_log_msql();
#endif
#if LOG_DBM
	_php3_log_db();
#endif
#endif
}

#if 0 /* XXX Not used anywhere -jaakko */
void php3_getlogfile(INTERNAL_FUNCTION_PARAMETERS) {
	/* construct the logfile name if it wasn't set by logas()
	   or because we already read the log once) */
	if (!log_stats.logfile)
		_php3_log_setfilename();
	RETURN_STRING(log_stats.logfile);
}
#endif

void php3_logas(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *as;
	if (ARG_COUNT(ht)!=1 || getParameters(ht, 1, &as) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(as);
	if (log_stats.logfile) efree(log_stats.logfile);
	log_stats.logfile = estrdup(as->value.strval);
	_php3_flushlogstats();
	RETURN_STRING(as->value.strval);
}

void _php3_load_log_info(void) {
	/* construct the logfile name if it wasn't set by logas()
	   or because we already read the log once) */
	if (!log_stats.logfile)
		_php3_log_setfilename();
#if LOG_DBM
	_php3_load_log_info_db();
#endif
}

#define LOAD_LAST_LOG_INFO \
	if (!log_stats.filled) \
		_php3_load_log_info();

void php3_getlasthost(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	if (log_stats.last_host) 
		RETURN_STRING(log_stats.last_host);
}

void php3_getlastref(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	if (log_stats.last_ref) 
		RETURN_STRING(log_stats.last_ref);
}

void php3_getlastemail(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	if (log_stats.last_email) 
		RETURN_STRING(log_stats.last_email);
}

void php3_getlastbrowser(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	if (log_stats.last_browser) 
		RETURN_STRING(log_stats.last_browser);
}

void php3_getlastaccess(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	RETURN_LONG(log_stats.last_access);
}

void php3_getstartlogging(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	RETURN_LONG(log_stats.start_logging);
}

void php3_gettotal(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	RETURN_LONG(log_stats.total_count);
}

void php3_gettoday(INTERNAL_FUNCTION_PARAMETERS) {
	LOAD_LAST_LOG_INFO;
	RETURN_LONG(log_stats.today_count);
}

static char *_php3_getlogdir(void) {
#if LOG_MSQL || LOG_MYSQL
	return log_conf.sql_log_db;
#else
#if LOG_DBM
	return log_conf.dbm_log_dir;
#else
	return NULL;
#endif
#endif
}

void php3_getlogdir(INTERNAL_FUNCTION_PARAMETERS) {
	char *ret = _php3_getlogdir();
	RETURN_STRING(ret);
}
#if 0 /* XXX not used anywhere -jaakko */
static char *_php3_getloghost(void) {
#if LOG_MSQL || LOG_MYSQL 
	return log_conf.sql_log_host;
#else
	return NULL;
#endif
}

void php3_getloghost(INTERNAL_FUNCTION_PARAMETERS) {
	char *ret = _php3_getloghost();
	RETURN_STRING(ret);
}
#endif /* XXX not used anywhere -jaakko */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
