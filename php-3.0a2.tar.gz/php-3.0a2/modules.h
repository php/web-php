/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
 */


#ifndef _MODULES_H
#define _MODULES_H

#if APACHE
#define INITFUNCARG php3_module_conf *conf
#else
#define INITFUNCARG void *conf
#endif

typedef struct {
	char *name;
	int (*module_startup_func)(INITFUNCARG);
	int (*module_shutdown_func)(void);
	int (*request_startup_func)(INITFUNCARG);
	int (*request_shutdown_func)(void);
	char *(*info_func)(void);
	unsigned char supported;
} php3_module;


typedef struct {
	/* general sql stuff */
	int allow_persistent;
	int max_persistent;
	int max_links;
#if HAVE_MYSQL
	int mysql_allow_persistent;
	int mysql_max_persistent;
	int mysql_max_links;
#endif
} configuration_settings;

extern configuration_settings configuration;

/* configuration module */
extern int php3_init_config(void);
extern int php3_shutdown_config(void);

/* environment module */
extern int php3_init_environ(INITFUNCARG);
extern int php3_shutdown_environ(void);

/* debugger module */
extern int php3_init_debugger(INITFUNCARG);
extern int php3_shutdown_debugger(void);
extern void php3_debugger_error(char *message, int type, char *filename, int lineno);




#endif
