/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Shane Caraveo                                               |
   |                                                                      |
   +----------------------------------------------------------------------+
 */

#include "parser.h"


#ifndef XP_WIN32
#include <unistd.h>  /* sleep */
#define DLLEXPORT
#else /* XP_WIN32 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#define DLLEXPORT __declspec(dllexport)
#endif /* XP_WIN32 */

void *aLock, *hLock;

extern int php_nsapi_main(pblock *pb, Session *sn, Request *rq);

DLLEXPORT void close_nsapi_mod(void *vparam)
{
	//global shutdown for all php threads
	//for now this will do nothing until we
	//make php thread-safe
	crit_terminate(aLock);
	crit_terminate(hLock);
}

DLLEXPORT int init_nsapi_mod(pblock *pb, Session *sn, Request *rq)
{
	//global initialization for all php threads
	//for now this will do nothing until we
	//make php thread-safe
	aLock = crit_init();
	hLock = crit_init();

	daemon_atrestart(close_nsapi_mod, NULL);
	return REQ_PROCEED;
}

DLLEXPORT void nsapi_php_main(pblock *pb, Session *sn, Request *rq)
{
	//start a php thread
	php_nsapi_main(pb,sn,rq);
}

void nsapi_writeclient(char *s, int size)
{
	net_write(nssn->csd, s, size);
}

void nsapi_putc(char c)
{
	net_write(nssn->csd, &c, 1);
}