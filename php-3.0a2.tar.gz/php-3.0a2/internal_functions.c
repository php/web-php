/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   |          Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
 */


/* $Id: internal_functions.c,v 1.181 1997/11/06 17:45:15 zeev Exp $ */

#include "parser.h"
#include "internal_functions.h"
#include "internal_functions_registry.h"
#include "list.h"
#include "modules.h"
#include <stdarg.h>

#include "functions/basic_functions.h"
#include "functions/phpmath.h"
#include "functions/phpstring.h"
#include "functions/odbc.h"
#include "functions/oracle.h"
#include "functions/phpdir.h"
#include "functions/dns.h"
#include "functions/phpmysql.h"
#include "functions/phpmsql.h"
#include "functions/pgsql.h"
#include "functions/reg.h"
#include "functions/mail.h"
#include "functions/md5.h"
#include "functions/phpgd.h"
#include "functions/html.h"
#include "functions/dl.h"
#include "functions/head.h"
#include "functions/post.h"
#include "functions/exec.h"
#include "functions/solid.h"
#include "functions/sybsql.h"
#include "functions/adabasd.h"
#include "functions/file.h"
#include "functions/dbase.h"
#include "functions/filepro.h"
#include "functions/log.h"
#include "functions/db.h"

#if APACHE
extern module *top_module;
#endif

static module_initialized_modules;
static request_initialized_modules;

/* Function pointers for dynamically loaded functions */
dl_functions_structure dl_functions_global = {
	0/*
	dl_addfunc, 
	my_phperror,
	getParameters,
	getParametersArray, 
	convert_to_string,
	convert_to_long,
	convert_to_double, 
	&return_value,
	&empty_string
    array_init, 
	hash_next_index_insert, 
	_emalloc,
	_efree,
	_ecalloc,
	_erealloc,
	_estrdup,
	_estrndup */
};

/* The various modules.  The names are currently ignored, but might be
 * used in the future, and should help people to recognize what's
 * going on anyway.  The second and third arguments are startup and
 * shutdown functions, called at program startup and shutdown, respectively.
 * The fourth and fifth arguments are startup and shutdown functions, called
 * in the beginning and end of every request, respectively.
 * The sixth element denotes on whether the module is enabled or not.
 *
 * Initialization of the modules happens in the order they appear here.
 */
php3_module php3_modules[] =
{
	{"environ",		NULL,				NULL,	php3_init_environ,	php3_shutdown_environ,	NULL,				1},
	{"db",			NULL,				NULL,	php3_init_db,		NULL,					php3_info_db,				1},
	{"odbc",		NULL,				NULL,	php3_init_odbc,		NULL,					NULL,				HAVE_IODBC},
	{"dl",			NULL,				NULL,	php3_init_dl,		php3_shutdown_dl,		NULL,				HAVE_LIBDL},
	{"crypt",		NULL,				NULL,	NULL,				NULL,					NULL,				HAVE_CRYPT},
	{"filestat",	NULL,				NULL,	php3_init_filestat,	php3_shutdown_filestat,	NULL,				1},
	{"head",		NULL,				NULL,	php3_init_head,		NULL,					NULL,				1},
	{"access log",	NULL,				NULL,	php3_init_log,		php3_shutdown_log,		NULL,				LOGGING},
	{"mail",		NULL,				NULL,	NULL,				NULL,					php3_info_mail,		HAVE_SENDMAIL},
	{"mime",		NULL,				NULL,	php3_init_mime,		NULL,					NULL,				1},
	{"debugger",	NULL,				NULL,	php3_init_debugger,	php3_shutdown_debugger,	NULL,				PHP_DEBUGGER},
	{"syslog",		NULL,				NULL,	php3_init_syslog,	NULL,					NULL,				HAVE_SYSLOG_H},
#ifndef MSVC5
	{"adabas",		NULL,				NULL,	php3_init_adabas,	php3_shutdown_adabas,	php3_info_adabas,	HAVE_ADABAS},
	{"mysql",		php3_minit_mysql,	NULL,	php3_rinit_mysql,	NULL,					php3_info_mysql,	HAVE_MYSQL},
	{"msql",		NULL,				NULL,	php3_init_msql,		NULL,					NULL,				HAVE_MSQL},
	{"pgsql",		NULL,				NULL,	php3_init_pgsql,	NULL,					NULL,				HAVE_PGSQL},
	{"solid",		NULL,				NULL,	php3_init_sql,		php3_shutdown_sql,		php3_info_solid,	HAVE_SOLID},
	{"oracle",		NULL,				NULL,	php3_init_oracle,	NULL,					php3_info_oracle,	HAVE_ORACLE},
	{"sybase",		NULL,				NULL,	php3_init_sybase,	NULL,					php3_info_sybase,	HAVE_SYBASE},
#endif
	{NULL,			NULL,				NULL,	NULL,				NULL,					NULL,				0}
};

/* function names must be in LOWER CASE.
 * alphabetically sorted for ease-of-reading purposes only.
 */
internal_function internal_functions[] =
{
	{"abs", php3_abs, 1},
	{"acos", php3_acos, 1},
#ifndef MSVC5
	{"ada_autocommit", php3_Ada_autocommit, HAVE_ADABAS},
	{"ada_close", php3_Ada_close, HAVE_ADABAS},
	{"ada_closeall", php3_Ada_closeAll, HAVE_ADABAS},
	{"ada_commit", php3_Ada_commit, HAVE_ADABAS},
	{"ada_connect", php3_Ada_connect, HAVE_ADABAS},
	{"ada_exec", php3_Ada_exec, HAVE_ADABAS},
	{"ada_fetchrow", php3_Ada_fetchRow, HAVE_ADABAS},
	{"ada_fieldlen", php3_Ada_fieldLen, HAVE_ADABAS},
	{"ada_fieldname", php3_Ada_fieldName, HAVE_ADABAS},
	{"ada_fieldtype", php3_Ada_fieldType, HAVE_ADABAS},
	{"ada_freeresult", php3_Ada_freeResult, HAVE_ADABAS},
	{"ada_numfields", php3_Ada_numFields, HAVE_ADABAS},
	{"ada_numrows", php3_Ada_numRows, HAVE_ADABAS},
	{"ada_result", php3_Ada_result, HAVE_ADABAS},
	{"ada_resultall", php3_Ada_resultAll, HAVE_ADABAS},
	{"ada_rollback", php3_Ada_rollback, HAVE_ADABAS},
#endif
	{"addslashes", php3_addslashes, 1},
	{"asin", php3_asin, 1},
	{"asort", php3_asort, 1},
	{"atan", php3_atan, 1},
	{"bindec", php3_bindec, 1},
	{"ceil", php3_ceil, 1},
	{"chop", php3_chop, 1},
	{"chr", php3_chr, 1},
	{"cos", php3_cos, 1},
	{"current", array_current, 1},
	{"pos", array_current, 1},
	{"date", php3_date, 1},

	{"dblist", php3_dblist, 1},
	{"dbmopen", php3_dbmopen, 1},
	{"dbmclose", php3_dbmclose, 1},
	{"dbminsert", php3_dbminsert, 1},
	{"dbmfetch", php3_dbmfetch, 1},
	{"dbmreplace", php3_dbmreplace, 1},
	{"dbmexists", php3_dbmexists, 1},
	{"dbmdelete", php3_dbmdelete, 1},
	{"dbmfirstkey", php3_dbmfirstkey, 1},
	{"dbmnextkey", php3_dbmnextkey, 1},

	{"decbin", php3_decbin, 1},
	{"dechex", php3_dechex, 1},
	{"decoct", php3_decoct, 1},
	{"doubleval", double_value, 1},
	{"end", array_end, 1},
	{"ereg", php3_ereg, 1},
	{"ereg_replace", php3_eregreplace, 1},
	{"eregi", php3_eregi, 1},
	{"eregi_replace", php3_eregireplace, 1},
	{"escapeshellcmd", php3_escapeshellcmd, 1},
	{"exec", php3_exec, 1},
	{"exp", php3_exp, 1},
	{"fclose", php3_fclose, 1},
	{"feof", php3_feof, 1},
	{"fgets", php3_fgets, 1},
	{"fgetss", php3_fgetss, 1},

	{"filepro", php3_filepro, HAVE_FILEPRO},
	{"filepro_rowcount", php3_filepro_rowcount, HAVE_FILEPRO},
	{"filepro_fieldname", php3_filepro_fieldname, HAVE_FILEPRO},
	{"filepro_fieldtype", php3_filepro_fieldtype, HAVE_FILEPRO},
	{"filepro_fieldwidth", php3_filepro_fieldwidth, HAVE_FILEPRO},
	{"filepro_fieldcount", php3_filepro_fieldcount, HAVE_FILEPRO},
	{"filepro_retrieve", php3_filepro_retrieve, HAVE_FILEPRO},

	{"floor", php3_floor, 1},
	{"flush", php3_flush, 1},
	{"fopen", php3_fopen, 1},
	{"fpassthru", php3_fpassthru, 1},
	{"fputs", php3_fputs, 1},
	{"fsockopen", php3_fsockopen, 1},
	{"fseek", php3_fseek, 1},
	{"ftell", php3_ftell, 1},
	{"getimagesize", php3_getimagesize, 1},
	{"gmdate", php3_gmdate, 1},
	{"header", php3_Header, 1},
	{"hexdec", php3_hexdec, 1},
	{"htmlspecialchars", php3_htmlspecialchars, 1},
	{"intval", int_value, 1},
	{"key", array_current_key, 1},
	{"ksort", php3_key_sort, 1},
	{"log", php3_log, 1},
	{"log10", php3_log10, 1},
	{"max", php3_max, 1},
	{"md5", php3_md5, 1},
	{"min", php3_min, 1},
	{"mkdir", php3_mkdir, 1},
	{"mktime", php3_mktime, 1},

#ifndef MSVC5
	{"mysql_connect", php3_mysql_connect, HAVE_MYSQL},
	{"mysql_pconnect", php3_mysql_pconnect, HAVE_MYSQL},
	{"mysql_close", php3_mysql_close, HAVE_MYSQL},
	{"mysql_select_db", php3_mysql_select_db, HAVE_MYSQL},
	{"mysql_create_db", php3_mysql_create_db, HAVE_MYSQL},
	{"mysql_drop_db", php3_mysql_drop_db, HAVE_MYSQL},
	{"mysql_query", php3_mysql_query, HAVE_MYSQL},
	{"mysql", php3_mysql_db_query, HAVE_MYSQL},
	{"mysql_list_dbs", php3_mysql_list_dbs, HAVE_MYSQL},
	{"mysql_list_tables", php3_mysql_list_tables, HAVE_MYSQL},
	{"mysql_list_fields", php3_mysql_list_fields, HAVE_MYSQL},
	{"mysql_affected_rows", php3_mysql_affected_rows, HAVE_MYSQL},
	{"mysql_insert_id", php3_mysql_insert_id, HAVE_MYSQL},
	{"mysql_result", php3_mysql_result, HAVE_MYSQL},
	{"mysql_num_rows", php3_mysql_num_rows, HAVE_MYSQL},
	{"mysql_num_fields", php3_mysql_num_fields, HAVE_MYSQL},
	{"mysql_fetch_row", php3_mysql_fetch_row, HAVE_MYSQL},
	{"mysql_data_seek", php3_mysql_data_seek, HAVE_MYSQL},
	{"mysql_fetch_lengths", php3_mysql_fetch_lengths, HAVE_MYSQL},
	{"mysql_fetch_field", php3_mysql_fetch_field, HAVE_MYSQL},
	{"mysql_field_seek", php3_mysql_field_seek, HAVE_MYSQL},
	{"mysql_free_result", php3_mysql_free_result, HAVE_MYSQL},
	{"mysql_fieldname", php3_mysql_field_name, HAVE_MYSQL},
	{"mysql_fieldtable", php3_mysql_field_table, HAVE_MYSQL},
	{"mysql_fieldlen", php3_mysql_field_len, HAVE_MYSQL},
	{"mysql_fieldtype", php3_mysql_field_type, HAVE_MYSQL},
	{"mysql_fieldflags", php3_mysql_field_flags, HAVE_MYSQL},
	/* for downwards compatability */
	{"mysql_selectdb", php3_mysql_select_db, HAVE_MYSQL},
	{"mysql_createdb", php3_mysql_create_db, HAVE_MYSQL},
	{"mysql_dropdb", php3_mysql_drop_db, HAVE_MYSQL},
	{"mysql_freeresult", php3_mysql_free_result, HAVE_MYSQL},
	{"mysql_numfields", php3_mysql_num_fields, HAVE_MYSQL},
	{"mysql_numrows", php3_mysql_num_rows, HAVE_MYSQL},
	{"mysql_listdbs", php3_mysql_list_dbs, HAVE_MYSQL},
	{"mysql_listtables", php3_mysql_list_tables, HAVE_MYSQL},
	{"mysql_dbname", php3_mysql_result, HAVE_MYSQL},
	{"mysql_tablename", php3_mysql_result, HAVE_MYSQL},
	
	{"msql_connect", php3_msql_connect, HAVE_MSQL},
	{"msql_pconnect", php3_msql_pconnect, HAVE_MSQL},
	{"msql_close", php3_msql_close, HAVE_MSQL},
	{"msql_select_db", php3_msql_select_db, HAVE_MSQL},
	{"msql_create_db", php3_msql_create_db, HAVE_MSQL},
	{"msql_drop_db", php3_msql_drop_db, HAVE_MSQL},
	{"msql_query", php3_msql_query, HAVE_MSQL},
	{"msql", php3_msql_db_query, HAVE_MSQL},
	{"msql_list_dbs", php3_msql_list_dbs, HAVE_MSQL},
	{"msql_list_tables", php3_msql_list_tables, HAVE_MSQL},
	{"msql_list_fields", php3_msql_list_fields, HAVE_MSQL},
	{"msql_result", php3_msql_result, HAVE_MSQL},
	{"msql_num_rows", php3_msql_num_rows, HAVE_MSQL},
	{"msql_num_fields", php3_msql_num_fields, HAVE_MSQL},
	{"msql_fetch_row", php3_msql_fetch_row, HAVE_MSQL},
	{"msql_data_seek", php3_msql_data_seek, HAVE_MSQL},
	{"msql_fetch_field", php3_msql_fetch_field, HAVE_MSQL},
	{"msql_field_seek", php3_msql_field_seek, HAVE_MSQL},
	{"msql_free_result", php3_msql_free_result, HAVE_MSQL},
	{"msql_fieldname", php3_msql_field_name, HAVE_MSQL},
	{"msql_fieldtable", php3_msql_field_table, HAVE_MSQL},
	{"msql_fieldlen", php3_msql_field_len, HAVE_MSQL},
	{"msql_fieldtype", php3_msql_field_type, HAVE_MSQL},
	{"msql_fieldflags", php3_msql_field_flags, HAVE_MSQL},
	{"msql_regcase", php3_sql_regcase, HAVE_MSQL},
	/* for downwards compatability */
	{"msql_selectdb", php3_msql_select_db, HAVE_MSQL},
	{"msql_createdb", php3_msql_create_db, HAVE_MSQL},
	{"msql_dropdb", php3_msql_drop_db, HAVE_MSQL},
	{"msql_freeresult", php3_msql_free_result, HAVE_MSQL},
	{"msql_numfields", php3_msql_num_fields, HAVE_MSQL},
	{"msql_numrows", php3_msql_num_rows, HAVE_MSQL},
	{"msql_listdbs", php3_msql_list_dbs, HAVE_MSQL},
	{"msql_listtables", php3_msql_list_tables, HAVE_MSQL},
	{"msql_dbname", php3_msql_result, HAVE_MSQL},
	{"msql_tablename", php3_msql_result, HAVE_MSQL},

	{"pg_connect", php3_pgsql_connect, HAVE_PGSQL},
	{"pg_pconnect", php3_pgsql_pconnect, HAVE_PGSQL},
	{"pg_close", php3_pgsql_close, HAVE_PGSQL},
	{"pg_dbname", php3_pgsql_dbname, HAVE_PGSQL},
	{"pg_errormessage", php3_pgsql_error_message, HAVE_PGSQL},
	{"pg_options", php3_pgsql_options, HAVE_PGSQL},
	{"pg_port", php3_pgsql_port, HAVE_PGSQL},
	{"pg_tty", php3_pgsql_tty, HAVE_PGSQL},
	{"pg_host", php3_pgsql_host, HAVE_PGSQL},
	{"pg_exec", php3_pgsql_exec, HAVE_PGSQL},
	{"pg_numrows", php3_pgsql_num_rows, HAVE_PGSQL},
	{"pg_numfields", php3_pgsql_num_fields, HAVE_PGSQL},
	{"pg_fieldname", php3_pgsql_field_name, HAVE_PGSQL},
	{"pg_fieldsize", php3_pgsql_field_size, HAVE_PGSQL},
	{"pg_fieldtype", php3_pgsql_field_type, HAVE_PGSQL},
	{"pg_fieldnum", php3_pgsql_field_number, HAVE_PGSQL},
	{"pg_result", php3_pgsql_result, HAVE_PGSQL},
	{"pg_fieldprtlen", php3_pgsql_data_length, HAVE_PGSQL},
	{"pg_getlastoid", php3_pgsql_last_oid, HAVE_PGSQL},
	{"pg_freeresult", php3_pgsql_free_result, HAVE_PGSQL},
	{"pg_locreate", php3_pgsql_lo_create, HAVE_PGSQL},
	{"pg_lounlink", php3_pgsql_lo_unlink, HAVE_PGSQL},
	{"pg_loopen", php3_pgsql_lo_open, HAVE_PGSQL},
	{"pg_loclose", php3_pgsql_lo_close, HAVE_PGSQL},
	{"pg_loread", php3_pgsql_lo_read, HAVE_PGSQL},
	{"pg_lowrite", php3_pgsql_lo_write, HAVE_PGSQL},
	{"pg_loreadall", php3_pgsql_lo_readall, HAVE_PGSQL},
#endif	

	{"next", array_next, 1},
	{"octdec", php3_octdec, 1},
	{"ord", php3_ord, 1},
	{"parse_str", php3_parsestr, 1},
	{"passthru", php3_fpassthru, 1},
	{"pclose", php3_pclose, 1},
	{"phpinfo", php3_info, 1},
	{"phpversion", php3_version, 1},
	{"pi", php3_pi, 1},
	{"popen", php3_popen, 1},
	{"pow", php3_pow, 1},
	{"prev", array_prev, 1},
	{"readfile", php3_readfile, 1},
	{"reset", array_reset, 1},
	{"rewind", php3_rewind, 1},
	{"rmdir", php3_rmdir, 1},
	{"setcookie", php3_SetCookie, 1},
	{"short_tags", php3_toggle_short_open_tag, 1},
	{"sleep", php3_sleep, 1},
	{"umask", php3_fileumask, 1},
	{"usleep", php3_usleep, HAVE_USLEEP},
	{"sort", php3_sort, 1},
	{"split", php3_split, 1},
	{"strlen", php3_strlen, 1},
	{"strval", string_value, 1},
	{"strtok", php3_strtok, 1},
	{"strtoupper", php3_strtoupper, 1},
	{"strtolower", php3_strtolower, 1},
	{"strchr", php3_strstr, 1},
	{"stripslashes", php3_stripslashes, 1},
	{"strstr", php3_strstr, 1},
	{"strrchr", php3_strrchr, 1},
	{"substr", php3_substr, 1},
	{"tempnam", php3_tempnam, 1},
	{"quotemeta", php3_quotemeta, 1},
	{"urlencode", php3_urlencode, 1},
	{"urldecode", php3_urldecode, 1},
	{"ucfirst", php3_ucfirst, 1},
	{"strtr", php3_strtr, 1},
	{"sqrt", php3_sqrt, 1},
	{"sql_regcase", php3_sql_regcase, 1},
	{"sprintf", php3_user_sprintf, 1},
	{"printf", php3_user_printf, 1},
	{"sin", php3_sin, 1},
	{"tan", php3_tan, 1},
	{"time", php3_time, 1},

	{"system", php3_system, 1},

#ifndef MSVC5
	{"ora_close", php3_Ora_Close, HAVE_ORACLE},
	{"ora_commit", php3_Ora_Commit, HAVE_ORACLE},
	{"ora_commitoff", php3_Ora_CommitOff, HAVE_ORACLE},
	{"ora_commiton", php3_Ora_CommitOn, HAVE_ORACLE},
	{"ora_error", php3_Ora_Error, HAVE_ORACLE},
	{"ora_errorcode", php3_Ora_ErrorCode, HAVE_ORACLE},
	{"ora_exec", php3_Ora_Exec, HAVE_ORACLE},
	{"ora_fetch", php3_Ora_Fetch, HAVE_ORACLE},
	{"ora_getcolumn", php3_Ora_GetColumn, HAVE_ORACLE},
	{"ora_logoff", php3_Ora_Logoff, HAVE_ORACLE},
	{"ora_logon", php3_Ora_Logon, HAVE_ORACLE},
	{"ora_open", php3_Ora_Open, HAVE_ORACLE},
	{"ora_parse", php3_Ora_Parse, HAVE_ORACLE},
	{"ora_rollback", php3_Ora_Rollback, HAVE_ORACLE},

	/* Sybase functions that were available in PHP2 */
	{"sybsql_seek", php3_sybsql_seek, HAVE_SYBASE},
	{"sybsql_exit", php3_sybsql_exit, HAVE_SYBASE},
	{"sybsql_dbuse", php3_sybsql_dbuse, HAVE_SYBASE},
	{"sybsql_query", php3_sybsql_query, HAVE_SYBASE},
	{"sybsql_isrow", php3_sybsql_isrow, HAVE_SYBASE},
	{"sybsql_result", php3_sybsql_result, HAVE_SYBASE},
	{"sybsql_connect", php3_sybsql_connect, HAVE_SYBASE},
	{"sybsql_nextrow", php3_sybsql_nextrow, HAVE_SYBASE},
	{"sybsql_numrows", php3_sybsql_numrows, HAVE_SYBASE},
	{"sybsql_getfield", php3_sybsql_getfield, HAVE_SYBASE},
	{"sybsql_numfields", php3_sybsql_numfields, HAVE_SYBASE},
	{"sybsql_fieldname", php3_sybsql_fieldname, HAVE_SYBASE},
	{"sybsql_result_all", php3_sybsql_result_all, HAVE_SYBASE},
	{"sybsql_checkconnect", php3_sybsql_checkconnect, HAVE_SYBASE},
#endif
	/* Sybase functions new in PHP3 */

	/* none yet */


	{"dl", dl, HAVE_LIBDL},
	{"getdate", php3_getdate, 1},
	{"checkdate", php3_checkdate, 1},
	{"soundex", soundex, 1},
	{"crypt", php3_crypt, HAVE_CRYPT},
	{"rand", php3_rand, 1},
	{"srand", php3_srand, 1},
	{"getrandmax", php3_getrandmax, 1},
	{"opendir", php3_opendir, 1},
	{"closedir", php3_closedir, 1},
	{"chdir", php3_chdir, 1},
	{"rewinddir", php3_rewinddir, 1},
	{"readdir", php3_readdir, 1},
	{"dir", php3_getdir, 1},
	{"gethostbyaddr", php3_gethostbyaddr, 1},
	{"gethostbyname", php3_gethostbyname, 1},
	{"mail", php3_mail, HAVE_SENDMAIL},
	{"explode", php3_explode, 1},
	{"implode", php3_implode, 1},
	{"getenv", php3_getenv, 1},
	{"putenv", php3_putenv, HAVE_PUTENV},
	{"gettype", php3_gettype, 1},
	{"settype", php3_settype, 1},
	{"microtime", php3_microtime, HAVE_GETTIMEOFDAY},
	{"uniqid", php3_uniqid, HAVE_GETTIMEOFDAY},
	{"error_reporting", php3_error_reporting, 1},

	{"openlog", php3_openlog, HAVE_SYSLOG_H},
	{"syslog", php3_syslog, HAVE_SYSLOG_H},
	{"closelog", php3_closelog, HAVE_SYSLOG_H},

	{"clearstatcache", php3_clearstatcache, 1},
	{"fileatime", php3_fileatime, 1},
	{"filectime", php3_filectime, 1},
	{"filegroup", php3_filegroup, 1},
	{"fileinode", php3_fileinode, 1},
	{"filemtime", php3_filemtime, 1},
	{"fileowner", php3_fileowner, 1},
	{"fileperms", php3_fileperms, 1},
	{"filesize", php3_filesize, 1},
	{"filetype", php3_filetype, 1},
	{"stat", php3_stat, 1},

	{"chown", php3_chown, 1},
	{"chgrp", php3_chgrp, 1},
	{"chmod", php3_chmod, 1},
	{"touch", php3_touch, HAVE_UTIME},

	{"linkinfo", php3_linkinfo, HAVE_SYMLINK},
	{"readlink", php3_readlink, HAVE_SYMLINK},
	{"symlink", php3_symlink, HAVE_SYMLINK},
	{"link", php3_link, HAVE_LINK},
	{"unlink", php3_unlink, 1},
	{"rename", php3_rename, 1},

	{"getmyuid", php3_getmyuid, 1},
	{"getmypid", php3_getmypid, 1},
	{"getmyinode", php3_getmyinode, 1},
	{"getlastmod", php3_getlastmod, 1},

	/* logging support */
	{"getlastaccess", php3_getlastaccess, LOGGING},
	{"getlastbrowser", php3_getlastbrowser, LOGGING},
	{"getlastemail", php3_getlastemail, LOGGING},
	{"getlasthost", php3_getlasthost, LOGGING},
	{"getlastref", php3_getlastref, LOGGING},
	{"getlogdir", php3_getlogdir, LOGGING},
	{"getstartlogging", php3_getstartlogging, LOGGING},
	{"gettoday", php3_gettoday, LOGGING},
	{"gettotal", php3_gettotal, LOGGING},
	{"logas", php3_logas, LOGGING},

	/* apache support */
	{"virtual", php3_virtual, APACHE},

#ifndef MSVC5
	{"imagearc", php3_imagearc, HAVE_LIBGD},
	{"imagechar", php3_imagechar, HAVE_LIBGD},
	{"imagecharup", php3_imagecharup, HAVE_LIBGD},
	{"imagecolorallocate", php3_imagecolorallocate, HAVE_LIBGD},
	{"imagecolortransparent", php3_imagecolortransparent, HAVE_LIBGD},
	{"imagecopyresized", php3_imagecopyresized, HAVE_LIBGD},
	{"imagecreate", php3_imagecreate, HAVE_LIBGD},
	{"imagecreatefromgif", php3_imagecreatefromgif, HAVE_LIBGD},
	{"imagedestroy", php3_imagedestroy, HAVE_LIBGD},
	{"imagefill", php3_imagefill, HAVE_LIBGD},
	{"imagefilledpolygon", php3_imagefilledpolygon, HAVE_LIBGD},
	{"imagefilledrectangle", php3_imagefilledrectangle, HAVE_LIBGD},
	{"imagefilltoborder", php3_imagefilltoborder, HAVE_LIBGD},
	{"imagegif", php3_imagegif, HAVE_LIBGD},
	{"imageinterlace", php3_imageinterlace, HAVE_LIBGD},
	{"imageline", php3_imageline, HAVE_LIBGD},
	{"imagepolygon", php3_imagepolygon, HAVE_LIBGD},
	{"imagerectangle", php3_imagerectangle, HAVE_LIBGD},
	{"imagesetpixel", php3_imagesetpixel, HAVE_LIBGD},
	{"imagestring", php3_imagestring, HAVE_LIBGD},
	{"imagestringup", php3_imagestringup, HAVE_LIBGD},
	{"imagesx", php3_imagesxfn, HAVE_LIBGD},
	{"imagesy", php3_imagesyfn, HAVE_LIBGD},
#endif

	{"dbase_open", php3_dbase_open, DBASE},
	{"dbase_create", php3_dbase_create, DBASE},
	{"dbase_close", php3_dbase_close, DBASE},
	{"dbase_numrecords", php3_dbase_numrecords, DBASE},
	{"dbase_numfields", php3_dbase_numfields, DBASE},
	{"dbase_add_record", php3_dbase_add_record, DBASE},
	{"dbase_get_record", php3_dbase_get_record, DBASE},
	{"dbase_delete_record", php3_dbase_delete_record, DBASE},
	{"dbase_pack", php3_dbase_pack, DBASE},

#ifndef MSVC5
	/* old Solid functions */
	{"solid_exec", php3_sql_exec, HAVE_SOLID},
	{"solid_fetchrow", php3_sql_fetchrow, HAVE_SOLID},
	{"solid_result", php3_sql_result, HAVE_SOLID},
	{"solid_freeresult", php3_sql_freeresult, HAVE_SOLID},
	{"solid_connect", php3_sql_connect, HAVE_SOLID},
	{"solid_close", php3_sql_close, HAVE_SOLID},
	{"solid_numrows", php3_sql_numrows, HAVE_SOLID},
	{"solid_numfields", php3_sql_numfields, HAVE_SOLID},
	{"solid_fieldname", php3_sql_fieldname, HAVE_SOLID},
	{"solid_fieldnum", php3_sql_fieldnum, HAVE_SOLID},
#endif

	/* old ODBC functions */
	{"sqlconnect", ODBCconnect, HAVE_IODBC},
	{"sqldisconnect", ODBCdisconnect, HAVE_IODBC},
	{"sqlfetch", ODBCfetch, HAVE_IODBC},
	{"sqlexecdirect", ODBCexecdirect, HAVE_IODBC},
	{"sqlgetdata", ODBCgetdata, HAVE_IODBC},
	{"sqlfree", ODBCfree, HAVE_IODBC},
	{"sqlrowcount", ODBCrowcount, HAVE_IODBC},

	{NULL, NULL, 0}
};


/* this function doesn't check for too many parameters */
PHPAPI int getParameters(HashTable *ht, int param_count,...)
{
	va_list ptr;
	YYSTYPE **param, *tmp = NULL;
	int i;

	va_start(ptr, param_count);

	for (i = 0; i < param_count; i++) {
		param = va_arg(ptr, YYSTYPE **);
		if (hash_index_find(ht, i, (void **) &tmp) == FAILURE) {
			va_end(ptr);
			return FAILURE;
		}
		*param = tmp;
	}
	va_end(ptr);
	return SUCCESS;
}


PHPAPI int getParametersArray(HashTable *ht, int param_count, YYSTYPE **argument_array)
{
	int i;
	YYSTYPE *data;

	for (i = 0; i < param_count; i++) {
		if (hash_index_find(ht, i, (void **) &data) == FAILURE) {
			return FAILURE;
		}
		argument_array[i] = data;
	}
	return SUCCESS;
}

PHPAPI int getThis(YYSTYPE **this) {
	YYSTYPE *data;
	if (hash_find(active_symbol_table, "this", 4, (void **)&data) == FAILURE) {
		return FAILURE;
	}
	*this = data;
	return SUCCESS;
}

PHPAPI int ParameterPassedByReference(HashTable *ht, uint n)
{
	return hash_index_IsPointer(ht, n-1);
}

#ifndef __cplusplus
inline PHPAPI int array_init(YYSTYPE *arg)
{
	arg->value.ht = (HashTable *) emalloc(sizeof(HashTable));
	if (!arg->value.ht || hash_init(arg->value.ht, 0, NULL, YYSTYPE_DESTRUCTOR, 0)) {
		my_phperror(ERRTYPE_ERROR, "Cannot allocate memory for array");
		return FAILURE;
	}
	arg->type = IS_ARRAY;
	return SUCCESS;
}

inline PHPAPI int object_init(YYSTYPE *arg)
{
	arg->value.ht = (HashTable *) emalloc(sizeof(HashTable));
	if (!arg->value.ht || hash_init(arg->value.ht, 0, NULL, YYSTYPE_DESTRUCTOR, 0)) {
		my_phperror(ERRTYPE_ERROR, "Cannot allocate memory for array");
		return FAILURE;
	}
	arg->type = IS_OBJECT;
	return SUCCESS;
}

inline PHPAPI int add_assoc_long(char *key, long n)
{
	YYSTYPE tmp;

	tmp.type = IS_LONG;
	tmp.value.lval = n;
	return hash_update(return_value.value.ht, key, strlen(key), (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_assoc_double(char *key, double d)
{
	YYSTYPE tmp;

	tmp.type = IS_DOUBLE;
	tmp.value.dval = d;
	return hash_update(return_value.value.ht, key, strlen(key), (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_assoc_string(char *key, char *str)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_update(return_value.value.ht, key, strlen(key), (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_assoc_stringl(char *key, char *str, uint length)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_update(return_value.value.ht, key, strlen(key), (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_assoc_function(char *key,void (*function_ptr)(INTERNAL_FUNCTION_PARAMETERS))
{
	YYSTYPE tmp;
	
	tmp.type = IS_INTERNAL_FUNCTION;
	tmp.value.internal_function = (void (*)(INTERNAL_FUNCTION_PARAMETERS)) function_ptr;
	return hash_update(return_value.value.ht, key, strlen(key), (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_index_long(uint index, long n)
{
	YYSTYPE tmp;

	tmp.type = IS_LONG;
	tmp.value.lval = n;
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_index_double(uint index, double d)
{
	YYSTYPE tmp;

	tmp.type = IS_DOUBLE;
	tmp.value.dval = d;
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_index_string(uint index, char *str)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_index_stringl(uint index, char *str, uint length)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE));
}

inline PHPAPI int add_next_index_long(long n)
{
	YYSTYPE tmp;

	tmp.type = IS_LONG;
	tmp.value.lval = n;
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_next_index_double(double d)
{
	YYSTYPE tmp;

	tmp.type = IS_DOUBLE;
	tmp.value.dval = d;
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_next_index_string(char *str)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE));
}


inline PHPAPI int add_next_index_stringl(char *str, uint length)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE));
}

#endif


int hash_internal_functions(void)
{
	internal_function *ptr = internal_functions;
	YYSTYPE phps;
	int i = 0;

	while (ptr->name) {
		phps.offset = i++;
		phps.value.internal_function = (void (*)(INTERNAL_FUNCTION_PARAMETERS))ptr->handler;
		if (ptr->supported) {
			phps.type = IS_INTERNAL_FUNCTION;
		} else {
			phps.type = IS_UNSUPPORTED_FUNCTION;
		}
		if (hash_update(&function_table, ptr->name, strlen(ptr->name), &phps, sizeof(YYSTYPE)) == FAILURE) {
			return FAILURE;
		}
		ptr++;
	}
	return SUCCESS;
}




int module_startup_modules(void *conf)
{
	php3_module *ptr = php3_modules;
	long i=1;

	module_initialized_modules=0;
	
	while (ptr->name) {
		if (ptr->supported && ptr->module_startup_func) {
			if (ptr->module_startup_func(conf) == FAILURE) {
				return FAILURE;
			}
			module_initialized_modules |= i;
		}
		ptr++;
		i <<= 1;
	}
	return SUCCESS;
}


int module_shutdown_modules(void)
{
	php3_module *ptr = php3_modules;
	long i=1;

	while (ptr->name) {
		if (module_initialized_modules & i) {
			if (ptr->supported && ptr->module_shutdown_func) {
				if (ptr->module_shutdown_func() == FAILURE) {
					return FAILURE;
				}
			}
			module_initialized_modules &= ~i;
		}
		ptr++;
		i <<= 1;
	}
	return SUCCESS;
}


int request_startup_modules(void *conf)
{
	php3_module *ptr = php3_modules;
	long i=1;

	request_initialized_modules=0;
	
	while (ptr->name) {
		if (ptr->supported && ptr->request_startup_func) {
			if (ptr->request_startup_func(conf) == FAILURE) {
				return FAILURE;
			}
			request_initialized_modules |= i;
		}
		ptr++;
		i <<= 1;
	}
	return SUCCESS;
}


int request_shutdown_modules()
{
	php3_module *ptr = php3_modules;
	long i=1;

	while (ptr->name) {
		if (request_initialized_modules & i) {
			if (ptr->supported && ptr->request_shutdown_func) {
				if (ptr->request_shutdown_func() == FAILURE) {
					return FAILURE;
				}
			}
			request_initialized_modules &= ~i;
		}
		ptr++;
		i <<= 1;
	}
	return SUCCESS;
}

void _php3_info(void) {
	char *s;
	int i;

	if(!php3_header(0,NULL)) {  /* Don't send anything on a HEAD request */
		return;
	}
	php3_printf("<html><head><title>PHP Version %s</title></head>", PHP_VERSION);
	php3_printf("<body bgcolor=\"#ffffff\"><h1>PHP Version %s</h1>\n", PHP_VERSION);
	PUTS("by <a href=\"mailto:rasmus@lerdorf.on.ca\">Rasmus Lerdorf</a>,\n");
	PUTS("<a href=\"mailto:andi@vipe.technion.ac.il\">Andi Gutmans</a>,\n");
	PUTS("<a href=\"mailto:bourbon@netvision.net.il\">Zeev Suraski</a>,\n");
	PUTS("<a href=\"mailto:ssb@guardian.no\">Stig Bakken</a>,\n");
	PUTS("<a href=\"mailto:shane@caraveo.com\">Shane Caraveo</a>,\n");
	PUTS("<a href=\"mailto:jimw@adventure.com\">Jim Winstead</a>, and countless others.<P>\n");
    PUTS("<TT>This program is free software; you can redistribute it and/or modify\n");
    PUTS("it under the terms of the GNU General Public License as published by\n");
    PUTS("the Free Software Foundation; either version 2 of the License, or\n");
    PUTS("(at your option) any later version.<p>\n");
    PUTS("This program is distributed in the hope that it will be useful,\n");
    PUTS("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
    PUTS("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
    PUTS("GNU General Public License for more details.<p>\n");
    PUTS("You should have received a copy of the GNU General Public License\n");
    PUTS("along with this program; if not, write to the <b>Free Software\n");
    PUTS("Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.</b></TT><p>\n");
	PUTS("<hr><p><b>");
#ifdef WINDOWS
#ifdef WIN32
	PUTS("Windows95/NT Version</b> compiled with MS VC++ V5\n");
#endif
#else
	{
		FILE *fp;
		char buf[256];

		buf[255]=0;
		PUTS("Unix version:</b> ");
		fp = popen("uname -a","r");
		if(fp) {
			while(fgets(buf,255,fp)) {
				PUTS(buf);
			}
			pclose(fp);
		}
	}
#endif
	PUTS("\n");



	/* FIXME - need something to walk through hashed environment tables and display them */


	/* FIXME - also need something to walk through cfg hash table */


#if APACHE
	{
		array_header *env_arr;
		table_entry *env;

		php3_printf("<p><b>HTTP Request:</b> %s<p>\n", php3_rqst->the_request);
		PUTS("<table border=0>\n");
		PUTS(" <tr><th colspan=2>HTTP&nbsp;Request&nbsp;Headers:</th></tr>\n");
		env_arr = table_elts(php3_rqst->headers_in);
		env = (table_entry *)env_arr->elts;
		for (i = 0; i < env_arr->nelts; ++i) {
			if (env[i].key) {
				php3_printf(" <tr><th align=right>%s:</th><td align=left>%s</td></tr>\n",
							env[i].key, env[i].val);
			}
		}
		PUTS(" <tr><th colspan=2>HTTP&nbsp;Response&nbsp;Headers:</th></tr>\n");
		env_arr = table_elts(php3_rqst->headers_out);
		env = (table_entry *)env_arr->elts;
		for(i = 0; i < env_arr->nelts; ++i) {
			if (env[i].key) {
				php3_printf(" <tr><th align=right>%s:</th><td align=left>%s</td></tr>\n",
							env[i].key, env[i].val);
			}
		}
		PUTS("</table>\n\n");
	}
#endif

	PUTS("<hr><p><b>PHP modules and extensions:</b><p>\n");
	PUTS("<table border=2>\n");
	PUTS(" <tr><th>module</th> <th>status</th> <th>additional&nbsp;information</th></tr>\n");
	PUTS(" <tr><th align=left>PHP core</th><td>&nbsp;</td>\n");
#ifndef MSVC5
	PUTS("     <td><tt>CFLAGS=" PHP_CFLAGS "<br>\n");
	PUTS("             HSREGEX=" PHP_HSREGEX "</td></tr>\n");
#endif
	i = 0;
	while (php3_modules[i].name) {
		PUTS(" <tr><th align=left>");
		PUTS(php3_modules[i].name);
		PUTS("</th> <td>");
		if (php3_modules[i].supported) {
			PUTS("<font size=+1><b>enabled</b></font>");
		} else {
			PUTS("<i>disabled</i>");
		}
		PUTS("</td>\n    <td>");
		if(php3_modules[i].info_func && (s=(php3_modules[i].info_func)()) && strlen(s)) {
			PUTS(s);
		} else {
			PUTS("&nbsp;");
		}
		PUTS("</td></tr>\n\n");
		i++;
	}

#if APACHE
	{
		module *modp = NULL;
		char name[64];
		char *p;
		server_rec *serv = php3_rqst->server;
		extern char server_root[MAX_STRING_LEN];
		extern uid_t user_id;
		extern char *user_name;
		extern gid_t group_id;
		extern int max_requests_per_child;

		PUTS(" <tr><th align=left>Apache</th> <td>enabled</td>\n");
		PUTS("     <td>\n");
		php3_printf("<tt>APACHE_INCLUDE=%s<br>\n", PHP_APACHE_INCLUDE);
		php3_printf("APACHE_TARGET=%s<br></tt>\n", PHP_APACHE_TARGET);
		php3_printf("Apache Version: <b>%s</b><br>",SERVER_VERSION);
#ifdef APACHE_RELEASE
		php3_printf("Apache Release: <b>%d</b><br>",APACHE_RELEASE);
#endif
		php3_printf("Apache API Version: <b>%d</b><br>",MODULE_MAGIC_NUMBER);
		php3_printf("Hostname/port: <b>%s:%u</b><br>\n",serv->server_hostname,serv->port);
		php3_printf("User/Group: <b>%s(%d)/%d</b><br>\n",user_name,(int)user_id,(int)group_id);
		php3_printf("Max Requests: <b>per child: %d &nbsp;&nbsp; keep alive: %s &nbsp;&nbsp; max per connection: %d</b><br>\n",max_requests_per_child,serv->keep_alive ? "on":"off", serv->keep_alive_max);
		php3_printf("Timeouts: <b>connection: %d &nbsp;&nbsp; keep-alive: %d</b><br>",serv->timeout,serv->keep_alive_timeout);
		php3_printf("Server Root: <b>%s</b><br>\n",server_root);
		
		PUTS("Loaded modules: ");
		for(modp = top_module; modp; modp = modp->next) {
			strncpy(name, modp->name, sizeof(name) - 1);
			if ((p = strrchr(name, '.'))) {
				*p='\0'; /* Cut off ugly .c extensions on module names */
			}
			PUTS(name);
			if (modp->next) {
				PUTS(", ");
			}
		}
		PUTS("<br>\n");
	}	
#endif
	PUTS("</table>\n");
	PUTS("</body></html>\n");
	
	RETURN_TRUE;
}

void php3_info(INTERNAL_FUNCTION_PARAMETERS) {
	_php3_info();
}

void php3_version(INTERNAL_FUNCTION_PARAMETERS)
{
    RETURN_STRING(PHP_VERSION);
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
