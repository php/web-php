#ifndef _HILIGHT_H
#define _HILIGHT_H

#define HL_COMMENT_COLOR     "#CC3333"    /* red */
#define HL_DEFAULT_COLOR     "#333399"    /* blue */
#define HL_HTML_COLOR        "#000000"    /* black */
#define HL_STRING_COLOR      "#666666"    /* gray */
#define HL_BG_COLOR          "#FFFFFF"    /* white */
#define HL_KEYWORD_COLOR     "#336633"    /* green */

extern void syntax_highlight(Token *next_token);

#endif
