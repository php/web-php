/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   +----------------------------------------------------------------------+
 */


/* $Id: list.c,v 1.34 1997/11/07 01:25:03 zeev Exp $ */


#include "parser.h"
#include "list.h"
#include "modules.h"

#if HAVE_MYSQL
#include "mysql.h"
#endif

#if HAVE_MSQL
/* hacks to allow both msql.h and mysql.h in the same file */
#undef IS_NOT_NULL
#undef IS_PRI_KEY
#include "msql.h"
#endif

#if HAVE_PGSQL
#include "libpq-fe.h"
#include "functions/pgsql.h"
#endif

#if DBASE
#include "dbase/dbf.h"
#endif

#if HAVE_LIBGD
#include <gd.h>
#endif

#if HAVE_SOLID
#include "functions/solid.h"
#endif

#if HAVE_ORACLE
#include "functions/oracle.h"
#endif

#include "functions/db.h"

#if HAVE_DIRENT_H
#include <dirent.h>
#endif

#if MSVC5
#if !(APACHE)
#define NEEDRDH 1
#endif
#include "win32/readdir.h"
#endif


HashTable list, plist;


PHPAPI int php3_list_do_insert(HashTable *list,void *ptr, int type)
{
	int index;
	list_entry le;

	index = hash_next_free_element(list);

	if (index==0) index++;

	le.ptr=ptr;
	le.type=type;
	hash_index_update(list, index, (void *) &le, sizeof(list_entry));
	return index;
}

PHPAPI int php3_list_do_delete(HashTable *list,int id)
{
	return hash_index_del(list, id);
}

PHPAPI void *php3_list_do_find(HashTable *list,int id, int *type)
{
	list_entry *le;

	if (hash_index_find(list, id, (void **) &le)==SUCCESS) {
		*type = le->type;
		return le->ptr;
	} else {
		*type = -1;
		return NULL;
	}
}

PHPAPI void list_entry_destructor(void *ptr)
{
	list_entry *le = (list_entry *) ptr;
	
	switch(le->type) {
#if DBASE
		case LE_DBHEAD:
			close(((dbhead_t *)le->ptr)->db_fd);
			free_dbf_head((dbhead_t *)le->ptr);
			break;
#endif
#if HAVE_MYSQL
		case LE_MYSQL_RESULT:
			mysql_free_result((MYSQL_RES *) le->ptr);
			break;
		case LE_MYSQL_LINK:
			mysql_close((MYSQL *) le->ptr);
			efree(le->ptr);
			break;
		case LE_MYSQL_PLINK: /* persistent link, don't do anything */
			break;
#endif
#if HAVE_MSQL
		case LE_MSQL_RESULT:
			msqlFreeResult((m_result *) le->ptr);
			break;
		case LE_MSQL_LINK:
			msqlClose((int) le->ptr);
			break;
		case LE_MSQL_PLINK:
			break;
#endif
#if HAVE_PGSQL
		case LE_PGSQL_LINK:
			PQfinish((PGconn *) le->ptr);
			break;
		case LE_PGSQL_PLINK:
			break;
		case LE_PGSQL_RESULT:
			PQclear((PGresult *) le->ptr);
			break;
		case LE_PGSQL_LOFP:
			efree((pgLofp *) le->ptr);
			break;
#endif
#if HAVE_LIBGD
		case LE_GD:
			gdImageDestroy((gdImagePtr)le->ptr);
			break;
#endif
		case LE_FP:
			fclose((FILE *)le->ptr);
			break;
		case LE_DIRP:
			closedir((DIR *)le->ptr);
			break;
		case LE_PP:
			pclose((FILE *)le->ptr);
			break;
		case LE_DB:
			_php3_dbmclose((dbm_info *)le->ptr);
			break;
		case LE_INDEX_PTR:
			break;
		case LE_STRING:
			efree((char *)le->ptr);
			break;
#if HAVE_ORACLE
		case LE_ORACONN:
			/* XXX TODO FIXME call ologof() here if the connection is open */
			efree((oraConnection *)le->ptr);
			break;
		case LE_ORACUR:
		{
			oraCursor *cur;

			cur = (oraCursor *)le->ptr;
			/* XXX TODO FIXME call oclose() here if the cursor is open */
			if (cur->columns) {
				efree(cur->columns);
			}
			if (cur->current_query) {
				efree(cur->current_query);
			}
			efree(cur);
			break;
		}
#endif
#if HAVE_SOLID
		case LE_SQLRES:
		{
			SQLResult *res = ((SQLResult *)le->ptr);
			if (res && res->values) {
				efree(res->values);
			}
			if (res) {
				efree(res);
			}
			break;
		}
		case LE_SQLCONN:
		{
			list_entry *le2;
			SQLResult *res;
			SQLConn *conn = (SQLConn *)le->ptr;
			int i, nument = hash_num_elements(&list);

			for (i = 0; i < nument; i++) {
				if (hash_index_find(&list, i, (void **)&le2) == FAILURE ||
					le2->type != LE_SQLRES) {
					continue;
				}
				res = (SQLResult *)le2->ptr;
				if (res->conn == conn) {
					res->conn = NULL;
				}
			}
			break;
		}
#endif
		default:
			my_phperror(ERRTYPE_WARNING,"Unknown list entry type in request shutdown (%d)",le->type);
			break;
	}
}


PHPAPI void plist_entry_destructor(void *ptr)
{
	list_entry *le = (list_entry *) ptr;
	
	switch(le->type) {
#if HAVE_MYSQL
		case LE_MYSQL_PLINK:
			mysql_close((MYSQL *) le->ptr);
			free(le->ptr);
			break;
#endif
#if HAVE_MSQL
		case LE_MSQL_PLINK:
			msqlClose((int) le->ptr);
			break;
#endif
#if HAVE_PGSQL
		case LE_PGSQL_PLINK:
			PQfinish((PGconn *) le->ptr);
			break;
#endif
		default:
			my_phperror(ERRTYPE_WARNING,"Unknown persistent list entry type in module shutdown (%d)",le->type);
			break;
	}
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
