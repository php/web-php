
#include "parser.h"

#include <windows.h>
#include <stdio.h>
#include <httpext.h>

extern int php_isapi_main(LPEXTENSION_CONTROL_BLOCK lpEcb);

BOOL WINAPI GetExtensionVersion (HSE_VERSION_INFO  *version)
{
    version->dwExtensionVersion = MAKELONG( HSE_VERSION_MINOR,
                                            HSE_VERSION_MAJOR );
    strncpy( version->lpszExtensionDesc,
            "PHP v3.0 Beta 1 ISAPI Ext v1",
			HSE_MAX_EXT_DLL_NAME_LEN);

    return TRUE;
}

//
//
//

DWORD WINAPI HttpExtensionProc (LPEXTENSION_CONTROL_BLOCK lpEcb)
{
	return php_isapi_main(lpEcb);
}
   // end HttpExtensionProc


//
// Works like _getenv(), but uses isapi functions instead.
// 
char *isapi_getenv(LPEXTENSION_CONTROL_BLOCK lpEnvcb,LPSTR lpszEnvVar) {
	
	char var[255],dummy;
	DWORD dwLen, dummylen = 1;

	if (!lpszEnvVar)
		return "";
	
	dwLen =lpEnvcb->GetServerVariable(lpEnvcb->ConnID,lpszEnvVar,&dummy,&dummylen);

	if (dwLen == 0)
		return "";
	
	(void)lpEnvcb->GetServerVariable(lpEnvcb->ConnID,lpszEnvVar,var,&dwLen);

	return estrdup(var);
}


void isapi_puts(char *string)
{
	int n;
	n = strlen(string);
	lpPHPcb->WriteClient(lpPHPcb->ConnID,string,&n,0);
	return;
}

void isapi_putc(char character)
{
	int n = 1;
	lpPHPcb->WriteClient(lpPHPcb->ConnID,&character,&n,0);
	return;
}