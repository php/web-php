/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   +----------------------------------------------------------------------+
 */


/* $Id: parser.h,v 1.127 1997/11/03 03:38:51 zeev Exp $ */


#ifndef _PARSER_H
#define _PARSER_H

#if MSVC5
#include "config.w32.h"
#include "win95nt.h"
#if DL_MODULE
#define PHPAPI __declspec(dllimport) 
#else
#define PHPAPI __declspec(dllexport) 
#endif
#else
#include "build-defs.h"
#include "config.h"
#define PHPAPI
#endif
#include "environment.h"

/*
 * Then the ODBC support can use both iodbc and Solid,
 * uncomment this.
 * #define HAVE_ODBC (HAVE_IODBC|HAVE_SOLID)
 */

#include <stdlib.h>
#include <ctype.h>
#if HAVE_UNISTD_H
#include <unistd.h>
#endif
#if HAVE_STDARG_H
#include <stdarg.h>
#else   
# if HAVE_SYS_VARARGS_H
# include <sys/varargs.h>
# endif 
#endif 

#include "hash.h"
#include "alloc.h"
#if REGEX
#include "regex/regex.h"
#define _REGEX_H 1				/* this should stop Apache from loading the system version of regex.h */
#define _RX_H 1  /* Try defining this for Linux to avoid Apache including regex.h */
#else
#include <regex.h>
#endif
#if STDC_HEADERS
#include <string.h>
#else
# ifndef HAVE_MEMCPY
# define memcpy(d, s, n)         bcopy((s), (d), (n))
# endif
#endif

#ifndef HAVE_STRERROR
extern char *strerror(int);
#endif

#define CGI_BINARY (!APACHE && !PHP_ISAPI && !NSAPI)

#if APACHE /* apache httpd */
#include "httpd.h"
#include "http_main.h"
#include "http_core.h"
#include "http_protocol.h"
#include "http_config.h"
#include "mod_php3.h"
#define BLOCK_INTERRUPTIONS block_alarms()
#define UNBLOCK_INTERRUPTIONS unblock_alarms()
extern request_rec *php3_rqst;
#endif

#if PHP_ISAPI
#ifndef CHAR /* avoid language-parser conflicts */
#include <httpext.h>
extern LPEXTENSION_CONTROL_BLOCK lpPHPcb;
extern char *isapi_getenv(LPEXTENSION_CONTROL_BLOCK,char *);    
/* these need to be done */
#define BLOCK_INTERRUPTIONS
#define UNBLOCK_INTERRUPTIONS
#endif
#endif

#if NSAPI
/* NSAPI INCLUDES */
#ifndef CHAR
#include "base/pblock.h"
#include "base/session.h"
#include "frame/req.h"
#include "base/util.h"       /* is_mozilla, getline */
#include "frame/protocol.h"  /* protocol_start_response */
#include "base/file.h"       /* system_fopenRO */
#include "base/buffer.h"     /* filebuf */
#include "frame/log.h"       /* log_error */
#include "base/crit.h"
#include "base/daemon.h"
#define BLOCK_INTERRUPTIONS crit_enter(hLock)
#define UNBLOCK_INTERRUPTIONS crit_exit(hLock)
extern pblock *nspb;
extern Session *nssn;
extern Request *nsrq;
#endif
#endif

#if CGI_BINARY /* CGI version */
#define BLOCK_INTERRUPTIONS
#define UNBLOCK_INTERRUPTIONS
#endif


#if (!HAVE_SNPRINTF)
#define snprintf ap_snprintf
#define vsnprintf ap_vsnprintf
extern int ap_snprintf(char *, size_t, const char *, ...);
extern int ap_vsnprintf(char *, size_t, const char *, va_list);
#endif

extern PHPAPI char *empty_string;

#define PHP_VERSION "3.0a2"
#define EXEC_INPUT_BUF 4096
#define PHP_DOCUMENT_ROOT "/webshare/wwwroot"
#define PHP_USER_DIR "public_html"

#if DEBUG
#ifdef inline
#undef inline
#endif
#define inline
#endif

#if APACHE
#define PUTS(a) rputs((a),php3_rqst)
#define PUTC(a) rputc((a),php3_rqst)
#define PHPWRITE(a,n) rwrite((a),(n),php3_rqst)
#endif
#if PHP_ISAPI  /* the following definitions are *likely* to be wrong! */
extern void isapi_puts(char *string); /* located in isapi.c */
extern void isapi_putc(char character);
#define PUTS(a) isapi_puts(a)
#define PUTC(a) isapi_putc(a)
#define PHPWRITE(a,n) lpPHPcb->WriteClient(lpPHPcb->ConnID,(a),&n,0)
#endif
#if NSAPI
extern void nsapi_writeclient(char *, int);
extern void nsapi_putc(char c);
#define PUTS(a) nsapi_writeclient(a,strlen(a))
#define PUTC(a) nsapi_putc(a)
#define PHPWRITE(a,n) nsapi_writeclient(a, n)
#endif
#if CGI_BINARY
#define PUTS(a) fputs((a),stdout)
#define PUTC(a) fputc((a),stdout)
#define PHPWRITE(a,n) fwrite((a),(n),1,stdout)
#endif

/* will need to add apache once its code is fixed */
#if (NSAPI || PHP_ISAPI)
#define WIN32_SERVER_MOD 1
#endif

#define ERRTYPE_ERROR 0x1
#define ERRTYPE_WARNING 0x2
#define ERRTYPE_PARSE 0x4
#define ERRTYPE_STRICT 0x8
#define ERRTYPE_ALL (ERRTYPE_ERROR | ERRTYPE_WARNING | ERRTYPE_PARSE | ERRTYPE_STRICT)

/* data types */
#define IS_LONG 0x1
#define IS_DOUBLE 0x2
#define IS_STRING 0x4
#define IS_ARRAY 0x8
#define IS_EMPTY 0x10
#define IS_USER_FUNCTION 0x20
#define IS_INTERNAL_FUNCTION 0x40
#define IS_CLASS 0x80
#define IS_OBJECT 0x100
#define IS_UNSUPPORTED_FUNCTION 0x200
#define IS_NULL 0x400

/* general definitions */
#undef SUCCESS
#undef FAILURE
#define SUCCESS 0
#define FAILURE -1				/* this MUST stay a negative number, or it may effect functions! */


/* macros */
#define DO_OR_DIE(retvalue) if (retvalue==FAILURE) { return FAILURE; }
#define MAX(a,b)  (((a)>(b))?(a):(b))
#define MIN(a,b)  (((a)<(b))?(a):(b))
#define STR_FREE(ptr) if (ptr && ptr!=empty_string) { efree(ptr); }
#define COPY_STRING(yy)   (yy).value.strval = (char *) estrndup((yy).value.strval,(yy).strlen)

#define DO_NOTHING 0
#define DO_BREAK 1
#define DO_CONTINUE 2


typedef union {
	unsigned char switched;
	unsigned char included;
	unsigned short function_call_type;
	unsigned char array_write;
} control_structure_data;		/* control-structure data */


typedef union {
	long lval;					/* long value */
	double dval;				/* double value */
	char *strval;				/* string value */
	char chval;					/* char value */
	HashTable *ht;				/* hash table value */
	void (*internal_function)(); /* this would be casted to the right type */
	void *yystype_ptr;  /* used for implementation of multi-dimensional arrays */
} yystype_value;

typedef struct {
	/* Variable information */
	unsigned short type;		/* active type */

	/* Control structures */
	control_structure_data cs_data;
	unsigned int offset;

	yystype_value value;		/* value */
	int strlen;		/* string length */
} _yystype;


#define YYSTYPE _yystype

typedef struct {
	char *fname;
	void (*handler)();
} dlnames;


typedef struct {
	int notused;
/*	int (*dl_addfunc)(void *handle, dlnames *library_functions); 
	void (*my_phperror)(int type, char *format,...);
	int (*getParameters)(HashTable *ht, int param_count,...);
	int (*getParametersArray)(HashTable *ht, int param_count, YYSTYPE **argument_array);
	void (*convert_to_string)(YYSTYPE *arg);
	void (*convert_to_long)(YYSTYPE *arg);
	void (*convert_to_double)(YYSTYPE *arg);
	YYSTYPE (*return_value);
	char *(*empty_string);
 	int (*array_init)(YYSTYPE *arg);
	int (*hash_next_index_insert)(HashTable *ht, void *pData, uint nDataSize);
#if DEBUG
	void *(*_emalloc)(size_t size,char *filename,uint lineno);
	void (*_efree)(void *ptr,char *filename,uint lineno);
	void *(*_ecalloc)(size_t nmemb, size_t size,char *filename,uint lineno);
	void *(*_erealloc)(void *ptr, size_t size,char *filename,uint lineno);
	char *(*_estrdup)(const char *s,char *filename,uint lineno);
	char *(*_estrndup)(const char *s, unsigned int length,char *filename,uint lineno);
#else
	void *(*_emalloc)(size_t size);
	void (*_efree)(void *ptr);
	void *(*_ecalloc)(size_t nmemb, size_t size);
	void *(*_erealloc)(void *ptr, size_t size);
	char *(*_estrdup)(const char *s);
	char *(*_estrndup)(const char *s, unsigned int length);
#endif */
} dl_functions_structure;


#define INTERNAL_FUNCTION_PARAMETERS HashTable *ht, dl_functions_structure *dl_functions
#define INTERNAL_FUNCTION_PARAM_PASSTHRU ht, dl_functions


typedef struct {
	int loop_nest_level;
	int loop_change_type;
	int loop_change_level;
	int returned;
	HashTable *symbol_table;
	HashTable *function_symbol_table;
#if PHP_DEBUGGER
	/* where the function was called from */
	char *filename;
	int lineno;
#endif
	char *function_name;
	unsigned short function_type;
	void (*handler)(INTERNAL_FUNCTION_PARAMETERS);
} FunctionState;



/* global variables */
extern HashTable symbol_table, function_table;
extern HashTable include_names;
extern HashTable *active_symbol_table;
extern int phplineno, current_lineno;
extern int error_reporting,tmp_error_reporting;
extern YYSTYPE *data;
extern PHPAPI FunctionState function_state;
extern int include_count;
extern dl_functions_structure dl_functions_global;
extern PHPAPI YYSTYPE return_value;

extern int phplex(YYSTYPE *phplval);
extern int lex_scan(YYSTYPE *phplval);
extern void phperror(char *error);
extern PHPAPI void my_phperror(int type, char *format,...);
extern int php3_printf(char *format,...);
extern int Debug(char *format,...);
extern int phpparse();
extern int cfgparse();
extern void reset_scanner();
extern void html_putc(char c);

/* functions */
extern int include_file(YYSTYPE *file,int display_source);
extern void eval_string(YYSTYPE *str, YYSTYPE *return_offset);
extern int hash_internal_functions();
extern int hash_environment();
extern int module_startup_modules();
extern int module_shutdown_modules();
extern int request_startup_modules();
extern int request_shutdown_modules();
extern FILE *php3_fopen_url_wrapper(char *path, char *mode);
extern int php3_isurl(char *path);
extern char *php3_strip_url_passwd(char *path);

/* configuration abstraction layer */
extern int cfg_get_long(char *varname, long *result);
extern int cfg_get_double(char *varname, double *result);
extern int cfg_get_string(char *varname, char **result);

typedef struct php3_ini {
	char *smtp;
	long errors;
	long  magicquotes;
	char *docroot;
	char *userdir;
	long safemode;
	long track_vars;
	char *safemodeexecdir;
	char *cgiext;
	char *isapiext;
	char *nsapiext;
	char *includepath;
	char *autoprependfile;
	char *autoappendfile;
	char *uploadtmpdir;
	char *dldir;
	long  short_open_tag;
	long  logging;
	long  logdbm;
	long  logsql;
	char *logdbmdir;
	char *debughost;
	long  debugport;

	/* sql stuff */
	long sql_allow_persistent;
	long sql_max_persistent;
	long sql_max_links;
#if HAVE_MYSQL
	long mysql_allow_persistent;
	long mysql_max_persistent;
	long mysql_max_links;
#endif
#if HAVE_MSQL
	long msql_allow_persistent;
	long msql_max_persistent;
	long msql_max_links;
#endif
#if HAVE_PGSQL
	long pgsql_allow_persistent;
	long pgsql_max_persistent;
	long pgsql_max_links;
#endif
#if DISPLAY_SOURCE_SUPPORT
	char *highlight_comment;
	char *highlight_default;
	char *highlight_html;
	char *highlight_string;
	char *highlight_bg;
	char *highlight_keyword;
#endif
} php3_ini_structure;

extern php3_ini_structure php3_ini;

#include "stack.h"
#include "operators.h"
#include "token_cache.h"
#include "variables.h"

#define RETVAL_LONG(l) { return_value.type = IS_LONG; \
                         return_value.value.lval = l; }
#define RETVAL_DOUBLE(d) { return_value.type = IS_DOUBLE; \
                           return_value.value.dval = d; }
#define RETVAL_STRING(s) { return_value.strlen = strlen(s); \
                           return_value.value.strval = estrndup(s,return_value.strlen); \
                           return_value.type = IS_STRING; }
#define RETVAL_STRINGL(s,l) { return_value.strlen = l; \
                              return_value.value.strval = estrdup(s); \
                              return_value.type = IS_STRING; }

#define RETVAL_FALSE  {var_reset(&return_value);}
#define RETVAL_TRUE   RETVAL_LONG(1L)

#define RETURN_LONG(l) { return_value.type = IS_LONG; \
                         return_value.value.lval = l; \
                         return; }
#define RETURN_DOUBLE(d) { return_value.type = IS_DOUBLE; \
                           return_value.value.dval = d; \
                           return; }
#define RETURN_STRING(s) { return_value.strlen = strlen(s); \
                           return_value.value.strval = estrdup(s); \
                           return_value.type = IS_STRING; \
                           return; }
#define RETURN_STRINGL(s,l) { return_value.strlen = l; \
                              return_value.value.strval = estrndup(s,l); \
                              return_value.type = IS_STRING; \
                              return; }

/*#define RETURN_NEG    RETURN_LONG(-1L) */
#define RETURN_ONE    RETURN_LONG(1L)
#define RETURN_ZERO   RETURN_LONG(0L)
#define RETURN_FALSE  {var_reset(&return_value); return;}
#define RETURN_TRUE   RETURN_LONG(1L)

#define SET_VAR_STRING(n,v) { \
                           { \
                               YYSTYPE var; \
							   char *str=v; /* prevent 'v' from being evaluated more than once */ \
                               var.value.strval = (str); \
                               var.strlen = strlen((str)); \
                               var.type = IS_STRING; \
                               hash_update(&symbol_table, (n), strlen((n)), &var, sizeof(YYSTYPE)); \
                           } \
                       }
#define SET_VAR_LONG(n,v) { \
                           { \
                               YYSTYPE var; \
                               var.value.lval = (v); \
                               var.type = IS_LONG; \
                               hash_update(&symbol_table, (n), strlen((n)), &var, sizeof(YYSTYPE)); \
                           } \
                       }
#define SET_VAR_DOUBLE(n,v) { \
                           { \
                               YYSTYPE var; \
                               var.value.dval = (v); \
                               var.type = IS_DOUBLE; \
                               hash_update(&symbol_table, (n), strlen((n)), &var, sizeof(YYSTYPE)); \
                           } \
                       }

#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
