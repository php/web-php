Place regex.dll, libdb.dll and mSQL.dll into your system directory.

In your autoexec.bat file, add this line:

SET PHPRC=\windows\php3.ini

and place your php3.ini file in whatever directory you specify.

msql1.dll, calendar.dll and msql2.dll must be located in the
same directory as php3.exe, or you must specify where these files
are located either in your php3.ini file, or in the php3 script.

You can load modules at startup via the ini file by placing a line like:
extension=dbase.dll
in your ini file,
OR
To use a loadable module in your script you must have the following
command:

dl("dbase.dll");

For further instructions, html manual, reporting bugs, etc., 
see www.php.net

PHP and Apache CGI
PHP will look under your os directory (\windows or \winnt) for php3.ini

PHP ISAPI Module
This module IS NOT THREAD SAFE.  Do not use in any production environment.
It is included here for experimental purposes only!  Setting up this module
for MSPWS or IIS is the same as setting up the cgi module in the registry.
See the php email list archives for details.
