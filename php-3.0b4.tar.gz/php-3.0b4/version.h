#define PHP_VERSION "3.0b4"
