#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	CHAR	258
#define	NUMBER	259
#define	SECTEND	260
#define	SCDECL	261
#define	XSCDECL	262
#define	NAME	263
#define	PREVCCL	264
#define	EOF_OP	265
#define	OPTION_OP	266
#define	OPT_OUTFILE	267
#define	OPT_PREFIX	268
#define	OPT_YYCLASS	269
#define	CCE_ALNUM	270
#define	CCE_ALPHA	271
#define	CCE_BLANK	272
#define	CCE_CNTRL	273
#define	CCE_DIGIT	274
#define	CCE_GRAPH	275
#define	CCE_LOWER	276
#define	CCE_PRINT	277
#define	CCE_PUNCT	278
#define	CCE_SPACE	279
#define	CCE_UPPER	280
#define	CCE_XDIGIT	281


extern YYSTYPE yylval;
