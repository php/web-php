#ifndef _FLEX_TLS_H_
#define _FLEX_TLS_H_
/* platform specific defines */

# if (WIN32|WINNT )
#include <windows.h>
#	define YY_MUTEX_T HANDLE
#	define YY_MUTEX_TIMEOUT 5 /*milliseconds*/
#	define YY_CREATE_MUTEX(a,b) (a=CreateMutex(NULL,FALSE,"PHP_FLEX"))
#	define YY_MUTEX_DESTROY(a) CloseHandle(a)
#	define YY_SET_MUTEX(a) WaitForSingleObject(a,YY_MUTEX_TIMEOUT)
#	define YY_FREE_MUTEX(a) ReleaseMutex(a)
#	define YY_TLS_T DWORD
#	define YY_TLS_ALLOC(a) (a=TlsAlloc())
#	define YY_TLS_NOT_ALLOCED 0xFFFFFFFF
#	define YY_TLS_GET_DATA(a,b) b=TlsGetValue(a)
#	define YY_TLS_SET_DATA(a,b) TlsSetValue(a,b)
#	define YY_TLS_FREE(a) TlsFree(a)
#	define YY_TLS_MALLOC(a) LocalAlloc(LPTR, a)
#	define YY_TLS_MFREE(a) LocalFree((HLOCAL) a)

# else /*PTHREADS this all needs to be scrutinized before use! */
#	define YY_MUTEX_T pthread_mutex_t *
#	define YY_MUTEX_TIMEOUT 5 /*milliseconds*/
#	define YY_CREATE_MUTEX(a,b) pthread_mutex_init(a,b)
#	define YY_MUTEX_DESTROY(a) pthread_mutex_destroy(a)
#	define YY_SET_MUTEX(a) pthread_mutex_lock(a)
#	define YY_FREE_MUTEX(a) pthread_mutex_unlock(a)
#	define YY_TLS_T long
#	define YY_TLS_ALLOC(a)
#	define YY_TLS_NOT_ALLOCED NULL
#	define YY_TLS_GET_DATA(a,b) b=pthread_getspecific(a)
#	define YY_TLS_SET_DATA(a,b) pthread_setspecific(a,b)
#	define YY_TLS_SET_DATA(a)
#	define YY_TLS_MALLOC(a) malloc(a)
#	define YY_TLS_MFREE(a) free(a)
# endif

# define YY_THREAD


# define YY_TLS_THREAD_INIT(a,b) ((b=(flex_globals *)YY_TLS_MALLOC(sizeof(flex_globals))) && (YY_TLS_SET_DATA(a, (void *) b)))
# define YY_TLS_THREAD_FREE(a) (if(a)YY_TLS_MFREE(a))
# define YY_TLS_PROC_STARTUP(a) (YY_TLS_ALLOC(a)!=YY_TLS_NOT_ALLOCED)
# define YY_TLS_PROC_SHUTDOWN(a) if(a)YY_TLS_FREE(a)
# define YY_TLS_VARS flex_globals *YY_TLS_GET_DATA(yyLexTlsIndex,yy_gbl);

#endif