/*
   PROPRIETARY SOURCE CODE OF NETSCAPE COMMUNICATIONS CORPORATION.

   Copyright (c) 1994, 1995, 1996, and 1997 Netscape Communications
   Corporation.  All rights reserved.

   Use of this Source Code is subject to the terms of the applicable
   license agreement from Netscape Communications Corporation.
*/

#ifndef PUBLIC_FRAME_LOG_H
#define PUBLIC_FRAME_LOG_H

/*
 * File:        log.h
 *
 * Description:
 *
 *      Deprecated include file.
 */

#ifndef PUBLIC_NSAPI_H
#include "../nsapi.h"
#endif /* !PUBLIC_NSAPI_H */

#endif /* !PUBLIC_FRAME_LOG_H */
