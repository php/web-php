/*
   PROPRIETARY SOURCE CODE OF NETSCAPE COMMUNICATIONS CORPORATION.

   Copyright (c) 1996 and 1997 Netscape Communications Corporation.
   All rights reserved.

   Use of this Source Code is subject to the terms of the applicable
   license agreement from Netscape Communications Corporation.
*/

/*
   PROPRIETARY SOURCE CODE OF NETSCAPE COMMUNICATIONS CORPORATION.

   Copyright (c) 1996 and 1997 Netscape Communications Corporation.
   All rights reserved.

   Use of this Source Code is subject to the terms of the applicable
   license agreement from Netscape Communications Corporation.
*/

