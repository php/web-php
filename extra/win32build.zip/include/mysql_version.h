/* Copyright Abandoned 1996 TCX DataKonsult AB & Monty Program KB & Detron HB
   This file is public domain and comes with NO WARRANTY of any kind */

/* Version numbers for protocol & mysqld */

#define PROTOCOL_VERSION	10

#define MYSQL_SERVER_VERSION	"3.22.9-beta"
#define FRM_VER			6
#define MYSQL_VERSION_ID	32209
