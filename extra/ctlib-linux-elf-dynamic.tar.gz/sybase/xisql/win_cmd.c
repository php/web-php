/****************************************************************************

NAME
	win_cmd - command window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_cmd.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** local vars
*/
static Widget			cmd_window;

/*
** local routines
*/
static void do_kill(Widget w, XtPointer cc, XtPointer cd);
static void do_quit(Widget w, XtPointer cc, XtPointer cd);
static void do_cancel(Widget w, XtPointer cc, XtPointer cd);
static void do_close(Widget w, XtPointer cc, XtPointer cd);

/*
** table structure for commands
*/
typedef struct _wincmds
{
	char		*name;
	Widget		button;
	XtCallbackProc	callback;
	XtPointer	client_data;
} WinCmds;

/*
** commands used in command panel
*/
static WinCmds cmd_list[] = 
{
    { "Kill",		0, 	do_kill,	NULL },
    { "Quit",		0, 	do_quit,	NULL },
    { "Connect",	0, 	win_connect,	NULL },
    { "Close",		0, 	do_close,	NULL },
    { "Cancel",		0, 	do_cancel,	NULL },
    { "Lang",		0, 	win_lang,	NULL },
    { "Cursor",		0, 	win_cursor,	NULL },
    { "Dynamic",	0, 	win_dynamic,	NULL },
    { "Rpc",		0, 	win_rpc,	NULL },
    { "Options",	0, 	win_opt,	NULL },
    { "ConProps",	0, 	win_prop,	(XtPointer)CM_CON_PROP },
    { "CtxProps",	0, 	win_prop,	(XtPointer)CM_CTX_PROP },
    { "ReqCap",		0, 	win_caps,	(XtPointer)CS_CAP_REQUEST },
    { "RespCap",	0, 	win_caps,	(XtPointer)CS_CAP_RESPONSE },
    { "Debug",		0, 	win_debug,	NULL },
};

#define MAX_COMMANDS		(sizeof (cmd_list) / sizeof (cmd_list[0]))

/****************************************************************************
**
** win_cmd_create - initialize input window
**
****************************************************************************/
int 
win_cmd_create(Widget parent)
{
    Arg 	args[MAXARGS];
    Cardinal 	n;
    int		i;

    n = 0;
    cmd_window = XtCreateManagedWidget("commandWindow", boxWidgetClass,
					parent, args, n);

    /*
    ** Create command buttons
    */
    for (i = 0; i < MAX_COMMANDS; i++)
    {
	XtSetArg(args[n], XtNwidth, BUTTON_WIDTH(cmd_list[i].name));
	n++;
    	cmd_list[i].button = XtCreateManagedWidget(cmd_list[i].name,
				commandWidgetClass, cmd_window, args, n);
	XtAddCallback(cmd_list[i].button, XtNcallback,
			cmd_list[i].callback, cmd_list[i].client_data);
    }

    return SUCCESS;
}

/****************************************************************************
**
** do_kill - terminate program
**
****************************************************************************/
/*ARGSUSED*/
static void
do_kill(Widget w, XtPointer cc, XtPointer cd)
{
    exit(0);
}

/****************************************************************************
**
** do_quit - cleanup and exit program
**
****************************************************************************/
/*ARGSUSED*/
static void
do_quit(Widget w, XtPointer cc, XtPointer cd)
{
    if (cm_exit() != CM_SUCCESS)
    {
	window_bell(0);
	win_msg("Exit of OC-Lib failed (did you close the connection?)\n");
	win_msg("You can use Kill to terminate program\n");
	return;
    }
    exit(0);
}

/****************************************************************************
**
** do_close - do_close
**
****************************************************************************/
/*ARGSUSED*/
static void
do_close(Widget w, XtPointer cc, XtPointer cd)
{
    cm_close();
}

/****************************************************************************
**
** do_cancel - do_cancel
**
****************************************************************************/
/*ARGSUSED*/
static void
do_cancel(Widget w, XtPointer cc, XtPointer cd)
{
    cm_cancel();
}
