/****************************************************************************

NAME
	win_dbg - debug window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_dbg.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#include	<sys/types.h>
#include	<unistd.h>
#include	<fcntl.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** define debug command button states
*/
#define DBG_ASYNC		1
#define DBG_ERROR		2
#define DBG_MEM			3
#define DBG_PROTOCOL		4
#define DBG_API_STATES		5
#define DBG_PROTOCOL_STATES	6
#define DBG_NETWORK		7
#define DBG_MAXTOGGLE		8

/*
** buttons defined
*/
static Widget		dbg_popup;
#if DBG_FILE_IMPLEMENTED
static Widget		dbg_output;
#endif
static Widget		dbg_setfile;
static Widget		dbg_file;
static Widget		dbg_setprotofile;
static Widget		dbg_protofile;
static Widget		dbg_cmd[DBG_MAXTOGGLE];

#define DBG_MAX_BUFF	2048

#if DBG_FILE_IMPLEMENTED
/*
** vars for debug file support
*/
static int		dbg_fd = -1;
static char 		dbg_file_buf[MAX_FILE_NAME_LEN];
#endif

/*
** local routines
*/
static void do_set(Widget w, XtPointer cc, XtPointer cd);
static void do_update(Widget w, XtPointer cc, XtPointer cd);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_debug - initialize debug window
**
****************************************************************************/
void 
win_debug(Widget parent, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    Widget	DebugInput;
    Widget	Box;
    Widget	DbgCommands;
    Widget	Set;
    Widget	Dismiss;
    Widget	Update;
    char	*buttonname;

    dbg_popup = XtNameToWidget(parent, "Debug Input Window");

    if (!dbg_popup)
    {
	win_dbg_file_init();

	XtSetArg(args[0], XtNinput, True);
	XtSetArg(args[1], XtNwidth, 770);
#if DBG_FILE_IMPLEMENTED
	XtSetArg(args[2], XtNheight, 400);
#else
	XtSetArg(args[2], XtNheight, 120);
#endif
	dbg_popup = XtCreatePopupShell("Debug Input Window",
					transientShellWidgetClass,
					parent, args, 3);

	/*
	** create a form for the debug info
	*/
	XtSetArg(args[0], XtNdefaultDistance, 2);
	DebugInput = XtCreateManagedWidget("DebugInput", formWidgetClass,
			dbg_popup, args, 1);

	/*
	** debug output widget
	*/
#if DBG_FILE_IMPLEMENTED
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNinput, False);
	XtSetArg(args[3], XtNheight, 300);
	XtSetArg(args[4], XtNwidth, 700);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNtype, XawAsciiFile);
	XtSetArg(args[7], XtNstring, dbg_file_buf);
	XtSetArg(args[8], XtNeditType, XawtextAppend);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollAlways);
	dbg_output = XtCreateManagedWidget("DebugInput", asciiTextWidgetClass,
			DebugInput, args, 10);

	/*
	** form for commands
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 700);
	XtSetArg(args[2], XtNfromVert, dbg_output);
#else
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 700);
	XtSetArg(args[2], XtNfromVert, NULL);
#endif
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	DbgCommands = XtCreateManagedWidget("DbgCommands", formWidgetClass,
			DebugInput, args, 7);

	/*
	** debug file name button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNhighlightThickness, 1);
	XtSetArg(args[3], XtNstate, False);
	XtSetArg(args[4], XtNlabel, "Debug File");
	XtSetArg(args[5], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[6], XtNwidth, 120);
	dbg_setfile = XtCreateManagedWidget("DbgCommands", toggleWidgetClass,
			DbgCommands, args, 7);

	/*
	** debug file input string 
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, dbg_setfile);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 400);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	dbg_file = XtCreateManagedWidget("DbgCommands", asciiTextWidgetClass,
			DbgCommands, args, 10);

	/*
	** protocol file name button
	*/
	XtSetArg(args[0], XtNfromVert, dbg_setfile);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNhighlightThickness, 1);
	XtSetArg(args[3], XtNstate, False);
	XtSetArg(args[4], XtNlabel, "Protocol File");
	XtSetArg(args[5], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[6], XtNwidth, 120);
	dbg_setprotofile = XtCreateManagedWidget("DbgCommands", toggleWidgetClass,
			DbgCommands, args, 7);

	/*
	** debug protocol file input string 
	*/
	XtSetArg(args[0], XtNfromVert, dbg_file);
	XtSetArg(args[1], XtNfromHoriz, dbg_setprotofile);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 400);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	dbg_protofile = XtCreateManagedWidget("DbgCommands", asciiTextWidgetClass,
			DbgCommands, args, 10);

	/*
	** debug command buttons
	*/
	buttonname = "Async";
	XtSetArg(args[0], XtNfromVert, dbg_setprotofile);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[6], XtNstate, False);
	XtSetArg(args[7], XtNsensitive, True);
	dbg_cmd[DBG_ASYNC] = XtCreateManagedWidget("DbgCommands",
			toggleWidgetClass, DbgCommands, args, 8);

	buttonname = "Error";
	XtSetArg(args[1], XtNfromHoriz, dbg_cmd[DBG_ASYNC]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[7], XtNsensitive, True);
	dbg_cmd[DBG_ERROR] = XtCreateManagedWidget("DbgCommands",
			toggleWidgetClass, DbgCommands, args, 8);

	buttonname = "Memory";
	XtSetArg(args[1], XtNfromHoriz, dbg_cmd[DBG_ERROR]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[7], XtNsensitive, True);
	dbg_cmd[DBG_MEM] = XtCreateManagedWidget("DbgCommands",
			toggleWidgetClass, DbgCommands, args, 8);

	buttonname = "Protocol";
	XtSetArg(args[1], XtNfromHoriz, dbg_cmd[DBG_MEM]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[7], XtNsensitive, False);
	dbg_cmd[DBG_PROTOCOL] = XtCreateManagedWidget("DbgCommands",
			toggleWidgetClass, DbgCommands, args, 8);

	buttonname = "Api States";
	XtSetArg(args[1], XtNfromHoriz, dbg_cmd[DBG_PROTOCOL]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[7], XtNsensitive, True);
	dbg_cmd[DBG_API_STATES] = XtCreateManagedWidget("DbgCommands",
			toggleWidgetClass, DbgCommands, args, 8);

	buttonname = "Tds States";
	XtSetArg(args[1], XtNfromHoriz, dbg_cmd[DBG_API_STATES]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[7], XtNsensitive, True);
	dbg_cmd[DBG_PROTOCOL_STATES] = XtCreateManagedWidget("DbgCommands",
			toggleWidgetClass, DbgCommands, args, 8);

	buttonname = "Network";
	XtSetArg(args[1], XtNfromHoriz, dbg_cmd[DBG_PROTOCOL_STATES]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[7], XtNsensitive, True);
	dbg_cmd[DBG_NETWORK] = XtCreateManagedWidget("DbgCommands",
			toggleWidgetClass, DbgCommands, args, 8);

	/*
	** box for buttons
	*/
	XtSetArg(args[0], XtNheight, 50);
	XtSetArg(args[1], XtNwidth, 300);
	XtSetArg(args[2], XtNfromVert, DbgCommands);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 0);
	XtSetArg(args[5], XtNhSpace, 10);
	XtSetArg(args[6], XtNvSpace, 2);
	Box = XtCreateManagedWidget("Box", boxWidgetClass,
			DebugInput, args, 7);

	buttonname = "Dismiss";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Dismiss = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Dismiss, XtNcallback, do_dismiss, NULL);

	buttonname = "Set";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Set = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Set, XtNcallback, do_set, NULL);

	buttonname = "Update";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Update = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Update, XtNcallback, do_update, NULL);
    }

    window_popup(parent, dbg_popup);

    return;
}

/****************************************************************************
**
** do_set - do_set
**
****************************************************************************/
/*ARGSUSED*/
static void
do_set(Widget w, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    String	m;
    Boolean	b;
    char	*file;
    CS_INT	smask = 0;
    CS_INT	cmask = 0;

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(dbg_setfile, args, 1);
    if (b == True)
    {
	XtSetArg(args[0], XtNstring, &m);
	XtGetValues(dbg_file, args, 1);
	file = m;
	cm_debug(CS_SET_DBG_FILE, smask, (void *)file);
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(dbg_setprotofile, args, 1);
    if (b == True)
    {
	XtSetArg(args[0], XtNstring, &m);
	XtGetValues(dbg_protofile, args, 1);
	file = m;
	cm_debug(CS_SET_PROTOCOL_FILE, smask, (void *)file);
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(dbg_cmd[DBG_ASYNC], args, 1);
    smask |= (b == True) ? CS_DBG_ASYNC : 0;
    cmask |= (b != True) ? CS_DBG_ASYNC : 0;

    XtGetValues(dbg_cmd[DBG_ERROR], args, 1);
    smask |= (b == True) ? CS_DBG_ERROR : 0;
    cmask |= (b != True) ? CS_DBG_ERROR : 0;

    XtGetValues(dbg_cmd[DBG_MEM], args, 1);
    smask |= (b == True) ? CS_DBG_MEM : 0;
    cmask |= (b != True) ? CS_DBG_MEM : 0;

    XtGetValues(dbg_cmd[DBG_PROTOCOL], args, 1);
    smask |= (b == True) ? CS_DBG_PROTOCOL : 0;
    cmask |= (b != True) ? CS_DBG_PROTOCOL : 0;

    XtGetValues(dbg_cmd[DBG_API_STATES], args, 1);
    smask |= (b == True) ? CS_DBG_API_STATES : 0;
    cmask |= (b != True) ? CS_DBG_API_STATES : 0;

    XtGetValues(dbg_cmd[DBG_PROTOCOL_STATES], args, 1);
    smask |= (b == True) ? CS_DBG_PROTOCOL_STATES : 0;
    cmask |= (b != True) ? CS_DBG_PROTOCOL_STATES : 0;

    XtGetValues(dbg_cmd[DBG_NETWORK], args, 1);
    smask |= (b == True) ? CS_DBG_NETWORK : 0;
    cmask |= (b != True) ? CS_DBG_NETWORK : 0;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(dbg_file, args, 1);
    file = m;

    cm_debug(CS_SET_FLAG, smask, (void *)file);

    cm_debug(CS_CLEAR_FLAG, cmask, (void *)file);

    window_popdown(dbg_popup);
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    window_popdown(dbg_popup);
}

/****************************************************************************
**
** do_update - do_update
**
****************************************************************************/
/*ARGSUSED*/
static void
do_update(Widget w, XtPointer cc, XtPointer cd)
{
    win_dbg_file_update(NULL, NULL, NULL);
}

/****************************************************************************
**
** win_dbg_file_init - initialize debug file output
**
****************************************************************************/
int
win_dbg_file_init()
{
#if DBG_FILE_IMPLEMENTED
    sprintf(dbg_file_buf, "/tmp/xisql.%d", getpid());
    dbg_fd = open(dbg_file_buf, O_RDWR|O_CREAT, 0666);
    if (dbg_fd < 0)
    {
	perror("win_dbg_file_init: open failed");
	abort();
    }
    (void)dup2(dbg_fd, 0);
    (void)dup2(dbg_fd, 1);

    dbg_fd = fcntl(dbg_fd, F_SETFL, O_SYNC|O_APPEND);
    if (dbg_fd < 0)
    {
	perror("win_dbg_file_init: fcntl failed");
	abort();
    }
#endif

    return SUCCESS;
}

/****************************************************************************
**
** win_dbg_file_close - clean up debug file output
**
****************************************************************************/
int
win_dbg_file_close()
{
#if DBG_FILE_IMPLEMENTED
    if (unlink(dbg_file_buf) < 0)
    {
	perror("win_dbg_file_close: unlink failed");
	abort();
    }
#endif

    return SUCCESS;
}

/****************************************************************************
**
** win_dbg_file_update - initialize debug file output
**
****************************************************************************/
void
win_dbg_file_update(XtPointer cd, int *s, XtInputId *id)
{
#if DBG_FILE_IMPLEMENTED
    Arg 	args[MAXARGS];

    fsync(dbg_fd);

    XtSetArg(args[0], XtNtype, XawAsciiFile);
    XtSetArg(args[1], XtNstring, dbg_file_buf);
    XtSetValues(dbg_output, args, 2);
#endif

    return;
}
