/****************************************************************************

NAME
	win_prop - prop window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_prop.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** Property types we can display
*/
#define PROP_STRING	1
#define PROP_BINARY	2
#define PROP_INT	3
#define PROP_HEX	4

typedef struct _props
{
	char		*name;
	CS_INT		property;
	int		prop_type;
	Widget		prop_enable;
	Widget		prop_string;
} Props;

/*
** connection property table
*/
static Props conprops_table[] =
{
    { "ANSI_BINDS",		CS_ANSI_BINDS,		PROP_INT, 0, 0 },
    { "APPNAME",		CS_APPNAME,		PROP_STRING, 0, 0 },
    { "ASYNC_NOTIFS",		CS_ASYNC_NOTIFS,	PROP_INT, 0, 0 },
    { "BULK_LOGIN",		CS_BULK_LOGIN,		PROP_INT, 0, 0 },
    { "CHARSETCNV",		CS_CHARSETCNV,		PROP_INT, 0, 0 },
    { "COMMBLOCK",		CS_COMMBLOCK,		PROP_BINARY, 0, 0 },
    { "CON_STATUS",		CS_CON_STATUS,		PROP_HEX, 0, 0 },
    { "DIAG_TIMEOUT",		CS_DIAG_TIMEOUT,	PROP_INT, 0, 0 },
    { "DISABLE_POLL",		CS_DISABLE_POLL,	PROP_INT, 0, 0 },
    { "EED_CMD",		CS_EED_CMD,		PROP_BINARY, 0, 0 },
    { "ENDPOINT",		CS_ENDPOINT,		PROP_BINARY, 0, 0 },
    { "EXPOSE_FMTS",		CS_EXPOSE_FMTS,		PROP_INT, 0, 0 },
    { "EXTRA_INF",		CS_EXTRA_INF,		PROP_INT, 0, 0 },
    { "HIDDEN_KEYS",		CS_HIDDEN_KEYS,		PROP_INT, 0, 0 },
    { "HOSTNAME",		CS_HOSTNAME,		PROP_STRING, 0, 0 },
    { "LOC_PROP",		CS_LOC_PROP,		PROP_BINARY, 0, 0 },
    { "LOGIN_STATUS",		CS_LOGIN_STATUS,	PROP_INT, 0, 0 },
    { "NETIO",			CS_NETIO,		PROP_INT, 0, 0 },
    { "NO_TRUNCATE",		CS_NO_TRUNCATE,		PROP_INT, 0, 0 },
    { "NOINTERRUPT",		CS_NOINTERRUPT,		PROP_INT, 0, 0 },
    { "NOTIF_CMD",		CS_NOTIF_CMD,		PROP_BINARY, 0, 0 },
    { "PACKETSIZE",		CS_PACKETSIZE,		PROP_INT, 0, 0 },
    { "PARENT_HANDLE",		CS_PARENT_HANDLE,	PROP_BINARY, 0, 0 },
    { "PASSWORD",		CS_PASSWORD,		PROP_STRING, 0, 0 },
    { "SEC_CHALLENGE",		CS_SEC_CHALLENGE,	PROP_INT, 0, 0 },
    { "SEC_ENCRYPTION",		CS_SEC_ENCRYPTION,	PROP_INT, 0, 0 },
    { "SEC_NEGOTIATE",		CS_SEC_NEGOTIATE,	PROP_INT, 0, 0 },
    { "SERVERNAME",		CS_SERVERNAME,		PROP_STRING, 0, 0 },
    { "TDS_VERSION",		CS_TDS_VERSION,		PROP_INT, 0, 0 },
    { "TEXTLIMIT",		CS_TEXTLIMIT,		PROP_INT, 0, 0 },
    { "TRANSACTION_NAME",	CS_TRANSACTION_NAME,	PROP_STRING, 0, 0 },
    { "USERDATA",		CS_USERDATA,		PROP_BINARY, 0, 0 },
    { "USERNAME",		CS_USERNAME,		PROP_STRING, 0, 0 },
};

#define MAX_CON_PROPS 	(sizeof (conprops_table) / sizeof (conprops_table[0]))

/*
** property table
*/
static Props ctxprops_table[] =
{
    { "ANSI_BINDS",		CS_ANSI_BINDS,		PROP_INT, 0, 0 },
    { "EXPOSE_FMTS",		CS_EXPOSE_FMTS,		PROP_INT, 0, 0 },
    { "EXTRA_INF",		CS_EXTRA_INF,		PROP_INT, 0, 0 },
    { "HIDDEN_KEYS",		CS_HIDDEN_KEYS,		PROP_INT, 0, 0 },
    { "IFILE",			CS_IFILE,		PROP_STRING, 0, 0 },
    { "HOSTNAME",		CS_HOSTNAME,		PROP_STRING, 0, 0 },
    { "LOGIN_TIMEOUT",		CS_LOGIN_TIMEOUT,	PROP_INT, 0, 0 },
    { "MAX_CONNECT",		CS_MAX_CONNECT,		PROP_INT, 0, 0 },
    { "MEM_POOL",		CS_MEM_POOL,		PROP_INT, 0, 0 },
    { "NETIO",			CS_NETIO,		PROP_INT, 0, 0 },
    { "NOINTERRUPT",		CS_NOINTERRUPT,		PROP_INT, 0, 0 },
    { "TEXTLIMIT",		CS_TEXTLIMIT,		PROP_INT, 0, 0 },
    { "TIMEOUT",		CS_TIMEOUT,		PROP_INT, 0, 0 },
    { "USER_ALLOC",		CS_USER_ALLOC,		PROP_BINARY, 0, 0 },
    { "USER_FREE",		CS_USER_FREE,		PROP_BINARY, 0, 0 },
    { "VERSION",		CS_VERSION,		PROP_INT, 0, 0 },
    { "VER_STRING",		CS_VER_STRING,		PROP_STRING, 0, 0 },
};

#define MAX_CTX_PROPS 	(sizeof (ctxprops_table) / sizeof (ctxprops_table[0]))

static Props cmdprops_table[] =
{
    { "CUR_ID",			CS_CUR_ID,		PROP_INT, 0, 0 },
    { "CUR_NAME",		CS_CUR_NAME,		PROP_STRING, 0, 0 },
    { "CUR_ROWCOUNT",		CS_CUR_ROWCOUNT,	PROP_INT, 0, 0 },
    { "CUR_STATUS",		CS_CUR_STATUS,		PROP_HEX, 0, 0 },
    { "HIDDEN_KEYS",		CS_HIDDEN_KEYS,		PROP_INT, 0, 0 },
    { "PARENT_HANDLE",		CS_PARENT_HANDLE,	PROP_BINARY, 0, 0 },
    { "USERDATA",		CS_USERDATA,		PROP_BINARY, 0, 0 },
};

#define MAX_CMD_PROPS 	(sizeof (cmdprops_table) / sizeof (cmdprops_table[0]))


/*
** buttons defined
*/
static Widget		prop_popup;
static CS_INT		prop_type;
static Boolean		prop_isup = False;
static Props		*prop_table;
static int		prop_table_cnt;

/*
** local routines
*/
static void do_property(Widget w, XtPointer cc, XtPointer cd);
static void do_enable(Widget w, XtPointer cc, XtPointer cd);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_prop_form - construct prop parameter window
**
****************************************************************************/
static void 
win_prop_form(Widget parent, Props *table, int start, int end)
{
    Widget	PropForm;
    Arg 	args[MAXARGS];
    int		i;

    PropForm = NULL;
    for (i = start; i < end; i++)
    {
	/*
	** form for property entry
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 400);
	XtSetArg(args[2], XtNfromVert, PropForm);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	PropForm = XtCreateManagedWidget("PropForm", formWidgetClass,
			parent, args, 7);

	/*
	** property enable button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, 140);
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, table[i].name);
	XtSetArg(args[6], XtNstate, False);
	table[i].prop_enable = XtCreateManagedWidget("PropForm",
			    toggleWidgetClass, PropForm, args, 7);

	/*
	** property string field
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, table[i].prop_enable);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 260);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	table[i].prop_string = XtCreateManagedWidget("PropForm",
			    asciiTextWidgetClass, PropForm, args, 10);
    }
}

/****************************************************************************
**
** win_prop - initialize prop window
**
****************************************************************************/
void 
win_prop(Widget parent, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    Widget	PropInput;
    Widget	PropInfo;
    Widget	Box;
    Widget	Button;
    char	*buttonname;

    if (prop_isup == True)
    {
	window_bell(0);
	win_msg("Only one property panel can be active at a time\n");
	return;
    }
    prop_isup = True;

    prop_type = (CS_INT)cc;
    if (prop_type == CM_CTX_PROP)
    {
	prop_table = ctxprops_table;
	prop_table_cnt = MAX_CTX_PROPS;
	prop_popup = XtNameToWidget(parent, "Context Property Input Window");
    }
    else
    {
	prop_table = conprops_table;
	prop_table_cnt = MAX_CON_PROPS;
	prop_popup = XtNameToWidget(parent, "Connection Property Input Window");
    }

    if (!prop_popup)
    {
	XtSetArg(args[0], XtNinput, True);
	XtSetArg(args[1], XtNheight, 25 * prop_table_cnt);
	XtSetArg(args[2], XtNwidth, 900);
	if (prop_type == CM_CTX_PROP)
	{
	    prop_popup = XtCreatePopupShell("Context Property Input Window",
					transientShellWidgetClass,
					parent, args, 3);
	}
	else
	{
	    prop_popup = XtCreatePopupShell("Connection Property Input Window",
					transientShellWidgetClass,
					parent, args, 3);
	}

	/*
	** create a form for the prop info
	*/
	XtSetArg(args[0], XtNdefaultDistance, 2);
	PropInput = XtCreateManagedWidget("PropInput", formWidgetClass,
			prop_popup, args, 1);

	/*
	** form for first half of properties
	*/
	XtSetArg(args[0], XtNheight, 600);
	XtSetArg(args[1], XtNwidth, 400);
	XtSetArg(args[2], XtNfromVert, NULL);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	PropInfo = XtCreateManagedWidget("PropInfo", formWidgetClass,
			PropInput, args, 7);

	/*
	** Create property form
	*/
	win_prop_form(PropInfo, prop_table, 0, prop_table_cnt/2);

	/*
	** form for second half of properties
	*/
	XtSetArg(args[0], XtNheight, 600);
	XtSetArg(args[1], XtNwidth, 400);
	XtSetArg(args[2], XtNfromVert, NULL);
	XtSetArg(args[3], XtNfromHoriz, PropInfo);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	PropInfo = XtCreateManagedWidget("PropInfo", formWidgetClass,
			PropInput, args, 7);

	/*
	** Create property form
	*/
	win_prop_form(PropInfo, prop_table, prop_table_cnt/2, prop_table_cnt);

	/*
	** box for buttons
	*/
	XtSetArg(args[0], XtNheight, 200);
	XtSetArg(args[1], XtNwidth, 400);
	XtSetArg(args[2], XtNfromVert, PropInfo);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 0);
	XtSetArg(args[5], XtNhSpace, 10);
	XtSetArg(args[6], XtNvSpace, 2);
	Box = XtCreateManagedWidget("Box", boxWidgetClass,
			PropInput, args, 7);

	buttonname = "Dismiss";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_dismiss, NULL);

	buttonname = "Set";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_property, (XtPointer)CS_SET);

	buttonname = "Get";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_property, (XtPointer)CS_GET);

	buttonname = "Clear";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_property, (XtPointer)CS_CLEAR);

	buttonname = "Enable All";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_enable, (XtPointer)CS_SET);

	buttonname = "Disable All";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_enable, (XtPointer)CS_CLEAR);
    }

    window_popup(parent, prop_popup);

    return;
}

/****************************************************************************
**
** do_property - do_property
**
****************************************************************************/
/*ARGSUSED*/
static void
do_property(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    String	m;
    Boolean	b;
    CS_INT	cs_int;
    CS_INT	cs_len;
    CS_INT	outlen;
    CS_INT	action;
    Arg 	args[MAXARGS];
    char	charbuff[255];

    action = (CS_INT)cc;

    for (i = 0; i < prop_table_cnt; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(prop_table[i].prop_enable, args, 1);

	if (b == False)
	{
	    continue;
	}

	XtSetArg(args[0], XtNstring, &m);
	XtGetValues(prop_table[i].prop_string, args, 1);
	switch (prop_table[i].prop_type)
	{
	    case PROP_BINARY:
		COPSTR(charbuff, "UNSUPPORTED", sizeof (charbuff));
		/*
		cm_con_prop(action, prop_table[i].property, charbuff,
				STRLEN(charbuff));
		*/
		XtSetArg(args[0], XtNstring, charbuff);
		XtSetValues(prop_table[i].prop_string, args, 1);
		break;

	    case PROP_STRING:
		if (action == CS_GET)
		{
		    cs_len = sizeof (charbuff);
		}
		else
		{
		    COPSTR(charbuff, m, sizeof (charbuff));
		    cs_len = STRLEN(charbuff);
		}
		outlen = 0;
		cm_prop(prop_type, action, prop_table[i].property,
		    		charbuff, cs_len, &outlen);
		if (action == CS_GET)
		{
		    charbuff[outlen] = '\0';
		}
		XtSetArg(args[0], XtNstring, charbuff);
		XtSetValues(prop_table[i].prop_string, args, 1);
		break;

	    case PROP_INT:
		cs_int = atoi(m);
		cm_prop(prop_type, action, prop_table[i].property,
		    		&cs_int, CS_UNUSED,
				(action == CS_GET) ? &outlen : NULL);
		sprintf(charbuff, "%ld", cs_int);
		XtSetArg(args[0], XtNstring, charbuff);
		XtSetValues(prop_table[i].prop_string, args, 1);
		break;

	    case PROP_HEX:
		cs_int = strtol(m, NULL, 0);
		cm_prop(prop_type, action, prop_table[i].property,
		    		&cs_int, CS_UNUSED, &outlen);
		sprintf(charbuff, "0x%lx", cs_int);
		XtSetArg(args[0], XtNstring, charbuff);
		XtSetValues(prop_table[i].prop_string, args, 1);
		break;

	    default:
		BOMB();
		break;
	}
    }
}

/****************************************************************************
**
** do_enable - do_enable
**
****************************************************************************/
/*ARGSUSED*/
static void
do_enable(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    Boolean	b;
    Arg 	args[MAXARGS];

    b = ((CS_INT)cc == CS_SET) ? True : False;

    for (i = 0; i < prop_table_cnt; i++)
    {
	XtSetArg(args[0], XtNstate, b);
	XtSetValues(prop_table[i].prop_enable, args, 1);
    }
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    prop_isup = False;
    window_popdown(prop_popup);
}
