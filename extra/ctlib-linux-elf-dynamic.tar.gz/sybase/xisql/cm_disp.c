/****************************************************************************

NAME
	cm_disp - display results

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_disp.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** Maximum column count and length to deal with
*/
#define MAX_COLUMNS	256
#define MAX_COLUMN_LEN	1024

/*
** define a large working buffer for displaying data
*/
#define MAX_WBUFF	(MAX_COLUMNS * MAX_COLUMN_LEN)
static char		wbuf[MAX_WBUFF];

/****************************************************************************
**
** cm_display_dlen - return the number of bytes need to display a data type
**
****************************************************************************/
CS_INTERNAL int
cm_display_dlen(CS_DATAFMT *column)
{
    int		len;

    switch ((int)column->datatype)
    {
	case CS_CHAR_TYPE:
	case CS_VARCHAR_TYPE:
	case CS_TEXT_TYPE:
	    len = MIN(column->maxlength, MAX_COLUMN_LEN);
	    break;

	case CS_BINARY_TYPE:
	case CS_VARBINARY_TYPE:
	case CS_IMAGE_TYPE:
	    len = MIN(column->maxlength * 2, MAX_COLUMN_LEN);
	    break;

	case CS_BIT_TYPE:
	case CS_TINYINT_TYPE:
	    len = 3;
	    break;

	case CS_SMALLINT_TYPE:
	    len = 6;
	    break;

	case CS_INT_TYPE:
	    len = 11;
	    break;

	case CS_REAL_TYPE:
	case CS_FLOAT_TYPE:
	    len = 20;
	    break;

	case CS_MONEY_TYPE:
	case CS_MONEY4_TYPE:
	    len = 24;
	    break;

	case CS_DATETIME_TYPE:
	case CS_DATETIME4_TYPE:
	    len = 30;
	    break;

	case CS_NUMERIC_TYPE:
	case CS_DECIMAL_TYPE:
	    len = (CS_MAX_PREC + 2);
	    break;

	default:
	    len = 12;
	    break;
    }

    return len;
}

/****************************************************************************
**
** cm_display_header - 
**
****************************************************************************/
CS_INTERNAL int
cm_display_header
(
    CS_INT	numcols,
    CS_DATAFMT	columns[],
    CS_INT	disp_len[]
)
{
	CS_INT		i;
	char		*p;
	int		l;

	ASSERT( numcols < MAX_COLUMNS );

	win_result("\n");
	for (i = 0; i < numcols; i++)
	{
		disp_len[i] = MAX(strlen(columns[i].name) + 1,
				  cm_display_dlen(&columns[i]));
	}
	p = wbuf;
	for (i = 0; i < numcols; i++)
	{
		l = STRLEN(columns[i].name);
		memcpy(p, columns[i].name, l);
		p += l;
		l = disp_len[i] - l;
		memset(p, ' ', l);
		p += l;
	}
	*p++ = '\n';
	for (i = 0; i < numcols; i++)
	{
		l = disp_len[i] - 1;
		memset(p, '-', l);
		p += l;
		*p++ = ' ';
	}
	*p++ = '\n';
	*p++ = '\0';
	win_result(wbuf);

	return SUCCESS;
}

/****************************************************************************
**
** cm_display_data - 
**
****************************************************************************/
CS_INTERNAL int
cm_display_data
(
    CS_INT	numcols,
    CS_DATAFMT	columns[],
    CS_BYTE	*data[],
    CS_INT	datalength[],
    CS_SMALLINT	indicator[],
    CS_INT	disp_len[]
)
{
	CS_INT		i;
	int		padlen;
	CS_INT		olen;
	char		null[] = "NULL";
	char		nc[] = "NO CONVERT";
	char		cf[] = "CONVERT FAILED";
	CS_DATAFMT	bfmt;
	char		*p;
	CS_BOOL		res;

	p = wbuf;
	MEMZERO(&bfmt, sizeof (bfmt));
	bfmt.maxlength = MAX_COLUMN_LEN;
	bfmt.datatype  = CS_CHAR_TYPE;
	bfmt.format    = CS_FMT_NULLTERM;
	for (i = 0; i < numcols; i++)
	{
		if (indicator[i] == CS_NULLDATA)
		{
			olen = strlen(null);
			memcpy(p, null, olen);
		}
		else
		{
			cs_will_convert(Cdata.context, columns[i].datatype,
				CS_CHAR_TYPE, &res);
			if (res != CS_TRUE)
			{
				olen = strlen(nc);
				memcpy(p, nc, olen);
			}
			else
			{
				columns[i].maxlength = datalength[i];
				if (cs_convert(Cdata.context, &columns[i],
					data[i], &bfmt, p, &olen) != CS_SUCCEED)
				{
					olen = strlen(cf);
					memcpy(p, cf, olen);
				}
				else
				{
					/*
					** output length includes null
					** termination
					*/
					olen -= 1;
				}
			}
		}
		p += olen;
		padlen = disp_len[i] - olen;
		if (padlen > 0)
		{
			memset(p, ' ', padlen);
			p += padlen;
		}
	}
	*p++ = '\n';
	*p++ = '\0';
	win_result(wbuf);

	return SUCCESS;
}
