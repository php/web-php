/****************************************************************************

NAME
	win_con - connection window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_con.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#include	<sys/types.h>
#include	<unistd.h>
#include	<fcntl.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** buttons defined
*/
static Widget		con_popup;
static Widget		con_user;
static Widget		con_passwd;
static Widget		con_server;

/*
** local routines
*/
static void do_connect(Widget w, XtPointer cc, XtPointer cd);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_connect - initialize connect window
**
****************************************************************************/
void 
win_connect(Widget parent, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    Widget	ConnectInput;
    Widget	Box;
    Widget	ConnectInfo;
    Widget	Connect;
    Widget	Dismiss;
    Widget	label;

    con_popup = XtNameToWidget(parent, "Connect Input Window");

    if (!con_popup)
    {

	XtSetArg(args[0], XtNinput, True);
	XtSetArg(args[1], XtNwidth, 770);
	XtSetArg(args[2], XtNheight, 120);
	con_popup = XtCreatePopupShell("Connect Input Window",
					transientShellWidgetClass,
					parent, args, 3);

	/*
	** create a form for the connect info
	*/
	XtSetArg(args[0], XtNdefaultDistance, 2);
	ConnectInput = XtCreateManagedWidget("ConnectInput", formWidgetClass,
			con_popup, args, 1);

	/*
	** connect output widget
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 700);
	XtSetArg(args[2], XtNfromVert, NULL);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	ConnectInfo = XtCreateManagedWidget("ConnectInfo", formWidgetClass,
			ConnectInput, args, 7);

	/*
	** connect user name button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNhighlightThickness, 1);
	XtSetArg(args[3], XtNstate, False);
	XtSetArg(args[4], XtNlabel, "User Name");
	XtSetArg(args[5], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[6], XtNwidth, 120);
	label = XtCreateManagedWidget("ConnectInfo", toggleWidgetClass,
			ConnectInfo, args, 7);

	/*
	** connect user input string 
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 400);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, Xdata.user);
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	con_user = XtCreateManagedWidget("ConnectInfo", asciiTextWidgetClass,
			ConnectInfo, args, 10);

	/*
	** passed file name button
	*/
	XtSetArg(args[0], XtNfromVert, con_user);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNhighlightThickness, 1);
	XtSetArg(args[3], XtNstate, False);
	XtSetArg(args[4], XtNlabel, "Passwd");
	XtSetArg(args[5], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[6], XtNwidth, 120);
	label = XtCreateManagedWidget("ConnectInfo", toggleWidgetClass,
			ConnectInfo, args, 7);

	/*
	** connect passwd input string 
	*/
	XtSetArg(args[0], XtNfromVert, con_user);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 400);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, Xdata.passwd);
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	con_passwd = XtCreateManagedWidget("ConnectInfo", asciiTextWidgetClass,
			ConnectInfo, args, 10);

	/*
	** server name button
	*/
	XtSetArg(args[0], XtNfromVert, con_passwd);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNhighlightThickness, 1);
	XtSetArg(args[3], XtNstate, False);
	XtSetArg(args[4], XtNlabel, "Server");
	XtSetArg(args[5], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[6], XtNwidth, 120);
	label = XtCreateManagedWidget("ConnectInfo", toggleWidgetClass,
			ConnectInfo, args, 7);

	/*
	** server name input string 
	*/
	XtSetArg(args[0], XtNfromVert, con_passwd);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 400);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, Xdata.server);
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	con_server = XtCreateManagedWidget("ConnectInfo", asciiTextWidgetClass,
			ConnectInfo, args, 10);

	/*
	** box for buttons
	*/
	XtSetArg(args[0], XtNheight, 50);
	XtSetArg(args[1], XtNwidth, 300);
	XtSetArg(args[2], XtNfromVert, ConnectInfo);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 0);
	XtSetArg(args[5], XtNhSpace, 10);
	XtSetArg(args[6], XtNvSpace, 2);
	Box = XtCreateManagedWidget("Box", boxWidgetClass,
			ConnectInput, args, 7);

	XtSetArg(args[0], XtNwidth, 80);
	Dismiss = XtCreateManagedWidget("Dismiss", commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Dismiss, XtNcallback, do_dismiss, NULL);

	Connect = XtCreateManagedWidget("Connect", commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Connect, XtNcallback, do_connect, NULL);
    }

    window_popup(parent, con_popup);

    return;
}

/****************************************************************************
**
** do_connect - do_connect
**
****************************************************************************/
/*ARGSUSED*/
static void
do_connect(Widget w, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    String	m;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(con_user, args, 1);
    Xdata.user = m;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(con_passwd, args, 1);
    Xdata.passwd = m;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(con_server, args, 1);
    Xdata.server = m;

    cm_connect();

    window_popdown(con_popup);
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    window_popdown(con_popup);
}
