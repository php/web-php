/************************************************************************
**
** cm_int.h - header file for internal modules for Client Lib interface
**
**
**      Sccsid %Z% %M% %I% %G%
**
**      Confidential Property of Sybase, Inc.
**	Copyright  1991, 1993 by Sybase Incorporated
**	All rights reserved.
**
************************************************************************/

#ifndef __CM_INT_H__

#define __CM_INT_H__

/*
** temp display buffer size
*/
#define MAX_DISPLAY_BUF		1024

/*
** global data structure used
*/

typedef struct _cm_data
{
	CS_CONTEXT	*context;
	CS_CONNECTION	*connection;
} CData;                      

typedef struct _cmdname
{
	char		*name;
	CS_COMMAND	*cmd;
	struct _cmdname	*next;
} CmdName;

extern CData		Cdata;

#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

/* com.cc */
extern CS_PUBLIC CS_RETCODE cm_enc_handler P_((
	CS_CONNECTION *conn,
	CS_BYTE *t,
	CS_INT tlen,
	CS_BYTE *s,
	CS_INT slen,
	CS_BYTE **r,
	CS_INT *rlen
	));
extern CS_INTERNAL int cm_error P_((
	int error,
	char *msg
	));
/* cm_cur.cc */
extern CS_INTERNAL int cm_cursor_fetch P_((
	CS_COMMAND *cmd
	));
extern CS_INTERNAL CS_COMMAND *cm_get_cursor_cmd P_((
	char *name
	));
/* cm_cb.cc */
extern CS_PUBLIC CS_RETCODE cm_err_handler P_((
	CS_CONTEXT	*context,
	CS_CONNECTION *connection,
	CS_CLIENTMSG *errmsg
	));
extern CS_PUBLIC CS_RETCODE cm_msg_handler P_((
	CS_CONTEXT	*context,
	CS_CONNECTION *connection,
	CS_SERVERMSG *srvmsg
	));
extern CS_PUBLIC CS_RETCODE cm_notif_handler P_((
	CS_CONNECTION *connection,
	CS_CHAR *procname,
	CS_INT pnamelen
	));
/* cm_disp.cc */
extern CS_INTERNAL int cm_display_header P_((
	CS_INT numcols,
	CS_DATAFMT columns[],
	CS_INT disp_len[]
	));
extern CS_INTERNAL int cm_display_data P_((
	CS_INT numcols,
	CS_DATAFMT columns[],
	CS_BYTE *data[],
	CS_INT datalength[],
	CS_SMALLINT indicator[],
	CS_INT disp_len[]
	));
/* cm_dyn.c */
extern CS_INTERNAL CS_COMMAND *cm_get_dynamic_cmd P_((
	char *name
	));
/* cm_res.cc */
extern CS_INTERNAL int cm_fetch P_((
	CS_COMMAND *cmd,
	CS_INT res_type
	));
extern CS_INTERNAL int cm_results P_((
	CS_COMMAND *cmd
	));
/* cm_rpc.c */
extern CS_INTERNAL CS_INT cm_get_dtype P_((
	char *dtype_name
	));

#undef P_

#endif /* __CM_INT_H__ */
