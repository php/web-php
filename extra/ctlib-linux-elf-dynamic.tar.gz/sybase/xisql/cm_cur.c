/****************************************************************************

NAME
	cm_cur - xisql interface to CT-Lib cursor commands

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_cur.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** local defines
*/
#define MAXCOLUMNS      255

/*
** Linked list of cursor command handles
*/
static CmdName		*p_cmdhead = NIL(CmdName *);

/****************************************************************************
**
** cm_cursor - 
**
****************************************************************************/
CS_INTERNAL int
cm_cursor
(
    int		send_option,
    char	*p_cmd,
    char	*p_name,
    char	*p_text,
    int		command,
    int		options,
    CmParams	params[],
    int		numparams
)
{
	CS_COMMAND	*cmd;
	CS_RETCODE	ret;
	CS_DATAFMT	paramdesc;
	CS_INT		res_type;
	int		i;
	CS_INT		curopt = CS_UNUSED;
	CS_INT		curcmd;

	/*
	** get a command handle.
	*/
	cmd = cm_get_cursor_cmd(p_cmd);
	if (cmd == NULL)
	{
		return cm_error(CM_FAILURE, "cm_get_cursor_cmd failed");
	}

	/*
	** Get the command. Some of the commands require a null name and text.
	** Since the x interface does not know about this, we clear them here.
	*/
	switch (command)
	{
	    case CM_CURCMD_NONE:
	    	curcmd = CS_UNUSED;
		break;

	    case CM_CURCMD_DECLARE:
	    case CM_CURCMD_DYN_DECLARE:
	    	curcmd = CS_CURSOR_DECLARE;
		break;

	    case CM_CURCMD_OPEN:
		p_name = NULL;
		p_text = NULL;
	    	curcmd = CS_CURSOR_OPEN;
		break;

	    case CM_CURCMD_CLOSE:
		p_name = NULL;
		p_text = NULL;
	    	curcmd = CS_CURSOR_CLOSE;
		break;

	    case CM_CURCMD_DEALLOC:
		p_name = NULL;
		p_text = NULL;
	    	curcmd = CS_CURSOR_DEALLOC;
		break;

	    case CM_CURCMD_UPDATE:
	    	curcmd = CS_CURSOR_UPDATE;
		break;

	    case CM_CURCMD_DELETE:
		p_text = NULL;
	    	curcmd = CS_CURSOR_DELETE;
		break;

	    case CM_CURCMD_CURROWS:
	    	curopt = atoi(p_text);
		p_name = NULL;
		p_text = NULL;
	    	curcmd = CS_CURSOR_ROWS;
		break;

	    case CM_CURCMD_FETCH:
		/*
		** in this case, we used ct_fetch() to get a row
		*/
		return cm_cursor_fetch(cmd);

	    default:
	    	BOMB();
		return CM_FAILURE;
	}

	/*
	** get option
	*/
	switch (options)
	{
	    case CM_CUROPT_UNUSED:
	    	if (command  != CM_CURCMD_CURROWS)
		{
			curopt = CS_UNUSED;
		}
		break;

	    case CM_CUROPT_DEALLOC:
	    	curopt = CS_DEALLOC;
		break;

	    case CM_CUROPT_FOR_UPATE:
	    	curopt = CS_FOR_UPDATE;
		break;

	    case CM_CUROPT_READ_ONLY:
	    	curopt = CS_READ_ONLY;
		break;

	    default:
	    	BOMB();
		break;
	}

	/*
	** Tell Open Client about the query we want to send.
	*/
	if (command == CM_CURCMD_DYN_DECLARE)
	{
		ret = ct_dynamic(cmd, curcmd,
			p_text, (p_text == NULL) ? CS_UNUSED : CS_NULLTERM,
			p_name, (p_name == NULL) ? CS_UNUSED : CS_NULLTERM);
	}
	else
	{
		ret = ct_cursor(cmd, curcmd,
			p_name, (p_name == NULL) ? CS_UNUSED : CS_NULLTERM,
			p_text, (p_text == NULL) ? CS_UNUSED : CS_NULLTERM,
				curopt);
	}

	if (ret != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_cursor failed");
	}

	/*
	** Bundle up the params to send
	*/
	for (i = 0; i < numparams; i++)
	{
		strcpy(paramdesc.name, params[i].name);
		paramdesc.namelen = CS_NULLTERM;
		paramdesc.datatype = CS_CHAR_TYPE;
		paramdesc.maxlength = 255;
		paramdesc.format = CS_FMT_UNUSED;
		switch (params[i].options)
		{
		    case CM_CPOPT_UNUSED:
			paramdesc.status = CS_UNUSED;
			break;

		    case CM_CPOPT_UPDATECOL:
			paramdesc.status = CS_UPDATECOL;
			break;

		    case CM_CPOPT_INPUTVAL:
			paramdesc.status = CS_INPUTVALUE;
			break;

		    default:
		    	BOMB();
			paramdesc.status = CS_UNUSED;
			break;
		}
		ret = ct_param(cmd, &paramdesc, params[i].value,
			CS_NULLTERM, CS_GOODDATA);
		if (ret != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_param failed");
		}
	}

	if (send_option == CM_SEND_BATCH)
	{
		return CM_SUCCESS;
	}
	ASSERT( send_option == CM_SEND_NOW );

	/*
	** Now send the query to the server.
	*/
	if (ct_send(cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_send failed");
	}

	/*
	** Process the results of the query.
	*/
	while((ret = ct_results(cmd, &res_type)) == CS_SUCCEED)
	{
		switch ((int)res_type)
		{
		    case CS_ROW_RESULT:
		    case CS_PARAM_RESULT:
		    case CS_STATUS_RESULT:
			win_msg("unexpected ROW result type from ct_results\n");
			break;

		    case CS_CURSOR_RESULT:
			win_result("[Cursor rows present]\n");
			break;

		    case CS_CMD_SUCCEED:
			/*
			** This means no rows were returned.
			*/
			win_result("[Cursor Command succeeded]\n");
			break;

		    case CS_CMD_DONE:
			/*
			** Done with one result set, let's go
			** on to the next.
			*/
			break;

		    case CS_CMD_FAIL:
			/*
			** The server encountered an error while
			** processing our command.
			*/
			win_result("[Cursor Command failed]\n");
			break;

		    default:
			/*
			** We got something unexpected.
			*/
			win_msg("unexpected result type from ct_results\n");
			break;
		}
		if (res_type == CS_CURSOR_RESULT)
		{
			break;
		}
	}

	/*
	** We're done processing results. Let's check the
	** return value of ct_results() to see if everything
	** went ok.
	*/
	switch ((int)ret)
	{
	    case CS_SUCCEED:
	    case CS_END_RESULTS:
		/*
		** Everything went fine.
		*/
		break;

	    case CS_FAIL:
		/*
		** Something terrible happened.
		*/
		win_msg("ct_results() return FAIL.\n");
		break;

	    default:
		/*
		** We got an unexpected return value.
		*/
		cm_error(CM_FAILURE, "oc_result returned unexpected result type");
		break;
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_cursor_finish - 
**
****************************************************************************/
CS_INTERNAL int
cm_cursor_finish(char *p_cmdname)
{
	CmdName		*p_cmd;		/* used in scanning cache */
	CmdName		*p_prevcmd;	/* used in relinking cache */

	CHECK_PTR( p_cmdname );

	/*
	** Find command handle
	*/
	p_prevcmd = NULL;
	for (p_cmd = p_cmdhead; p_cmd != NULL; p_cmd = p_cmd->next)
	{
		CHECK_PTR( p_cmd );
		CHECK_PTR( p_cmd->name );
		if (STRCMP(p_cmdname, p_cmd->name) == 0)
		{
			break;
		}
		p_prevcmd = p_cmd;
	}

	if (p_cmd != NULL)
	{
		if (ct_cmd_drop(p_cmd->cmd) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_cmd_drop failed");
		}

		if (p_cmd == p_cmdhead)
		{
			p_cmdhead->next = p_cmd->next;
		}
		else
		{
			CHECK_PTR( p_prevcmd );
			p_prevcmd->next = p_cmd->next;
		}

		FREE(p_cmd->name);
		FREE(p_cmd);
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_cursor_fetch - 
**
****************************************************************************/
CS_INTERNAL int
cm_cursor_fetch(CS_COMMAND *cmd)
{
	CS_RETCODE	ret;
	CS_DATAFMT	columns[MAXCOLUMNS];
	CS_BYTE		*data[MAXCOLUMNS];
	CS_INT		datalength[MAXCOLUMNS];
	CS_SMALLINT	indicator[MAXCOLUMNS];
	CS_INT		numcols;
	CS_INT		i, count;
	char		buf[1024];
	CS_INT		disp_len[MAXCOLUMNS];

	/*
	** We need to find out how many columns
	** there are, allocate program variables to
	** hold them, and bind the incoming row
	** data to the variables.
	*/
	ret = ct_res_info(cmd, CS_NUMDATA, &numcols, CS_UNUSED, NULL);
	if (ret != CS_SUCCEED)
	{
		cm_error(CM_FAILURE, "ct_res_info failed");
	}
	if (numcols <= 0)
	{
		sprintf(buf,
			"cm_cursor_fetch: ct_res_info() returned %d columns\n",
			numcols);
		win_msg(buf);
	}

	for (i = 0; i < numcols; i++)
	{
		MEMZERO(&columns[i], sizeof (CS_DATAFMT));

		/*
		** Get the column description and
		** save the description so that we
		** can use it to print the data out
		** later.
		*/
		if (ct_describe(cmd, i + 1, &columns[i]) != CS_SUCCEED)
		{
			cm_error(CM_FAILURE, "ct_describe failed");
		}

		/*
		** Allocate space for the column.
		*/
		columns[i].maxlength += 1;
		columns[i].count = 1;

		data[i] = MALLOC(columns[i].maxlength, CS_BYTE);
		if (data[i] == NIL(CS_BYTE *))
		{
			cm_error(CM_FATAL, "malloc failed");
		}

		/*
		** Bind the results to the variable.
		*/
		if (ct_bind(cmd, i + 1, &columns[i], data[i],
		    &datalength[i], &indicator[i]) != CS_SUCCEED)
		{
			cm_error(CM_FAILURE, "ct_bind failed");
		}
	}
	cm_display_header(numcols, columns, disp_len);

	/*
	** Now fetch and print one row.
	*/
	ret = ct_fetch(cmd, CS_UNUSED, CS_UNUSED, CS_UNUSED, &count);
	if (ret == CS_SUCCEED)
	{

		/*
		** We have some rows, let's print them.
		*/
		cm_display_data(numcols, columns, data,
			datalength, indicator, disp_len);
	}
	/*
	** Check if we hit a recoverable error.
	*/
	else if (ret == CS_ROW_FAIL)
	{
		sprintf(buf, "Error on row\n");
		win_msg(buf);
	}
	/*
	** Let's check for final return value of ct_fetch().
	*/
	else if (ret == CS_END_DATA)
	{
		win_msg("All done processing rows\n");
		cm_results(cmd); 
	}
	else
	{
		/*
		** Something terrible happened.
		*/
		win_msg("ct_fetch failed\n");
	}

	/*
	** Free allocated space.
	*/
	for (i = 0; i < numcols; i++)
	{
		FREE(data[i]);
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_get_cursor_cmd - 
**
****************************************************************************/
CS_INTERNAL CS_COMMAND *
cm_get_cursor_cmd(char *name)
{
	CmdName		*p_cmd;		/* used in scanning cache */

	CHECK_PTR( name );

	for (p_cmd = p_cmdhead; p_cmd != NULL; p_cmd = p_cmd->next)
	{
		CHECK_PTR( p_cmd );
		CHECK_PTR( p_cmd->name );
		if (STRCMP(name, p_cmd->name) == 0)
		{
			return p_cmd->cmd;
		}
	}

	/*
	** allocate a new command name struct, copy name and allocate command
	** handle
	*/
	p_cmd = MALLOC(1, CmdName);
	if (p_cmd == NIL(CmdName *))
	{
		cm_error(CM_FATAL, "malloc failed");
		return NIL(CS_COMMAND *);
	}
	p_cmd->name = MALLOC(STRLEN(name) + 1, CS_CHAR);
	if (p_cmd->name == NULL)
	{
		cm_error(CM_FATAL, "malloc failed");
		return NIL(CS_COMMAND *);
	}
	STRCPY(p_cmd->name, name);
	if (ct_cmd_alloc(Cdata.connection, &p_cmd->cmd) != CS_SUCCEED)
	{
		cm_error(CM_FAILURE, "ct_cmd_alloc failed");
		return NIL(CS_COMMAND *);
	}

	/*
	** link into beginning of list
	*/
	p_cmd->next = p_cmdhead;
	p_cmdhead = p_cmd;

	return p_cmd->cmd;
}
