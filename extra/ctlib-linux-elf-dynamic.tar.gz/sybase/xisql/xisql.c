/****************************************************************************

NAME
	xisql - X window based interactive sql program

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	xisql.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** 
*/

/*****************************************************************************
**
** main - main entry point
**
*****************************************************************************/
int main(int argc, char **argv)
{
    /*
    ** debug stuff
    */
#if SUNOS
    /* malloc_debug(2);
    */
#endif

    /*
    ** initialize windowing system
    */
    window_init(argc, argv);

    /*
    ** flush out all events before initializing com system
    */
    while (window_event() == TRUE)
	;

    /*
    ** initialize Client Library communication system
    */
    cm_init();

    /*
    ** loop in window system dispatching user events
    */
    window_run();

    return 0;
}
