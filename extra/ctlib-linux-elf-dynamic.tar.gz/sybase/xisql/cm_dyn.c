/****************************************************************************

NAME
	cm_dyn - xisql interface to CT-Lib dynamic commands

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_dyn.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
	Mike Allen

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** local defines
*/
#define MAXCOLUMNS      255

/*
** Linked list of dynamic command handles
*/
static CmdName		*p_cmdhead = NIL(CmdName *);

/****************************************************************************
**
** cm_dynamic - 
**
****************************************************************************/
CS_INTERNAL int
cm_dynamic
(
    char	*p_cmd,
    char	*p_name,
    char	*p_text,
    int		command,
    CmParams 	params[],
    int		numparams
)
{
	CS_COMMAND	*cmd;
	CS_RETCODE	ret;
	CS_DATAFMT	paramdesc;
	CS_DATAFMT	indesc;
	CS_BYTE		data[255];
	CS_INT		len;
	CS_INT		dyncmd;
	CS_INT		i;

	/*
	** get a command handle.
	*/
	cmd = cm_get_dynamic_cmd(p_cmd);
	if (cmd == NULL)
	{
		return cm_error(CM_FAILURE, "cm_get_dynamic_cmd failed");
	}

	/*
	** Get the command. Some of the commands require a null name and text.
	** Since the x interface does not know about this, we clear them here.
	*/
	switch (command)
	{
	    case CM_DYNCMD_NONE:
	    	dyncmd = CS_UNUSED;
		break;

	    case CM_DYNCMD_PREPARE:
	    	dyncmd = CS_PREPARE;
		break;

	    case CM_DYNCMD_DEALLOC:
		p_text = NULL;
	    	dyncmd = CS_DEALLOC;
		break;

	    case CM_DYNCMD_EXECUTE:
		p_text = NULL;
	    	dyncmd = CS_EXECUTE;
		break;

	    case CM_DYNCMD_DESCIN:
		p_text = NULL;
	    	dyncmd = CS_DESCRIBE_INPUT;
		break;

	    case CM_DYNCMD_DESCOUT:
		p_text = NULL;
	    	dyncmd = CS_DESCRIBE_OUTPUT;
		break;

	    case CM_DYNCMD_EXEC_IMM:
		p_name = NULL;
	    	dyncmd = CS_EXEC_IMMEDIATE;
		break;

	    default:
	    	BOMB();
		return CM_FAILURE;
	}

	/*
	** Tell Open Client about the query we want to send.
	*/
	ret = ct_dynamic(cmd, dyncmd,
			p_name, (p_name == NULL) ? CS_UNUSED : CS_NULLTERM,
			p_text, (p_text == NULL) ? CS_UNUSED : CS_NULLTERM);
	if (ret != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_dynamic failed");
	}

	for (i = 0; i < numparams; i++)
	{
		MEMZERO(&indesc, sizeof (indesc));
		strcpy(indesc.name, params[i].name);
		indesc.namelen   = CS_NULLTERM;
		indesc.datatype  = CS_CHAR_TYPE;
		indesc.maxlength = STRLEN(params[i].value);
		indesc.format    = CS_FMT_UNUSED;
		indesc.status    = (params[i].options == CM_INPUT)
						? CS_INPUTVALUE : CS_RETURN;
		MEMCPY(&paramdesc, &indesc, sizeof (paramdesc));
		paramdesc.datatype = cm_get_dtype(params[i].dtype);
		if (cs_convert(Cdata.context, &indesc, 
			params[i].value, &paramdesc, data, &len) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, 
					"cm_dynamic: cs_convert failed");
		}
		if (ct_param(cmd, &paramdesc, data, 
				len, CS_GOODDATA) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_param failed");
		}
	}

	/*
	** Now send the query to the server.
	*/
	if (ct_send(cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_send failed");
	}

	cm_results(cmd);

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_dynamic_finish - 
**
****************************************************************************/
CS_INTERNAL int
cm_dynamic_finish(char *p_cmdname)
{
	CmdName		*p_cmd;		/* used in scanning cache */
	CmdName		*p_prevcmd;	/* used in relinking cache */

	CHECK_PTR( p_cmdname );

	/*
	** Find command handle
	*/
	p_prevcmd = NULL;
	for (p_cmd = p_cmdhead; p_cmd != NULL; p_cmd = p_cmd->next)
	{
		CHECK_PTR( p_cmd );
		CHECK_PTR( p_cmd->name );
		if (STRCMP(p_cmdname, p_cmd->name) == 0)
		{
			break;
		}
		p_prevcmd = p_cmd;
	}

	if (p_cmd != NULL)
	{
		if (ct_cmd_drop(p_cmd->cmd) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_cmd_drop failed");
		}

		if (p_cmd == p_cmdhead)
		{
			p_cmdhead->next = p_cmd->next;
		}
		else
		{
			CHECK_PTR( p_prevcmd );
			p_prevcmd->next = p_cmd->next;
		}

		FREE(p_cmd->name);
		FREE(p_cmd);
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_get_dynamic_cmd - 
**
****************************************************************************/
CS_INTERNAL CS_COMMAND *
cm_get_dynamic_cmd(char *name)
{
	CmdName		*p_cmd;		/* used in scanning cache */

	for (p_cmd = p_cmdhead; p_cmd != NULL; p_cmd = p_cmd->next)
	{
		if (STRCMP(name, p_cmd->name) == 0)
		{
			return p_cmd->cmd;
		}
	}

	/*
	** allocate a new command name struct, copy name and allocate command
	** handle
	*/
	p_cmd = MALLOC(1, CmdName);
	if (p_cmd == NIL(CmdName *))
	{
		cm_error(CM_FATAL, "malloc failed");
		return NIL(CS_COMMAND *);
	}
	p_cmd->name = MALLOC(STRLEN(name) + 1, CS_CHAR);
	if (p_cmd->name == NULL)
	{
		cm_error(CM_FATAL, "malloc failed");
		return NIL(CS_COMMAND *);
	}
	STRCPY(p_cmd->name, name);
	if (ct_cmd_alloc(Cdata.connection, &p_cmd->cmd) != CS_SUCCEED)
	{
		cm_error(CM_FAILURE, "ct_cmd_alloc failed");
		return NIL(CS_COMMAND *);
	}

	/*
	** link into beginning of list
	*/
	p_cmd->next = p_cmdhead;
	p_cmdhead = p_cmd;

	return p_cmd->cmd;
}
