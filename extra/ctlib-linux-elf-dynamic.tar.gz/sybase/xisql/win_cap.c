/****************************************************************************

NAME
	win_cap - capability window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_cap.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** define capability toggle indexs
*/
#define CAP_ON		0
#define CAP_OFF		1
#define CAP_MAXTOGGLE	2

typedef struct _bool_caps
{
	char		*name;
	CS_INT		capability;
	Widget		cap_enable;
	Widget		cap_onoff[CAP_MAXTOGGLE];
} CapEntry;

/*
** request capability table
*/
static CapEntry reqst_caps[] =
{
    { "REQ_LANG",		CS_REQ_LANG, 0, { 0, 0 } },
    { "REQ_RPC",		CS_REQ_RPC, 0, { 0, 0 } },
    { "REQ_NOTIF",		CS_REQ_NOTIF, 0, { 0, 0 } },
    { "REQ_MSTMT",		CS_REQ_MSTMT, 0, { 0, 0 } },
    { "REQ_BCP",		CS_REQ_BCP, 0, { 0, 0 } },
    { "REQ_CURSOR",		CS_REQ_CURSOR, 0, { 0, 0 } },
    { "REQ_DYN",		CS_REQ_DYN, 0, { 0, 0 } },
    { "REQ_MSG",		CS_REQ_MSG, 0, { 0, 0 } },
    { "REQ_PARAM",		CS_REQ_PARAM, 0, { 0, 0 } },
    { "DATA_INT1",		CS_DATA_INT1, 0, { 0, 0 } },
    { "DATA_INT2",		CS_DATA_INT2, 0, { 0, 0 } },
    { "DATA_INT4",		CS_DATA_INT4, 0, { 0, 0 } },
    { "DATA_BIT",		CS_DATA_BIT, 0, { 0, 0 } },
    { "DATA_CHAR",		CS_DATA_CHAR, 0, { 0, 0 } },
    { "DATA_VCHAR",		CS_DATA_VCHAR, 0, { 0, 0 } },
    { "DATA_BIN",		CS_DATA_BIN, 0, { 0, 0 } },
    { "DATA_VBIN",		CS_DATA_VBIN, 0, { 0, 0 } },
    { "DATA_MNY8",		CS_DATA_MNY8, 0, { 0, 0 } },
    { "DATA_MNY4",		CS_DATA_MNY4, 0, { 0, 0 } },
    { "DATA_DATE8",		CS_DATA_DATE8, 0, { 0, 0 } },
    { "DATA_DATE4",		CS_DATA_DATE4, 0, { 0, 0 } },
    { "DATA_FLT4",		CS_DATA_FLT4, 0, { 0, 0 } },
    { "DATA_FLT8",		CS_DATA_FLT8, 0, { 0, 0 } },
    { "DATA_NUM",		CS_DATA_NUM, 0, { 0, 0 } },
    { "DATA_TEXT",		CS_DATA_TEXT, 0, { 0, 0 } },
    { "DATA_IMAGE",		CS_DATA_IMAGE, 0, { 0, 0 } },
    { "DATA_DEC",		CS_DATA_DEC, 0, { 0, 0 } },
    { "DATA_LCHAR",		CS_DATA_LCHAR, 0, { 0, 0 } },
    { "DATA_LBIN",		CS_DATA_LBIN, 0, { 0, 0 } },
    { "DATA_INTN",		CS_DATA_INTN, 0, { 0, 0 } },
    { "DATA_DATETIMEN",		CS_DATA_DATETIMEN, 0, { 0, 0 } },
    { "DATA_MONEYN",		CS_DATA_MONEYN, 0, { 0, 0 } },
    { "CSR_PREV",		CS_CSR_PREV, 0, { 0, 0 } },
    { "CSR_FIRST",		CS_CSR_FIRST, 0, { 0, 0 } },
    { "CSR_LAST",		CS_CSR_LAST, 0, { 0, 0 } },
    { "CSR_ABS",		CS_CSR_ABS, 0, { 0, 0 } },
    { "CSR_REL",		CS_CSR_REL, 0, { 0, 0 } },
    { "CSR_MULTI",		CS_CSR_MULTI, 0, { 0, 0 } },
    { "CON_OOB",		CS_CON_OOB, 0, { 0, 0 } },
    { "CON_INBAND",		CS_CON_INBAND, 0, { 0, 0 } },
    { "CON_LOGICAL",		CS_CON_LOGICAL, 0, { 0, 0 } },
    { "PROTO_TEXT",		CS_PROTO_TEXT, 0, { 0, 0 } },
    { "PROTO_BULK",		CS_PROTO_BULK, 0, { 0, 0 } },
    { "REQ_URGNOTIF",		CS_REQ_URGNOTIF, 0, { 0, 0 } },
    { "DATA_SENSITIVITY",	CS_DATA_SENSITIVITY, 0, { 0, 0 } },
    { "DATA_BOUNDARY",		CS_DATA_BOUNDARY, 0, { 0, 0 } },
    { "PROTO_DYNAMIC",		CS_PROTO_DYNAMIC, 0, { 0, 0 } },
    { "PROTO_DYNPROC",		CS_PROTO_DYNPROC, 0, { 0, 0 } },
};

#define MAX_REQST_CAPS		(sizeof (reqst_caps) / sizeof (reqst_caps[0]))

/*
** response capability table
*/
static CapEntry resp_caps[] =
{
    { "RES_NOMSG",		CS_RES_NOMSG, 0, { 0, 0 } },
    { "RES_NOEED",		CS_RES_NOEED, 0, { 0, 0 } },
    { "RES_NOPARAM",		CS_RES_NOPARAM, 0, { 0, 0 } },
    { "DATA_NOINT1",		CS_DATA_NOINT1, 0, { 0, 0 } },
    { "DATA_NOINT2",		CS_DATA_NOINT2, 0, { 0, 0 } },
    { "DATA_NOINT4",		CS_DATA_NOINT4, 0, { 0, 0 } },
    { "DATA_NOBIT",		CS_DATA_NOBIT, 0, { 0, 0 } },
    { "DATA_NOCHAR",		CS_DATA_NOCHAR, 0, { 0, 0 } },
    { "DATA_NOVCHAR",		CS_DATA_NOVCHAR, 0, { 0, 0 } },
    { "DATA_NOBIN",		CS_DATA_NOBIN, 0, { 0, 0 } },
    { "DATA_NOVBIN",		CS_DATA_NOVBIN, 0, { 0, 0 } },
    { "DATA_NOMNY8",		CS_DATA_NOMNY8, 0, { 0, 0 } },
    { "DATA_NOMNY4",		CS_DATA_NOMNY4, 0, { 0, 0 } },
    { "DATA_NODATE8",		CS_DATA_NODATE8, 0, { 0, 0 } },
    { "DATA_NODATE4",		CS_DATA_NODATE4, 0, { 0, 0 } },
    { "DATA_NOFLT4",		CS_DATA_NOFLT4, 0, { 0, 0 } },
    { "DATA_NOFLT8",		CS_DATA_NOFLT8, 0, { 0, 0 } },
    { "DATA_NONUM",		CS_DATA_NONUM, 0, { 0, 0 } },
    { "DATA_NOTEXT",		CS_DATA_NOTEXT, 0, { 0, 0 } },
    { "DATA_NOIMAGE",		CS_DATA_NOIMAGE, 0, { 0, 0 } },
    { "DATA_NODEC",		CS_DATA_NODEC, 0, { 0, 0 } },
    { "DATA_NOLCHAR",		CS_DATA_NOLCHAR, 0, { 0, 0 } },
    { "DATA_NOLBIN",		CS_DATA_NOLBIN, 0, { 0, 0 } },
    { "DATA_NOINTN",		CS_DATA_NOINTN, 0, { 0, 0 } },
    { "DATA_NODATETIMEN",	CS_DATA_NODATETIMEN, 0, { 0, 0 } },
    { "DATA_NOMONEYN",		CS_DATA_NOMONEYN, 0, { 0, 0 } },
    { "CON_NOOOB",		CS_CON_NOOOB, 0, { 0, 0 } },
    { "CON_NOINBAND",		CS_CON_NOINBAND, 0, { 0, 0 } },
    { "PROTO_NOTEXT",		CS_PROTO_NOTEXT, 0, { 0, 0 } },
    { "PROTO_NOBULK",		CS_PROTO_NOBULK, 0, { 0, 0 } },
    { "DATA_NOSENSITIVITY",	CS_DATA_NOSENSITIVITY, 0, { 0, 0 } },
    { "DATA_NOBOUNDARY",	CS_DATA_NOBOUNDARY, 0, { 0, 0 } },
    { "RES_NOTDSDEBUG",		CS_RES_NOTDSDEBUG, 0, { 0, 0 } },
    { "RES_NOSTRIPBLANKS",	CS_RES_NOSTRIPBLANKS, 0, { 0, 0 } },
};

#define MAX_RESP_CAPS	(sizeof (resp_caps) / sizeof (resp_caps[0]))

/*
** 
*/
static Widget		cap_popup;
static Boolean		cap_isup = False;
static CS_INT		cap_type;
static CapEntry		*cap_table;
static int		cap_table_cnt;

/*
** local routines
*/
static void do_capability(Widget w, XtPointer cc, XtPointer cd);
static void do_enable(Widget w, XtPointer cc, XtPointer cd);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_cap_entry - initialize one capability form
**
****************************************************************************/
static void 
win_cap_entry(Widget parent, CapEntry *table, int start, int end)
{
    Widget	CapForm;
    Arg 	args[MAXARGS];
    int		i;

    CapForm = NULL;
    for (i = start; i < end; i++)
    {
	/*
	** form for capability
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 800);
	XtSetArg(args[2], XtNfromVert, CapForm);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	CapForm = XtCreateManagedWidget("CapForm", formWidgetClass,
			parent, args, 7);

	/*
	** capability enable button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, 160);
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, table[i].name);
	XtSetArg(args[6], XtNstate, False);
	table[i].cap_enable = XtCreateManagedWidget("CapForm",
			    toggleWidgetClass, CapForm, args, 7);

	/*
	** capability toggle button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, table[i].cap_enable);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, 60);
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, "Off");
	XtSetArg(args[6], XtNradioGroup, NULL);
	XtSetArg(args[7], XtNstate, True);
	table[i].cap_onoff[CAP_OFF] = XtCreateManagedWidget("CapForm",
			    toggleWidgetClass, CapForm, args, 8);

	XtSetArg(args[1], XtNfromHoriz, table[i].cap_onoff[CAP_OFF]);
	XtSetArg(args[5], XtNlabel, "On");
	XtSetArg(args[6], XtNradioGroup, table[i].cap_onoff[CAP_OFF]);
	XtSetArg(args[7], XtNstate, False);
	table[i].cap_onoff[CAP_ON] = XtCreateManagedWidget("CapForm",
			    toggleWidgetClass, CapForm, args, 8);

    }
}

/****************************************************************************
**
** win_caps - initialize capability window
**
****************************************************************************/
void 
win_caps(Widget parent, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    Widget	CapInput;
    Widget	CapForm;
    Widget	Box;
    Widget	Button;
    char	*buttonname;

    if (cap_isup == True)
    {
	window_bell(0);
	win_msg("Only one capability panel can be active at a time\n");
	return;
    }
    cap_isup = True;

    cap_type = (CS_INT)cc;
    if (cap_type == CS_CAP_REQUEST)
    {
	cap_table = reqst_caps;
	cap_table_cnt = MAX_REQST_CAPS;
	cap_popup = XtNameToWidget(parent, "Capability Request Window");
    }
    else
    {
	cap_table = resp_caps;
	cap_table_cnt = MAX_RESP_CAPS;
	cap_popup = XtNameToWidget(parent, "Capability Response Window");
    }

    if (!cap_popup)
    {
	XtSetArg(args[0], XtNinput, True);
	XtSetArg(args[1], XtNheight, 750);
	XtSetArg(args[2], XtNwidth, 900);
	if (cap_type == CS_CAP_REQUEST)
	{
	    cap_popup = XtCreatePopupShell("Capability Request Window",
					transientShellWidgetClass,
					parent, args, 3);
	}
	else
	{
	    cap_popup = XtCreatePopupShell("Capability Response Window",
					transientShellWidgetClass,
					parent, args, 3);
	}

	/*
	** create a form for the cap info
	*/
	XtSetArg(args[0], XtNdefaultDistance, 2);
	CapInput = XtCreateManagedWidget("CapInput", formWidgetClass,
			cap_popup, args, 1);

	/*
	** form for panel1 capabilities
	*/
	XtSetArg(args[0], XtNheight, 500);
	XtSetArg(args[1], XtNwidth, 400);
	XtSetArg(args[2], XtNfromVert, NULL);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	CapForm = XtCreateManagedWidget("CapForm", formWidgetClass,
			CapInput, args, 7);

	/*
	** Create entries for request capabilities
	*/
	win_cap_entry(CapForm, cap_table, 0, cap_table_cnt/2);

	/*
	** form for panel2 capabilities
	*/
	XtSetArg(args[0], XtNheight, 500);
	XtSetArg(args[1], XtNwidth, 300);
	XtSetArg(args[2], XtNfromVert, NULL);
	XtSetArg(args[3], XtNfromHoriz, CapForm);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	CapForm = XtCreateManagedWidget("CapForm", formWidgetClass,
			CapInput, args, 7);

	/*
	** Create entries for request capabilities
	*/
	win_cap_entry(CapForm, cap_table, cap_table_cnt/2, cap_table_cnt);

	/*
	** box for buttons
	*/
	XtSetArg(args[0], XtNheight, 100);
	XtSetArg(args[1], XtNwidth, 500);
	XtSetArg(args[2], XtNfromVert, CapForm);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 0);
	XtSetArg(args[5], XtNhSpace, 10);
	XtSetArg(args[6], XtNvSpace, 2);
	Box = XtCreateManagedWidget("Box", boxWidgetClass,
			CapInput, args, 7);

	buttonname = "Dismiss";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_dismiss, NULL);

	buttonname = "Set";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_capability, (XtPointer)CS_SET);

	buttonname = "Get";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_capability, (XtPointer)CS_GET);

	buttonname = "Clear";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_capability, (XtPointer)CS_CLEAR);

	buttonname = "Enable All";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_enable, (XtPointer)CS_SET);

	buttonname = "Disable All";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_enable, (XtPointer)CS_CLEAR);
    }

    window_popup(parent, cap_popup);

    return;
}

/****************************************************************************
**
** do_capability - do_capability
**
****************************************************************************/
/*ARGSUSED*/
static void
do_capability(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    Boolean	b;
    CS_BOOL	cs_bool;
    CS_INT	action;
    Arg 	args[MAXARGS];

    action = (CS_INT)cc;

    for (i = 0; i < cap_table_cnt; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(cap_table[i].cap_enable, args, 1);
	if (b == True)
	{
	    XtSetArg(args[0], XtNstate, &b);
	    XtGetValues(cap_table[i].cap_onoff[CAP_ON], args, 1);

	    cs_bool = (b == True) ? CS_TRUE : CS_FALSE;
	    cm_cap(cap_type, action, cap_table[i].capability, &cs_bool);

	    b = (cs_bool == CS_TRUE) ? True : False;
	    XtSetArg(args[0], XtNstate, b);
	    XtSetValues(cap_table[i].cap_onoff[CAP_ON], args, 1);
	    XtSetArg(args[0], XtNstate, !b);
	    XtSetValues(cap_table[i].cap_onoff[CAP_OFF], args, 1);
	}
    }

}

/****************************************************************************
**
** do_enable - do_enable
**
****************************************************************************/
/*ARGSUSED*/
static void
do_enable(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    Boolean	b;
    Arg 	args[MAXARGS];

    b = ((CS_INT)cc == CS_SET) ? True : False;

    for (i = 0; i < cap_table_cnt; i++)
    {
	XtSetArg(args[0], XtNstate, b);
	XtSetValues(cap_table[i].cap_enable, args, 1);
    }
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    cap_isup = False;
    window_popdown(cap_popup);
}
