/****************************************************************************

NAME
	cm_lang - send a language query

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_lang.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/****************************************************************************
**
** cm_lang - 
**
****************************************************************************/
CS_INTERNAL int
cm_lang
(
    char	*p_text,
    CmParams 	params[],
    int		numparams
)
{
	CS_COMMAND	*cmd;
	CS_DATAFMT	paramdesc;
	CS_BYTE		data[CS_MAX_CHAR];
	CS_DATAFMT	indesc;
	CS_INT		len;
	int		i;

	CHECK_PTR( p_text );
	CHECK_PTR( params );
	ASSERT( numparams >= 0 );

	/*
	** if zero length, don't bother to send it
	*/
	if (STRLEN(p_text) == 0)
	{
		win_msg("No command to send\n");
		window_bell(0);
		return CM_SUCCESS;
	}

	/*
	** Now get a command handle.
	*/
	if (ct_cmd_alloc(Cdata.connection, &cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_cmd_alloc failed");
	}

	/*
	** Tell Open Client about the query we want to send.
	*/
	if (ct_command(cmd, CS_LANG_CMD, p_text, CS_NULLTERM, CS_UNUSED) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_command failed");
	}

	/*
	** Bundle up the params to send
	*/
	for (i = 0; i < numparams; i++)
	{
		MEMZERO(&indesc, sizeof (indesc));
		strcpy(indesc.name, params[i].name);
		indesc.namelen   = CS_NULLTERM;
		indesc.datatype  = CS_CHAR_TYPE;
		indesc.maxlength = STRLEN(params[i].value);
		indesc.format    = CS_FMT_UNUSED;
		indesc.precision = 20;
		indesc.scale     = 10;
		indesc.status    = (params[i].options == CM_INPUT)
			? CS_INPUTVALUE : CS_RETURN;
		MEMCPY(&paramdesc, &indesc, sizeof (paramdesc));
		paramdesc.datatype = cm_get_dtype(params[i].dtype);
		if (cs_convert(Cdata.context, &indesc, params[i].value,
			&paramdesc, data, &len) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "cm_lang: cs_convert failed");
		}
		if (ct_param(cmd, &paramdesc, params[i].value,
			CS_NULLTERM, CS_GOODDATA) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_command failed");
		}
	}

	/*
	** Now send the query to the server.
	*/
	if (ct_send(cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_send failed");
	}

	cm_results(cmd);

	if (ct_cmd_drop(cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_cmd_drop failed");
	}

	return CM_SUCCESS;
}
