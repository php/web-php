/****************************************************************************

NAME
	cm_res - process results

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS

FILE
	cm_res.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char		Sccsid[] ="%Z% %M% %I% %G%";
#endif

/*
** local defines
*/
#define MAXCOLUMNS      255

#define CM_NONE	1
#define CM_INCMD	2
#define CM_CANCEL	3

typedef struct _rmap
{
	CS_INT		restype;
	CS_CHAR 	*resname;
} RMap;

static RMap cm__resmap[] =
{
	{ CS_ROW_RESULT,	"CS_ROW_RESULT" },
	{ CS_CURSOR_RESULT,	"CS_CURSOR_RESULT" },
	{ CS_PARAM_RESULT,	"CS_PARAM_RESULT" },
	{ CS_STATUS_RESULT,	"CS_STATUS_RESULT" },
	{ CS_MSG_RESULT,	"CS_MSG_RESULT" },
	{ CS_COMPUTE_RESULT,	"CS_COMPUTE_RESULT" },
	{ CS_CMD_DONE,		"CS_CMD_DONE" },
	{ CS_CMD_SUCCEED,	"CS_CMD_SUCCEED" },
	{ CS_CMD_FAIL,		"CS_CMD_FAIL" },
	{ CS_ROWFMT_RESULT,	"CS_ROWFMT_RESULT" },
	{ CS_COMPUTEFMT_RESULT,	"CS_COMPUTEFMT_RESULT" },
	{ CS_DESCRIBE_RESULT,	"CS_DESCRIBE_RESULT" },
};

#define NUM_RESTYPES		(sizeof (cm__resmap) / sizeof (cm__resmap[0]))

/*
** local vars
*/
static int		cm_state = CM_NONE;
static CS_COMMAND 	*active_cmd = NULL;

/*
** local routines
*/
CS_STATIC int		cm_browse(CS_COMMAND *cmd, CS_INT numcols);
CS_STATIC int		cm_do_status(CS_COMMAND *cmd);

/****************************************************************************
**
** cm_browse -
**
****************************************************************************/
CS_STATIC int
cm_browse
(
    CS_COMMAND	*cmd,
    CS_INT	numcols
)
{
	CS_BOOL		br_info;
	CS_CHAR		tblname[CS_OBJ_NAME];
	CS_RETCODE	ret;
	CS_INT		i;
	CS_INT		maxtbl;
	CS_INT		numtbl;
	CS_BROWSEDESC	bdesc;
	char		buf[MAX_DISPLAY_BUF];

	ret = ct_res_info(cmd, CS_BROWSE_INFO, &br_info, CS_UNUSED, NULL);
	if (ret != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_res_info failed");
	}

	if (br_info == CS_FALSE)
	{
		return CM_SUCCESS;
	}

	sprintf(buf, "\nBROWSE COLUMN INFO\n");
	win_result(buf);
	sprintf(buf, "------------------\n");
	win_result(buf);
	maxtbl = 0;
	for (i = 1; i <= numcols; i++)
	{
		ret = ct_br_column(cmd, i, &bdesc);
		if (ret != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_br_column failed");
		}
		sprintf(buf, "Column (%ld):\n", i);
		win_result(buf);
		sprintf(buf, "\tstatus = 0x%X : isbrowse = %s\n",
			bdesc.status, (bdesc.isbrowse == CS_TRUE)
				? "CS_TRUE" : "CS_FALSE");
		win_result(buf);
		sprintf(buf,
			"\torigname = %s : tablenum = %ld : tablename = %s\n",
				(strlen(bdesc.origname) == 0)
					? "NULL" : bdesc.origname,
				bdesc.tablenum, bdesc.tablename);
		win_result(buf);
		maxtbl = MAX(maxtbl, bdesc.tablenum);
	}

	sprintf(buf, "BROWSE TABLE INFO\n");
	win_result(buf);
	sprintf(buf, "-----------------\n");
	win_result(buf);
	ret = ct_br_table(cmd, CS_UNUSED, CS_TABNUM, &numtbl, CS_UNUSED, NULL);
	if (ret != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_br_table failed");
	}
	ASSERT(maxtbl <= numtbl);
	for (i = 1; i <= numtbl; i++)
	{
		ret = ct_br_table(cmd, i, CS_ISBROWSE, &br_info,
					CS_UNUSED, NULL);
		if (ret != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_br_table failed");
		}
		ret = ct_br_table(cmd, i, CS_TABNAME, tblname,
				  CS_SIZEOF(tblname), NULL);
		if (ret != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_br_table failed");
		}
		sprintf(buf, "Table (%ld):\n", i);
		win_result(buf);
		sprintf(buf, "\tisbrowse = %s : name = %s\n",
			(br_info == CS_TRUE) ? "CS_TRUE" : "CS_FALSE",
			(strlen(tblname) == 0) ? "NULL" : tblname);
		win_result(buf);
	}
	win_result("\n");
	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_do_status -
**
****************************************************************************/
CS_STATIC int
cm_do_status(CS_COMMAND *cmd)
{
	CS_RETCODE	ret;
	CS_DATAFMT	fmt;
	CS_INT		count;
	char		buf[MAX_DISPLAY_BUF];
	CS_INT		return_status;

	MEMZERO(&fmt, sizeof (CS_DATAFMT));
	fmt.maxlength = sizeof (return_status);
	fmt.datatype  = CS_INT_TYPE;
	fmt.format    = CS_FMT_UNUSED;
	fmt.count     = 1;
	if (ct_bind(cmd, 1, &fmt, &return_status, NULL, NULL) != CS_SUCCEED)
	{
		cm_error(CM_FAILURE, "ct_bind failed");
	}
	while (((ret = ct_fetch(cmd, CS_UNUSED, CS_UNUSED,
				CS_UNUSED, &count)) == CS_SUCCEED) ||
			(ret == CS_ROW_FAIL))
	{
		/*
		** Check if we hit a recoverable error.
		*/
		if (ret == CS_ROW_FAIL || count != 1)
		{
			return cm_error(CM_FAILURE,
				"unexpected failure for rpc status");
		}

		/*
		** We have some rows, let's print them.
		*/
		sprintf(buf, "\n(return status = %d)\n", return_status);
		win_result(buf);
	}

	/*
	** We're done processing return statuses. Let's check the final
	** return value of ct_fetch().
	*/
	if (ret != CS_END_DATA)
	{
		/*
		** Something terrible happened.
		*/
		win_msg("ct_fetch failed\n");
	}
	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_fetch -
**
****************************************************************************/
CS_INTERNAL int
cm_fetch
(
    CS_COMMAND	*cmd,
    CS_INT	res_type
)
{
	CS_RETCODE	ret;
	CS_DATAFMT	columns[MAXCOLUMNS];
	CS_BYTE 	*data[MAXCOLUMNS];
	CS_INT		datalength[MAXCOLUMNS];
	CS_SMALLINT	indicator[MAXCOLUMNS];
	CS_INT		disp_len[MAXCOLUMNS];
	CS_INT		numcols;
	CS_INT		count;
	CS_INT		i;
	char		buf[MAX_DISPLAY_BUF];

	/*
	** We need to find out how many columns there are, allocate program
	** variables to hold them, and bind the incoming row data to the
	** variables.
	*/
	if (ct_res_info(cmd, CS_NUMDATA, &numcols, CS_UNUSED, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_res_info failed");
	}

	if (res_type == CS_ROW_RESULT)
	{
		/*
		** See if any browse info exists
		*/
		if (cm_browse(cmd, numcols) != CM_SUCCESS)
		{
			return cm_error(CM_FAILURE, "cm_browse failed");
		}
	}

	for (i = 0; i < numcols; i++)
	{
		MEMZERO(&columns[i], sizeof (CS_DATAFMT));
		/*
		** Get the column description and save the description so
		** that we can use it to print the data out later.
		*/
		if (ct_describe(cmd, i + 1, &columns[i]) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_describe failed");
		}

		/*
		** Allocate space for the column.
		*/
		columns[i].maxlength += 1;
		columns[i].count = 1;

		data[i] = MALLOC(columns[i].maxlength, CS_BYTE);
		if (data[i] == NIL(CS_BYTE *))
		{
			return cm_error(CM_FATAL, "malloc failed");
		}

		/*
		** Bind the results to the variable.
		*/
		if (ct_bind(cmd, i + 1, &columns[i], data[i],
			    &datalength[i], &indicator[i]) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_bind failed");
		}
	}
	cm_display_header(numcols, columns, disp_len);

	/*
	** Now fetch and print the rows.
	*/
	while (((ret = ct_fetch(cmd, CS_UNUSED, CS_UNUSED,
				CS_UNUSED, &count)) == CS_SUCCEED) ||
			(ret == CS_ROW_FAIL))
	{
		/*
		** Check if we hit a recoverable error.
		*/
		if (ret == CS_ROW_FAIL)
		{
			sprintf(buf, "Error on row %d\n", count + 1);
			win_msg(buf);
		}

		/*
		** We have some rows, let's print them.
		*/
		cm_display_data(numcols, columns, data,
				datalength, indicator, disp_len);

		/*
		** flush out all events before getting next row
		*/
		while (window_event() == TRUE)
			;
		if (cm_state == CM_CANCEL)
		{
			ret = CS_END_DATA;
			break;
		}
	}

	/*
	** We're done processing rows. Let's check the final return value of
	** ct_fetch().
	*/
	if (ret == CS_END_DATA)
	{
		win_msg("All done processing rows\n");
	}
	else
	{
		/*
		** Something terrible happened.
		*/
		win_msg("ct_fetch failed\n");
	}

	/*
	** Free allocated space.
	*/
	for (i = 0; i < numcols; i++)
	{
		FREE(data[i]);
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_print_fmt -
**
****************************************************************************/
CS_INTERNAL int
cm_print_fmt(CS_COMMAND *cmd)
{
	CS_DATAFMT	datafmt;
	CS_INT		numcols;
	CS_INT		i;
	char		buf[MAX_DISPLAY_BUF];

	/*
	** For each item in the result set print the name of the column, the
	** type of the column, the maxlength, and its status information.
	*/
	if (ct_res_info(cmd, CS_NUMDATA, &numcols, CS_UNUSED, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_res_info failed");
	}

	for (i = 0; i < numcols; i++)
	{
		if (ct_describe(cmd, i + 1, &datafmt) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_describe failed");
		}

		sprintf(buf, "\ncolumn %d: name = %s\n", i, datafmt.name);
		win_result(buf);

		sprintf(buf, "\ttype = %d, maxlength = %d, status = %X\n",
			datafmt.datatype, datafmt.maxlength, datafmt.status);
		win_result(buf);

	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_print_restype -
**
****************************************************************************/
CS_INTERNAL int
cm_print_restype(CS_INT restype)
{
	CS_CHAR 	*resname;
	CS_INT		i;
	char		buf[MAX_DISPLAY_BUF];

	resname = "UNKNOWN";
	for (i = 0; i < NUM_RESTYPES; i++)
	{
		if (restype == cm__resmap[i].restype)
		{
			resname = cm__resmap[i].resname;
			break;
		}
	}
	sprintf(buf, "[Got %s]\n", resname);
	win_result(buf);

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_print_msg -
**
****************************************************************************/
CS_INTERNAL int
cm_print_msg(CS_COMMAND *cmd)
{
	CS_SMALLINT	msgid;
	char		buf[MAX_DISPLAY_BUF];

	/*
	** For each item in the result set print the name of the column, the
	** type of the column, the maxlength, and its status information.
	*/
	if (ct_res_info(cmd, CS_MSGTYPE, &msgid, CS_UNUSED, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_res_info failed");
	}

	sprintf(buf, "\nmsgid = %hd\n", msgid);
	win_result(buf);

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_results -
**
****************************************************************************/
CS_INTERNAL int
cm_results(CS_COMMAND *cmd)
{
	CS_RETCODE	ret;
	CS_INT		res_type;

	cm_state = CM_INCMD;
	active_cmd = cmd;

	/*
	** Process the results of the query.
	*/
	while ((ret = ct_results(cmd, &res_type)) == CS_SUCCEED)
	{
		/*
		** display what result type we got
		*/
		cm_print_restype(res_type);

		switch ((int) res_type)
		{
			case CS_ROW_RESULT:
			case CS_PARAM_RESULT:
			case CS_COMPUTE_RESULT:
				/*
				** fetch and display data values
				*/
				cm_fetch(cmd, res_type);
				break;

			case CS_STATUS_RESULT:
				/*
				** fetch and display status values
				*/
				cm_do_status(cmd);
				break;

			case CS_ROWFMT_RESULT:
				/*
				** This means no rows were returned.
				*/
				break;

			case CS_COMPUTEFMT_RESULT:
				/*
				** This means no rows were returned.
				*/
				break;

			case CS_DESCRIBE_RESULT:
				/*
				** This means no rows were returned.
				*/
				cm_print_fmt(cmd);
				break;

			case CS_MSG_RESULT:
				/*
				** This means no rows were returned.
				*/
				cm_print_msg(cmd);
				break;

			case CS_CMD_SUCCEED:
				/*
				** This means no rows were returned.
				*/
				break;

			case CS_CMD_DONE:
				/*
				** Done with one result set, let's go on to
				** the next.
				*/
				break;

			case CS_CMD_FAIL:
				/*
				** The server encountered an error while
				** processing our command.
				*/
				break;

			default:
				/*
				** We got something unexpected.
				*/
				break;
		}
		if (cm_state == CM_CANCEL)
		{
			ret = CS_END_RESULTS;
			win_result("\nQuery cancelled\n");
			break;
		}
	}
	active_cmd = NULL;
	cm_state = CM_NONE;

	/*
	** We're done processing results. Let's check the return value of
	** ct_results() to see if everything went ok.
	*/
	switch ((int) ret)
	{
		case CS_END_RESULTS:
			/*
			** Everything went fine.
			*/
			break;

		case CS_FAIL:
			/*
			** Something terrible happened.
			*/
			win_msg("ct_results() return FAIL.\n");
			break;

		default:
			/*
			** We got an unexpected return value.
			*/
			return cm_error(CM_FAILURE, "oc_result returned unexpected result type");
			break;
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_cancel -
**
****************************************************************************/
CS_INTERNAL int
cm_cancel()
{
	if (cm_state != CM_INCMD)
	{
		if (ct_cancel(Cdata.connection, NULL, CS_CANCEL_ALL) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE,"ct_cancel failed");
		}
	}
	else
	{
		ASSERT(active_cmd != NULL);
		if (ct_cancel(NULL, active_cmd, CS_CANCEL_ALL) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_cancel failed");
		}
		cm_state = CM_CANCEL;
	}

	return CM_SUCCESS;
}
