/****************************************************************************

NAME
	cm_cb - xisql callback handlers

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS

FILE
	cm_cb.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char		Sccsid[] ="%Z% %M% %I% %G%";
#endif

#define MAXBUF		1024

/*
** local vars
*/

/*
** local routines
*/

/****************************************************************************
**
** cm_err_handler -
**
****************************************************************************/
CS_PUBLIC CS_RETCODE
cm_err_handler
(
    CS_CONTEXT		*context,
    CS_CONNECTION	*connection,
    CS_CLIENTMSG	*errmsg
)
{
	char		ebuf[MAXBUF];

	sprintf(ebuf, "Open Client Error: %s\n", errmsg->msgstring);
	win_msg(ebuf);

	if (errmsg->osstringlen > 0)
	{
		sprintf(ebuf, "Operating System Error: %s\n", errmsg->osstring);
		win_msg(ebuf);
	}

	/*
	** If there is a timeout error, we want to try again
	** 
	** if (errmsg->severity == CS_TIMEOUT_ERROR)
	** {
	** 	return CS_FAIL;
	** }
	*/
	return CS_SUCCEED;
}

/****************************************************************************
**
** cm_msg_handler -
**
****************************************************************************/
CS_PUBLIC CS_RETCODE
cm_msg_handler
(
    CS_CONTEXT		*context,
    CS_CONNECTION	*connection,
    CS_SERVERMSG	*srvmsg
)
{
	char		mbuf[MAXBUF];
	CS_COMMAND 	*cmd;

	sprintf(mbuf, "Server message %ld, Severity %ld, State %ld, Line %ld\n",
	  srvmsg->msgnumber, srvmsg->severity, srvmsg->state, srvmsg->line);
	win_msg(mbuf);

	if (srvmsg->svrnlen > 0)
	{
		sprintf(mbuf, "Server '%s' ", srvmsg->svrname);
		win_msg(mbuf);
	}

	if (srvmsg->proclen > 0)
	{
		sprintf(mbuf, "Procedure '%s' ", srvmsg->proc);
		win_msg(mbuf);
	}

	if (srvmsg->status != 0)
	{
		sprintf(mbuf, "Status 0x%X ", srvmsg->status);
		win_msg(mbuf);
	}

	sprintf(mbuf, "\n%s\n", srvmsg->text);
	win_msg(mbuf);

	if (srvmsg->status & CS_HASEED)
	{
		win_result("\n[Start Extended ERROR]\n");
		if (ct_con_props(connection, CS_GET, CS_EED_CMD,
				 &cmd, CS_UNUSED, NULL) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_con_props(CS_EED_CMD) failed");
		}
		cm_fetch(cmd, CS_ROW_RESULT);
		win_result("\n[End Extended ERROR]\n\n");
	}

	return CS_SUCCEED;
}

/****************************************************************************
**
** cm_notif_handler -
**
****************************************************************************/
CS_PUBLIC CS_RETCODE
cm_notif_handler
(
    CS_CONNECTION	*connection,
    CS_CHAR		*procname,
    CS_INT		pnamelen
)
{
	char		buf[MAX_DISPLAY_BUF];
	CS_COMMAND 	*cmd;

	sprintf(buf, "\n-- Notification received --\nprocedure name = '%s'\n\n", procname);
	win_result(buf);

	if (ct_con_props(connection, CS_GET, CS_NOTIF_CMD,
			 &cmd, CS_UNUSED, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_con_props(CS_NOTIF_CMD) failed");
	}
	return cm_fetch(cmd, CS_ROW_RESULT);
}
