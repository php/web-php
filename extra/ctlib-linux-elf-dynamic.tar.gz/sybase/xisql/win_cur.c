/****************************************************************************

NAME
	win_cur - cursor window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_cur.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

#define MAX_PARAMS 		5
#define CMD_NAME_SIZE 		20

/*
** define cursor command radio button states
*/
#define CUR_DECLARE	0
#define CUR_DYN_DECLARE	1
#define CUR_OPEN	2
#define CUR_CLOSE	3
#define CUR_DEALLOC	4
#define CUR_FETCH	5
#define CUR_UPDATE	6
#define CUR_DELETE	7
#define CUR_CURROWS	8
#define CUR_MAXTOGGLE	9

/*
** define cursor options radio button states
*/
#define OPT_UNUSED	0
#define OPT_DEALLOC	1
#define OPT_FOR_UPATE	2
#define OPT_READ_ONLY	3
#define OPT_MAXTOGGLE	4

/*
** define parameter radio button states
*/
#define P_UNUSED	0
#define P_UPDATECOL	1
#define P_INPUTVAL	2
#define P_MAXTOGGLE	3

/*
** cursor panel
*/
typedef struct _cur_panel
{
    int			cur_id;
    char		cmd_id[CMD_NAME_SIZE];
    Widget		cur_popup;
    Widget		cur_name;
    Widget		cur_text;
    Widget		cur_opt[OPT_MAXTOGGLE];
    Widget		cur_row;
    Widget		cur_cmd[CUR_MAXTOGGLE];
    Widget		p_param[MAX_PARAMS][P_MAXTOGGLE];
    Widget		p_name[MAX_PARAMS];
    Widget		p_val[MAX_PARAMS];
    struct _cur_panel	*next;
} CurPanel;

/*
** Linked list of all cursor panels
*/
static CurPanel	*p_cur_head = NULL;
static int	global_ids = 0;

/*
** local routines
*/
static void do_send(Widget w, XtPointer cc, XtPointer cd);
static void do_batch(Widget w, XtPointer cc, XtPointer cd);
static void send_cursor(CurPanel *p_cur, int send_option);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_cursor - initialize cursor window
**
****************************************************************************/
void 
win_cursor(Widget parent, XtPointer cc, XtPointer cd)
{
    CurPanel	*p_cur;
    Arg 	args[MAXARGS];
    Widget	CursorInput;
    Widget	Box;
    Widget	Param;
    Widget	Send;
    Widget	Batch;
    Widget	Dismiss;
    int		i;
    Widget	label;
    Widget	cmdname;
    char	*buttonname;


    /*
    ** create the core cursor entry
    */
    p_cur = MALLOC(1, CurPanel);
    if (p_cur == NULL)
    {
	fprintf(stderr, "FATAL ERROR: malloc failed\n");
	exit(-1);
    }
    p_cur->next = p_cur_head;
    p_cur_head = p_cur;
    p_cur->cur_id = global_ids++;
    sprintf(p_cur->cmd_id, "cmd%02d", p_cur->cur_id);

    /*
    ** create popup shell for the cursor entry
    */
    XtSetArg(args[0], XtNinput, True);
    XtSetArg(args[1], XtNwidth, 840);
    XtSetArg(args[2], XtNheight, 360);
    p_cur->cur_popup = XtCreatePopupShell("Cursor Input Window",
    					transientShellWidgetClass,
					parent, args, 3);

    /*
    ** create a form for the cursor info
    */
    XtSetArg(args[0], XtNdefaultDistance, 2);
    CursorInput = XtCreateManagedWidget("CursorInput", formWidgetClass,
		    p_cur->cur_popup, args, 1);

    /*
    ** command name label
    */
    XtSetArg(args[0], XtNfromVert, NULL);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNlabel, "Command handle:");
    XtSetArg(args[3], XtNborderWidth, 0);
    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[5], XtNwidth, 140);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    label = XtCreateManagedWidget("CursorInput", labelWidgetClass,
			CursorInput, args, 7);

    /*
    ** command name value 
    */
    XtSetArg(args[0], XtNfromVert, NULL);
    XtSetArg(args[1], XtNfromHoriz, label);
    XtSetArg(args[2], XtNlabel, p_cur->cmd_id);
    XtSetArg(args[5], XtNborderWidth, 0);
    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[4], XtNwidth, 360);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    cmdname = XtCreateManagedWidget("CursorInput", labelWidgetClass,
    			CursorInput, args, 7);
    /*
    ** cursor name label
    */
    XtSetArg(args[0], XtNfromVert, label);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNlabel, " Name:");
    XtSetArg(args[3], XtNborderWidth, 0);
    XtSetArg(args[4], XtNheight, FIELD_HEIGHT + 3);
    XtSetArg(args[5], XtNwidth, 60);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    label = XtCreateManagedWidget("CursorInput", labelWidgetClass,
			CursorInput, args, 7);

    /*
    ** cursor name input string 
    */
    XtSetArg(args[0], XtNfromVert, cmdname);
    XtSetArg(args[1], XtNfromHoriz, label);
    XtSetArg(args[2], XtNinput, True);
    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[4], XtNwidth, 400);
    XtSetArg(args[5], XtNborderWidth, 1);
    XtSetArg(args[6], XtNstring, "");
    XtSetArg(args[7], XtNeditType, XawtextEdit);
    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
    p_cur->cur_name = XtCreateManagedWidget("CursorInput",
    			asciiTextWidgetClass, CursorInput, args, 10);
    /*
    ** cursor text label
    */
    XtSetArg(args[0], XtNfromVert, label);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNlabel, " Text:");
    XtSetArg(args[3], XtNborderWidth, 0);
    XtSetArg(args[4], XtNheight, FIELD_HEIGHT + 3);
    XtSetArg(args[5], XtNwidth, 60);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    label = XtCreateManagedWidget("CursorInput", labelWidgetClass,
			CursorInput, args, 7);

    /*
    ** text input string 
    */
    XtSetArg(args[0], XtNfromVert, p_cur->cur_name);
    XtSetArg(args[1], XtNfromHoriz, label);
    XtSetArg(args[2], XtNinput, True);
    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[4], XtNwidth, 400);
    XtSetArg(args[5], XtNborderWidth, 1);
    XtSetArg(args[6], XtNstring, "");
    XtSetArg(args[7], XtNeditType, XawtextEdit);
    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
    p_cur->cur_text = XtCreateManagedWidget("CursorInput",
    			asciiTextWidgetClass, CursorInput, args, 10);

    /*
    ** command radio buttons
    */
    buttonname = "Declare";
    XtSetArg(args[0], XtNfromVert, label);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[4], XtNhighlightThickness, 1);
    XtSetArg(args[5], XtNlabel, buttonname);
    XtSetArg(args[6], XtNradioGroup, NULL);
    XtSetArg(args[7], XtNstate, True);
    p_cur->cur_cmd[CUR_DECLARE] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "DynDeclare";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_DECLARE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    XtSetArg(args[6], XtNradioGroup, p_cur->cur_cmd[CUR_DECLARE]);
    XtSetArg(args[7], XtNstate, False);
    p_cur->cur_cmd[CUR_DYN_DECLARE] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "Open";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_DYN_DECLARE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_cmd[CUR_OPEN] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "Close";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_OPEN]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_cmd[CUR_CLOSE] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "DeAlloc";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_CLOSE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_cmd[CUR_DEALLOC] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "Fetch";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_DEALLOC]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_cmd[CUR_FETCH] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "Update";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_FETCH]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_cmd[CUR_UPDATE] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "Delete";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_UPDATE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_cmd[CUR_DELETE] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "CurRows";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_DELETE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_cmd[CUR_CURROWS] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    /*
    ** currow value 
    */
    XtSetArg(args[0], XtNfromVert, label);
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_cmd[CUR_CURROWS]);
    XtSetArg(args[2], XtNinput, True);
    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[4], XtNwidth, 50);
    XtSetArg(args[5], XtNborderWidth, 1);
    XtSetArg(args[6], XtNstring, "");
    XtSetArg(args[7], XtNeditType, XawtextEdit);
    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
    p_cur->cur_row = XtCreateManagedWidget("CursorInput",
    			asciiTextWidgetClass, CursorInput, args, 10);

    /*
    ** option radio buttons
    */
    buttonname = "No Option";
    XtSetArg(args[0], XtNfromVert, p_cur->cur_cmd[CUR_DECLARE]);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[4], XtNhighlightThickness, 1);
    XtSetArg(args[5], XtNlabel, buttonname);
    XtSetArg(args[6], XtNradioGroup, NULL);
    XtSetArg(args[7], XtNstate, True);
    p_cur->cur_opt[OPT_UNUSED] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "Dealloc";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_opt[OPT_UNUSED]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    XtSetArg(args[6], XtNradioGroup, p_cur->cur_opt[OPT_UNUSED]);
    XtSetArg(args[7], XtNstate, False);
    p_cur->cur_opt[OPT_DEALLOC] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "For Update";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_opt[OPT_DEALLOC]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_opt[OPT_FOR_UPATE] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    buttonname = "Read Only";
    XtSetArg(args[1], XtNfromHoriz, p_cur->cur_opt[OPT_FOR_UPATE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_cur->cur_opt[OPT_READ_ONLY] = XtCreateManagedWidget("CursorInput",
		    toggleWidgetClass, CursorInput, args, 8);

    Param = p_cur->cur_opt[OPT_UNUSED];
    for (i = 0; i < MAX_PARAMS; i++)
    {
	/*
	** form for parameter
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 840);
	XtSetArg(args[2], XtNfromVert, Param);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	Param = XtCreateManagedWidget("Param", formWidgetClass,
			CursorInput, args, 7);

	/*
	** param toggle button
	*/
	buttonname = "Unused";
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[6], XtNradioGroup, NULL);
	XtSetArg(args[7], XtNstate, True);
	p_cur->p_param[i][P_UNUSED] = XtCreateManagedWidget("Param",
			    toggleWidgetClass, Param, args, 8);

	buttonname = "UpdateCol";
	XtSetArg(args[1], XtNfromHoriz, p_cur->p_param[i][P_UNUSED]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[6], XtNradioGroup, p_cur->p_param[i][P_UNUSED]);
	p_cur->p_param[i][P_UPDATECOL] = XtCreateManagedWidget("Param",
			    toggleWidgetClass, Param, args, 7);

	buttonname = "InputVal";
	XtSetArg(args[1], XtNfromHoriz, p_cur->p_param[i][P_UPDATECOL]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	p_cur->p_param[i][P_INPUTVAL] = XtCreateManagedWidget("Param",
			    toggleWidgetClass, Param, args, 7);

	/*
	** cursor parameter input name label and value
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, p_cur->p_param[i][P_INPUTVAL]);
	XtSetArg(args[2], XtNlabel, "Name:");
	XtSetArg(args[3], XtNborderWidth, 0);
	XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[5], XtNwidth, 45);
	label = XtCreateManagedWidget("Param", labelWidgetClass,
			Param, args, 6);

	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 120);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	p_cur->p_name[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			Param, args, 10);

	/*
	** cursor parameter input name label and value
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, p_cur->p_name[i]);
	XtSetArg(args[2], XtNlabel, "Value: ");
	XtSetArg(args[3], XtNborderWidth, 0);
	XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[5], XtNwidth, 55);
	label = XtCreateManagedWidget("Param", labelWidgetClass,
			Param, args, 6);

	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 170);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	p_cur->p_val[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			Param, args, 10);
    }

    /*
    ** box for buttons
    */
    XtSetArg(args[0], XtNheight, 50);
    XtSetArg(args[1], XtNwidth, 300);
    XtSetArg(args[2], XtNfromVert, Param);
    XtSetArg(args[3], XtNfromHoriz, NULL);
    XtSetArg(args[4], XtNborderWidth, 0);
    XtSetArg(args[5], XtNhSpace, 10);
    XtSetArg(args[6], XtNvSpace, 2);
    Box = XtCreateManagedWidget("Box", boxWidgetClass,
		    CursorInput, args, 7);

    buttonname = "Dismiss";
    XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
    Dismiss = XtCreateManagedWidget(buttonname, commandWidgetClass,
		    Box, args, 1);
    XtAddCallback(Dismiss, XtNcallback, do_dismiss, p_cur);

    buttonname = "Send";
    XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
    Send = XtCreateManagedWidget(buttonname, commandWidgetClass,
		    Box, args, 1);
    XtAddCallback(Send, XtNcallback, do_send, p_cur);

    buttonname = "Batch";
    XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
    Batch = XtCreateManagedWidget(buttonname, commandWidgetClass,
		    Box, args, 1);
    XtAddCallback(Batch, XtNcallback, do_batch, p_cur);

    window_popup(parent, p_cur->cur_popup);

    return;
}

/****************************************************************************
**
** do_send - do_send
**
****************************************************************************/
/*ARGSUSED*/
static void
do_send(Widget w, XtPointer cc, XtPointer cd)
{
    CurPanel	*p_cur;

    p_cur = (CurPanel *)cc;

    send_cursor(p_cur, CM_SEND_NOW);
}

/****************************************************************************
**
** do_batch - do_batch
**
****************************************************************************/
/*ARGSUSED*/
static void
do_batch(Widget w, XtPointer cc, XtPointer cd)
{
    CurPanel	*p_cur;

    p_cur = (CurPanel *)cc;

    send_cursor(p_cur, CM_SEND_BATCH);
}

/****************************************************************************
**
** send_cursor - send_cursor
**
****************************************************************************/
static void
send_cursor(CurPanel *p_cur, int send_option)
{
    Arg 	args[MAXARGS];
    String	m;
    Boolean	b;
    int		i;
    char	*cmdname;
    char	*name;
    char	*text;
    int		options;
    int		cmd;
    CmParams	params[MAX_PARAMS];
    int		numparams = 0;

    CHECK_PTR( p_cur );
    cmdname = p_cur->cmd_id;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(p_cur->cur_name, args, 1);
    name = m;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(p_cur->cur_text, args, 1);
    text = m;

    /*
    ** Get current command. We could use the current value of the radio
    ** group (i think) and switch on the value, but what the hell.
    */
    cmd = CM_CURCMD_NONE;
    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_DECLARE], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_DECLARE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_DYN_DECLARE], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_DYN_DECLARE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_OPEN], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_OPEN;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_CLOSE], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_CLOSE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_DEALLOC], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_DEALLOC;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_FETCH], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_FETCH;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_UPDATE], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_UPDATE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_DELETE], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_DELETE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_cmd[CUR_CURROWS], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_CURCMD_NONE );
	cmd = CM_CURCMD_CURROWS;
	XtSetArg(args[0], XtNstring, &m);
	XtGetValues(p_cur->cur_row, args, 1);
	text = m;
    }

    /*
    ** Get current options. Agains, we could use the current value of the
    ** radio group (i think) and switch on the value, but what the hell.
    */
    options =  CM_CUROPT_NONE;
    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_opt[OPT_UNUSED], args, 1);
    if (b == True)
    {
	ASSERT( options == CM_CUROPT_NONE );
	options = CM_CUROPT_UNUSED;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_opt[OPT_DEALLOC], args, 1);
    if (b == True)
    {
	ASSERT( options == CM_CUROPT_NONE );
	options = CM_CUROPT_DEALLOC;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_opt[OPT_FOR_UPATE], args, 1);
    if (b == True)
    {
	ASSERT( options == CM_CUROPT_NONE );
	options = CM_CUROPT_FOR_UPATE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_cur->cur_opt[OPT_READ_ONLY], args, 1);
    if (b == True)
    {
	ASSERT( options == CM_CUROPT_NONE );
	options = CM_CUROPT_READ_ONLY;
    }

    /*
    ** get parameters
    */
    for (i = 0; i < MAX_PARAMS; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(p_cur->p_param[i][P_UNUSED], args, 1);

	if (b == False)
	{
	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_cur->p_name[i], args, 1);
	    params[numparams].name = m;

	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_cur->p_val[i], args, 1);
	    params[numparams].value = m;

	    params[numparams].options = CM_CPOPT_UNUSED;
	    XtSetArg(args[0], XtNstate, &b);
	    XtGetValues(p_cur->p_param[i][P_UPDATECOL], args, 1);
	    if (b == True)
	    {
		ASSERT( params[numparams].options == CM_CPOPT_UNUSED );
		params[numparams].options = CM_CPOPT_UPDATECOL;
	    }
	    XtSetArg(args[0], XtNstate, &b);
	    XtGetValues(p_cur->p_param[i][P_INPUTVAL], args, 1);
	    if (b == True)
	    {
		ASSERT( params[numparams].options == CM_CPOPT_UNUSED );
		params[numparams].options = CM_CPOPT_INPUTVAL;
	    }
	    numparams++;
	}
    }

    cm_cursor(send_option, cmdname, name, text, cmd, 
				options, params, numparams);
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    CurPanel	*p_cur;

    p_cur = (CurPanel *)cc;
    CHECK_PTR( p_cur );

    if (cm_cursor_finish(p_cur->cmd_id) != CM_SUCCESS)
    {
	    window_bell(0);
	    return;
    }

    window_popdown(p_cur->cur_popup);
}
