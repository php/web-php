/****************************************************************************

NAME
	cm - xisql routines to setup CT-Lib.

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS

FILE
	cm.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char		Sccsid[] ="%Z% %M% %I% %G%";
#endif

/*
** declare global communication structure
*/
CData		Cdata;

/****************************************************************************
**
** cm_enc_handler - encryption handler
**
****************************************************************************/
CS_PUBLIC CS_RETCODE
cm_enc_handler
(
    CS_CONNECTION	*conn,
    CS_BYTE		*t,
    CS_INT		tlen,
    CS_BYTE		*s,
    CS_INT		slen,
    CS_BYTE		**r,
    CS_INT		*rlen
)
{
	static CS_BYTE		result[255];

	*r = result;
	/*
	return com_encrypt(conn, t, tlen, s, slen, *r, rlen);
	*/
	return(CS_SUCCEED);
}

/****************************************************************************
**
** cm_init - initialize communication library
**
****************************************************************************/
CS_INTERNAL int
cm_init()
{
	CS_BYTE 	*mempool;
	CS_INT		memsize;
	CS_RETCODE	ret;

	/*
	** debug stuff
	** 
	** com_errset(CS_ERR_TRACE_ALL);
	*/

	/*
	** get a context handle to use
	*/
	if (cs_ctx_alloc(CS_VERSION_100, &Cdata.context) != CS_SUCCEED)
	{
		return cm_error(CM_FATAL, "cs_ctx_alloc failed");
	}

	/*
	** Initialize Open Client.
	*/
	if (ct_init(Cdata.context, CS_VERSION_100) != CS_SUCCEED)
	{
		return cm_error(CM_FATAL, "ct_init failed");
	}

	/*
	** Install a memory pool to use in ctlib (should be a config option)
	*/
	memsize = 50000;
	mempool = MALLOC(memsize, CS_BYTE);
	if (mempool == NULL)
	{
		return cm_error(CM_FATAL, "malloc failed");
	}
	ret = ct_config(Cdata.context, CS_SET, CS_MEM_POOL,
				mempool, memsize, NULL);
	if (ret != CS_SUCCEED)
	{
		return cm_error(CM_FATAL, "ct_config(CS_MEM_POOL) failed");
	}

	/*
	** install message and error handlers
	*/
	if (ct_callback(Cdata.context, NULL, CS_SET, CS_CLIENTMSG_CB,
			(CS_VOID *) cm_err_handler) != CS_SUCCEED)
	{
		return cm_error(CM_FATAL, "ct_callback failed");
	}
	if (ct_callback(Cdata.context, NULL, CS_SET, CS_SERVERMSG_CB,
			(CS_VOID *) cm_msg_handler) != CS_SUCCEED)
	{
		return cm_error(CM_FATAL, "ct_callback failed");
	}
	if (ct_callback(Cdata.context, NULL, CS_SET, CS_NOTIF_CB,
			(CS_VOID *) cm_notif_handler) != CS_SUCCEED)
	{
		return cm_error(CM_FATAL, "ct_callback failed");
	}

#if DO_ENCRYPT
	/*
	** install encryption routine
	*/
	if (ct_callback(Cdata.context, NULL, CS_SET, CS_ENCRYPT_CB,
			cm_enc_handler) != CS_SUCCEED)
	{
		return cm_error(CM_FATAL, "ct_callback failed");
	}
#endif				/* DO_ENCRYPT */

	/*
	** Allocate the connection handle to use
	*/
	if (ct_con_alloc(Cdata.context, &Cdata.connection) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_con_alloc failed");
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_connect - establish a connection library
**
****************************************************************************/
CS_INTERNAL int
cm_connect()
{
	CS_BOOL		bool;

	/*
	** Open a connection to the server.
	*/
	if (ct_con_props(Cdata.connection, CS_SET, CS_USERNAME,
			 Xdata.user, CS_NULLTERM, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_con_props(CS_USERNAME) failed");
	}

	if (ct_con_props(Cdata.connection, CS_SET, CS_PASSWORD,
			 Xdata.passwd, CS_NULLTERM, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_con_props(CS_PASSWORD) failed");
	}

	bool = CS_TRUE;
	if (ct_con_props(Cdata.connection, CS_SET, CS_EXPOSE_FMTS,
			 &bool, CS_UNUSED, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_con_props(CS_EXPOSE_FMTS) failed");
	}

	if (ct_connect(Cdata.connection, Xdata.server, CS_NULLTERM)
			!= CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_connect failed");
	}
#ifdef DEBUG
	if (ct_debug(Cdata.context, Cdata.connection, CS_SET_FLAG,
		     CS_DBG_PROTOCOL_STATES, NULL, CS_UNUSED) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_debug failed");
	}
#endif /* DEBUG */

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_close - close a connection
**
****************************************************************************/
CS_INTERNAL int
cm_close()
{

	if (ct_close(Cdata.connection,CS_UNUSED) !=CS_SUCCEED)
	{
		return cm_error(CM_FAILURE,"ct_close failed");
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_exit - close communication library
**
****************************************************************************/
CS_INTERNAL int
cm_exit()
{
	if (ct_con_drop(Cdata.connection) !=CS_SUCCEED)
	{
		return cm_error(CM_FAILURE,"ct_con_drop failed");
	}

	if (ct_exit(Cdata.context, CS_UNUSED) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_exit failed");
	}

	if (cs_ctx_drop(Cdata.context) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "cs_ctx_drop failed");
	}

	return CM_SUCCESS;
}

/****************************************************************************
**
** {m_debug - interface to ct_debug
**
****************************************************************************/
CS_INTERNAL int cm_debug
(
    CS_INT	command,
    CS_INT	mask,
    void	*file
)
{
	CS_RETCODE	ret;	/* check return of function */

#ifdef DEBUG
	switch ((int)command)
	{
	    case CS_SET_PROTOCOL_FILE:
		ret = ct_debug(NULL, Cdata.connection, CS_SET_PROTOCOL_FILE,
				CS_UNUSED, (CS_CHAR *)file, CS_NULLTERM);
		if (ret != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_debug failed");
		}
		break;

	    case CS_SET_DBG_FILE:
		ret = ct_debug(Cdata.context, NULL, CS_SET_DBG_FILE,
				CS_UNUSED, (CS_CHAR *) file, CS_NULLTERM);
		if (ret != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_debug failed");
		}
		break;

	    case CS_SET_FLAG:
	    case CS_CLEAR_FLAG:
		if (mask != 0)
		{
			ret = ct_debug(Cdata.context, Cdata.connection,
					command, mask, (CS_CHAR *)file,
					CS_NULLTERM);
			if (ret != CS_SUCCEED)
			{
				return cm_error(CM_FAILURE, "ct_debug failed");
			}
		}
		break;

	    default:
		return cm_error(CM_FATAL, "unknown command in cm_debug");
	}
#endif /* DEBUG */

	return CM_SUCCESS;
}

/****************************************************************************
**
** cm_error - print error, exit
**
****************************************************************************/
CS_INTERNAL int
cm_error
(
    int		error,
    char	*msg
)
{
	char		buf[1024];

	if (error == CM_FATAL)
	{
		fprintf(stderr, "FATAL ERROR: %s\n", msg);
		exit(-1);
	}
	else
	{
		sprintf(buf, "ERROR: %s\n", msg);
		win_msg(buf);
	}
	return error;
}
