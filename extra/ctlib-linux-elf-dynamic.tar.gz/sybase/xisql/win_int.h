/************************************************************************
**
** win_int.h - internal header file for window manager
**
**
**      Sccsid %Z% %M% %I% %G%
**
**      Confidential Property of Sybase, Inc.
**	Copyright  1991, 1993 by Sybase Incorporated
**	All rights reserved.
**
************************************************************************/

#ifndef __WIN_INT_H__

#define __WIN_INT_H__

/*
** include Xlib header files
*/
#ifndef NeedFunctionPrototypes
#define NeedFunctionPrototypes  1
#endif

#include	<X11/Intrinsic.h>
#include	<X11/Core.h>
#include	<X11/StringDefs.h>
#include	<X11/Shell.h>
#include	<X11/Xaw/Paned.h>
#include	<X11/Xaw/Label.h>
#include	<X11/Xaw/Form.h>
#include	<X11/Xaw/Command.h>
#include	<X11/Xaw/AsciiText.h>
#include	<X11/Xaw/Box.h>
#include	<X11/Xaw/Scrollbar.h>
#include	<X11/Xaw/Toggle.h>

#define PROMPT			"(xisql) "
#define VERSION			"1.0"

#ifndef PATCHLEVEL
#define PATCHLEVEL		0
#endif /* PATCHLEVEL */

/*
** NOTE: Should really used font size defined
*/
#define BUTTON_WIDTH(N)		((STRLEN(N) + 1) * 10)
#define FIELD_HEIGHT		20

/*
** define array sizes
*/
#define MAXARGS			20

#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

/* win_dbg.cc */
extern void win_debug P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
extern int win_dbg_file_init P_((void));
extern int win_dbg_file_close P_((void));
extern void win_dbg_file_update P_((XtPointer cd, int *s, XtInputId *id));
/* win_cap.cc */
extern void win_caps P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* win_cmd.cc */
extern int win_cmd_create P_((
	Widget parent
	));
/* win_con.cc */
extern void win_connect P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* win_cur.cc */
extern void win_cursor P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* win_dyn.cc */
extern void win_dynamic P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* win_lang.cc */
extern void win_lang P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* win_msg.cc */
extern int win_msg_create P_((
	Widget parent
	));
/* win_opt.cc */
extern void win_opt P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* win_prop.cc */
extern void win_prop P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* win_res.cc */
extern int win_result_create P_((
	Widget parent
	));
/* win_rpc.cc */
extern void win_rpc P_((
	Widget parent,
	XtPointer cc,
	XtPointer cd
	));
/* window.cc */
extern int window_reg_event P_((
	int fd,
	XtInputCallbackProc proc
	));
extern int window_popup P_((
	Widget parent,
	Widget popup
	));
extern int window_popdown P_((
	Widget popup
	));

#undef P_

#endif /* __WIN_INT_H__ */
