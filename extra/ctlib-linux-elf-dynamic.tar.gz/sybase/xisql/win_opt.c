/****************************************************************************

NAME
	win_opt - opt window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_opt.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

#define MAX_PARAMS 		5

/*
** define option toggle indexs
*/
#define OPT_ON		0
#define OPT_OFF		1
#define OPT_MAXTOGGLE	2

typedef struct _bool_opts
{
	char		*name;
	CS_INT		option;
	Widget		opt_enable;
	Widget		opt_onoff[OPT_MAXTOGGLE];
} BoolOpts;

/*
** boolean option table
*/
static BoolOpts bool_opt[] =
{
    { "ansinull",	CS_OPT_ANSINULL,	0, { 0, 0 } },
    { "arithabort",	CS_OPT_ARITHABORT,	0, { 0, 0 } },
    { "arithignore",	CS_OPT_ARITHIGNORE,	0, { 0, 0 } },
    { "chainxacts",	CS_OPT_CHAINXACTS,	0, { 0, 0 } },
    { "curcloseonxact",	CS_OPT_CURCLOSEONXACT,	0, { 0, 0 } },
    { "forceplan",	CS_OPT_FORCEPLAN,	0, { 0, 0 } },
    { "formatonly",	CS_OPT_FORMATONLY,	0, { 0, 0 } },
    { "fipsflag",	CS_OPT_FIPSFLAG,	0, { 0, 0 } },
    { "getdata",	CS_OPT_GETDATA,		0, { 0, 0 } },
    { "nocount",	CS_OPT_NOCOUNT,		0, { 0, 0 } },
    { "noexec",		CS_OPT_NOEXEC,		0, { 0, 0 } },
    { "parseonly",	CS_OPT_PARSEONLY,	0, { 0, 0 } },
    { "restrees",	CS_OPT_RESTREES,	0, { 0, 0 } },
    { "showplan",	CS_OPT_SHOWPLAN,	0, { 0, 0 } },
    { "stats io",	CS_OPT_STATS_IO,	0, { 0 } },
    { "stats time",	CS_OPT_STATS_TIME,	0, { 0 } },
    { "truncignore",	CS_OPT_TRUNCIGNORE,	0, { 0, 0 } },
};

#define MAX_BOOL_OPTS	(sizeof (bool_opt) / sizeof (bool_opt[0]))

typedef struct _param_opts
{
	char		*name;
	CS_INT		option;
	Widget		opt_enable;
	Widget		opt_string;
} ParamOpts;

/*
** parameterized option table
*/
static ParamOpts param_opt[] =
{
    { "authoff",	CS_OPT_AUTHOFF,		0, 0 },
    { "authon",		CS_OPT_AUTHON,		0, 0 },
    { "charset",	CS_OPT_CHARSET,		0, 0 },
    { "curread",	CS_OPT_CURREAD,		0, 0 },
    { "curwrite",	CS_OPT_CURWRITE,	0, 0 },
    { "datefirst",	CS_OPT_DATEFIRST,	0, 0 },
    { "dateformat",	CS_OPT_DATEFORMAT,	0, 0 },
    { "indentityoff",	CS_OPT_IDENTITYOFF,	0, 0 },
    { "indentityon",	CS_OPT_IDENTITYON,	0, 0 },
    { "isolation",	CS_OPT_ISOLATION,	0, 0 },
    { "natlang",	CS_OPT_NATLANG,		0, 0 },
    { "rowcount",	CS_OPT_ROWCOUNT,	0, 0 },
    { "textsize",	CS_OPT_TEXTSIZE,	0, 0 },
};

#define MAX_PARAM_OPTS	(sizeof (param_opt) / sizeof (param_opt[0]))

/*
** buttons defined
*/
static Widget		opt_popup;

/*
** local routines
*/
static void do_option(Widget w, XtPointer cc, XtPointer cd);
static void do_enable(Widget w, XtPointer cc, XtPointer cd);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_opt_param - initialize option parameter window
**
****************************************************************************/
static void 
win_opt_param(Widget parent)
{
    Widget	ParamOption;
    Arg 	args[MAXARGS];
    int		i;

    ParamOption = NULL;
    for (i = 0; i < MAX_PARAM_OPTS; i++)
    {
	/*
	** form for option
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 400);
	XtSetArg(args[2], XtNfromVert, ParamOption);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	ParamOption = XtCreateManagedWidget("ParamOption", formWidgetClass,
			parent, args, 7);

	/*
	** option enable button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, 150);
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, param_opt[i].name);
	XtSetArg(args[6], XtNstate, False);
	param_opt[i].opt_enable = XtCreateManagedWidget("ParamOption",
			    toggleWidgetClass, ParamOption, args, 7);

	/*
	** option string field
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, param_opt[i].opt_enable);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 250);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	param_opt[i].opt_string = XtCreateManagedWidget("ParamOption",
			    asciiTextWidgetClass, ParamOption, args, 10);
    }
}

/****************************************************************************
**
** win_opt_bool - initialize option boolean window
**
****************************************************************************/
static void 
win_opt_bool(Widget parent, int start, int end)
{
    Widget	BoolOption;
    Arg 	args[MAXARGS];
    int		i;

    BoolOption = NULL;
    for (i = start; i < end; i++)
    {
	/*
	** form for option
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 200);
	XtSetArg(args[2], XtNfromVert, BoolOption);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	BoolOption = XtCreateManagedWidget("BoolOption", formWidgetClass,
			parent, args, 7);

	/*
	** option enable button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, 150);
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, bool_opt[i].name);
	XtSetArg(args[6], XtNstate, False);
	bool_opt[i].opt_enable = XtCreateManagedWidget("BoolOption",
			    toggleWidgetClass, BoolOption, args, 7);

	/*
	** option toggle button
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, bool_opt[i].opt_enable);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, 50);
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, "Off");
	XtSetArg(args[6], XtNradioGroup, NULL);
	XtSetArg(args[7], XtNstate, True);
	bool_opt[i].opt_onoff[OPT_OFF] = XtCreateManagedWidget("BoolOption",
			    toggleWidgetClass, BoolOption, args, 8);

	XtSetArg(args[1], XtNfromHoriz, bool_opt[i].opt_onoff[OPT_OFF]);
	XtSetArg(args[5], XtNlabel, "On");
	XtSetArg(args[6], XtNradioGroup, bool_opt[i].opt_onoff[OPT_OFF]);
	XtSetArg(args[7], XtNstate, False);
	bool_opt[i].opt_onoff[OPT_ON] = XtCreateManagedWidget("BoolOption",
			    toggleWidgetClass, BoolOption, args, 8);

    }
}

/****************************************************************************
**
** win_opt - initialize opt window
**
****************************************************************************/
void 
win_opt(Widget parent, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    Widget	OptInput;
    Widget	OptParam;
    Widget	OptBool;
    Widget	Box;
    Widget	Button;
    char	*buttonname;

    opt_popup = XtNameToWidget(parent, "Option Input Window");

    if (!opt_popup)
    {
	XtSetArg(args[0], XtNinput, True);
	XtSetArg(args[1], XtNheight, 600);
	XtSetArg(args[2], XtNwidth, 900);
	opt_popup = XtCreatePopupShell("Option Input Window",
					transientShellWidgetClass,
					parent, args, 3);

	/*
	** create a form for the opt info
	*/
	XtSetArg(args[0], XtNdefaultDistance, 2);
	OptInput = XtCreateManagedWidget("OptInput", formWidgetClass,
			opt_popup, args, 1);

	/*
	** form for options with args
	*/
	XtSetArg(args[0], XtNheight, 500);
	XtSetArg(args[1], XtNwidth, 400);
	XtSetArg(args[2], XtNfromVert, NULL);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	OptParam = XtCreateManagedWidget("OptParam", formWidgetClass,
			OptInput, args, 7);

	/*
	** Create option list with params
	*/
	win_opt_param(OptParam);

	/*
	** form for options with bool
	*/
	XtSetArg(args[0], XtNheight, 500);
	XtSetArg(args[1], XtNwidth, 200);
	XtSetArg(args[2], XtNfromVert, NULL);
	XtSetArg(args[3], XtNfromHoriz, OptParam);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	OptBool = XtCreateManagedWidget("OptBool", formWidgetClass,
			OptInput, args, 7);

	/*
	** Create option list of boolean options
	*/
	win_opt_bool(OptBool, 0, MAX_BOOL_OPTS);

	/*
	** box for buttons
	*/
	XtSetArg(args[0], XtNheight, 100);
	XtSetArg(args[1], XtNwidth, 500);
	XtSetArg(args[2], XtNfromVert, OptParam);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 0);
	XtSetArg(args[5], XtNhSpace, 10);
	XtSetArg(args[6], XtNvSpace, 2);
	Box = XtCreateManagedWidget("Box", boxWidgetClass,
			OptInput, args, 7);

	buttonname = "Dismiss";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_dismiss, NULL);

	buttonname = "Set";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_option, (XtPointer)CS_SET);

	buttonname = "Get";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_option, (XtPointer)CS_GET);

	buttonname = "Clear";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_option, (XtPointer)CS_CLEAR);

	buttonname = "Enable All";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_enable, (XtPointer)CS_SET);

	buttonname = "Disable All";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Button = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Button, XtNcallback, do_enable, (XtPointer)CS_CLEAR);
    }

    window_popup(parent, opt_popup);

    return;
}

/****************************************************************************
**
** do_option - do_option
**
****************************************************************************/
/*ARGSUSED*/
static void
do_option(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    String	m;
    Boolean	b;
    CS_INT	cs_bool;
    CS_INT	cs_int;
    CS_INT	action;
    Arg 	args[MAXARGS];
    char	charbuff[255];

    action = (CS_INT)cc;

    for (i = 0; i < MAX_BOOL_OPTS; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(bool_opt[i].opt_enable, args, 1);

	if (b == True)
	{
	    XtGetValues(bool_opt[i].opt_onoff[OPT_ON], args, 1);
	    cs_bool = (b == TRUE) ? CS_TRUE : CS_FALSE;
	    cm_opt(action, bool_opt[i].option, &cs_bool);

	    b = (cs_bool == CS_TRUE) ? True : False;
	    XtSetArg(args[0], XtNstate, b);
	    XtSetValues(bool_opt[i].opt_onoff[OPT_ON], args, 1);
	    XtSetArg(args[0], XtNstate, !b);
	    XtSetValues(bool_opt[i].opt_onoff[OPT_OFF], args, 1);
	}
    }

    for (i = 0; i < MAX_PARAM_OPTS; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(param_opt[i].opt_enable, args, 1);

	if (b == True)
	{
	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(param_opt[i].opt_string, args, 1);
	    COPSTR(charbuff, m, sizeof (charbuff));
	    cm_opt(action, param_opt[i].option, charbuff);
	    switch ((int)param_opt[i].option)
	    {
		case CS_OPT_CHARSET:
		case CS_OPT_CURREAD:
		case CS_OPT_CURWRITE:
		case CS_OPT_NATLANG:
		    XtSetArg(args[0], XtNstring, charbuff);
		    XtSetValues(param_opt[i].opt_string, args, 1);
		    break;

		default:
		    MEMCPY(&cs_int, charbuff, sizeof(cs_int));
		    sprintf(charbuff, "%ld", cs_int);
		    XtSetArg(args[0], XtNstring, charbuff);
		    XtSetValues(param_opt[i].opt_string, args, 1);
		    break;
	    }
	}
    }
}

/****************************************************************************
**
** do_enable - do_enable
**
****************************************************************************/
/*ARGSUSED*/
static void
do_enable(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    Boolean	b;
    Arg 	args[MAXARGS];

    b = ((CS_INT)cc == CS_SET) ? True : False;

    for (i = 0; i < MAX_BOOL_OPTS; i++)
    {
	XtSetArg(args[0], XtNstate, b);
	XtSetValues(bool_opt[i].opt_enable, args, 1);
    }
    for (i = 0; i < MAX_PARAM_OPTS; i++)
    {
	XtSetArg(args[0], XtNstate, b);
	XtSetValues(param_opt[i].opt_enable, args, 1);
    }
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    window_popdown(opt_popup);
}
