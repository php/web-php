/****************************************************************************

NAME
	cm_opt - xisql interface to CT-Lib option commands

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_opt.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/****************************************************************************
**
** cm_opt - 
**
****************************************************************************/
CS_INTERNAL int
cm_opt
(
    CS_INT	action,
    CS_INT	option,
    CS_VOID	*value
)
{
	CS_INT	len = CS_UNUSED;
	CS_INT	new_value;

	/*
	** massage len and values
	*/
	switch ((int)option)
	{
	    case CS_OPT_DATEFIRST:
	    case CS_OPT_DATEFORMAT:
	    case CS_OPT_ISOLATION:
	    case CS_OPT_ROWCOUNT:
	    case CS_OPT_TEXTSIZE:
		if (action == CS_SET)
		{
			new_value = strtol(value, (char **)NULL, 0);
			MEMCPY(value, &new_value, sizeof(new_value));
		}
		break;

	    case CS_OPT_AUTHOFF:
	    case CS_OPT_AUTHON:
	    case CS_OPT_CHARSET:
	    case CS_OPT_CURREAD:
	    case CS_OPT_CURWRITE:
	    case CS_OPT_IDENTITYOFF:
	    case CS_OPT_IDENTITYON:
	    case CS_OPT_NATLANG:
		if (action == CS_SET)
		{
			len = STRLEN(value);
		}
		else
		{
			len = 255;
		}
		break;

	    default:
		break;
	}

	/*
	** execute option command.
	*/
	if (ct_options(Cdata.connection, action, option,
			    value, len, NULL) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_options failed");
	}

	return CM_SUCCESS;
}
