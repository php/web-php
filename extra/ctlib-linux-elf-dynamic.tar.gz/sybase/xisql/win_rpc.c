/****************************************************************************

NAME
	win_rpc - rpc window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_rpc.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

#define MAX_PARAMS 		5

/*
** define parameter toggle states
*/
#define P_UNUSED	0
#define P_INPUT		1
#define P_OUTPUT	2
#define P_MAXTOGGLE	3

/*
** buttons defined
*/
static Widget		rpc_popup;
static Widget		rpc_name;
static Widget		rpc_option;
static Widget		p_param[MAX_PARAMS][P_MAXTOGGLE];
static Widget		p_name[MAX_PARAMS];
static Widget		p_dtype[MAX_PARAMS];
static Widget		p_val[MAX_PARAMS];

/*
** local routines
*/
static void do_send(Widget w, XtPointer cc, XtPointer cd);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_rpc - initialize rpc window
**
****************************************************************************/
void 
win_rpc(Widget parent, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    Widget	RpcInput;
    Widget	Box;
    Widget	Param;
    Widget	Send;
    Widget	Dismiss;
    int		i;
    Widget	label;
    char	*buttonname;

    rpc_popup = XtNameToWidget(parent, "Rpc Input Window");

    if (!rpc_popup)
    {
	XtSetArg(args[0], XtNinput, True);
	XtSetArg(args[1], XtNwidth, 830);
	XtSetArg(args[2], XtNheight, 250);
	rpc_popup = XtCreatePopupShell("Rpc Input Window",
					transientShellWidgetClass,
					parent, args, 3);

	/*
	** create a form for the rpc info
	*/
	XtSetArg(args[0], XtNdefaultDistance, 2);
	RpcInput = XtCreateManagedWidget("RpcInput", formWidgetClass,
			rpc_popup, args, 1);

	/*
	** rpc name label
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNlabel, "RpcName:");
	XtSetArg(args[3], XtNborderWidth, 0);
	XtSetArg(args[4], XtNheight, FIELD_HEIGHT + 3);
	XtSetArg(args[5], XtNwidth, 80);
	XtSetArg(args[6], XtNjustify, XtJustifyLeft);
	label = XtCreateManagedWidget("RpcInput", labelWidgetClass,
			RpcInput, args, 7);

	/*
	** rpc name input string 
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 270);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	rpc_name = XtCreateManagedWidget("RpcInput", asciiTextWidgetClass,
			RpcInput, args, 10);

	/*
	** recompile toggle button
	*/
	buttonname = "Recompile";
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, rpc_name);
	XtSetArg(args[2], XtNhighlightThickness, 1);
	XtSetArg(args[3], XtNstate, False);
	XtSetArg(args[4], XtNlabel, buttonname);
	XtSetArg(args[5], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[6], XtNwidth, BUTTON_WIDTH(buttonname));
	rpc_option = XtCreateManagedWidget("RpcInput", toggleWidgetClass,
			RpcInput, args, 7);

	Param = label;
	for (i = 0; i < MAX_PARAMS; i++)
	{
	    /*
	    ** form for parameter
	    */
	    XtSetArg(args[0], XtNheight, 25);
	    XtSetArg(args[1], XtNwidth, 830);
	    XtSetArg(args[2], XtNfromVert, Param);
	    XtSetArg(args[3], XtNfromHoriz, NULL);
	    XtSetArg(args[4], XtNborderWidth, 1);
	    XtSetArg(args[5], XtNhSpace, 2);
	    XtSetArg(args[6], XtNvSpace, 2);
	    Param = XtCreateManagedWidget("Param", formWidgetClass,
			    RpcInput, args, 7);

	    /*
	    ** param toggle button
	    */
	    buttonname = "Unused";
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, NULL);
	    XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	    XtSetArg(args[4], XtNhighlightThickness, 1);
	    XtSetArg(args[5], XtNlabel, buttonname);
	    XtSetArg(args[6], XtNradioGroup, NULL);
	    XtSetArg(args[7], XtNstate, True);
	    p_param[i][P_UNUSED] = XtCreateManagedWidget("Param",
	    			toggleWidgetClass, Param, args, 8);

	    buttonname = "Input";
	    XtSetArg(args[1], XtNfromHoriz, p_param[i][P_UNUSED]);
	    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	    XtSetArg(args[5], XtNlabel, buttonname);
	    XtSetArg(args[6], XtNradioGroup, p_param[i][P_UNUSED]);
	    p_param[i][P_INPUT] = XtCreateManagedWidget("Param",
	    			toggleWidgetClass, Param, args, 7);

	    buttonname = "Output";
	    XtSetArg(args[1], XtNfromHoriz, p_param[i][P_INPUT]);
	    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	    XtSetArg(args[5], XtNlabel, buttonname);
	    p_param[i][P_OUTPUT] = XtCreateManagedWidget("Param",
	    			toggleWidgetClass, Param, args, 7);

	    /*
	    ** rpc parameter input name label and value
	    */
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, p_param[i][P_OUTPUT]);
	    XtSetArg(args[2], XtNlabel, "Name:");
	    XtSetArg(args[3], XtNborderWidth, 0);
	    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[5], XtNwidth, 35);
	    label = XtCreateManagedWidget("Param", labelWidgetClass,
			    Param, args, 6);

	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, label);
	    XtSetArg(args[2], XtNinput, True);
	    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[4], XtNwidth, 100);
	    XtSetArg(args[5], XtNborderWidth, 1);
	    XtSetArg(args[6], XtNstring, "");
	    XtSetArg(args[7], XtNeditType, XawtextEdit);
	    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	    p_name[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			    Param, args, 10);

	    /*
	    ** rpc parameter datatype label and value
	    */
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, p_name[i]);
	    XtSetArg(args[2], XtNlabel, "Datatype:");
	    XtSetArg(args[3], XtNborderWidth, 0);
	    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[5], XtNwidth, 75);
	    label = XtCreateManagedWidget("Param", labelWidgetClass,
			    Param, args, 6);

	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, label);
	    XtSetArg(args[2], XtNinput, True);
	    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[4], XtNwidth, 110);
	    XtSetArg(args[5], XtNborderWidth, 1);
	    XtSetArg(args[6], XtNstring, "");
	    XtSetArg(args[7], XtNeditType, XawtextEdit);
	    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	    p_dtype[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			    Param, args, 10);

	    /*
	    ** rpc parameter input value label and value
	    */
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, p_dtype[i]);
	    XtSetArg(args[2], XtNlabel, "Value: ");
	    XtSetArg(args[3], XtNborderWidth, 0);
	    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[5], XtNwidth, 40);
	    label = XtCreateManagedWidget("Param", labelWidgetClass,
			    Param, args, 6);

	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, label);
	    XtSetArg(args[2], XtNinput, True);
	    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[4], XtNwidth, 150);
	    XtSetArg(args[5], XtNborderWidth, 1);
	    XtSetArg(args[6], XtNstring, "");
	    XtSetArg(args[7], XtNeditType, XawtextEdit);
	    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	    p_val[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			    Param, args, 10);
	}

	/*
	** box for buttons
	*/
	XtSetArg(args[0], XtNheight, 50);
	XtSetArg(args[1], XtNwidth, 200);
	XtSetArg(args[2], XtNfromVert, Param);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 0);
	XtSetArg(args[5], XtNhSpace, 10);
	XtSetArg(args[6], XtNvSpace, 2);
	Box = XtCreateManagedWidget("Box", boxWidgetClass,
			RpcInput, args, 7);

	buttonname = "Dismiss";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Dismiss = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Dismiss, XtNcallback, do_dismiss, NULL);

	buttonname = "Send";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Send = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Send, XtNcallback, do_send, NULL);
    }

    window_popup(parent, rpc_popup);

    return;
}

/****************************************************************************
**
** do_send - do_send
**
****************************************************************************/
/*ARGSUSED*/
static void
do_send(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    String	m;
    Boolean	b;
    char	*name;
    int		options;
    CmParams	params[MAX_PARAMS];
    int		numparams = 0;
    Arg 	args[MAXARGS];

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(rpc_name, args, 1);
    name = m;

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(rpc_option, args, 1);
    options = (b == True) ? CM_RECOMPILE : CM_NO_OPTION;

    for (i = 0; i < MAX_PARAMS; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(p_param[i][P_UNUSED], args, 1);

	if (b == False)
	{
	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_name[i], args, 1);
	    params[numparams].name = m;

	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_dtype[i], args, 1);
	    params[numparams].dtype = m;

	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_val[i], args, 1);
	    params[numparams].value = m;

	    XtSetArg(args[0], XtNstate, &b);
	    XtGetValues(p_param[i][P_INPUT], args, 1);
	    params[numparams].options = (b == True) ? CM_INPUT : CM_OUTPUT;
	    numparams++;
	}
    }

    cm_rpc(name, options, params, numparams);
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    window_popdown(rpc_popup);
}
