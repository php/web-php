/****************************************************************************

NAME
	win_lang - command window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_lang.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** maximum number of params to support
*/
#define MAX_PARAMS 	5

/*
** define parameter toggle states
*/
#define P_UNUSED	0
#define P_INPUT		1
#define P_MAXTOGGLE	2

/*
** buttons defined
*/
static Widget		lang_popup;
static Widget		lang_text;
static Widget		p_param[MAX_PARAMS][P_MAXTOGGLE];
static Widget		p_name[MAX_PARAMS];
static Widget		p_dtype[MAX_PARAMS];
static Widget		p_val[MAX_PARAMS];

/*
** local routines
*/
static void do_send(Widget w, XtPointer cc, XtPointer cd);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);
static void do_clear(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_lang - initialize lang window
**
****************************************************************************/
void 
win_lang(Widget parent, XtPointer cc, XtPointer cd)
{
    Arg 	args[MAXARGS];
    Widget	LangInput;
    Widget	Box;
    Widget	Param;
    Widget	Send;
    Widget	Dismiss;
    Widget	Clear;
    int		i;
    Widget	label;
    char	*buttonname;

    lang_popup = XtNameToWidget(parent, "Language Input Window");

    if (!lang_popup)
    {
	XtSetArg(args[0], XtNinput, True);
	XtSetArg(args[1], XtNheight, 350);
	XtSetArg(args[2], XtNwidth, 830);
	lang_popup = XtCreatePopupShell("Language Input Window",
					transientShellWidgetClass,
					parent, args, 3);

	/*
	** create a form for the lang info
	*/
	XtSetArg(args[0], XtNdefaultDistance, 2);
	LangInput = XtCreateManagedWidget("LangInput", formWidgetClass,
			lang_popup, args, 1);

	/*
	** lang text input area 
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, 100);
	XtSetArg(args[4], XtNwidth, 700);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");	
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollVertical, XawtextScrollAlways);
	XtSetArg(args[9], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	lang_text = XtCreateManagedWidget("LangInput", asciiTextWidgetClass,
			LangInput, args, 10);

	Param = lang_text;
	for (i = 0; i < MAX_PARAMS; i++)
	{
	    /*
	    ** form for parameter
	    */
	    XtSetArg(args[0], XtNheight, 25);
	    XtSetArg(args[1], XtNwidth, 700);
	    XtSetArg(args[2], XtNfromVert, Param);
	    XtSetArg(args[3], XtNfromHoriz, NULL);
	    XtSetArg(args[4], XtNborderWidth, 1);
	    XtSetArg(args[5], XtNhSpace, 2);
	    XtSetArg(args[6], XtNvSpace, 2);
	    Param = XtCreateManagedWidget("Param", formWidgetClass,
			    LangInput, args, 7);

	    /*
	    ** param toggle button
	    */
	    buttonname = "Unused";
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, NULL);
	    XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	    XtSetArg(args[4], XtNhighlightThickness, 1);
	    XtSetArg(args[5], XtNlabel, buttonname);
	    XtSetArg(args[6], XtNradioGroup, NULL);
	    XtSetArg(args[7], XtNstate, True);
	    p_param[i][P_UNUSED] = XtCreateManagedWidget("Param",
	    			toggleWidgetClass, Param, args, 8);

	    buttonname = "Input";
	    XtSetArg(args[1], XtNfromHoriz, p_param[i][P_UNUSED]);
	    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	    XtSetArg(args[5], XtNlabel, buttonname);
	    XtSetArg(args[6], XtNradioGroup, p_param[i][P_UNUSED]);
	    p_param[i][P_INPUT] = XtCreateManagedWidget("Param",
	    			toggleWidgetClass, Param, args, 7);

	    /*
	    ** lang parameter input name label and value
	    */
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, p_param[i][P_INPUT]);
	    XtSetArg(args[2], XtNlabel, "Name:");
	    XtSetArg(args[3], XtNborderWidth, 0);
	    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[5], XtNwidth, 35);
	    label = XtCreateManagedWidget("Param", labelWidgetClass,
			    Param, args, 6);

	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, label);
	    XtSetArg(args[2], XtNinput, True);
	    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[4], XtNwidth, 100);
	    XtSetArg(args[5], XtNborderWidth, 1);
	    XtSetArg(args[6], XtNstring, "");
	    XtSetArg(args[7], XtNeditType, XawtextEdit);
	    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	    p_name[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			    Param, args, 10);

	    /*
	    ** lang parameter datatype label and value
	    */
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, p_name[i]);
	    XtSetArg(args[2], XtNlabel, "Datatype:");
	    XtSetArg(args[3], XtNborderWidth, 0);
	    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[5], XtNwidth, 75);
	    label = XtCreateManagedWidget("Param", labelWidgetClass,
			    Param, args, 6);

	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, label);
	    XtSetArg(args[2], XtNinput, True);
	    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[4], XtNwidth, 110);
	    XtSetArg(args[5], XtNborderWidth, 1);
	    XtSetArg(args[6], XtNstring, "");
	    XtSetArg(args[7], XtNeditType, XawtextEdit);
	    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	    p_dtype[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			    Param, args, 10);

	    /*
	    ** lang parameter input value label and value
	    */
	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, p_dtype[i]);
	    XtSetArg(args[2], XtNlabel, "Value: ");
	    XtSetArg(args[3], XtNborderWidth, 0);
	    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[5], XtNwidth, 40);
	    label = XtCreateManagedWidget("Param", labelWidgetClass,
			    Param, args, 6);

	    XtSetArg(args[0], XtNfromVert, NULL);
	    XtSetArg(args[1], XtNfromHoriz, label);
	    XtSetArg(args[2], XtNinput, True);
	    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	    XtSetArg(args[4], XtNwidth, 150);
	    XtSetArg(args[5], XtNborderWidth, 1);
	    XtSetArg(args[6], XtNstring, "");
	    XtSetArg(args[7], XtNeditType, XawtextEdit);
	    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	    p_val[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			    Param, args, 10);
	}

	/*
	** box for buttons
	*/
	XtSetArg(args[0], XtNheight, 50);
	XtSetArg(args[1], XtNwidth, 700);
	XtSetArg(args[2], XtNfromVert, Param);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 0);
	XtSetArg(args[5], XtNhSpace, 10);
	XtSetArg(args[6], XtNvSpace, 2);
	Box = XtCreateManagedWidget("Box", boxWidgetClass,
			LangInput, args, 7);

	buttonname = "Dismiss";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Dismiss = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Dismiss, XtNcallback, do_dismiss, NULL);

	buttonname = "Send";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Send = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Send, XtNcallback, do_send, NULL);

	buttonname = "Clear";
	XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
	Clear = XtCreateManagedWidget(buttonname, commandWidgetClass,
			Box, args, 1);
	XtAddCallback(Clear, XtNcallback, do_clear, NULL);
    }

    window_popup(parent, lang_popup);

    return;
}

/****************************************************************************
**
** do_send - do_send
**
****************************************************************************/
static void
do_send(Widget w, XtPointer cc, XtPointer cd)
{
    int		i;
    String	m;
    Boolean	b;
    char	*text;
    CmParams	params[MAX_PARAMS];
    int		numparams = 0;
    Arg 	args[MAXARGS];

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(lang_text, args, 1);
    text = m;

    for (i = 0; i < MAX_PARAMS; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(p_param[i][P_UNUSED], args, 1);

	if (b == False)
	{
	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_name[i], args, 1);
	    params[numparams].name = m;

	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_dtype[i], args, 1);
	    params[numparams].dtype = m;

	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_val[i], args, 1);
	    params[numparams].value = m;

	    XtSetArg(args[0], XtNstate, &b);
	    XtGetValues(p_param[i][P_INPUT], args, 1);
	    params[numparams].options = (b == True) ? CM_INPUT : CM_NO_OPTION;
	    numparams++;
	}
    }

    cm_lang(text, params, numparams);
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    window_popdown(lang_popup);
}

/****************************************************************************
**
** do_clear - clear the language window
**
****************************************************************************/
static void
do_clear(Widget w, XtPointer cc, XtPointer cd)
{
    XawTextBlock        textblock;
    XawTextPosition	begpos;
    XawTextPosition     endpos;

    textblock.firstPos = 0;
    textblock.length   = 0;
    textblock.ptr      = "";

    /*
    begpos = XawTextTopPosition(lang_text);
    */
    begpos = 0;
    endpos = XawTextGetInsertionPoint(lang_text);
    XawTextReplace(lang_text, begpos, endpos, &textblock);
    XawTextSetInsertionPoint(lang_text, begpos);
}
