/****************************************************************************

NAME
	cm_prop - xisql interface to CT-Lib property commands

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_prop.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/****************************************************************************
**
** cm_prop - 
**
****************************************************************************/
CS_INTERNAL int
cm_prop
(
    CS_INT	prop_type,
    CS_INT	action,
    CS_INT	property,
    CS_VOID	*value,
    CS_INT	len,
    CS_INT	*outlen
)
{
	if (prop_type == CM_CTX_PROP)
	{
		/*
		** execute property command.
		*/
		if (ct_config(Cdata.context, action, property,
				    value, len, outlen) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_config failed");
		}
	}
	else
	{
		/*
		** execute property command.
		*/
		if (ct_con_props(Cdata.connection, action, property,
				    value, len, outlen) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_con_props failed");
		}
	}

	return CM_SUCCESS;
}
