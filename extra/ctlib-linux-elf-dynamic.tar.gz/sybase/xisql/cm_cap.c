/****************************************************************************

NAME
	cm_cap - xisql interface to CT-Lib capabilities

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_cap.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/****************************************************************************
**
** cm_cap - 
**
****************************************************************************/
CS_INTERNAL int
cm_cap
(
    CS_INT	type,
    CS_INT 	action,
    CS_INT 	cap,
    CS_BOOL 	*value
)
{
	/*
	** execute capability command.
	*/
	if (ct_capability(Cdata.connection, action, type,
			cap, (CS_VOID *)value) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_capability failed");
	}

	return CM_SUCCESS;
}
