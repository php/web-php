/****************************************************************************

NAME
	util - Sybase utility programs

SYNOPSIS
	#include "xisql.h"

	void utl_bomb(file, line)
	  char	*file;
	  int	line;

	void utl_copstr(dest, src, size)
	  char	*dest;
	  char	*src;
	  int	size;

	void utl_catstr(dest, src, size)
	  char	*dest;
	  char	*src;
	  int	size;

	void utl_panic(msg)
	  char	*msg;

	void utl_chkptr(p_ptr, file, line)
	  char	*p_ptr;
	  char	*file;
	  int	line;

DESCRIPTION
	utl_bomb() will print the file name line number specified to stderr,
	and crash the system via abort().

	utl_copstr() and utl_catstr() are sanity check functions which make
	sure that the destination of and string copies/cats can hold the
	data.

	utl_panic() prints the message given, and exits with a -1 status code.

	utl_chkptr() will try and verify that the data space pointed to by
	p_ptr is in the users valid data space.  If a invalid pointer is
	found, the offending file and line number are printed out, and the
	program aborted via abort(). 

RETURNS
	Nothing

WARNINGS	

COPYRIGHT
        Copyright (C) 1990 by Sybase Incorporated
        All rights reserved.

AUTHOR
        Otto Lind

****************************************************************************/

#include	<stdio.h>
#include	<errno.h>

#if SUNOS_4
#include	<signal.h>
#include	<string.h>
#include	<sys/file.h>
#endif

#include	<xisql.h>

#if SUNOS_4
extern void exit();
#endif

#ifndef NO_SCCSID
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** local functions
*/
static void do_abort(void);

/**************************************************************************
**
** utl_bomb - abort program, prints file and line number of offending module
**
**************************************************************************/
void 
utl_bomb(char *file, int line)
{
	/*
	** Print out an error message.
	*/
	(void)fprintf(stderr, "\n\rassertion failed, file '%s' line %d\n\r",
		    file, line);

	do_abort();
}

/**************************************************************************
**
** utl_copstr - check sanity of strcpy
**
**************************************************************************/
void
utl_copstr(char *dest, char *src, int size)
{
	ASSERT( dest != NIL(char *) );
	ASSERT( src != NIL(char *) );
	ASSERT( size > 0 );
	ASSERT( strlen(src) < size );

	(void)strcpy(dest, src);
}

/**************************************************************************
**
** utl_catstr - check sanity of strcat
**
**************************************************************************/
void
utl_catstr(char *dest, char *src, int size)
{
	ASSERT( dest != NIL(char *) );
	ASSERT( src != NIL(char *) );
	ASSERT( size > 0 );
	ASSERT( strlen(dest) + strlen(src) < size );

	(void)strcat(dest, src);
}

/****************************************************************************
**
** utl_panic - write message, exit program
**
****************************************************************************/
void 
utl_panic(char *msg)
{
	ASSERT( msg != NIL(char *) );

	(void)fprintf(stderr, "\nSYSTEM ERROR: unrecoverable error: %s\n", msg);
	exit(-1);
}

/****************************************************************************
**
** utl_chkptr - validate pointer is in valid memory space
**
****************************************************************************/
void
utl_chkptr(char *p_ptr, char *file, int line)
{
#ifdef CHECK_ALL_MEMORY
    int		a;		/* return of access function */

    /*
    ** Use the access function to verify that the dataspace pointed to by
    ** p_ptr is valid.  We really don't care about the return value of a,
    ** unless errno set set to EFAULT, which indicates a toasted pointer.
    */
    a = access(p_ptr, F_OK);

    if ( a != 0 )
    {
	if (errno == EFAULT)
	{
	    (void)fprintf(stderr, 
			"\n\rInvalid pointer 0x%X, file '%s' line %d\n\r",
			p_ptr, file, line);

	    do_abort();
	}
    }
#else
    if (p_ptr == NULL)
    {
	(void)fprintf(stderr, 
		    "\n\rInvalid pointer 0x%X, file '%s' line %d\n\r",
		    (unsigned)p_ptr, file, line);

	do_abort();
    }
#endif /* CHECK_ALL_MEMORY */
}

/**************************************************************************
**
** do_abort - the name says it all!!
**
**************************************************************************/
static void do_abort()
{
	/*
	** force a flush of stderr 
	*/
	(void)fclose (stderr);	

#if SUNOS_4
	/*
	** Make sure signal is not caught when doing abort
	*/
	(void)sigblock(0);
	(void)signal(SIGIOT, SIG_DFL);

	/*
	** Call "abort" to generate the IOT signal and exit with a core dump.
	*/
	(void)abort();
#else
	abort();
#endif /* SUNOS_4 */

}
