/************************************************************************
**
** cm.h - header file for Interfacing to Client Library
**
**
**      Sccsid %Z% %M% %I% %G%
**
**      Confidential Property of Sybase, Inc.
**	Copyright  1991, 1993 by Sybase Incorporated
**	All rights reserved.
**
************************************************************************/

#ifndef __CM_H__

#define __CM_H__

/*
** include CT-lib header file used for comunications
*/
#include <ctpublic.h>

/*
** parameter structure
*/
typedef struct _params
{
    char	*name;
    char	*dtype;
    char	*value;
    int		options;
} CmParams;

/*
** rpc and language parameter options
*/
#define CM_NO_OPTION		1
#define CM_RECOMPILE		2
#define CM_INPUT		3
#define CM_OUTPUT		4

/*
** return codes
*/
#define CM_SUCCESS		1
#define CM_FAILURE		2
#define CM_FATAL		3

/*
** cursor commands
*/
#define CM_CURCMD_NONE		-1
#define CM_CURCMD_DECLARE	1
#define CM_CURCMD_DYN_DECLARE	2
#define CM_CURCMD_OPEN		3
#define CM_CURCMD_CLOSE		4
#define CM_CURCMD_DEALLOC	5
#define CM_CURCMD_FETCH		6
#define CM_CURCMD_UPDATE	7
#define CM_CURCMD_DELETE	8
#define CM_CURCMD_CURROWS	9

/*
** cursor options
*/
#define CM_CUROPT_NONE		-1
#define CM_CUROPT_UNUSED	1
#define CM_CUROPT_DEALLOC	2
#define CM_CUROPT_FOR_UPATE	3
#define CM_CUROPT_READ_ONLY	4

/*
** cursor param options
*/
#define CM_CPOPT_UNUSED	-1
#define CM_CPOPT_UPDATECOL	1
#define CM_CPOPT_INPUTVAL	2

/*
** cursor send options
*/
#define CM_SEND_NOW		1
#define CM_SEND_BATCH		2

/*
** dynamic sql commands
*/
#define CM_DYNCMD_NONE		-1
#define CM_DYNCMD_PREPARE	1
#define CM_DYNCMD_DEALLOC	2
#define CM_DYNCMD_EXECUTE	3
#define CM_DYNCMD_DESCIN	4
#define CM_DYNCMD_DESCOUT	5
#define CM_DYNCMD_EXEC_IMM	6

/*
** Proprety types
*/
#define CM_CMD_PROP		1
#define CM_CON_PROP		2
#define CM_CTX_PROP		3
	
#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

/* com.cc */
extern CS_INTERNAL int cm_init P_((void));
extern CS_INTERNAL int cm_exit P_((void));
extern CS_INTERNAL int cm_connect P_((void));
extern CS_INTERNAL int cm_close P_((void));
extern CS_INTERNAL int cm_debug P_((
	CS_INT command,
	CS_INT mask,
	void *file
	));
/* cm_cap.cc */
extern CS_INTERNAL int cm_cap P_((
	CS_INT type,
	CS_INT action,
	CS_INT cap,
	CS_BOOL *value
	));
/* cm_cur.cc */
extern CS_INTERNAL int cm_cursor P_((
	int	send_option,
	char	*p_cmd,
	char	*p_name,
	char	*p_text,
	int	command,
	int	options,
	CmParams params[],
	int numparams
	));
extern CS_INTERNAL int cm_cursor_finish P_((
	char	*p_cmdname
	));
/* cm_dyn.cc */
extern CS_INTERNAL int cm_dynamic P_((
	char	*p_cmd,
	char	*p_name,
	char	*p_text,
	int	command,
	CmParams params[],
	int numparams
	));
extern CS_INTERNAL int cm_dynamic_finish P_((
	char	*p_cmdname
	));
/* cm_lang.cc */
extern CS_INTERNAL int cm_lang P_((
	char *p_text,
	CmParams params[],
	int numparams
	));
/* cm_prop.cc */
extern CS_INTERNAL int cm_prop P_((
	CS_INT prop_type,
	CS_INT action,
	CS_INT property,
	CS_VOID *value,
	CS_INT len,
	CS_INT *outlen
	));
/* cm_opt.cc */
extern CS_INTERNAL int cm_opt P_((
	CS_INT action,
	CS_INT option,
	CS_VOID *value
	));
/* cm_res.cc */
extern CS_INTERNAL int cm_cancel P_((void));
/* cm_rpc.cc */
extern CS_INTERNAL int cm_rpc P_((
	char *p_name,
	int options,
	CmParams params[],
	int numparams
	));

#undef P_

#endif /* __CM_H__ */
