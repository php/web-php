/****************************************************************************

NAME
	win_msg - command window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_msg.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** local vars
*/
static Widget			msg_window;
static Widget			separator;
static XawTextPosition		last_position;

/*
** local routines
*/

/****************************************************************************
**
** win_msg_create - initialize message window
**
****************************************************************************/
int
win_msg_create(Widget parent)
{
    Arg 	args[MAXARGS];
    Cardinal 	n;

    n = 0;
    XtSetArg(args[n], XtNborderWidth, (XtArgVal)0);
    n++;
    XtSetArg(args[n], XtNmin, (XtArgVal)2);
    n++;
    XtSetArg(args[n], XtNmax, (XtArgVal)2);
    n++;
    XtSetArg(args[n], XtNshowGrip, (XtArgVal)False);
    n++;
    separator = XtCreateManagedWidget("", labelWidgetClass, parent, args, n);

    n = 0;
    XtSetArg(args[n], XtNeditType, (XtArgVal)XawtextAppend);
    n++;
    XtSetArg(args[n], XtNscrollVertical, XawtextScrollAlways);
    n++;
    XtSetArg(args[n], XtNwrap, XawtextWrapWord);
    n++;
    msg_window = XtCreateManagedWidget("messageWindow", asciiTextWidgetClass,
					parent, args, n);
    last_position = XawTextGetInsertionPoint(msg_window);

    return SUCCESS;
}

/****************************************************************************
**
** win_msg - display message into message window
**
****************************************************************************/
int
win_msg(char *msg)
{
    XawTextBlock	text_block;

    text_block.firstPos = 0;
    text_block.length   = strlen(msg);
    text_block.ptr      = msg;
    XawTextReplace(msg_window, last_position, last_position, &text_block);

    last_position = XawTextGetInsertionPoint(msg_window);

    return SUCCESS;
}
