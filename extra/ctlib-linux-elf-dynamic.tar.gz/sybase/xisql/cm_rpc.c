/****************************************************************************

NAME
	cm_rpc - xisql interface to CT-Lib RPC commands

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	cm_rpc.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win.h>
#include	<cm.h>
#include	<cm_int.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

typedef struct _dmap
{
	CS_INT		dtype;
	CS_CHAR		*dname;
} DMap;

static DMap cm__datamap[] =
{
	{ CS_ILLEGAL_TYPE,	"CS_ILLEGAL" },
	{ CS_CHAR_TYPE,		"CS_CHAR" },
	{ CS_VARCHAR_TYPE,	"CS_VARCHAR" },
	{ CS_BINARY_TYPE,	"CS_BINARY" },
	{ CS_VARBINARY_TYPE,	"CS_VARBINARY" },
	{ CS_TEXT_TYPE,		"CS_TEXT" },
	{ CS_IMAGE_TYPE,	"CS_IMAGE" },
	{ CS_TINYINT_TYPE,	"CS_TINYINT" },
	{ CS_SMALLINT_TYPE,	"CS_SMALLINT" },
	{ CS_INT_TYPE,		"CS_INT" },
	{ CS_REAL_TYPE,		"CS_REAL" },
	{ CS_FLOAT_TYPE,	"CS_FLOAT" },
	{ CS_BIT_TYPE,		"CS_BIT" },
	{ CS_DATETIME_TYPE,	"CS_DATETIME" },
	{ CS_DATETIME4_TYPE,	"CS_DATETIME4" },
	{ CS_MONEY_TYPE,	"CS_MONEY" },
	{ CS_MONEY4_TYPE,	"CS_MONEY4" },
	{ CS_NUMERIC_TYPE,	"CS_NUMERIC" },
	{ CS_DECIMAL_TYPE,	"CS_DECIMAL" },
}; 

#define NUM_TYPES	(sizeof (cm__datamap) / sizeof (cm__datamap[0]))

/****************************************************************************
**
** cm_get_dtype - 
**
****************************************************************************/
CS_INTERNAL CS_INT
cm_get_dtype(char *dtype_name)
{
	int	i;
	char	buf[MAX_DISPLAY_BUF];

	if (STRLEN(dtype_name) == 0)
	{
		return CS_CHAR_TYPE;
	}

	for (i = 0; i < NUM_TYPES; i++)
	{
		if (STRCMP(dtype_name, cm__datamap[i].dname) == 0)
		{
			return cm__datamap[i].dtype;
		}
	}
	sprintf(buf, "Illegal datatype '%s' specified, defaulting to CS_CHAR\n",
		dtype_name);
	win_msg(buf);
	return CS_CHAR_TYPE;
}

/****************************************************************************
**
** cm_rpc - 
**
****************************************************************************/
CS_INTERNAL int
cm_rpc
(
    char	*p_name,
    int		options,
    CmParams	params[],
    int		numparams
)
{
	CS_COMMAND	*cmd;
	CS_DATAFMT	paramdesc;
	CS_DATAFMT	indesc;
	int		i;
	CS_BYTE		data[CS_MAX_CHAR];
	CS_VOID		*p_data;
	CS_INT		len;

	/*
	** get a command handle.
	*/
	if (ct_cmd_alloc(Cdata.connection, &cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_cmd_alloc failed");
	}

	/*
	** Tell Open Client about the query we want to send.
	*/
	if (ct_command(cmd, CS_RPC_CMD, p_name, CS_NULLTERM, CS_UNUSED) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_command failed");
	}

	/*
	** Bundle up the params to send
	*/
	for (i = 0; i < numparams; i++)
	{
		MEMZERO(&indesc, sizeof (indesc));
		strcpy(indesc.name, params[i].name);
		indesc.namelen   = CS_NULLTERM;
		indesc.datatype  = CS_CHAR_TYPE;
		if (params[i].options == CM_INPUT)
		{
			indesc.maxlength = STRLEN(params[i].value);
		}
		else
		{
			indesc.maxlength = 255;
			len = 0;
		}
		indesc.format    = CS_FMT_UNUSED;
		indesc.precision = 20;
		indesc.scale     = 10;
		indesc.status    = (params[i].options == CM_INPUT)
					? CS_INPUTVALUE : CS_RETURN;
		MEMCPY(&paramdesc, &indesc, sizeof (paramdesc));
		paramdesc.datatype = cm_get_dtype(params[i].dtype);
		if (STRCMP(params[i].value, "NULL") == 0)
		{
			p_data = NULL;
			len = 0;
		}
		else if (params[i].options == CM_INPUT)
		{
			if (cs_convert(Cdata.context, &indesc, params[i].value,
					&paramdesc, data, &len) != CS_SUCCEED)
			{
				return cm_error(CM_FAILURE,
					"cm_rpc: cs_convert failed");
			}
			p_data = (CS_VOID *)data;
		}
		else if (paramdesc.datatype == CS_NUMERIC_TYPE ||
			 paramdesc.datatype == CS_DECIMAL_TYPE)
		{
			indesc.maxlength = strlen("0.0");
			if (cs_convert(Cdata.context, &indesc, "0.0",
					&paramdesc, data, &len) != CS_SUCCEED)
			{
				return cm_error(CM_FAILURE,
					"cm_rpc: cs_convert failed");
			}
			p_data = (CS_VOID *)data;
		}
		if (ct_param(cmd, &paramdesc, p_data, len, CS_GOODDATA) != CS_SUCCEED)
		{
			return cm_error(CM_FAILURE, "ct_command failed");
		}
	}

	/*
	** Now send the query to the server.
	*/
	if (ct_send(cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_send failed");
	}

	cm_results(cmd);

	if (ct_cmd_drop(cmd) != CS_SUCCEED)
	{
		return cm_error(CM_FAILURE, "ct_cmd_drop failed");
	}
	return CM_SUCCESS;
}
