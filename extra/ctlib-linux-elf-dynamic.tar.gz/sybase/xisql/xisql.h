/************************************************************************
**
** xisql.h - header file for generic stuff
**
**
**      Sccsid %Z% %M% %I% %G%
**
**      Confidential Property of Sybase, Inc.
**	Copyright  1991, 1993 by Sybase Incorporated
**	All rights reserved.
**
************************************************************************/

#ifndef _XISQL_

#define _XISQL_

/*
** define c++ wrappers around stdlib functions
*/

#define START_EXTERN_C	extern "C" {
#define END_EXTERN_C	}

/*
** include common clib headers
*/
#include 	<stdio.h>
#include 	<stdlib.h>
#include	<string.h>
#include	<memory.h>

/*
** common defines
*/
#ifndef NULL
#define NULL		0
#endif

#ifndef VOID
#define VOID		void
#endif

#ifndef	TRUE
#define TRUE		1
#endif
#ifndef	FALSE
#define FALSE		0
#endif

#define NIL(T)		((T) NULL)
#define NIL_FUNC(T)	(NIL( T (*) ()))

/*
** Values to be returned by procedural functions.
*/
#ifndef SUCCESS
#define SUCCESS		0
#endif
#ifndef FAILURE
#define FAILURE		(-1)
#endif

/*
** maximum buffer sizes used
*/
#define MAX_FILE_NAME_LEN	256

/*
** misc string defines
*/
#ifndef EOS
#define EOS		'\0'
#endif
#ifndef NULL_TERMINATE
#define NULL_TERMINATE(P, S)	((P)[S - 1] = EOS)
#endif

/*
** Range and bounds checking macros
*/
#ifndef IN_BOUNDS
#define IN_BOUNDS(N, LO, HI)	((LO) < (N) && (N) < (HI)) 
#endif
#ifndef IN_RANGE
#define IN_RANGE(N, LO, HI)	((LO) <= (N) && (N) <= (HI)) 
#endif

/*
** Bit manipulation macros
*/
#ifndef SETBIT
#define SETBIT(B,N)	((B) |= (1 << (N)))
#endif
#ifndef CLRBIT
#define CLRBIT(B,N)	((B) &= ~(1 << (N)))
#endif
#ifndef TSTBIT
#define TSTBIT(B,N)	((B) & (1 << (N)))
#endif

/*
** odd/even tests
*/
#ifndef EVEN
#define EVEN(N)		(((N) & 1) == 0)
#endif
#ifndef ODD
#define ODD(N)		(((N) & 1) == 1)
#endif

/*
** Miscellaneous arithmetic macros
*/
#ifndef MAX
#define MAX(X,Y)	(((X) > (Y)) ? (X) : (Y))
#endif

#ifndef MIN
#define MIN(X,Y)	(((X) < (Y)) ? (X) : (Y))
#endif

#ifndef ABS
#define ABS(X)		(((X) > 0) ? (X) : - (X))
#endif

/*
** define Rounding macros
*/
#ifndef POS_ROUND
#define POS_ROUND(X)	((X) + 0.5)
#endif
#ifndef ROUND
#define ROUND(X)	(((X) > 0) ? ((X) + 0.5) : ((X) - 0.5))
#endif

#ifndef SQUARE
#define SQUARE(X)	((X) * (X))
#endif

/*
** CLIB macro replacments, used in hiding exact clib functions, does argument
** casting to help in porting
*/
#define STRLEN(S1)	(strlen(S1))
#define STRCMP(S1, S2)	(strcmp(S1, S2))
#define STREQ(S1, S2)	(strcmp(S1, S2) == 0)
#define STRCPY(D,S)	(void)strcpy((char *)(D), (char *)(S))
#define STRNCPY(D,S,N)	(void)strncpy((char *)(D), (char *)(S), (int)(N))
#define STRCAT(D,S)	(void)strcat((char *)(D), (char *)(S))
#define STRNCAT(D,S,N)	(void)strncat((char *)(D), (char *)(S), (int)(N))
#define MEMCPY(D,S,N)	(void)memcpy((char *)(D), (char *)(S), (int)(N))
#define MEMSET(D,V,N)	(void)memset((char *)(D), (int)(V), (int)(N))
#define MEMZERO(D,N)	(void)memset((char *)(D), (int)(0), (int)(N))

/*
** Structure assignment macros.
*/
#ifndef STASS
#define STASS(DST, SRC)	MEMCPY((DST), (SRC), sizeof(*DST))
#endif

/*
** to shut lint up about malloc and varargs, casting to null should pickup any
** ptr type mismatches
*/
#ifdef lint
#define MALLOC(S,T)	((T *)NULL)
#define REALLOC(P,S,T)	((T *)NULL)
#define VA_ARG(L,T)	((L) ? (T)NULL : (T)NULL)
#else
#define MALLOC(S,T)     ((T *)malloc((unsigned)(S) * sizeof (T)))
#define REALLOC(P,S,T)  ((T *)realloc((char *)(P), (unsigned)(S) * sizeof (T)))
#define VA_ARG(L,T)	va_arg(L, T)
#endif
#define FREE(P)		free((char *)(P))

/*
** shorthand type definitions
*/
typedef unsigned char	Uchar;
typedef unsigned short	Ushort;
typedef unsigned long	Ulong;
typedef int		(*FuncPtr) ();

/*
** Using braces around code in C macros can cause problems when the macros are
** used in if conditional statements. e.g.:
**
**	#define MACRO()		{ do something }
**
**	if (cond)
**		MACRO();	<- causes syntax error since ; before else
**	else
**		other stuff
**
** The following macro fixes this problem, and should not affect performance.
** (Unless the C compiler is real brain dead)
*/
#ifdef lint
#define BRACKET(C)	do { C } while(stdin)
#else
#define BRACKET(C)	do { C } while(0)
#endif /* lint */

/*
** Debug macros.
*/

#ifdef DEBUG

#define ASSERT(X)		BRACKET(if (!(X)) utl_bomb(__FILE__, __LINE__);)
#define BOMB()			utl_bomb(__FILE__, __LINE__)
#define COPSTR(P_D, P_S, SIZE)	utl_copstr(P_D, P_S, SIZE)
#define CATSTR(P_D, P_S, SIZE)	utl_catstr(P_D, P_S, SIZE)
#define CHECK_PTR(P_P)		utl_chkptr((char *)(P_P), __FILE__, __LINE__)
#define CHECK_VARG(P_P)		utl_chkptr((char *)(P_P), __FILE__, __LINE__)

#else

#define ASSERT(X)
#define BOMB()
#define COPSTR(P_D, P_S, SIZE)	(void)strcpy(P_D, P_S)
#define CATSTR(P_D, P_S, SIZE)	(void)strcat(P_D, P_S)
#define CHECK_PTR(P_P)
#define CHECK_VARG(P_P)

#endif /* DEBUG */

/*
** extern function definition
*/
#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

/*
** port specific stuff
*/
#if defined(SUNOS)
extern long strtol P_((
	char *str,
	char **ptr,
	int base
	));
#endif /* defined(SUNOS) */   

/*
** xisql utility stuff
*/

/* util.cc */
extern void utl_bomb P_((
	char *file,
	int line
	));
extern void utl_copstr P_((
	char *dest,
	char *src,
	int size
	));
extern void utl_catstr P_((
	char *dest,
	char *src,
	int size
	));
extern void utl_panic P_((
	char *msg
	));
extern void utl_chkptr P_((
	char *p_ptr,
	char *file,
	int line
	));

#undef P_

#endif /* _XISQL_ */
