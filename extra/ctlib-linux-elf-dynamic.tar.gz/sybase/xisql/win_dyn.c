/****************************************************************************

NAME
	win_dyn - dynamic sql window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_dyn.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Mike Allen (based on file written by Otto Lind)

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>
#include	<cm.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

#define MAX_PARAMS 		5
#define CMD_NAME_SIZE 		20

/*
** define dynamic sql command radio button states
*/
#define DYN_PREPARE	0
#define DYN_DEALLOC	1
#define DYN_DESCIN	2
#define DYN_DESCOUT	3
#define DYN_EXECUTE	4
#define DYN_EXEC_IMM	5
#define DYN_MAXTOGGLE	6

/*
** define parameter radio button states
*/
#define P_UNUSED	0
#define P_INPUT		1
#define P_OUTPUT	2
#define P_MAXTOGGLE	3

/*
** dynamic sql panel
*/
typedef struct _dyn_panel
{
    int			dyn_id;
    char		cmd_id[CMD_NAME_SIZE];
    Widget		dyn_popup;
    Widget		dyn_name;
    Widget		dyn_text;
    Widget		dyn_cmd[DYN_MAXTOGGLE];
    Widget		p_param[MAX_PARAMS][P_MAXTOGGLE];
    Widget		p_name[MAX_PARAMS];
    Widget		p_dtype[MAX_PARAMS];
    Widget		p_val[MAX_PARAMS];
    struct _dyn_panel	*next;
} DynPanel;

/*
** Linked list of all dynamic sql panels
*/
DynPanel	*p_dyn_head = NULL;
int		global_dynids = 0;

/*
** local routines
*/
static void do_send(Widget w, XtPointer cc, XtPointer cd);
static void send_dynamic(DynPanel *p_dyn);
static void do_dismiss(Widget w, XtPointer cc, XtPointer cd);

/****************************************************************************
**
** win_dyn - initialize dynamic window
**
****************************************************************************/
void 
win_dynamic(Widget parent, XtPointer cc, XtPointer cd)
{
    DynPanel	*p_dyn;
    Arg 	args[MAXARGS];
    Widget	DynamicInput;
    Widget	Box;
    Widget	Param;
    Widget	Send;
    Widget	Dismiss;
    int		i;
    Widget	label;
    Widget	cmdname;
    char	*buttonname;


    /*
    ** create the core dynamic sql entry
    */
    p_dyn = MALLOC(1, DynPanel);
    if (p_dyn == NULL)
    {
	fprintf(stderr, "FATAL ERROR: malloc failed\n");
	exit(-1);
    }
    p_dyn->next = p_dyn_head;
    p_dyn_head = p_dyn;
    p_dyn->dyn_id = global_dynids++;
    sprintf(p_dyn->cmd_id, "dyncmd%02d", p_dyn->dyn_id);

    /*
    ** create popup shell for the dynamic sql entry
    */
    XtSetArg(args[0], XtNinput, True);
    XtSetArg(args[1], XtNwidth, 770);
    XtSetArg(args[2], XtNheight, 360);
    p_dyn->dyn_popup = XtCreatePopupShell("Dynamic SQL Input Window",
    					transientShellWidgetClass,
					parent, args, 3);

    /*
    ** create a form for the dynamic sql info
    */
    XtSetArg(args[0], XtNdefaultDistance, 2);
    DynamicInput = XtCreateManagedWidget("DynamicInput", formWidgetClass,
		    p_dyn->dyn_popup, args, 1);

    /*
    ** command name label
    */
    XtSetArg(args[0], XtNfromVert, NULL);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNlabel, "Command handle:");
    XtSetArg(args[3], XtNborderWidth, 0);
    XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[5], XtNwidth, 140);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    label = XtCreateManagedWidget("DynamicSqlInput", labelWidgetClass,
			DynamicInput, args, 7);

    /*
    ** command name value 
    */
    XtSetArg(args[0], XtNfromVert, NULL);
    XtSetArg(args[1], XtNfromHoriz, label);
    XtSetArg(args[2], XtNlabel, p_dyn->cmd_id);
    XtSetArg(args[5], XtNborderWidth, 0);
    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[4], XtNwidth, 360);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    cmdname = XtCreateManagedWidget("DynamicSqlInput", labelWidgetClass,
    			DynamicInput, args, 7);
    /*
    ** dynamic sql id label
    */
    XtSetArg(args[0], XtNfromVert, label);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNlabel, " ID:");
    XtSetArg(args[3], XtNborderWidth, 0);
    XtSetArg(args[4], XtNheight, FIELD_HEIGHT + 3);
    XtSetArg(args[5], XtNwidth, 60);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    label = XtCreateManagedWidget("DynamicSqlInput", labelWidgetClass,
			DynamicInput, args, 7);

    /*
    ** dynamic sql id input string 
    */
    XtSetArg(args[0], XtNfromVert, cmdname);
    XtSetArg(args[1], XtNfromHoriz, label);
    XtSetArg(args[2], XtNinput, True);
    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[4], XtNwidth, 400);
    XtSetArg(args[5], XtNborderWidth, 1);
    XtSetArg(args[6], XtNstring, "");
    XtSetArg(args[7], XtNeditType, XawtextEdit);
    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
    p_dyn->dyn_name = XtCreateManagedWidget("DynamicSqlInput",
    			asciiTextWidgetClass, DynamicInput, args, 10);
    /*
    ** dynamic sql text label
    */
    XtSetArg(args[0], XtNfromVert, label);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNlabel, " Text:");
    XtSetArg(args[3], XtNborderWidth, 0);
    XtSetArg(args[4], XtNheight, FIELD_HEIGHT + 3);
    XtSetArg(args[5], XtNwidth, 60);
    XtSetArg(args[6], XtNjustify, XtJustifyLeft);
    label = XtCreateManagedWidget("DynamicSqlInput", labelWidgetClass,
			DynamicInput, args, 7);

    /*
    ** text input string 
    */
    XtSetArg(args[0], XtNfromVert, p_dyn->dyn_name);
    XtSetArg(args[1], XtNfromHoriz, label);
    XtSetArg(args[2], XtNinput, True);
    XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[4], XtNwidth, 400);
    XtSetArg(args[5], XtNborderWidth, 1);
    XtSetArg(args[6], XtNstring, "");
    XtSetArg(args[7], XtNeditType, XawtextEdit);
    XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
    XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
    p_dyn->dyn_text = XtCreateManagedWidget("DynamicSqlInput",
    			asciiTextWidgetClass, DynamicInput, args, 10);

    /*
    ** command radio buttons
    */
    buttonname = "Prepare";
    XtSetArg(args[0], XtNfromVert, label);
    XtSetArg(args[1], XtNfromHoriz, NULL);
    XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[4], XtNhighlightThickness, 1);
    XtSetArg(args[5], XtNlabel, buttonname);
    XtSetArg(args[6], XtNradioGroup, NULL);
    XtSetArg(args[7], XtNstate, True);
    p_dyn->dyn_cmd[DYN_PREPARE] = XtCreateManagedWidget("DynamicSqlInput",
		    toggleWidgetClass, DynamicInput, args, 8);

    buttonname = "Dealloc";
    XtSetArg(args[1], XtNfromHoriz, p_dyn->dyn_cmd[DYN_PREPARE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    XtSetArg(args[6], XtNradioGroup, p_dyn->dyn_cmd[DYN_PREPARE]);
    XtSetArg(args[7], XtNstate, False);
    p_dyn->dyn_cmd[DYN_DEALLOC] = XtCreateManagedWidget("DynamicSqlInput",
		    toggleWidgetClass, DynamicInput, args, 8);

    buttonname = "Execute";
    XtSetArg(args[1], XtNfromHoriz, p_dyn->dyn_cmd[DYN_DEALLOC]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_dyn->dyn_cmd[DYN_EXECUTE] = XtCreateManagedWidget("DynamicSqlInput",
		    toggleWidgetClass, DynamicInput, args, 8);

    buttonname = "DescInput";
    XtSetArg(args[1], XtNfromHoriz, p_dyn->dyn_cmd[DYN_EXECUTE]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_dyn->dyn_cmd[DYN_DESCIN] = XtCreateManagedWidget("DynamicSqlInput",
		    toggleWidgetClass, DynamicInput, args, 8);

    buttonname = "DescOutput";
    XtSetArg(args[1], XtNfromHoriz, p_dyn->dyn_cmd[DYN_DESCIN]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_dyn->dyn_cmd[DYN_DESCOUT] = XtCreateManagedWidget("DynamicSqlInput",
		    toggleWidgetClass, DynamicInput, args, 8);

    buttonname = "ExecImm";
    XtSetArg(args[1], XtNfromHoriz, p_dyn->dyn_cmd[DYN_DESCOUT]);
    XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
    XtSetArg(args[5], XtNlabel, buttonname);
    p_dyn->dyn_cmd[DYN_EXEC_IMM] = XtCreateManagedWidget("DynamicSqlInput",
		    toggleWidgetClass, DynamicInput, args, 8);

    Param = p_dyn->dyn_cmd[DYN_PREPARE];
    for (i = 0; i < MAX_PARAMS; i++)
    {
	/*
	** form for parameter
	*/
	XtSetArg(args[0], XtNheight, 25);
	XtSetArg(args[1], XtNwidth, 830);
	XtSetArg(args[2], XtNfromVert, Param);
	XtSetArg(args[3], XtNfromHoriz, NULL);
	XtSetArg(args[4], XtNborderWidth, 1);
	XtSetArg(args[5], XtNhSpace, 2);
	XtSetArg(args[6], XtNvSpace, 2);
	Param = XtCreateManagedWidget("Param", formWidgetClass,
			DynamicInput, args, 7);

	/*
	** param toggle button
	*/
	buttonname = "Unused";
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, NULL);
	XtSetArg(args[2], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[4], XtNhighlightThickness, 1);
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[6], XtNradioGroup, NULL);
	XtSetArg(args[7], XtNstate, True);
	p_dyn->p_param[i][P_UNUSED] = XtCreateManagedWidget("Param",
			    toggleWidgetClass, Param, args, 8);

	buttonname = "Input";
	XtSetArg(args[1], XtNfromHoriz, p_dyn->p_param[i][P_UNUSED]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	XtSetArg(args[6], XtNradioGroup, p_dyn->p_param[i][P_UNUSED]);
	p_dyn->p_param[i][P_INPUT] = XtCreateManagedWidget("Param",
			    toggleWidgetClass, Param, args, 7);

	buttonname = "Output";
	XtSetArg(args[1], XtNfromHoriz, p_dyn->p_param[i][P_INPUT]);
	XtSetArg(args[3], XtNwidth, BUTTON_WIDTH(buttonname));
	XtSetArg(args[5], XtNlabel, buttonname);
	p_dyn->p_param[i][P_OUTPUT] = XtCreateManagedWidget("Param",
			    toggleWidgetClass, Param, args, 7);

	/*
	** dynamic sql parameter input name label and value
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, p_dyn->p_param[i][P_OUTPUT]);
	XtSetArg(args[2], XtNlabel, "Name:");
	XtSetArg(args[3], XtNborderWidth, 0);
	XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[5], XtNwidth, 35);
	label = XtCreateManagedWidget("Param", labelWidgetClass, 
				Param, args, 6);

	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 100);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	p_dyn->p_name[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
			Param, args, 10);

	/*
	** dynamic parameter datatype label and value
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, p_dyn->p_name[i]);
	XtSetArg(args[2], XtNlabel, "Datatype:");
	XtSetArg(args[3], XtNborderWidth, 0);
	XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[5], XtNwidth, 75);
	label = XtCreateManagedWidget("Param", labelWidgetClass,
		    Param, args, 6);

	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 110);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	p_dyn->p_dtype[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
		    Param, args, 10);

	/*
	** dynamic parameter input value label and value
	*/
	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, p_dyn->p_dtype[i]);
	XtSetArg(args[2], XtNlabel, "Value: ");
	XtSetArg(args[3], XtNborderWidth, 0);
	XtSetArg(args[4], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[5], XtNwidth, 40);
	label = XtCreateManagedWidget("Param", labelWidgetClass,
		    Param, args, 6);

	XtSetArg(args[0], XtNfromVert, NULL);
	XtSetArg(args[1], XtNfromHoriz, label);
	XtSetArg(args[2], XtNinput, True);
	XtSetArg(args[3], XtNheight, FIELD_HEIGHT);
	XtSetArg(args[4], XtNwidth, 150);
	XtSetArg(args[5], XtNborderWidth, 1);
	XtSetArg(args[6], XtNstring, "");
	XtSetArg(args[7], XtNeditType, XawtextEdit);
	XtSetArg(args[8], XtNscrollHorizontal, XawtextScrollWhenNeeded);
	XtSetArg(args[9], XtNscrollVertical, XawtextScrollWhenNeeded);
	p_dyn->p_val[i] = XtCreateManagedWidget("Param", asciiTextWidgetClass,
		    Param, args, 10);
    }

    /*
    ** box for buttons
    */
    XtSetArg(args[0], XtNheight, 50);
    XtSetArg(args[1], XtNwidth, 300);
    XtSetArg(args[2], XtNfromVert, Param);
    XtSetArg(args[3], XtNfromHoriz, NULL);
    XtSetArg(args[4], XtNborderWidth, 0);
    XtSetArg(args[5], XtNhSpace, 10);
    XtSetArg(args[6], XtNvSpace, 2);
    Box = XtCreateManagedWidget("Box", boxWidgetClass,
		    DynamicInput, args, 7);

    buttonname = "Dismiss";
    XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
    Dismiss = XtCreateManagedWidget(buttonname, commandWidgetClass,
		    Box, args, 1);
    XtAddCallback(Dismiss, XtNcallback, do_dismiss, p_dyn);

    buttonname = "Send";
    XtSetArg(args[0], XtNwidth, BUTTON_WIDTH(buttonname));
    Send = XtCreateManagedWidget(buttonname, commandWidgetClass,
		    Box, args, 1);
    XtAddCallback(Send, XtNcallback, do_send, p_dyn);

    window_popup(parent, p_dyn->dyn_popup);

    return;
}

/****************************************************************************
**
** do_send - do_send
**
****************************************************************************/
/*ARGSUSED*/
static void
do_send(Widget w, XtPointer cc, XtPointer cd)
{
    DynPanel	*p_dyn;

    p_dyn = (DynPanel *)cc;

    send_dynamic(p_dyn);
}

/****************************************************************************
**
** send_dynamic - send_dynamic
**
****************************************************************************/
static void
send_dynamic(DynPanel *p_dyn)
{
    Arg 	args[MAXARGS];
    String	m;
    Boolean	b;
    int		i;
    char	*cmdname;
    char	*name;
    char	*text;
    int		cmd;
    CmParams	params[MAX_PARAMS];
    int		numparams = 0;

    CHECK_PTR( p_dyn );
    cmdname = p_dyn->cmd_id;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(p_dyn->dyn_name, args, 1);
    name = m;

    XtSetArg(args[0], XtNstring, &m);
    XtGetValues(p_dyn->dyn_text, args, 1);
    text = m;

    /*
    ** Get current command. We could use the current value of the radio
    ** group (i think) and switch on the value, but what the hell.
    */
    cmd = CM_DYNCMD_NONE;
    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_dyn->dyn_cmd[DYN_PREPARE], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_DYNCMD_NONE );
	cmd = CM_DYNCMD_PREPARE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_dyn->dyn_cmd[DYN_DEALLOC], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_DYNCMD_NONE );
	cmd = CM_DYNCMD_DEALLOC;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_dyn->dyn_cmd[DYN_EXECUTE], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_DYNCMD_NONE );
	cmd = CM_DYNCMD_EXECUTE;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_dyn->dyn_cmd[DYN_DESCIN], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_DYNCMD_NONE );
	cmd = CM_DYNCMD_DESCIN;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_dyn->dyn_cmd[DYN_DESCOUT], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_DYNCMD_NONE );
	cmd = CM_DYNCMD_DESCOUT;
    }

    XtSetArg(args[0], XtNstate, &b);
    XtGetValues(p_dyn->dyn_cmd[DYN_EXEC_IMM], args, 1);
    if (b == True)
    {
	ASSERT( cmd == CM_DYNCMD_NONE );
	cmd = CM_DYNCMD_EXEC_IMM;
    }


    /*
    ** get parameters
    */
    for (i = 0; i < MAX_PARAMS; i++)
    {
	XtSetArg(args[0], XtNstate, &b);
	XtGetValues(p_dyn->p_param[i][P_UNUSED], args, 1);

	if (b == False)
	{
	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_dyn->p_name[i], args, 1);
	    params[numparams].name = m;

	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_dyn->p_dtype[i], args, 1);
	    params[numparams].dtype = m;

	    XtSetArg(args[0], XtNstring, &m);
	    XtGetValues(p_dyn->p_val[i], args, 1);
	    params[numparams].value = m;

	    XtSetArg(args[0], XtNstate, &b);
	    XtGetValues(p_dyn->p_param[i][P_INPUT], args, 1);
	    params[numparams].options = (b == True) ? CM_INPUT : CM_OUTPUT;
	    numparams++;
	}
    }

    cm_dynamic(cmdname, name, text, cmd, params, numparams);
}

/****************************************************************************
**
** do_dismiss - do_dismiss
**
****************************************************************************/
/*ARGSUSED*/
static void
do_dismiss(Widget w, XtPointer cc, XtPointer cd)
{
    DynPanel	*p_dyn;

    p_dyn = (DynPanel *)cc;
    CHECK_PTR( p_dyn );

    if (cm_dynamic_finish(p_dyn->cmd_id) != CM_SUCCESS)
    {
	    window_bell(0);
	    return;
    }
    window_popdown(p_dyn->dyn_popup);
}
