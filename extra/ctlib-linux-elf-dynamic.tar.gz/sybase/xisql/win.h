/************************************************************************
**
** win.h - header file for window manager
**
**
**      Sccsid %Z% %M% %I% %G%
**
**      Confidential Property of Sybase, Inc.
**	Copyright  1991, 1993 by Sybase Incorporated
**	All rights reserved.
**
************************************************************************/

#ifndef __WIN_H__

#define __WIN_H__

/*
** user accessable data
*/
typedef struct _xdata
{
    char	*prompt;
    char	*user;
    char	*passwd;
    char	*server;
    int		debug;
} XData;                      

extern XData		Xdata;

#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

/* win_msg.cc */
extern int win_msg P_((
	char *msg
	));
/* win_res.cc */
extern int win_result P_((
	char *msg
	));
/* window.cc */
extern int window_init P_((
	int argc,
	char **argv
	));
extern int window_run P_((void));
extern int window_event P_((void));
extern int window_bell P_((
	int volume
	));
extern int window_close P_((void));

#undef P_

#endif /* __WIN_H__ */
