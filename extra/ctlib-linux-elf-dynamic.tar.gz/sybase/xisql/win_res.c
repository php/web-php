/****************************************************************************

NAME
	win_result - command window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	win_result.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

/*
** local vars
*/
static Widget			result_window;
static XawTextPosition		last_position;

/*
** local routines
*/

/****************************************************************************
**
** win_result_create - initialize result window
**
****************************************************************************/
int
win_result_create(Widget parent)
{
    Arg 	args[MAXARGS];
    Cardinal 	n;


    n = 0;
    XtSetArg(args[n], XtNeditType, (XtArgVal) XawtextRead);
    n++;
    XtSetArg(args[n], XtNscrollVertical, XawtextScrollAlways);
    n++;
    /*
    XtSetArg(args[n], XtNwrap, XawtextWrapWord);
    */
    XtSetArg(args[n], XtNscrollHorizontal, XawtextScrollAlways);
    n++;
    result_window = XtCreateManagedWidget("resultWindow", asciiTextWidgetClass,
					 parent, args, n );
    last_position = XawTextGetInsertionPoint(result_window);

    return SUCCESS;
}

/****************************************************************************
**
** win_result - display message into result window
**
****************************************************************************/
int
win_result(char *msg)
{
    Arg 		args[MAXARGS];
    Cardinal 		n;
    XawTextBlock	text_block;

    n = 0;
    XtSetArg(args[n], XtNeditType, (XtArgVal) XawtextAppend);
    n++;
    XtSetValues(result_window, args, n);

    text_block.firstPos = 0;
    text_block.length   = strlen(msg);
    text_block.ptr      = msg;
    XawTextReplace(result_window, last_position, last_position, &text_block);

    last_position = XawTextGetInsertionPoint(result_window);

    n = 0;
    XtSetArg(args[n], XtNeditType, (XtArgVal) XawtextRead);
    n++;
    XtSetValues(result_window, args, n);

    return SUCCESS;
}
