/****************************************************************************

NAME
	window - window management routines

SYNOPSIS

DESCRIPTION

RETURNS

SIDE EFFECTS

WARNINGS	

FILE
	window.c

COPYRIGHT
        Copyright  1991, 1993 by Sybase Incorporated
        All rights reserved.

AUTHORS
        Otto Lind

****************************************************************************/

#include	<xisql.h>
#include	<win_int.h>
#include	<win.h>

/*
** extra internal X stuff for popup support 
*/
#include	<X11/IntrinsicP.h>
#include	<X11/CoreP.h>

#if (!NO_SCCSID && !lint)
static char Sccsid[] = "%Z% %M% %I% %G%";
#endif

#define MAX_TITLE		100

/*
** declare the global data here
*/
XData		Xdata;

/*
** define the structure to pass to XtGetApplicationResources()
*/
typedef struct _xi_resources
{
    String		user;		/* string of user name */
    String		passwd;		/* string of passwd */
    String		server;		/* string of server */
    Boolean		debug;		/* TRUE if we are in debg mode */
    String		prompt;		/* string of prompt to display */
} XisqlResources;

static XisqlResources	xisql_resources;

/*
** xisql resources
*/
static XtResource resources[] =
{
    {"user", "User", XtRString, sizeof(Boolean),
	XtOffset(XisqlResources *, user), XtRImmediate, (caddr_t)NULL},
    {"passwd", "Passwd", XtRString, sizeof(Boolean),
	XtOffset(XisqlResources *, passwd), XtRImmediate, (caddr_t)NULL},
    {"server", "Server", XtRString, sizeof(Boolean),
	XtOffset(XisqlResources *, server), XtRImmediate, (caddr_t)NULL},
    {"debug", "Xisqloptions", XtRBoolean, sizeof(Boolean),
	XtOffset(XisqlResources *, debug), XtRImmediate, (caddr_t)False},
    {"prompt", "Prompt", XtRString, sizeof(char *), 
	XtOffset(XisqlResources *, prompt), XtRImmediate, (caddr_t)NULL},
};

/*
** default xisql resources (in case there is no .apps file)
*/
static String default_resources[] =
{
    "*allowShellResize:                 True",
    "*borderWidth:			1",
    "*font:                             fixed",
    "*vpane.width:                      785",
    "*Scrollbar*thickness:              5",
    "*messageWindow.preferredPaneSize:	90",
    "*messageWindow.skipAdjust:  	True",
    "*messageWindow*thickness:  	10",
    "*commandWindow.preferredPaneSize:  80",
    "*commandWindow.skipAdjust:		True",
    "*commandWindow.hSpace:		16",
    "*commandWindow.vSpace:		10",
    "*resultWindow.preferredPaneSize:	270",
    "*resultWindow.resizeToPreferred:	True",
    "*resultWindow*thickness:		10",
    "*Command.height:                   20",
    "*Command.width:                    60",
    "*List.columnSpacing:               10",
    "*popup*showGrip:  			False",
    NULL,
};

static XrmOptionDescRec options[] =
{
    {"-debug",	"debug",	XrmoptionNoArg, "True"},
    {"-U",	"user",		XrmoptionSepArg, NULL},
    {"-P",	"passwd",	XrmoptionSepArg, NULL},
    {"-S",	"server",	XrmoptionSepArg, NULL},
};

/*
** internal display information
*/
static XtAppContext	xisqlcontext;

/*
** widgets used
*/
static Widget		topwidget;	/* the top level widget */

/*
** local routines
*/
static void win_subwindows(Widget twidget);

/****************************************************************************
**
** window_init - initialize window environment
**
****************************************************************************/
int window_init(int argc, char **argv)
{
    char	title[MAX_TITLE];

    /*
    ** initialize tool kit
    */
    topwidget = XtAppInitialize(&xisqlcontext, "XIsql", options,
		XtNumber(options), (Cardinal *)&argc, argv,
		default_resources, NULL, 0);

    /*
    ** get resources
    */
    XtGetApplicationResources(topwidget, (XtPointer)&xisql_resources,
    				resources, XtNumber(resources), NULL, 0);

    /*
    ** create all the subwindows
    */
    win_subwindows(topwidget);

    XtRealizeWidget(topwidget);

    /*
    ** set up global data based on resources
    */
    if (xisql_resources.prompt && strcmp(xisql_resources.prompt, "") != 0)
	Xdata.prompt = xisql_resources.prompt;
    else
	Xdata.prompt = XtNewString(PROMPT);
    Xdata.debug = xisql_resources.debug;
    Xdata.user = xisql_resources.user;
    Xdata.passwd = xisql_resources.passwd;
    Xdata.server = xisql_resources.server;
    if ( (Xdata.passwd == NULL) || (STRCMP(Xdata.passwd, "NULL") == 0) )
    {
	Xdata.passwd = "";
    }

    /*
    ** install program name
    */
    sprintf(title, "xisql %s (patch level %d)", VERSION, PATCHLEVEL);
    XStoreName(XtDisplay(topwidget), XtWindow(topwidget), title);
    XSetIconName(XtDisplay(topwidget), XtWindow(topwidget), "xisql");

    return SUCCESS;
}

/****************************************************************************
**
** window_run - run the menu system.
**
****************************************************************************/
int window_run()
{
    XtAppMainLoop(xisqlcontext);

    return SUCCESS;
}

/****************************************************************************
**
** window_event - check to see if an event pending, dispatch it if true.
**
****************************************************************************/
int window_event()
{
    XEvent	event;

    /*
    win_dbg_file_update(NULL, NULL, NULL);
    */

    if (XtAppPending(xisqlcontext))
    {
	XtAppNextEvent(xisqlcontext, &event);
	XtDispatchEvent(&event);
	return TRUE;
    }

    return FALSE;
}

/****************************************************************************
**
** window_reg_event - register a function for read/write events
**
****************************************************************************/
int window_reg_event(int fd, XtInputCallbackProc proc)
{
    /*
    XtAppAddInput(xisqlcontext, fd, XtInputWriteMask | XtInputReadMask,
    		proc, NULL);
    XtAppAddInput(xisqlcontext, fd, XtInputWriteMask, proc, NULL);
    XtAppAddInput(xisqlcontext, fd, XtInputReadMask, proc, NULL);
		*/

    return SUCCESS;
}

/****************************************************************************
**
** window_bell - ring bell in window environment
**
****************************************************************************/
int window_bell(int volume)
{
    XBell(XtDisplay(topwidget), volume);

    return SUCCESS;
}

/****************************************************************************
**
** window_close - cleanup window environment
**
****************************************************************************/
int window_close()
{
    return SUCCESS;
}

/****************************************************************************
**
** window_popup - pop up a subwindow 
**
****************************************************************************/
int window_popup(Widget parent, Widget popup)
{
    Arg 	args[MAXARGS];
    Display	*dpy = XtDisplay(parent);
    Window	dumy;
    int		x, y;

    /*
    ** set up x and y to popup over current application
    */
    XTranslateCoordinates(dpy, XtWindow(XtParent(parent)),
    			 RootWindow(dpy, DefaultScreen(dpy)),
			 0, 0, &x, &y, &dumy);
    y += 200;

    if (XtWindowOfObject(popup) == 0)
    {
    	XtRealizeWidget(popup);
    }

    if (x + popup->core.width > XDisplayWidth(dpy, DefaultScreen(dpy)))
    {
	x = XDisplayWidth(dpy, DefaultScreen(dpy)) - popup->core.width - 2;
    }

    if (y + popup->core.height > XDisplayHeight(dpy, DefaultScreen(dpy)))
    {
	y = XDisplayHeight(dpy, DefaultScreen(dpy)) - popup->core.height - 2;
    }

    XtSetArg(args[0], XtNx, x);
    XtSetArg(args[1], XtNy, y);
    XtSetValues(popup, args, 2);

    XtPopup(popup, XtGrabNone);

    return SUCCESS;
}

/****************************************************************************
**
** window_popdown - pop down a window
**
****************************************************************************/
int window_popdown(Widget popup)
{
    XtPopdown(popup);

    return SUCCESS;
}

/****************************************************************************
**
** win_subwindows - initialize window environment
**
****************************************************************************/
static void win_subwindows(Widget twidget)
{
    Widget	panewidget;
    Arg		args[MAXARGS];

    /*
    ** create paned widget to store all other windows in.
    */
    panewidget = XtCreateManagedWidget("vpane", panedWidgetClass, twidget,
			args, 0);

    win_msg_create(panewidget);
    win_cmd_create(panewidget);
    win_result_create(panewidget);
}
