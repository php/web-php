

/* Sccsid %Z% %M% %I% %G% */

/*
**	Sybase OpenClient Version 10.0
**	Confidential Property of Sybase, Inc.
**	(c) Copyright Sybase, Inc. 1992, 1993
**	All rights reserved
*/

/*
** exasync.h - This is the header file which defines constants
** and data structures which are used in the async example program
*/
#ifndef __EXASYNC_H__

#define __EXASYNC_H__

/*****************************************************************************
** 
** port specific defines used 
** 
*****************************************************************************/

#if SUNOS

extern void usleep PROTOTYPE((unsigned useconds));
extern int fputc PROTOTYPE((char c, FILE *stream));
extern int malloc_debug PROTOTYPE((int level));

#endif /* SUNOS */

/*****************************************************************************
** 
** generic defines used 
** 
*****************************************************************************/

#define ERROR_EXIT	(-1)

/*
** function callback id
*/
#define EX_ASYNC_QUERY	(CT_USER_FUNC + 1)

/*
** async handle
*/
#define EX_ASYNC	CS_VOID

/*****************************************************************************
** 
** data structures used 
** 
*****************************************************************************/

/*
** result output area created by library routine
*/
typedef struct _ex_results
{
	CS_INT		numrows;	/* number of rows is result set */
	CS_INT		numcols;	/* number of columns is result set */
	CS_DATAFMT	*colfmts;	/* column formats used */
	CS_BYTE		**data;		/* column data is stored here */
	CS_INT		**datalen;	/* data lengths are stored here */
	CS_SMALLINT	**indicator;	/* indicators are stored here */
} EX_RESULTS;

/*****************************************************************************
** 
** functions used
** 
*****************************************************************************/

/* ex_alib.c */
extern CS_RETCODE CS_PUBLIC ex_async_query PROTOTYPE((
	EX_ASYNC *ex_handle,
	CS_CHAR *query,
	CS_INT	querylen
	));
extern CS_RETCODE CS_PUBLIC ex_async_alloc PROTOTYPE((
	CS_CONNECTION *connection,
	EX_RESULTS *results,
	CS_VOID *mempool,
	CS_INT maxpool,
	EX_ASYNC **ex_handle
	));
extern CS_RETCODE CS_PUBLIC ex_async_free PROTOTYPE((
	EX_ASYNC *ex_handle
	));

#endif /* __EXASYNC_H__ */
