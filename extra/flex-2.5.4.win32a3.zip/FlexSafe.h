/* this is copied from the flex output */
#ifndef _FLEXSAFE_H_
#define _FLAXSAFE_H_

#ifndef YY_BUFFER_NEW
typedef unsigned int yy_size_t;
typedef int yy_state_type;
struct yy_buffer_state
	{
	FILE *yy_input_file;
	char *yy_ch_buf;
	char *yy_buf_pos;
	yy_size_t yy_buf_size;
	int yy_n_chars;
	int yy_is_our_buffer;
	int yy_is_interactive;
	int yy_at_bol;
	int yy_fill_buffer;
	int yy_buffer_status;
#define YY_BUFFER_NEW 0
#define YY_BUFFER_NORMAL 1
#define YY_BUFFER_EOF_PENDING 2
	};
typedef struct yy_buffer_state *YY_BUFFER_STATE;
#endif

struct flex_global_vars{
	FILE *in, *out;
	YY_BUFFER_STATE current_buffer;
	char hold_char;
	int n_chars;
	int leng;
	char *c_buf_p;
	int init;
	int start;
	int did_buffer_switch_on_eof;
	char *text;
#if YY_STACK_USED
	int start_stack_ptr;
	int start_stack_depth;
	int *start_stack;
#endif

};

typedef struct flex_global_vars flex_globals;

#endif