/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   |          Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
 */


/* $Id: internal_functions.c,v 1.266 1997/11/21 20:36:22 shane Exp $ */

#include "parser.h"
#ifndef MSVC5
#include "build-defs.h"
#endif
#include "internal_functions.h"
#include "internal_functions_registry.h"
#include "list.h"
#include "modules.h"
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>

#if HAVE_LIBDL
# if MSVC5
#  include <windows.h>
#  define dlclose FreeLibrary
#  define dlopen(a,b) LoadLibrary(a)
#  define dlsym GetProcAddress
# else
#  include <dlfcn.h>
# endif
#endif

#include "functions/php3_mysql.h"
#include "functions/php3_msql.h"
#include "functions/basic_functions.h"
#include "functions/phpmath.h"
#include "functions/php3_string.h"
#include "functions/oracle.h"
#include "functions/odbc.h"
#include "functions/base64.h"
#include "functions/php3_dir.h"
#include "functions/dns.h"
#include "functions/php3_pgsql.h"
#include "functions/php3_sybase.h"
#include "functions/reg.h"
#include "functions/mail.h"
#include "functions/md5.h"
#include "functions/php3_gd.h"
#include "functions/html.h"
#include "functions/dl.h"
#include "functions/head.h"
#include "functions/post.h"
#include "functions/exec.h"
#include "functions/php3_solid.h"
#include "functions/sybsql.h"
#include "functions/adabasd.h"
#include "functions/file.h"
#include "functions/dbase.h"
#include "functions/filepro.h"
#include "functions/db.h"
#include "functions/php3_syslog.h"
#include "functions/php3_filestat.h"
#include "php3_debugger.h"

#if APACHE
THREAD_LS extern module *top_module;
#endif

THREAD_LS HashTable list_destructors,module_registry;

THREAD_LS php3_builtin_module php3_builtin_modules[] = 
{
	{"Basic functions",				basic_functions_module_ptr},
	{"Dynamic extension loading",	dl_module_ptr},
	{"Directory",					php3_dir_module_ptr},
	{"File statting",				php3_filestat_module_ptr},
	{"File handling",				php3_file_module_ptr},
	{"HTTP Header",					php3_header_module_ptr},
	{"Sendmail",					mail_module_ptr},
	{"Debugger",					debugger_module_ptr},
	{"Syslog",						syslog_module_ptr},
	{"MySQL",						mysql_module_ptr},
	{"mSQL",						msql_module_ptr},
	{"PostgresSQL",					pgsql_module_ptr},
	{"ODBC",						odbc_module_ptr},
	{"FilePro",						filepro_module_ptr},
	{"Sybase SQL",					sybase_module_ptr},
	{"Sybase SQL - old",			sybase_old_module_ptr},
	{"DBase",						dbase_module_ptr},
	{"Regular Expressions",			regexp_module_ptr},
	{"Solid",						solid_module_ptr},
	{"Adabas",						adabas_module_ptr},
	{"Image",						gd_module_ptr},
	{"Oracle",						oracle_module_ptr},
	{"Apache",						apache_module_ptr},
	{"Crypt",						crypt_module_ptr},
	{"DBM",							dbm_module_ptr},
	{NULL,							NULL}
};

	
/* this function doesn't check for too many parameters */
PHPAPI int getParameters(HashTable *ht, int param_count,...)
{
	va_list ptr;
	YYSTYPE **param, *tmp = NULL;
	int i;

	va_start(ptr, param_count);

	for (i = 0; i < param_count; i++) {
		param = va_arg(ptr, YYSTYPE **);
		if (hash_index_find(ht, i, (void **) &tmp) == FAILURE) {
			va_end(ptr);
			return FAILURE;
		}
		*param = tmp;
	}
	va_end(ptr);
	return SUCCESS;
}


PHPAPI int getParametersArray(HashTable *ht, int param_count, YYSTYPE **argument_array)
{
	int i;
	YYSTYPE *data;

	for (i = 0; i < param_count; i++) {
		if (hash_index_find(ht, i, (void **) &data) == FAILURE) {
			return FAILURE;
		}
		argument_array[i] = data;
	}
	return SUCCESS;
}

PHPAPI int getThis(YYSTYPE **this) {
	YYSTYPE *data;
	if (hash_find(active_symbol_table, "this", sizeof("this"), (void **)&data) == FAILURE) {
		return FAILURE;
	}
	*this = data;
	return SUCCESS;
}

PHPAPI int ParameterPassedByReference(HashTable *ht, uint n)
{
	return hash_index_is_pointer(ht, n-1);
}

inline PHPAPI int array_init(YYSTYPE *arg)
{
	arg->value.ht = (HashTable *) emalloc(sizeof(HashTable));
	if (!arg->value.ht || hash_init(arg->value.ht, 0, NULL, YYSTYPE_DESTRUCTOR, 0)) {
		php3_error(E_CORE_ERROR, "Cannot allocate memory for array");
		return FAILURE;
	}
	arg->type = IS_ARRAY;
	return SUCCESS;
}

inline PHPAPI int object_init(YYSTYPE *arg)
{
	arg->value.ht = (HashTable *) emalloc(sizeof(HashTable));
	if (!arg->value.ht || hash_init(arg->value.ht, 0, NULL, YYSTYPE_DESTRUCTOR, 0)) {
		php3_error(E_CORE_ERROR, "Cannot allocate memory for array");
		return FAILURE;
	}
	arg->type = IS_OBJECT;
	return SUCCESS;
}

inline PHPAPI int add_assoc_long(char *key, long n)
{
	YYSTYPE tmp;

	tmp.type = IS_LONG;
	tmp.value.lval = n;
	return hash_update(return_value.value.ht, key, strlen(key)+1, (void *) &tmp, sizeof(YYSTYPE), NULL);
}


inline PHPAPI int add_assoc_double(char *key, double d)
{
	YYSTYPE tmp;

	tmp.type = IS_DOUBLE;
	tmp.value.dval = d;
	return hash_update(return_value.value.ht, key, strlen(key)+1, (void *) &tmp, sizeof(YYSTYPE), NULL);
}


inline PHPAPI int add_assoc_string(char *key, char *str)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_update(return_value.value.ht, key, strlen(key)+1, (void *) &tmp, sizeof(YYSTYPE), NULL);
}


inline PHPAPI int add_assoc_stringl(char *key, char *str, uint length)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_update(return_value.value.ht, key, strlen(key)+1, (void *) &tmp, sizeof(YYSTYPE), NULL);
}


inline PHPAPI int add_assoc_function(char *key,void (*function_ptr)(INTERNAL_FUNCTION_PARAMETERS))
{
	YYSTYPE tmp;
	
	tmp.type = IS_INTERNAL_FUNCTION;
	tmp.value.internal_function = (void (*)(INTERNAL_FUNCTION_PARAMETERS)) function_ptr;
	return hash_update(return_value.value.ht, key, strlen(key)+1, (void *) &tmp, sizeof(YYSTYPE), NULL);
}


inline PHPAPI int add_index_long(uint index, long n)
{
	YYSTYPE tmp;

	tmp.type = IS_LONG;
	tmp.value.lval = n;
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE),NULL);
}


inline PHPAPI int add_index_double(uint index, double d)
{
	YYSTYPE tmp;

	tmp.type = IS_DOUBLE;
	tmp.value.dval = d;
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE),NULL);
}


inline PHPAPI int add_index_string(uint index, char *str)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE),NULL);
}


inline PHPAPI int add_index_stringl(uint index, char *str, uint length)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE),NULL);
}

inline PHPAPI int add_next_index_long(long n)
{
	YYSTYPE tmp;

	tmp.type = IS_LONG;
	tmp.value.lval = n;
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE),NULL);
}


inline PHPAPI int add_next_index_double(double d)
{
	YYSTYPE tmp;

	tmp.type = IS_DOUBLE;
	tmp.value.dval = d;
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE),NULL);
}


inline PHPAPI int add_next_index_string(char *str)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE),NULL);
}


inline PHPAPI int add_next_index_stringl(char *str, uint length)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_next_index_insert(return_value.value.ht, &tmp, sizeof(YYSTYPE),NULL);
}


inline PHPAPI int add_get_assoc_string(char *key, char *str, void **dest)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_update(return_value.value.ht, key, strlen(key)+1, (void *) &tmp, sizeof(YYSTYPE), dest);
}


inline PHPAPI int add_get_assoc_stringl(char *key, char *str, uint length, void **dest)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_update(return_value.value.ht, key, strlen(key)+1, (void *) &tmp, sizeof(YYSTYPE), dest);
}

inline PHPAPI int add_get_index_string(uint index, char *str, void **dest)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = strlen(str);
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE),dest);
}


inline PHPAPI int add_get_index_stringl(uint index, char *str, uint length, void **dest)
{
	YYSTYPE tmp;

	tmp.type = IS_STRING;
	tmp.strlen = length;
	tmp.value.strval = estrndup(str,tmp.strlen);
	return hash_index_update(return_value.value.ht, index, (void *) &tmp, sizeof(YYSTYPE),dest);
}

int module_startup_modules(void *conf)
{
	php3_builtin_module *ptr = php3_builtin_modules;

	while (ptr->name) {
		if (ptr->module) {
			if (ptr->module->module_startup_func) {
				if (ptr->module->module_startup_func(MODULE_PERSISTENT)==FAILURE) {
					return FAILURE;
				}
			}
			ptr->module->type = MODULE_PERSISTENT;
			register_module(ptr->module);
		}
		ptr++;
	}
	return SUCCESS;
}


int _register_list_destructors(void (*list_destructor)(void *), void (*plist_destructor)(void *))
{
	list_destructors_entry ld;
	
	ld.list_destructor=(void (*)(void *)) list_destructor;
	ld.plist_destructor=(void (*)(void *)) plist_destructor;
	
	if (hash_next_index_insert(&list_destructors,(void *) &ld,sizeof(list_destructors),NULL)==FAILURE) {
		return FAILURE;
	}
	return list_destructors.nNextFreeElement-1;
}


/* registers all functions in *library_functions in the function hash */
PHPAPI int register_functions(function_entry *functions)
{
	function_entry *ptr = functions;
	YYSTYPE phps;
	int count=0,unload=0;

	while (ptr->fname) {
		phps.value.internal_function = (void (*)(INTERNAL_FUNCTION_PARAMETERS))ptr->handler;
		phps.type = IS_INTERNAL_FUNCTION;
		if (!phps.value.internal_function) {
			php3_error(E_CORE_WARNING,"Null function defined as active function");
			unregister_functions(functions,count);
			return FAILURE;
		}
		if (hash_add(&function_table, ptr->fname, strlen(ptr->fname)+1, &phps, sizeof(YYSTYPE), NULL) == FAILURE) {
			unload=1;
			break;
		}
		ptr++;
		count++;
	}
	if (unload) { /* before unloading, display all remaining bad function in the module */
		while (ptr->fname) {
			if (hash_exists(&function_table, ptr->fname, strlen(ptr->fname)+1)) {
				php3_error(E_CORE_WARNING,"Module load failed - duplicate function name - %s",ptr->fname);
			}
			ptr++;
		}
		unregister_functions(functions,count);
		return FAILURE;
	}
	return SUCCESS;
}

/* count=-1 means erase all functions, otherwise, 
 * erase the first count functions
 */
PHPAPI void unregister_functions(function_entry *functions,int count)
{
	function_entry *ptr = functions;
	int i=0;

	while (ptr->fname) {
		if (count!=-1 && i>=count) {
			break;
		}
#if 0
		php3_printf("Unregistering %s()\n",ptr->fname);
#endif
		hash_del(&function_table,ptr->fname,strlen(ptr->fname)+1);
		ptr++;
		i++;
	}
}


int register_module(php3_module_entry *module)
{
#if 0
	php3_printf("%s:  Registering module\n",module->name);
#endif
	if (register_functions(module->functions)==FAILURE) {
		php3_error(E_CORE_WARNING,"%s:  Unable to register functions, unable to load",module->name);
		return FAILURE;
	}
	module->module_started=1;
	return hash_add(&module_registry,module->name,strlen(module->name)+1,(void *)module,sizeof(php3_module_entry),NULL);
}


void module_destructor(php3_module_entry *module)
{
	if (module->request_started && module->request_shutdown_func) {
#if 0
		php3_printf("%s:  Request shutdown\n",module->name);
#endif
		module->request_shutdown_func();
	}
	module->request_started=0;
	if (module->module_started && module->module_shutdown_func) {
#if 0
		php3_printf("%s:  Module shutdown\n",module->name);
#endif
		module->module_shutdown_func();
	}
	module->module_started=0;
	unregister_functions(module->functions,-1);
	if (module->handle) {
		dlclose(module->handle);
	}
	
}


/* call request startup for all modules */
int module_registry_request_startup(php3_module_entry *module)
{
	if (!module->request_started && module->request_startup_func) {
#if 0
		php3_printf("%s:  Request startup\n",module->name);
#endif
		module->request_startup_func(module->type);
	}
	module->request_started=1;
	return 0;
}


/* for persistent modules - call request shutdown and flag NOT to erase
 * for temporary modules - do nothing, and flag to erase
 */
int module_registry_cleanup(php3_module_entry *module)
{
	switch(module->type) {
		case MODULE_PERSISTENT:
			if (module->request_started && module->request_shutdown_func) {
#if 0
				php3_printf("%s:  Request shutdown\n",module->name);
#endif
				module->request_shutdown_func();
			}
			module->request_started=0;
			return 0;
			break;
		case MODULE_TEMPORARY:
			return 1;
			break;
	}
	return 0;
}


void _php3_info(void) {
	if(!php3_header(0,NULL)) {  /* Don't send anything on a HEAD request */
		return;
	}
	php3_printf("<html><head><title>PHP Version %s</title></head>", PHP_VERSION);
	php3_printf("<body bgcolor=\"#ffffff\"><h1>PHP Version %s</h1>\n", PHP_VERSION);
	PUTS("by <a href=\"mailto:rasmus@lerdorf.on.ca\">Rasmus Lerdorf</a>,\n");
	PUTS("<a href=\"mailto:andi@vipe.technion.ac.il\">Andi Gutmans</a>,\n");
	PUTS("<a href=\"mailto:bourbon@netvision.net.il\">Zeev Suraski</a>,\n");
	PUTS("<a href=\"mailto:ssb@guardian.no\">Stig Bakken</a>,\n");
	PUTS("<a href=\"mailto:shane@caraveo.com\">Shane Caraveo</a>,\n");
	PUTS("<a href=\"mailto:jimw@adventure.com\">Jim Winstead</a>, and countless others.<P>\n");
    PUTS("<TT>This program is free software; you can redistribute it and/or modify\n");
    PUTS("it under the terms of the GNU General Public License as published by\n");
    PUTS("the Free Software Foundation; either version 2 of the License, or\n");
    PUTS("(at your option) any later version.<p>\n");
    PUTS("This program is distributed in the hope that it will be useful,\n");
    PUTS("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
    PUTS("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
    PUTS("GNU General Public License for more details.<p>\n");
    PUTS("You should have received a copy of the GNU General Public License\n");
    PUTS("along with this program; if not, write to the <b>Free Software\n");
    PUTS("Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.</b></TT><p>\n");
	PUTS("<hr><p><b>");
#ifdef WINDOWS
#ifdef WIN32
	PUTS("Windows95/NT Version</b> compiled with MS VC++ V5\n");
#endif
#else
	{
		FILE *fp;
		char buf[256];

		buf[255]=0;
		PUTS("Unix version:</b> ");
		fp = popen("uname -a","r");
		if(fp) {
			while(fgets(buf,255,fp)) {
				PUTS(buf);
			}
			pclose(fp);
		}
	}
#endif
	PUTS("\n");



	/* FIXME - need something to walk through hashed environment tables and display them */


	/* FIXME - also need something to walk through cfg hash table */


#if APACHE
	{
		array_header *env_arr;
		table_entry *env;
		int i;

		php3_printf("<p><b>HTTP Request:</b> %s<p>\n", php3_rqst->the_request);
		PUTS("<table border=0>\n");
		PUTS(" <tr><th colspan=2>HTTP&nbsp;Request&nbsp;Headers:</th></tr>\n");
		env_arr = table_elts(php3_rqst->headers_in);
		env = (table_entry *)env_arr->elts;
		for (i = 0; i < env_arr->nelts; ++i) {
			if (env[i].key) {
				php3_printf(" <tr><th align=right>%s:</th><td align=left>%s</td></tr>\n",
							env[i].key, env[i].val);
			}
		}
		PUTS(" <tr><th colspan=2>HTTP&nbsp;Response&nbsp;Headers:</th></tr>\n");
		env_arr = table_elts(php3_rqst->headers_out);
		env = (table_entry *)env_arr->elts;
		for(i = 0; i < env_arr->nelts; ++i) {
			if (env[i].key) {
				php3_printf(" <tr><th align=right>%s:</th><td align=left>%s</td></tr>\n",
							env[i].key, env[i].val);
			}
		}
		PUTS("</table>\n\n");
	}
#endif

	PUTS("<hr><p><b>PHP modules and extensions:</b><p>\n");
	PUTS("<table border=2>\n");
	PUTS(" <tr><th>module</th> <th>status</th> <th>additional&nbsp;information</th></tr>\n");
	PUTS(" <tr><th align=left>PHP core</th><td>&nbsp;</td>\n");
#ifndef MSVC5
	PUTS("     <td><tt>CFLAGS=" PHP_CFLAGS "<br>\n");
	PUTS("             HSREGEX=" PHP_HSREGEX "</td></tr>\n");
#endif

#if APACHE
	{
		module *modp = NULL;
#if !defined(WIN32) && !defined(WINNT)
		char name[64];
		char *p;
#endif
		server_rec *serv = php3_rqst->server;
		extern char server_root[MAX_STRING_LEN];
		extern uid_t user_id;
		extern char *user_name;
		extern gid_t group_id;
		extern int max_requests_per_child;

		PUTS(" <tr><th align=left>Apache</th> <td>enabled</td>\n");
		PUTS("     <td>\n");
#if WIN32|WINNT
		PUTS("Apache for Windows 95/NT<br>");
#else
		php3_printf("<tt>APACHE_INCLUDE=%s<br>\n", PHP_APACHE_INCLUDE);
		php3_printf("APACHE_TARGET=%s<br></tt>\n", PHP_APACHE_TARGET);
#endif
		php3_printf("Apache Version: <b>%s</b><br>",SERVER_VERSION);
#ifdef APACHE_RELEASE
		php3_printf("Apache Release: <b>%d</b><br>",APACHE_RELEASE);
#endif
		php3_printf("Apache API Version: <b>%d</b><br>",MODULE_MAGIC_NUMBER);
		php3_printf("Hostname/port: <b>%s:%u</b><br>\n",serv->server_hostname,serv->port);
#if !defined(WIN32) && !defined(WINNT)
		php3_printf("User/Group: <b>%s(%d)/%d</b><br>\n",user_name,(int)user_id,(int)group_id);
		php3_printf("Max Requests: <b>per child: %d &nbsp;&nbsp; keep alive: %s &nbsp;&nbsp; max per connection: %d</b><br>\n",max_requests_per_child,serv->keep_alive ? "on":"off", serv->keep_alive_max);
#endif
		php3_printf("Timeouts: <b>connection: %d &nbsp;&nbsp; keep-alive: %d</b><br>",serv->timeout,serv->keep_alive_timeout);
#if !defined(WIN32) && !defined(WINNT)
		php3_printf("Server Root: <b>%s</b><br>\n",server_root);
		
		PUTS("Loaded modules: ");
		for(modp = top_module; modp; modp = modp->next) {
			strncpy(name, modp->name, sizeof(name) - 1);
			if ((p = strrchr(name, '.'))) {
				*p='\0'; /* Cut off ugly .c extensions on module names */
			}
			PUTS(name);
			if (modp->next) {
				PUTS(", ");
			}
		}
#endif
		PUTS("<br>\n");
	}	
#endif
	PUTS("</table>\n");
	PUTS("</body></html>\n");
	
	RETURN_TRUE;
}

void php3_info(INTERNAL_FUNCTION_PARAMETERS) {
	_php3_info();
}

void php3_version(INTERNAL_FUNCTION_PARAMETERS)
{
    RETURN_STRING(PHP_VERSION);
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
