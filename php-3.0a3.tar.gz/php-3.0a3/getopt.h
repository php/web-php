/* Borrowed from Apache NT Port */
#include "parser.h"

THREAD_LS extern char *optarg;
THREAD_LS extern int optind;
THREAD_LS extern int opterr;
THREAD_LS extern int optopt;

extern int getopt(int argc, char* const *argv, const char *optstr);
