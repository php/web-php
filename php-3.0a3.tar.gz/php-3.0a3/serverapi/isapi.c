#include <stdio.h>
#include "parser.h"
#include "language-parser.tab.h"
#include "main.h"
#include "control_structures.h"
#include "list.h"
#include "modules.h"
#include "functions/file.h"
#include "functions/head.h"
#include "functions/post.h"
#include "functions/head.h"
#include "functions/type.h"
#include "highlight.h"

#include <windows.h>
#include <stdio.h>
#include <httpext.h>

extern void phprestart(FILE *);
THREAD_LS extern FILE *phpin;
THREAD_LS LPEXTENSION_CONTROL_BLOCK lpPHPcb;






BOOL APIENTRY DllMain(HANDLE hModule, 
                      DWORD  ul_reason_for_call, 
                      LPVOID lpReserved)
{
    switch( ul_reason_for_call ) {
    case DLL_PROCESS_ATTACH:
		/* 
		   I should be loading ini vars here 
		   and doing whatever true global inits
		   need to be done
		*/
		break;
    case DLL_THREAD_ATTACH:
		if (php3_module_startup()==FAILURE) {
			return FAILURE;
		}
		break;
    case DLL_THREAD_DETACH:
		if (initialized) {
			php3_module_shutdown();
			return SUCCESS;
		} else {
			return FAILURE;
		}
		break;
    case DLL_PROCESS_DETACH:
		/*
		    close down anything down in process_attach 
		*/
		break;
    }
    return TRUE;
}


BOOL WINAPI GetExtensionVersion (HSE_VERSION_INFO  *version)
{
    version->dwExtensionVersion = MAKELONG( HSE_VERSION_MINOR,
                                            HSE_VERSION_MAJOR );
    strncpy( version->lpszExtensionDesc,
            "PHP v3.0 Beta 1 ISAPI Ext v1",
			HSE_MAX_EXT_DLL_NAME_LEN);

    return TRUE;
}




/* this is php3_isapi_main()!!! */
DWORD WINAPI HttpExtensionProc (LPEXTENSION_CONTROL_BLOCK lpEcb)
{
	int cgi = 1;
	FILE *in = NULL;

	lpPHPcb = lpEcb;

	if (php3_request_startup((void *) lpEcb) == FAILURE) {
		return FAILURE;
	}

	in = php3_OpenFile(request_info.filename);
	if (in) {
		phpin = in;
		phprestart(phpin);
		initialized |= INIT_SCANNER;
		hash_index_update(&include_names, 0, (void *) &request_info.filename, sizeof(char *), NULL);
	}

	(void) phpparse();
	
	if (initialized) {
		php3_header(0, NULL);	/* Make sure headers have been sent */
		php3_request_shutdown();
		return SUCCESS;
	} else {
		return FAILURE;
	}
}


//
// Works like _getenv(), but uses isapi functions instead.
// 
char *isapi_getenv(LPEXTENSION_CONTROL_BLOCK lpEnvcb,LPSTR lpszEnvVar) {
	
	char var[255],dummy;
	DWORD dwLen, dummylen = 1;

	if (!lpszEnvVar)
		return "";
	
	dwLen =lpEnvcb->GetServerVariable(lpEnvcb->ConnID,lpszEnvVar,&dummy,&dummylen);

	if (dwLen == 0)
		return "";
	
	(void)lpEnvcb->GetServerVariable(lpEnvcb->ConnID,lpszEnvVar,var,&dwLen);

	return estrdup(var);
}


void isapi_puts(char *string)
{
	int n;
	n = strlen(string);
	lpPHPcb->WriteClient(lpPHPcb->ConnID,string,&n,0);
	return;
}

void isapi_putc(char character)
{
	int n = 1;
	lpPHPcb->WriteClient(lpPHPcb->ConnID,&character,&n,0);
	return;
}