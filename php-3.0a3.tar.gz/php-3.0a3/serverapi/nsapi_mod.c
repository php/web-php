/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Shane Caraveo                                               |
   |                                                                      |
   +----------------------------------------------------------------------+
 */

#include "parser.h"
#include "language-parser.tab.h"
#include "main.h"
#include "control_structures.h"
#include "list.h"
#include "modules.h"
#include "functions/file.h"
#include "functions/head.h"
#include "functions/post.h"
#include "functions/head.h"
#include "functions/type.h"
#include "highlight.h"


#ifndef XP_WIN32
#include <unistd.h>  /* sleep */
#define DLLEXPORT
#else /* XP_WIN32 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#define DLLEXPORT __declspec(dllexport)
#endif /* XP_WIN32 */

extern void phprestart(FILE *);
THREAD_LS extern FILE *phpin;
void *aLock, *hLock;
THREAD_LS pblock *nspb;
THREAD_LS Session *nssn;
THREAD_LS Request *nsrq;

DLLEXPORT void close_nsapi_mod(void *vparam)
{
	//global shutdown for all php threads
	//for now this will do nothing until we
	//make php thread-safe
	crit_terminate(aLock);
	crit_terminate(hLock);
}

DLLEXPORT int init_nsapi_mod(pblock *pb, Session *sn, Request *rq)
{
	//global initialization for all php threads
	//for now this will do nothing until we
	//make php thread-safe
	aLock = crit_init();
	hLock = crit_init();

	daemon_atrestart(close_nsapi_mod, NULL);
	return REQ_PROCEED;
}

DLLEXPORT int nsapi_php_main(pblock *pb, Session *sn, Request *rq)
{
	int cgi = 1;
	int display_source_mode = 0;
	FILE *in = NULL;
	void *conf = NULL;

	nspb = pb;
	nssn = sn;
	nsrq = rq;

	if (php3_module_startup()==FAILURE || php3_request_startup((void *) conf)==FAILURE) {
		return REQ_ABORTED; /*FAILURE*/
	}

	in = php3_OpenFile(request_info.filename);
	if (in) {
		phpin = in;
		phprestart(phpin);
		initialized |= INIT_SCANNER;
		hash_index_update(&include_names, 0, (void *) &request_info.filename, sizeof(char *), NULL);
	}

	(void) phpparse();
	
	if (initialized) {
		php3_header(0, NULL);	/* Make sure headers have been sent */
		php3_request_shutdown();
		php3_module_shutdown();
		return REQ_PROCEED; /*SUCCESS*/
	} else {
		return REQ_ABORTED; /*FAILURE*/
	}
}


void nsapi_writeclient(char *s, int size)
{
	net_write(nssn->csd, s, size);
}

void nsapi_putc(char c)
{
	net_write(nssn->csd, &c, 1);
}