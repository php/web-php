/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   +----------------------------------------------------------------------+
 */


/* $Id: internal_functions.h,v 1.105 1997/11/20 23:05:51 zeev Exp $ */


#ifndef _INTERNAL_FUNCTIONS_H
#define _INTERNAL_FUNCTIONS_H

#include "mod_php3.h"
#include "modules.h"

extern PHPAPI int getParameters(HashTable *ht, int param_count,...);
extern PHPAPI int getParametersArray(HashTable *ht, int param_count, YYSTYPE **argument_array);
extern PHPAPI int getThis(YYSTYPE **this);
extern PHPAPI int ParameterPassedByReference(HashTable *ht, uint n);
extern PHPAPI int register_functions(function_entry *functions);
extern PHPAPI void unregister_functions(function_entry *functions, int count);
extern PHPAPI int register_module(php3_module_entry *module_entry);

#define WRONG_PARAM_COUNT { php3_error(E_WARNING,"Wrong parameter count for %s()",function_state.function_name); return; }
#define WRONG_PARAM_COUNT_WITH_RETVAL(ret) { php3_error(E_WARNING,"Wrong parameter count for %s()",function_state.function_name); return ret; }
#define ARG_COUNT(ht) (ht->nNextFreeElement)

#if !MSVC5
#define DLEXPORT
#endif

extern inline PHPAPI int array_init(YYSTYPE *arg);
extern inline PHPAPI int object_init(YYSTYPE *arg);
extern inline PHPAPI int add_assoc_long(char *key, long n);
extern inline PHPAPI int add_assoc_double(char *key, double d);
extern inline PHPAPI int add_assoc_string(char *key, char *str);
extern inline PHPAPI int add_assoc_stringl(char *key, char *str, uint length);
extern inline PHPAPI int add_assoc_function(char *key,void (*function_ptr)(INTERNAL_FUNCTION_PARAMETERS));
extern inline PHPAPI int add_index_long(uint index, long n);
extern inline PHPAPI int add_index_double(uint index, double d);
extern inline PHPAPI int add_index_string(uint index, char *str);
extern inline PHPAPI int add_index_stringl(uint index, char *str, uint length);
extern inline PHPAPI int add_next_index_long(long n);
extern inline PHPAPI int add_next_index_double(double d);
extern inline PHPAPI int add_next_index_string(char *str);
extern inline PHPAPI int add_next_index_stringl(char *str, uint length);

extern inline PHPAPI int add_get_assoc_string(char *key, char *str, void **dest);
extern inline PHPAPI int add_get_assoc_stringl(char *key, char *str, uint length, void **dest);
extern inline PHPAPI int add_get_index_string(uint index, char *str, void **dest);
extern inline PHPAPI int add_get_index_stringl(uint index, char *str, uint length, void **dest);

#define add_property_long(key,n)  add_assoc_long((key),(n))
#define add_property_double(key,d)  add_assoc_double((key),(n))
#define add_property_string(key,str)  add_assoc_string((key),(str))
#define add_property_stringl(key,str,length)  add_assoc_stringl((key),(str),(length))
#define add_method(key,method)	add_assoc_function((key),(method))

/* info functions */
extern void php3_version(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_info(INTERNAL_FUNCTION_PARAMETERS);

#endif							/* _INTERNAL_FUNCTIONS_H */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
