/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   +----------------------------------------------------------------------+
 */


/* $Id: control_structures_inline.h,v 1.79 1997/11/21 23:36:17 andi Exp $ */


#include "parser.h"
#include "internal_functions.h"
#include "functions/head.h"
#include <stdio.h>
#include <string.h>

THREAD_LS extern YYSTYPE *array_ptr;

inline int cs_global_variable(YYSTYPE *varname)
{
	YYSTYPE *data;
	if (Execute) {
		if (!function_state.function_name) {
			php3_error(E_WARNING, "GLOBAL variable decleration meaningless in main() scope");
			return FAILURE;
		}
		if (varname->type != IS_STRING) {
			yystype_destructor(varname);
			php3_error(E_WARNING, "Incorrect variable type in global in function %s()", function_state.function_name);
			return FAILURE;
		}
		if (hash_find(active_symbol_table, varname->value.strval, varname->strlen+1, (void **) &data) == SUCCESS) {
			php3_error(E_WARNING, "Variable used in global statement already exists in the function");
			STR_FREE(varname->value.strval);
			return FAILURE;
		}
		if (hash_find(&symbol_table, varname->value.strval, varname->strlen+1, (void **) &data) == FAILURE) {
			YYSTYPE tmp;
		
			tmp.type = IS_STRING;
			tmp.value.strval = undefined_variable_string;	
			tmp.strlen = 0;
			
			if (hash_update(&symbol_table, varname->value.strval, varname->strlen+1, (void *) &tmp, sizeof(YYSTYPE), (void **) &data)==FAILURE) {
				php3_error(E_WARNING, "Unable to initialize global variable $%s",varname->value.strval);
				STR_FREE(varname->value.strval);
				return FAILURE;
			}
		}
		if (hash_pointer_update(active_symbol_table, varname->value.strval, varname->strlen+1, (void *) data) == FAILURE) {
			php3_error(E_WARNING, "Error updating symbol table");
			STR_FREE(varname->value.strval);
			return FAILURE;
		}
		STR_FREE(varname->value.strval);
	}
	return SUCCESS;
}

inline int pass_parameter_by_reference(YYSTYPE *varname)
{
	YYSTYPE *data;
	if (Execute) {
		if (varname->type != IS_STRING) {
			yystype_destructor(varname);
			php3_error(E_WARNING, "Incorrect variable name type for function %s()", function_state.function_name);
			function_state.function_type = 0;	/* don't execute the function call */
			return FAILURE;
		}
		if (hash_find(active_symbol_table, varname->value.strval, varname->strlen+1, (void **) &data) == FAILURE) {
			YYSTYPE tmp;

			var_reset(&tmp);
			if (hash_update(active_symbol_table, varname->value.strval, varname->strlen+1, (void *) &tmp, sizeof(YYSTYPE), (void **) &data) == FAILURE) {
				php3_error(E_WARNING, "$%s does not exist, unable to initialize it", varname->value.strval);
				STR_FREE(varname->value.strval);
				function_state.function_type = 0;	/* don't execute the function call */
				return FAILURE;
			}
		}
		if (hash_next_index_pointer_insert(function_state.function_symbol_table, (void *) data) == FAILURE) {
			php3_error(E_WARNING, "Error updating symbol table");
			STR_FREE(varname->value.strval);
			function_state.function_type = 0;	/* don't execute the function call */
			return FAILURE;
		}
		STR_FREE(varname->value.strval);
	}
	return SUCCESS;
}


inline int cs_static_variable(YYSTYPE *varname, YYSTYPE *value)
{
	if (Execute) {
		YYSTYPE *function_entry, *variable_entry, tmp;

		if (!function_state.function_name) {
			php3_error(E_WARNING, "STATIC variable decleration meaningless in main() scope");
			STR_FREE(varname->value.strval);
			if (value) {
				yystype_destructor(value);
			}
			return FAILURE;
		}
		if (varname->type != IS_STRING) {
			yystype_destructor(varname);
			yystype_destructor(value);
			php3_error(E_WARNING, "Incorrect variable type in static in function %s()", function_state.function_name);
			return FAILURE;
		}
		if (hash_find(&function_table, function_state.function_name, strlen(function_state.function_name)+1, (void **) &function_entry) == FAILURE) {
			STR_FREE(varname->value.strval);
			if (value) {
				yystype_destructor(value);
			}
			return FAILURE;
		}
		if (!function_entry->value.ht) {
			function_entry->value.ht = (HashTable *) emalloc(sizeof(HashTable));
			hash_init(function_entry->value.ht, 0, NULL, YYSTYPE_DESTRUCTOR, 0);
		}
		if (hash_find(function_entry->value.ht, varname->value.strval, varname->strlen+1, (void **) &variable_entry) == FAILURE) {
			if (value) {
				hash_update(function_entry->value.ht, varname->value.strval, varname->strlen+1, value, sizeof(YYSTYPE), (void **) &variable_entry);
			} else {
				var_reset(&tmp);
				hash_update(function_entry->value.ht, varname->value.strval, varname->strlen+1, &tmp, sizeof(YYSTYPE), (void **) &variable_entry);
			}
			/*
			if (hash_find(function_entry->value.ht, varname->value.strval, varname->strlen+1, (void **) &variable_entry) == FAILURE) {
				php3_error(E_ERROR, "Inserted static variable got lost");
				STR_FREE(varname->value.strval);
				if (value) {
					yystype_destructor(value);
				}
				return FAILURE;
			}
			*/
		}
		if (hash_pointer_update(active_symbol_table, varname->value.strval, varname->strlen+1, (void *) variable_entry) == FAILURE) {
			php3_error(E_ERROR, "Unable to initialize static variable");
			STR_FREE(varname->value.strval);
			if (value) {
				yystype_destructor(value);
			}
			return FAILURE;
		} else {
			hash_find(active_symbol_table, varname->value.strval, varname->strlen+1, (void **) &variable_entry);
		}
		STR_FREE(varname->value.strval);
	}
	return SUCCESS;
}

inline void cs_start_while(YYSTYPE *expr)
{
	function_state.loop_nest_level++;
	stack_push(&css, &ExecuteFlag, sizeof(int));

	if (Execute) {
		if (yystype_true(expr)) {
			ExecuteFlag = EXECUTE;
			Execute = SHOULD_EXECUTE;
		} else {
			ExecuteFlag = DONT_EXECUTE;
			Execute = SHOULD_EXECUTE;
		}
		yystype_destructor(expr);
	}
}


inline void cs_end_while(YYSTYPE *while_token)
{

#if (_DEBUG_ & CONTROL_DEBUG)
	fprintf(stderr, "end of while, execute=%d, changecount=%d, changetype=%d\n", Execute, function_state.loop_change_level, function_state.loop_change_level);
#endif

	if (Execute) {
		seek_token(&token_cache_manager, while_token->offset);
	} else {
		if ((function_state.loop_change_type != DO_NOTHING) && (function_state.loop_change_level == function_state.loop_nest_level)) {
			if (function_state.loop_change_type == DO_CONTINUE) {
				seek_token(&token_cache_manager, while_token->offset);
			}
			function_state.loop_change_type = DO_NOTHING;
			function_state.loop_change_level = 0;
		}
	}
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
	function_state.loop_nest_level--;
}


inline void cs_start_do_while()
{
	function_state.loop_nest_level++;
	stack_push(&css, &ExecuteFlag, sizeof(int));
}


/* force evaluation of the expression if we're in a CONTINUE */
inline void cs_force_eval_do_while()
{
	if (function_state.loop_change_level == function_state.loop_nest_level
		&& function_state.loop_change_type == DO_CONTINUE) {
		function_state.loop_change_type = DO_NOTHING;
		function_state.loop_change_level = 0;
		ExecuteFlag = EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void cs_end_do_while(YYSTYPE *do_token, YYSTYPE *expr)
{

#if (_DEBUG_ & CONTROL_DEBUG)
	fprintf(stderr, "end of while, execute=%d, changecount=%d, changetype=%d\n", Execute, function_state.loop_change_level, function_state.loop_change_level);
#endif

	if (Execute && yystype_true(expr)) {
		yystype_destructor(expr);
		seek_token(&token_cache_manager, do_token->offset);
	} else {
		if (Execute) {
			yystype_destructor(expr);
		}
		if ((function_state.loop_change_type != DO_NOTHING) && (function_state.loop_change_level == function_state.loop_nest_level)) {
			function_state.loop_change_type = DO_NOTHING;
			function_state.loop_change_level = 0;
		}
	}
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
	function_state.loop_nest_level--;
}


inline void cs_start_if(YYSTYPE *expr)
{
	stack_push(&css, &ExecuteFlag, sizeof(int));	/* push current state to stack */

	if (Execute) {				/* we're in a code block that needs to be evaluated */
		if (yystype_true(expr)) {	/* the IF expression is yystype_true, execute IF code */
			ExecuteFlag = EXECUTE;
			Execute = SHOULD_EXECUTE;
		} else {				/* the IF expression is false, don't execute IF code */
			ExecuteFlag = BEFORE_EXECUTE;
			Execute = SHOULD_EXECUTE;
		}
		yystype_destructor(expr);
	} else {
		ExecuteFlag = DONT_EXECUTE;
	}
}


inline void cs_end_if()
{
	/* restore previous status */
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
}


inline int cs_break_continue(YYSTYPE *expr, int op_type)
{
	if (Execute) {
		if (expr) {
			convert_to_long(expr);
			function_state.loop_change_level = function_state.loop_nest_level - expr->value.lval + 1;
		} else {
			function_state.loop_change_level = function_state.loop_nest_level;
		}
		if (function_state.loop_change_level <= 0) {
			php3_error(E_ERROR, "Cannot %s from %d loop(s) from nesting level %d",
						(op_type == DO_BREAK ? "break" : "continue"), (expr ? expr->value.lval : 1), function_state.loop_nest_level);
			if (expr) {	
				yystype_destructor(expr);			
			}
			return FAILURE;
		} else if (function_state.loop_change_level > function_state.loop_nest_level) {
			php3_error(E_ERROR, "Cannot continue from %d loops", (expr ? expr->value.lval : -1));
			if (expr) {
				yystype_destructor(expr);
			}
			return FAILURE;
		}
		function_state.loop_change_type = op_type;
		Execute = 0;
		if (expr) {
			yystype_destructor(expr);
		}
	}
	return SUCCESS;
}


inline void cs_elseif_start_evaluate()
{
	int stack_top = stack_int_top(&css);

	stack_push(&css, &ExecuteFlag, sizeof(int));
	if (ExecuteFlag == BEFORE_EXECUTE && stack_top == EXECUTE) {
		ExecuteFlag = EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void cs_elseif_end_evaluate()
{
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
}


inline void cs_start_elseif(YYSTYPE *expr)
{
	if (ExecuteFlag == EXECUTE) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
	if (ExecuteFlag == BEFORE_EXECUTE) {
		if (yystype_true(expr)) {
			ExecuteFlag = EXECUTE;
			Execute = SHOULD_EXECUTE;
		}
		yystype_destructor(expr);
	}
}


inline void cs_start_else()
{
	if (ExecuteFlag == EXECUTE) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
	if (ExecuteFlag == BEFORE_EXECUTE) {
		ExecuteFlag = EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void get_function_parameter(YYSTYPE *varname)
{
	if (Execute) {
		YYSTYPE tmp;

		yystype_copy_constructor(varname);
		
		if (hash_index_find(active_symbol_table, param_index, (void **) &data) == FAILURE) {
			php3_error(E_WARNING, "Missing argument %d in call to %s()",param_index+1,function_state.function_name);
			var_reset(&tmp);
			hash_update(active_symbol_table, varname->value.strval, varname->strlen+1, &tmp, sizeof(YYSTYPE), NULL);
		} else if (!hash_index_is_pointer(active_symbol_table, param_index)) { /* passed by value */
			tmp = *data;
			yystype_copy_constructor(&tmp);
			hash_update(active_symbol_table, varname->value.strval, varname->strlen+1, &tmp, sizeof(YYSTYPE), NULL);
		} else { /* passed by reference */
			hash_pointer_update(active_symbol_table, varname->value.strval, varname->strlen+1, data);
			hash_index_del(active_symbol_table, param_index);
		}

		param_index++;
		STR_FREE(varname->value.strval);
	}
}


inline void pass_parameter_by_value(YYSTYPE *expr)
{
	if (Execute) {

		if (hash_next_index_insert(function_state.function_symbol_table, expr, sizeof(YYSTYPE),NULL) == FAILURE) {
			php3_error(E_WARNING, "Error updating symbol table");
			yystype_destructor(expr);
			function_state.function_type = 0;	/* don't execute the function call */
		}
	}
}


inline void start_function_decleration(YYSTYPE *function_token, YYSTYPE *function_name)
{
	HashTable *target_symbol_table;

	if (Execute) {
		yystype_copy_constructor(function_name);
		
		if (class_name) {
			target_symbol_table = class_symbol_table;
			hash_del(class_symbol_table, function_name->value.strval, function_name->strlen+1);	/* for inheritance */
		} else {
			target_symbol_table = &function_table;
		}
		php3_str_tolower(function_name->value.strval, function_name->strlen);
		if (hash_exists(target_symbol_table, function_name->value.strval, function_name->strlen+1)) {
			php3_error(E_ERROR, "Can't redeclare already declared function");
			yystype_destructor(function_name);
			return;
		}
		function_token->type = IS_USER_FUNCTION;
		function_token->value.ht = NULL;
		hash_update(target_symbol_table, function_name->value.strval, function_name->strlen+1, function_token, sizeof(YYSTYPE), NULL);
		yystype_destructor(function_name);
	}
	stack_push(&css, &ExecuteFlag, sizeof(int));
	ExecuteFlag = DONT_EXECUTE;
	Execute = SHOULD_EXECUTE;
}


inline void end_function_decleration()
{
	ExecuteFlag = stack_int_top(&css);
	Execute = SHOULD_EXECUTE;
	stack_del_top(&css);
}


/* don't execute expr1 except for the first iteration */
inline void for_pre_expr1(YYSTYPE *for_token)
{
	function_state.loop_nest_level++;
	stack_push(&css, &ExecuteFlag, sizeof(int));
	if (Execute) {
		if (stack_int_top(&for_stack) == (long) for_token->offset) {	/* 2nd or later iteration */
			ExecuteFlag = DONT_EXECUTE;
			Execute = SHOULD_EXECUTE;
		}
	}
}


/* expr2 is the increment if we're switched.  don't execute it in the first
 * iteration, and execute it otherwise.
 * if we're not switched, it's the truth value, and we want to evaluate it anyway.
 */
inline void for_pre_expr2(YYSTYPE *for_token)
{
	ExecuteFlag = stack_int_top(&css);
	Execute = SHOULD_EXECUTE;
	if (for_token->cs_data.switched && stack_int_top(&for_stack) != (long) for_token->offset) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;	/* first iteration of already switched for */
	}
}


/* if we're not switched, expr3 is the increment.  we shouldn't execute it
 * in the first iteration.  since not being switched --> first iteration,
 * we don't have to check the for_stack.
 */
inline void for_pre_expr3(YYSTYPE *for_token, YYSTYPE *expr2)
{
	if (for_token->cs_data.switched && stack_int_top(&for_stack) != (long) for_token->offset) {
		var_reset(expr2);
	}
	ExecuteFlag = stack_int_top(&css);
	Execute = SHOULD_EXECUTE;
	if (Execute && !for_token->cs_data.switched) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void for_pre_statement(YYSTYPE *for_token, YYSTYPE *expr2, YYSTYPE *expr3)
{
	ExecuteFlag = stack_int_top(&css);
	Execute = SHOULD_EXECUTE;
	if (Execute && !for_token->cs_data.switched) {
		var_reset(expr3);
	}
	if (Execute && for_token->cs_data.switched) {
		if (yystype_true(expr3)) {
			ExecuteFlag = EXECUTE;
		} else {
			ExecuteFlag = DONT_EXECUTE;
		}
		Execute = SHOULD_EXECUTE;
		yystype_destructor(expr2);
		yystype_destructor(expr3);
	} else if (Execute && !for_token->cs_data.switched) {
		if (yystype_true(expr2)) {
			ExecuteFlag = EXECUTE;
		} else {
			ExecuteFlag = DONT_EXECUTE;
		}
		Execute = SHOULD_EXECUTE;
		yystype_destructor(expr2);
		yystype_destructor(expr3);
	}
}

inline void for_post_statement(YYSTYPE *for_token, YYSTYPE *first_semicolon, YYSTYPE *second_semicolon, YYSTYPE *close_parentheses)
{

	if (stack_int_top(&for_stack) != (long) for_token->offset) {	/* first iteration */
		stack_push(&for_stack, &for_token->offset, sizeof(int));
	}
	if (!for_token->cs_data.switched) {
		tc_switch(&token_cache_manager, first_semicolon->offset + 1, close_parentheses->offset - 1, second_semicolon->offset);
		tc_set_switched(&token_cache_manager, for_token->offset);
	}
	if (Execute) {
		seek_token(&token_cache_manager, for_token->offset);
	} else {
		if ((function_state.loop_change_type != DO_NOTHING) && (function_state.loop_change_level == function_state.loop_nest_level)) {
			if (function_state.loop_change_type == DO_CONTINUE) {
				seek_token(&token_cache_manager, for_token->offset);
			} else {
				if (stack_int_top(&for_stack) == (long) for_token->offset) {
#if (_DEBUG_ & CONTROL_DEBUG)
					fprintf(stderr, "Deleting for addr=%d from for stack", for_token->offset);
#endif
					stack_del_top(&for_stack);
				}
			}
			function_state.loop_change_type = DO_NOTHING;
			function_state.loop_change_level = 0;
		} else {
			if (stack_int_top(&for_stack) == (long) for_token->offset) {
#if (_DEBUG_ & CONTROL_DEBUG)
				fprintf(stderr, "Deleting for addr=%d from for stack", for_token->offset);
#endif
				stack_del_top(&for_stack);
			}
		}
	}
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;

	function_state.loop_nest_level--;
}


inline void cs_return(YYSTYPE *expr)
{
	if (Execute) {
		if (expr) {
			return_value = *expr;
		} else {
			var_reset(&return_value);
		}
		function_state.returned = 1;
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void cs_start_include(YYSTYPE *include_token)
{
	/* evaluate the expression even at Execute=0, if it's the first time we see this include(), otherwise,
	 * don't evaluate it.
	 */
	stack_push(&css, &ExecuteFlag, sizeof(int));
	if (!include_token->cs_data.included) {
		ExecuteFlag = EXECUTE;
		Execute = SHOULD_EXECUTE;
	} else {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}

inline void cs_end_include(YYSTYPE *include_token, YYSTYPE *expr)
{
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
	if (!include_token->cs_data.included) {
#if DISPLAY_SOURCE_SUPPORT
		if (!php3_display_source) {
			include_file(expr,0);
		}
#else
		include_file(expr,0);
#endif
		tc_set_included(&token_cache_manager, include_token->offset);
		yystype_destructor(expr);
	}
}



inline void cs_show_source(YYSTYPE *expr)
{
#if DISPLAY_SOURCE_SUPPORT
	if (include_file(expr,1)==SUCCESS) {
		php3_header(0, NULL);
		stack_push(&css, &ExecuteFlag, sizeof(int));
		ExecuteFlag = DONT_EXECUTE;
		Execute = 0;
		php3_display_source=1;
		php3_printf("<font color=%s>",php3_ini.highlight_html);
	}
#else
	php3_error(E_WARNING,"Syntax highlighting is not supported in this compilation");
#endif
	yystype_destructor(expr);
}


inline void cs_pre_boolean_or(YYSTYPE *left_expr)
{
	stack_push(&css, &ExecuteFlag, sizeof(int));
	if (Execute && yystype_true(left_expr)) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;;
	}
}


inline void cs_post_boolean_or(YYSTYPE *result, YYSTYPE *left_expr, YYSTYPE *right_expr)
{
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
	if (Execute) {
		boolean_or_function(result, left_expr, right_expr);
	}
}


inline void cs_pre_boolean_and(YYSTYPE *left_expr)
{
	stack_push(&css, &ExecuteFlag, sizeof(int));
	if (Execute && !yystype_true(left_expr)) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void cs_post_boolean_and(YYSTYPE *result, YYSTYPE *left_expr, YYSTYPE *right_expr)
{
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
	if (Execute) {
		boolean_and_function(result, left_expr, right_expr);
	}
}


inline void cs_questionmark_op_pre_expr1(YYSTYPE *truth_value)
{
	stack_push(&css, &ExecuteFlag, sizeof(int));
	if (Execute && !yystype_true(truth_value)) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void cs_questionmark_op_pre_expr2(YYSTYPE *truth_value)
{
	ExecuteFlag = stack_int_top(&css);
	Execute = SHOULD_EXECUTE;
	if (Execute && yystype_true(truth_value)) {
		ExecuteFlag = DONT_EXECUTE;
		Execute = SHOULD_EXECUTE;
	}
}


inline void cs_questionmark_op_post_expr2(YYSTYPE *result, YYSTYPE *truth_value, YYSTYPE *expr1, YYSTYPE *expr2)
{
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
	if (Execute) {
		if (yystype_true(truth_value)) {
			*result = *expr1;
		} else {
			*result = *expr2;
		}
		yystype_destructor(truth_value);
	}
}


inline void cs_functioncall_pre_variable_passing(YYSTYPE *function_name, YYSTYPE *class_ptr)
{
	int minus_one = -1;
	HashTable *target_symbol_table = &function_table;	/* the symbol table in which the function would be searched */
	YYSTYPE *object=NULL;

	if (Execute) {
		if (class_ptr) {		/* use member function rather than global function */
			object = (YYSTYPE *) class_ptr->value.yystype_ptr;
			
			if (!object) {
				yystype_destructor(function_name);
				return;
			}
			target_symbol_table = object->value.ht;
		}
		if (function_name->type != IS_STRING) {
			php3_error(E_ERROR, "Function names must be strings");
			yystype_destructor(function_name);
			return;
		}
		php3_str_tolower(function_name->value.strval, function_name->strlen);
		if (hash_find(target_symbol_table, function_name->value.strval, function_name->strlen+1, (void **) &data) == SUCCESS) {
			if (!(data->type & VALID_FUNCTION)) {
				if (data->type == IS_UNSUPPORTED_FUNCTION) {
					php3_error(E_ERROR, "Function %s() is not supported in this compilation", function_name->value.strval);
				} else {
					php3_error(E_ERROR, "Function call to a non-function (%s)", function_name->value.strval);
				}
				STR_FREE(function_name->value.strval);
				function_name->cs_data.function_call_type=0;
				return;
			}
			/* we're gonna call the function... */
			stack_push(&for_stack, &minus_one, sizeof(int));
			stack_push(&function_state_stack, &function_state, sizeof(FunctionState));	/* save function state */
			function_name->cs_data.function_call_type = data->type;
			function_name->offset = data->offset;
			function_state.function_symbol_table = (HashTable *) emalloc(sizeof(HashTable));
			function_state.function_name = (char *) estrndup(function_name->value.strval,function_name->strlen);
			function_state.function_type = data->type;
			function_state.handler = (void (*)(INTERNAL_FUNCTION_PARAMETERS)) data->value.internal_function;
			if (!function_state.function_symbol_table || !function_state.function_name) {
				php3_error(E_ERROR, "Unable to allocate necessary memory for function call");
				STR_FREE(function_name->value.strval);
				function_name->cs_data.function_call_type=0;
				return;
			}
			if (hash_init(function_state.function_symbol_table, 0, NULL, YYSTYPE_DESTRUCTOR, 0) == FAILURE) {
				php3_error(E_ERROR, "Unable to initialize new symbol table in function call");
				STR_FREE(function_name->value.strval);
				function_name->cs_data.function_call_type=0;
				return;
			}
			/* push GLOBAL */
			globals.type = IS_ARRAY;
			globals.value.ht = &symbol_table;
			hash_pointer_update(function_state.function_symbol_table, "GLOBALS", sizeof("GLOBALS"), (void *) &globals);
			if (object) {	/* push $this */
				hash_pointer_update(function_state.function_symbol_table, "this", sizeof("this"), (void *) object);
			}
		} else {
			php3_error(E_ERROR, "Call to unsupported or undefined function %s()", function_name->value.strval);
			STR_FREE(function_name->value.strval);
			function_name->cs_data.function_call_type=0;
			return;
		}
	} else {
		function_name->cs_data.function_call_type = 0;
	}
}


inline void cs_functioncall_post_variable_passing(YYSTYPE *function_name)
{
	if (function_name->cs_data.function_call_type) {
		stack_push(&css, &ExecuteFlag, sizeof(int));

		/* prepare a new function state */
		function_state.symbol_table = function_state.function_symbol_table;
		active_symbol_table = function_state.symbol_table;
		function_state.function_symbol_table = NULL;
		function_state.loop_nest_level = function_state.loop_change_level = function_state.loop_change_type = 0;

		switch (function_state.function_type) {
			case IS_USER_FUNCTION:
				seek_token(&token_cache_manager, function_name->offset);
				break;
			case IS_INTERNAL_FUNCTION:
			case IS_TEMPORARY_INTERNAL_FUNCTION:
				var_reset(&return_value);  /* default return value */
				function_state.handler(function_state.symbol_table);
				break;
			default:			/* don't execute the function call */
				break;
		}
	}
}


inline void cs_functioncall_end(YYSTYPE *result, YYSTYPE *function_name, YYSTYPE *close_parentheses)
{
	if (function_name->cs_data.function_call_type) {
		FunctionState *fs_ptr;

		/* handle return value for user functions (internal functions do that themselves) */
		*result = return_value;
		if (function_state.function_type==IS_USER_FUNCTION && !function_state.returned) {
			var_reset(result);  /* default return value */
		}
		
		/* clean up */
		hash_destroy(function_state.symbol_table);
		efree(function_state.symbol_table);
		STR_FREE(function_state.function_name);
		yystype_destructor(function_name);
		
		while (stack_int_top(&for_stack) != -1) {  /* pop FOR stack */
			stack_del_top(&for_stack);
		}
		stack_del_top(&for_stack);
		
	
		/* jump back */
		if (function_state.function_type == IS_USER_FUNCTION) {
			seek_token(&token_cache_manager, close_parentheses->offset + 1);
		}
		
		
		/* get previous function state */
		stack_top(&function_state_stack, (void **) &fs_ptr);
		function_state = *fs_ptr;
		stack_del_top(&function_state_stack);
		active_symbol_table = function_state.symbol_table;


		/* restore execution state */
		ExecuteFlag = stack_int_top(&css);
		stack_del_top(&css);
		Execute = SHOULD_EXECUTE;
	}
}


inline void cs_switch_start(YYSTYPE *switch_token, YYSTYPE *expr)
{
	switch_expr se;

	function_state.loop_nest_level++;
	stack_push(&css, &ExecuteFlag, sizeof(int));

	se.expr = *expr;
	se.offset = switch_token->offset;
	stack_push(&switch_stack, &se, sizeof(switch_expr));
}


/* if case_expr is NULL, assume default */
inline void cs_switch_case_pre(YYSTYPE *case_expr)
{
	if (Execute) {
		switch_expr *se;
		YYSTYPE expr, result;
		int is_equal = 0;

		stack_top(&switch_stack, (void **) &se);
		if (se->offset != -1) {	/* no matched case yet */
			if (case_expr) {
				expr = se->expr;
				yystype_copy_constructor(&expr);
				is_equal_function(&result, &expr, case_expr);
				is_equal = yystype_true(&result);
			}
			if (!case_expr || is_equal) {
				se->offset=-1;
				ExecuteFlag = EXECUTE;
				Execute = SHOULD_EXECUTE;
			} else {
				ExecuteFlag = DONT_EXECUTE;
				Execute = SHOULD_EXECUTE;
			}
		}
	}
}

inline void cs_switch_case_post()
{
	ExecuteFlag = stack_int_top(&css);
	Execute = SHOULD_EXECUTE;
}


inline void cs_switch_end(YYSTYPE *expr)
{
	if (!Execute) {
		if (function_state.loop_change_level == function_state.loop_nest_level) {
			function_state.loop_change_type = DO_NOTHING;
		}
	}
	ExecuteFlag = stack_int_top(&css);
	stack_del_top(&css);
	Execute = SHOULD_EXECUTE;
	if (Execute) {
		yystype_destructor(expr);
	}
	stack_del_top(&switch_stack);
	function_state.loop_nest_level--;
}


inline void cs_start_class_decleration(YYSTYPE *classname, YYSTYPE *parent)
{
	if (Execute) {
		YYSTYPE new_class, *parent_ptr;

		if (hash_exists(&function_table, classname->value.strval, classname->strlen+1)) {
			php3_error(E_ERROR,"%s is already a function or class",classname->value.strval);
		}
		if (parent) {
			if (hash_find(&function_table, parent->value.strval, parent->strlen+1, (void **) &parent_ptr) == FAILURE) {
				php3_error(E_ERROR, "Cannot extend non existant class %s", parent->value.strval);
				return;
			}
			new_class = *parent_ptr;
			yystype_copy_constructor(&new_class);
		} else {
			new_class.type = IS_CLASS;
			new_class.value.ht = (HashTable *) emalloc(sizeof(HashTable));
			hash_init(new_class.value.ht, 0, NULL, YYSTYPE_DESTRUCTOR, 0);
		}
		if (hash_update(&function_table, classname->value.strval, classname->strlen+1, &new_class, sizeof(YYSTYPE),NULL) == FAILURE) {
			php3_error(E_ERROR, "Unable to initialize new class");
		}
		class_name = classname->value.strval;
		class_symbol_table = new_class.value.ht;
	}
}


inline void cs_end_class_decleration()
{
	if (Execute) {
		class_name = NULL;
		class_symbol_table = NULL;
	}
}


inline void start_array_parsing(YYSTYPE *array_name,YYSTYPE *class_ptr)
{
	if (Execute) {
		HashTable *target_symbol_table=active_symbol_table;
		
		if (array_name->type != IS_STRING) {
			php3_error(E_WARNING,"Illegal array name");
			array_ptr = NULL;
		} else {
			if (class_ptr) {
				YYSTYPE *object=(YYSTYPE *) class_ptr->value.yystype_ptr;
				
				if (!object) {
					array_ptr=NULL;
					yystype_destructor(array_name);
					return;
				}
				target_symbol_table = object->value.ht;
			}
			if (hash_find(target_symbol_table,array_name->value.strval, array_name->strlen+1, (void **)&array_ptr) == FAILURE) {
				YYSTYPE tmp;
				variable_tracker vt;

				array_init(&tmp);
				hash_update(target_symbol_table,array_name->value.strval,array_name->strlen+1,(void *) &tmp, sizeof(YYSTYPE),(void **) &array_ptr);
				array_ptr->cs_data.array_write=1;
								
				vt.type = IS_STRING;
				vt.strlen = array_name->strlen;
				vt.strval = estrndup(array_name->value.strval,vt.strlen);
				vt.ht = target_symbol_table;
				stack_push(&variable_unassign_stack,(void *) &vt, sizeof(variable_tracker));
			} else {
				array_ptr->cs_data.array_write=0;
			}
			if (array_ptr->type != IS_ARRAY && array_ptr->type != IS_STRING) {
	            php3_error(E_WARNING, "Variable $%s is not an array or string", array_name->value.strval);
				array_ptr = NULL;
			}
		}
		yystype_destructor(array_name);
	}
}

inline void start_dimensions_parsing(YYSTYPE *result)
{
	if (Execute) {
		result->value.yystype_ptr = array_ptr;
		if (array_ptr) {
			result->cs_data.array_write=array_ptr->cs_data.array_write;
		}
		result->strlen=-1;
	}
}
  
inline void fetch_array_index(YYSTYPE *result, YYSTYPE *expr, YYSTYPE *dimension)
{
	if (Execute) {
		int original_array_write = dimension->cs_data.array_write;
		
		result->cs_data.array_write = dimension->cs_data.array_write;
			
		if (dimension->value.yystype_ptr) {
			YYSTYPE *data,tmp,*arr_ptr=dimension->value.yystype_ptr;
			int new_array=0; /* whether we created the array just now */
	
			if (arr_ptr->type == IS_STRING && arr_ptr->value.strval != empty_string) {
				if (dimension->strlen == -1) { /* ok */
					convert_to_long(expr);
					if (expr->value.lval<0 || expr->value.lval>=arr_ptr->strlen) {
						php3_error(E_WARNING,"Illegal string index");
						result->value.yystype_ptr=NULL;
						return;
					}
					result->strlen = expr->value.lval;
					return;
				} else {
					php3_error(E_WARNING,"Cannot index a string index");
					result->value.yystype_ptr=NULL;
					return;
				}
			}
			if (arr_ptr->type==IS_NULL || (arr_ptr->type==IS_STRING && arr_ptr->value.strval==empty_string)) {
				array_init(arr_ptr);
				new_array=1;
			} else if (arr_ptr->type!=IS_ARRAY) {
				php3_error(E_WARNING,"Index referencing a non-array");
				result->value.yystype_ptr=NULL;
				yystype_destructor(expr);
				return;
			}
			if (expr) {
				switch (expr->type) {
					case IS_LONG:
					case IS_DOUBLE:
						convert_to_long(expr);
						if (new_array || hash_index_find(arr_ptr->value.ht, expr->value.lval, (void **) &data) == FAILURE) {
							tmp.type = IS_NULL;
							hash_index_update(arr_ptr->value.ht, expr->value.lval, (void *)&tmp, sizeof(YYSTYPE),(void **) &data);
							result->value.yystype_ptr = data;
							result->cs_data.array_write = 1;
							if (!original_array_write) { /* we raised the write flag just now, record this variable */
								variable_tracker vt;
								
								vt.type = IS_LONG;
								vt.lval = expr->value.lval;
								vt.ht = arr_ptr->value.ht;
								stack_push(&variable_unassign_stack,(void *) &vt, sizeof(variable_tracker));
							}
						} else {
							result->value.yystype_ptr = data;
						}
						break;
					case IS_STRING:
						if (new_array || hash_find(arr_ptr->value.ht, expr->value.strval, expr->strlen+1, (void **) &data)==FAILURE) {
							tmp.type = IS_NULL;
							if (hash_update(arr_ptr->value.ht, expr->value.strval, expr->strlen+1, (void *) &tmp, sizeof(YYSTYPE),(void **) &data)==FAILURE) {
								result->value.yystype_ptr=NULL;
								STR_FREE(expr->value.strval);
								return;
							}
							result->value.yystype_ptr = data;
							result->cs_data.array_write = 1;
							if (!original_array_write) { /* we raised the write flag just now, record this variable */
								variable_tracker vt;
								
								vt.type = IS_STRING;
								vt.strval = estrndup(expr->value.strval,expr->strlen);
								vt.strlen = expr->strlen;
								vt.ht = arr_ptr->value.ht;
								stack_push(&variable_unassign_stack,(void *) &vt, sizeof(variable_tracker));
							}
						} else {
							result->value.yystype_ptr = data;
						}
						break;
					default:
						result->value.yystype_ptr = NULL;
						php3_error(E_WARNING, "Illegal index type");
						break;
				}
			} else { /* assign-next */
				int new_index=hash_next_free_element(arr_ptr->value.ht);
				
				tmp.type = IS_NULL;
				hash_next_index_insert(arr_ptr->value.ht, (void *) &tmp, sizeof(YYSTYPE), (void **) &data);
				result->value.yystype_ptr = data;
				result->cs_data.array_write=1;
				if (!original_array_write) { /* we raised the write flag just now, record this variable */
					variable_tracker vt;
								
					vt.type = IS_LONG;
					vt.lval = new_index;
					vt.ht = arr_ptr->value.ht;
					stack_push(&variable_unassign_stack,(void *) &vt, sizeof(variable_tracker));
				}
			}
		} else {
			result->value.yystype_ptr=NULL;
		}
		if (expr) {
			yystype_destructor(expr);
		}
	}
}	


inline void clean_unassigned_variable_top(int delete_var)
{
	variable_tracker *vt;
	
	if (stack_top(&variable_unassign_stack,(void **) &vt)==SUCCESS) {
		switch(vt->type) {
			case IS_LONG:
				if (delete_var) {
					hash_index_del(vt->ht,vt->lval);
				}
				break;
			case IS_STRING:
				if (delete_var) {
					hash_del(vt->ht,vt->strval,vt->strlen+1);
				}
				STR_FREE(vt->strval);
				break;
		}
	}
	stack_del_top(&variable_unassign_stack);
}


inline void get_regular_variable_pointer(YYSTYPE *result, YYSTYPE *varname)
{
	if (Execute) {
		if (varname->type != IS_STRING) {
			php3_error(E_WARNING,"Illegal variable name");
			result->value.yystype_ptr = NULL;
			return;
		} else {
			YYSTYPE *data;

			if (hash_find(active_symbol_table,varname->value.strval, varname->strlen+1, (void **)&data) == FAILURE) {
				YYSTYPE tmp;
				variable_tracker vt;

				var_reset(&tmp);
				hash_update(active_symbol_table,varname->value.strval,varname->strlen+1,(void *) &tmp, sizeof(YYSTYPE), (void **) &data);
				
				vt.type = IS_STRING;
				vt.strlen = varname->strlen;
				vt.strval = estrndup(varname->value.strval,vt.strlen);
				vt.ht = active_symbol_table;
				stack_push(&variable_unassign_stack,(void *) &vt, sizeof(variable_tracker));
				result->cs_data.array_write = 1;
			} else {
				result->cs_data.array_write = 0;
			}
			result->value.yystype_ptr = data;
			result->strlen = -1; /* Not indexed string */
			
		}
		yystype_destructor(varname);
	}
}


inline void get_class_variable_pointer(YYSTYPE *result, YYSTYPE *class_ptr, YYSTYPE *varname)
{
	if (Execute) {
		YYSTYPE *object = (YYSTYPE *) class_ptr->value.yystype_ptr;
		
		if (!object) {
			result->value.yystype_ptr = NULL;
			yystype_destructor(varname);
			return;
		}
		if (varname->type != IS_STRING) {
			php3_error(E_WARNING,"Illegal property name");
			result->value.yystype_ptr = NULL;
			yystype_destructor(varname);
			return;
		} else {
			YYSTYPE *data;

			if (hash_find(object->value.ht,varname->value.strval, varname->strlen+1, (void **)&data) == FAILURE) {
				YYSTYPE tmp;
				variable_tracker vt;

				var_reset(&tmp);
				hash_update(object->value.ht,varname->value.strval,varname->strlen+1,(void *) &tmp, sizeof(YYSTYPE),(void **) &data);
				
				vt.type = IS_STRING;
				vt.strlen = varname->strlen;
				vt.strval = estrndup(varname->value.strval,vt.strlen);
				vt.ht = object->value.ht;
				stack_push(&variable_unassign_stack,(void *) &vt, sizeof(variable_tracker));
				result->cs_data.array_write = 1;
			} else {
				result->cs_data.array_write = 0;
			}
			result->value.yystype_ptr = data;
			result->strlen = -1; /* Not indexed string */
			yystype_destructor(varname);
		}
	}
}


inline void read_pointer(YYSTYPE *result,YYSTYPE *array_result)
{
	if (array_result->value.yystype_ptr) {
		if (array_result->cs_data.array_write) {
		    variable_tracker *vt;
		        
			if (stack_top(&variable_unassign_stack,(void **) &vt)==SUCCESS) {
				switch(vt->type) {
					case IS_STRING:
						php3_error(E_NOTICE,"Uninitialized variable or array index or property (%s)",vt->strval);
						break;
					case IS_LONG:
						php3_error(E_NOTICE,"Uninitialized array index (%d)",vt->lval);
						break;
				}
			} else {
				php3_error(E_NOTICE,"Uninitialized variable");
			}
			var_reset(result);
			clean_unassigned_variable_top(1);
		} else {
			if (array_result->strlen == -1) {
				*result = *((YYSTYPE *)array_result->value.yystype_ptr);
				yystype_copy_constructor(result);
			} else {
				YYSTYPE *tmp=(YYSTYPE *) array_result->value.yystype_ptr;
	
				result->value.strval = (char *) emalloc(2);
				result->value.strval[0]=tmp->value.strval[array_result->strlen];
				result->value.strval[1]=0;
				result->strlen=1;
				result->type = IS_STRING;
			}
		}
	} else {
		var_reset(result);
	}	
}
/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
