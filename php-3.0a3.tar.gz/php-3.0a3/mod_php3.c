/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
 */
/* $Id: mod_php3.c,v 1.27 1997/11/21 23:29:15 shane Exp $ */

#include "httpd.h"
#include "http_config.h"
#include "http_core.h"
#include "http_main.h"
#include "http_protocol.h"
#include "http_request.h"
#include "http_log.h"
#include "util_script.h"
#include "mod_php3.h"

module MODULE_VAR_EXPORT php3_module;
int saved_umask;

#ifdef PHP_XBITHACK
#define DEFAULT_PHP_XBITHACK 1
#else
#define DEFAULT_PHP_XBITHACK 0
#endif

extern int apache_php3_module_main(request_rec * r, php3_module_conf *, int fd, int display_source_mode);
extern int php3_module_startup();
extern void php3_module_shutdown();

void php3_save_umask()
{
	saved_umask = umask(077);
	umask(saved_umask);
}

void php3_restore_umask()
{
	umask(saved_umask);
}

int send_parsed_php3(request_rec * r)
{
	int fd, retval;
	php3_module_conf *conf;

	/* Make sure file exists */
	if (r->finfo.st_mode == 0)
		return NOT_FOUND;

	/* grab configuration settings */
	conf = (php3_module_conf *) get_module_config(r->per_dir_config, &php3_module);

	/* 
	 * If PHP parser engine has been turned off with the phpEngine off directive,
	 * then decline to handle this request
	 */
	if (!conf->engine) {
		r->content_type = "text/html";
		return DECLINED;
	}

	/* Open the file */
	if ((fd = popenf(r->pool, r->filename, O_RDONLY, 0)) == -1) {
		log_reason("file permissions deny server access", r->filename, r);
		return FORBIDDEN;
	}
	/* Apache 1.2+ has a more complex mechanism for reading POST data */
#if MODULE_MAGIC_NUMBER > 19961007
	if ((retval = setup_client_block(r, REQUEST_CHUNKED_ERROR)))
		return retval;
#endif

	if (conf->LastModified) {
#if MODULE_MAGIC_NUMBER < 19970912
		if (retval = set_last_modified(r, r->finfo.st_mtime)) {
			return retval;
		}
#else
		update_mtime (r, r->finfo.st_mtime);
		set_last_modified(r);
		set_etag(r);
#endif
	}
	/* Assume output will be HTML.  Individual scripts may change this 
	   further down the line */
	r->content_type = "text/html";

	/* Init timeout */
	hard_timeout("send", r);

	php3_save_umask();
	chdir_file(r->filename);
	add_common_vars(r);
	add_cgi_vars(r);
	apache_php3_module_main(r, conf, fd, 0);

	/* Done, restore umask, turn off timeout, close file and return */
	php3_restore_umask();
	kill_timeout(r);
	pclosef(r->pool, fd);
	return OK;
}


int send_parsed_php3_source(request_rec * r)
{
	int fd, retval;
	php3_module_conf *conf;

	/* Make sure file exists */
	if (r->finfo.st_mode == 0)
		return NOT_FOUND;

	/* grab configuration settings */
	conf = (php3_module_conf *) get_module_config(r->per_dir_config, &php3_module);

	/* 
	 * If PHP parser engine has been turned off with the phpEngine off directive,
	 * then decline to handle this request
	 */
	if (!conf->engine) {
		r->content_type = "text/html";
		return DECLINED;
	}
	/* Open the file */
	if ((fd = popenf(r->pool, r->filename, O_RDONLY, 0)) == -1) {
		log_reason("file permissions deny server access", r->filename, r);
		return FORBIDDEN;
	}
	/* Apache 1.2 has a more complex mechanism for reading POST data */
#if MODULE_MAGIC_NUMBER > 19961007
	if ((retval = setup_client_block(r, REQUEST_CHUNKED_ERROR)))
		return retval;
#endif

	if (conf->LastModified) {
#if MODULE_MAGIC_NUMBER < 19970912
		if (retval = set_last_modified(r, r->finfo.st_mtime)) {
			return retval;
		}
#else
		update_mtime (r, r->finfo.st_mtime);
		set_last_modified(r);
		set_etag(r);
#endif
	}
	/* Assume output will be HTML.  Individual scripts may change this 
	   further down the line */
	r->content_type = "text/html";

	/* Init timeout */
	hard_timeout("send", r);

	php3_save_umask();
	chdir_file(r->filename);
	add_common_vars(r);
	add_cgi_vars(r);
	apache_php3_module_main(r, conf, fd, 1);

	/* Done, restore umask, turn off timeout, close file and return */
	php3_restore_umask();
	kill_timeout(r);
	pclosef(r->pool, fd);
	return OK;
}


/* Initialize a per-directory module configuation structure */
void *php3_create_conf(pool * p, char *dummy)
{
	php3_module_conf *new;

	new = (php3_module_conf *) palloc(p, sizeof(php3_module_conf));
	new->ShowInfo = 1;
	new->Logging = 1;
	new->UploadTmpDir = NULL;
	new->dbmLogDir = NULL;
	new->SQLLogDB = NULL;
	new->SQLLogHost = NULL;
	new->AccessDir = NULL;
	new->MaxDataSpace = 8192;
	new->XBitHack = DEFAULT_PHP_XBITHACK;
	new->IncludePath = NULL;
	new->AutoPrependFile = NULL;
	new->AutoAppendFile = NULL;
	new->Debug = 0;
	new->engine = 1;
	new->LastModified = 0;
	new->AdaUser = NULL;
	new->AdaPW = NULL;
	new->AdaDB = NULL;
	return new;
}

#if MODULE_MAGIC_NUMBER > 19961007
const char *php3flaghandler(cmd_parms * cmd, php3_module_conf * conf, int val)
{
#else
char *php3flaghandler(cmd_parms * cmd, php3_module_conf * conf, int val)
{
#endif
	int c = (int) cmd->info;

	switch (c) {
		case 0:
			conf->ShowInfo = val;
			break;
		case 1:
			conf->Logging = val;
			break;
		case 2:
			conf->XBitHack = val;
			break;
		case 3:
			conf->Debug = val;
			break;
		case 4:
			conf->engine = val;
			break;
		case 5:
			conf->LastModified = val;
			break;
	}
	return NULL;
}

#if MODULE_MAGIC_NUMBER > 19961007
const char *php3take1handler(cmd_parms * cmd, php3_module_conf * conf, char *arg)
{
#else
char *php3take1handler(cmd_parms * cmd, php3_module_conf * conf, char *arg)
{
#endif
	int c = (int) cmd->info;

	switch (c) {
		case 0:
			conf->UploadTmpDir = pstrdup(cmd->pool, arg);
			break;
		case 1:
			conf->dbmLogDir = pstrdup(cmd->pool, arg);
			break;
		case 2:
			conf->SQLLogDB = pstrdup(cmd->pool, arg);
			break;
		case 3:
			conf->AccessDir = pstrdup(cmd->pool, arg);
			break;
		case 4:
			conf->MaxDataSpace = atoi(arg);
			break;
		case 5:
			conf->SQLLogHost = pstrdup(cmd->pool, arg);
			break;
		case 6:
			conf->IncludePath = pstrdup(cmd->pool, arg);
			break;
		case 7:
			conf->AutoPrependFile = pstrdup(cmd->pool, arg);
			break;
		case 8:
			conf->AutoAppendFile = pstrdup(cmd->pool, arg);
			break;
		case 9:
			conf->AdaDB = pstrdup(cmd->pool, arg);
			break;
		case 10:
			conf->AdaUser = pstrdup(cmd->pool, arg);
			break;
		case 11:
			conf->AdaPW = pstrdup(cmd->pool, arg);
			break;
	}
	return NULL;
}

int php3_xbithack_handler(request_rec * r)
{
	php3_module_conf *conf;

	conf = (php3_module_conf *) get_module_config(r->per_dir_config, &php3_module);
	if (!(r->finfo.st_mode & S_IXUSR))
		return DECLINED;
	if (conf->XBitHack == 0)
		return DECLINED;
	return send_parsed_php3(r);
}

void php3_exit_handler(server_rec *s, pool *p)
{
	php3_module_shutdown();
}

void php3_init_handler(server_rec *s, pool *p)
{
	/* For Apache 1.2 try registering a cleanup function for the main server pool */
#if MODULE_MAGIC_NUMBER < 19970728
	register_cleanup(p, NULL, php3_module_shutdown, php3_module_shutdown);
#endif
	php3_module_startup();
}

handler_rec php3_handlers[] =
{
	{"application/x-httpd-php3", send_parsed_php3},
	{"application/x-httpd-php3-source", send_parsed_php3_source},
	{"text/html", php3_xbithack_handler},
	{NULL}
};


command_rec php3_commands[] =
{
{"php3ShowInfo", php3flaghandler, (void *) 0, OR_OPTIONS, FLAG, "on|off"},
{"php3Logging", php3flaghandler, (void *) 1, OR_OPTIONS, FLAG, "on|off"},
  {"php3Debug", php3flaghandler, (void *) 3, OR_OPTIONS, FLAG, "on|off"},
	{"php3UploadTmpDir", php3take1handler, (void *) 0, OR_OPTIONS, TAKE1, "directory"},
	{"php3DbmLogDir", php3take1handler, (void *) 1, OR_OPTIONS, TAKE1, "directory"},
	{"php3MsqlLogDB", php3take1handler, (void *) 2, OR_OPTIONS, TAKE1, "database"},
	{"php3SQLLogDB", php3take1handler, (void *) 2, OR_OPTIONS, TAKE1, "database"},
	{"php3AccessDir", php3take1handler, (void *) 3, OR_OPTIONS, TAKE1, "directory"},
	{"php3MaxDataSpace", php3take1handler, (void *) 4, OR_OPTIONS, TAKE1, "number of kilobytes"},
	{"php3MsqlLogHost", php3take1handler, (void *) 5, OR_OPTIONS, TAKE1, "hostname"},
	{"php3SQLLogHost", php3take1handler, (void *) 5, OR_OPTIONS, TAKE1, "hostname"},
{"php3XBitHack", php3flaghandler, (void *) 2, OR_OPTIONS, FLAG, "on|off"},
	{"php3IncludePath", php3take1handler, (void *) 6, OR_OPTIONS, TAKE1, "colon-separated path"},
  {"php3Engine", php3flaghandler, (void *) 4, RSRC_CONF, FLAG, "on|off"},
	{"php3LastModified", php3flaghandler, (void *) 5, OR_OPTIONS, FLAG, "on|off"},
	{"php3AutoPrependFile", php3take1handler, (void *) 7, OR_OPTIONS, TAKE1, "file name"},
	{"php3AutoAppendFile", php3take1handler, (void *) 8, OR_OPTIONS, TAKE1, "file name"},
	{"php3AdaDefDB", php3take1handler, (void *) 9, OR_OPTIONS, TAKE1, "database"},
	{"php3AdaDefUser", php3take1handler, (void *) 10, OR_OPTIONS, TAKE1, "user"},
	{"php3AdaDefPW", php3take1handler, (void *) 11, OR_OPTIONS, TAKE1, "password"},
	{NULL}
};



module MODULE_VAR_EXPORT php3_module =
{
	STANDARD_MODULE_STUFF,
	php3_init_handler,			/* initializer */
	php3_create_conf,			/* per-directory config creator */
	NULL,						/* dir merger --- default is to override */
	NULL,						/* per-server config creator */
	NULL,						/* merge server config */
	php3_commands,				/* command table */
	php3_handlers,				/* handlers */
	NULL,						/* filename translation */
	NULL,						/* check_user_id */
	NULL,						/* check auth */
	NULL,						/* check access */
	NULL,						/* type_checker */
	NULL,						/* fixups */
	NULL						/* logger */
#if MODULE_MAGIC_NUMBER >= 19970103
	,NULL						/* header parser */
#endif
#if MODULE_MAGIC_NUMBER >= 19970719
	,NULL             			/* child_init */
#endif
#if MODULE_MAGIC_NUMBER >= 19970728
	,php3_exit_handler			/* child_exit */
#endif
#if MODULE_MAGIC_NUMBER >= 19970902
	,NULL						/* post read-request */
#endif
};

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
