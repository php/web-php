/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans   <andi@vipe.technion.ac.il>                   |
   |          Zeev Suraski   <bourbon@netvision.net.il>                   |
   |          Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
 */
#include "alloc.h"
#include "parser.h"

THREAD_LS static mem_header *head;

/* used by ISAPI and NSAPI */
extern void *hLock;

#if DEBUG
PHPAPI void *_emalloc(size_t size, char *filename, uint lineno)
#else
PHPAPI void *_emalloc(size_t size)
#endif
{
	mem_header *p;

	BLOCK_INTERRUPTIONS;

	p  = (mem_header *) malloc(sizeof(mem_header) + size + PLATFORM_PADDING);

	if (!p) {
		UNBLOCK_INTERRUPTIONS;
		return (void *)p;
	}
	p->pNext = head;
	if (head) {
		head->pLast = p;
	}
	p->pLast = (mem_header *) NULL;
	head = p;
#if DEBUG
	p->filename = strdup(filename);
	p->lineno = lineno;
	p->size = size;
#endif
	UNBLOCK_INTERRUPTIONS;
	return (void *)((char *)p + sizeof(mem_header) + PLATFORM_PADDING);
}


#if DEBUG
PHPAPI void _efree(void *ptr, char *filename, uint lineno)
#else
PHPAPI void _efree(void *ptr)
#endif
{
	mem_header *p = (mem_header *) ((char *)ptr - sizeof(mem_header) - PLATFORM_PADDING);

	BLOCK_INTERRUPTIONS;
	if (p == head) {
		head = p->pNext;
	} else {
		p->pLast->pNext = p->pNext;
	}
	if (p->pNext) {
		p->pNext->pLast = p->pLast;
	}
#if DEBUG
	free(p->filename);
#endif
	free(p);
	UNBLOCK_INTERRUPTIONS;
}


#if DEBUG
PHPAPI void *_ecalloc(size_t nmemb, size_t size, char *filename, uint lineno)
#else
PHPAPI void *_ecalloc(size_t nmemb, size_t size)
#endif
{
	mem_header *p;
	int final_size;

	final_size = sizeof(mem_header) + PLATFORM_PADDING + (nmemb * size);
	BLOCK_INTERRUPTIONS;
	p = (mem_header *) malloc(final_size);
	if (!p) {
		UNBLOCK_INTERRUPTIONS;
		return (void *) p;
	}
	memset(p,(int)NULL,final_size);
	p->pNext = head;
	if (head) {
		head->pLast = p;
	}
	p->pLast = (mem_header *) NULL;
	head = p;
#if DEBUG
	p->filename = strdup(filename);
	p->lineno = lineno;
	p->size = size;
#endif	
	UNBLOCK_INTERRUPTIONS;
	return (void *)((char *)p + sizeof(mem_header) + PLATFORM_PADDING);
}


#if DEBUG
PHPAPI void *_erealloc(void *ptr, size_t size, char *filename, uint lineno)
#else
PHPAPI void *_erealloc(void *ptr, size_t size)
#endif
{
	mem_header *p = (mem_header *) ((char *)ptr-sizeof(mem_header)-PLATFORM_PADDING);

	BLOCK_INTERRUPTIONS;
	p = (mem_header *) realloc(p,sizeof(mem_header)+size+PLATFORM_PADDING);
	if (!p) {
		UNBLOCK_INTERRUPTIONS;
		return (void *)p;
	}
	if (p->pLast) {
		p->pLast->pNext = p;
	} else {
		head = p;
	}
	if (p->pNext) {
		p->pNext->pLast = p;
	}
#if DEBUG
	free(p->filename);
	p->filename = strdup(filename);
	p->lineno = lineno;
	p->size = size;
#endif	
	UNBLOCK_INTERRUPTIONS;
	return (void *)((char *)p+sizeof(mem_header)+PLATFORM_PADDING);
}


#if DEBUG
PHPAPI char *_estrdup(const char *s, char *filename, uint lineno)
#else
PHPAPI char *_estrdup(const char *s)
#endif
{
	int length;
	char *p;

	length = strlen(s)+1;
	BLOCK_INTERRUPTIONS;
#if DEBUG
	p = (char *) _emalloc(length,filename,lineno);
#else
	p = (char *) emalloc(length);
#endif
	if (!p) {
		UNBLOCK_INTERRUPTIONS;
		return p;
	}
	UNBLOCK_INTERRUPTIONS;
	memcpy(p,s,length);
	return p;
}


#if DEBUG
PHPAPI char *_estrndup(const char *s, uint length, char *filename, uint lineno)
#else
PHPAPI char *_estrndup(const char *s, uint length)
#endif
{
	char *p;

	BLOCK_INTERRUPTIONS;
#if DEBUG
	p = (char *) _emalloc(length+1,filename,lineno);
#else
	p = (char *) emalloc(length+1);
#endif
	if (!p) {
		UNBLOCK_INTERRUPTIONS;
		return p;
	}
	UNBLOCK_INTERRUPTIONS;
	memcpy(p,s,length);
	p[length]=0;
	return p;
}

PHPAPI char *strndup(const char *s, uint length)
{
	char *p;

	p = (char *) malloc(length+1);
	if (!p) {
		return p;
	}
	memcpy(p,s,length);
	p[length]=0;
	return p;
}

void start_memory_manager(void)
{
	head = NULL;
}

void shutdown_memory_manager(void)
{
	mem_header *p=head,*t=head;
	while (t) {
#if DEBUG
		/* Don't send debug message on a HEAD request */
#if APACHE
		if ((error_reporting & E_WARNING) && !php3_rqst->header_only) {
#else
		if ((error_reporting & E_WARNING)) {
#endif
			php3_printf("Freeing %x (%d bytes), allocated in %s on line %d<br>\n",(void *)((char *)t+sizeof(mem_header)+PLATFORM_PADDING),t->size,t->filename,t->lineno);
		}
#endif
		p = t->pNext;
#if DEBUG
		free(t->filename);
#endif
		free(t);
		t = p;
	}
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
