/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                  |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
 */

#include "parser.h"
#include "internal_functions.h"
#include "reg.h"
#include "html.h"

/* This code should be cleaned up seriously.  Perhaps it should be
 * integrated with formatted_print?
 * -Stig
 */

typedef struct php_extra_ents {
	int code;
	char str[6];
} php_extra_ents;

void php3_htmlspecialchars(INTERNAL_FUNCTION_PARAMETERS)
{
    YYSTYPE *arg;
    int i;
    char lookfor[2];
    char replace[10];
    char *new, *work;
    static char EntTable[][7] =
    {
	"nbsp","iexcl","cent","pound","curren","yen","brvbar",
	"sect","uml","copy","ordf","laquo","not","shy","reg",
	"macr","deg","plusmn","sup2","sup3","acute","micro",
	"para","middot","cedil","sup1","ordm","raquo","frac14",
	"frac12","frac34","iquest","Agrave","Aacute","Acirc",
	"Atilde","Auml","Aring","AElig","Ccedil","Egrave",
	"Eacute","Ecirc","Euml","Igrave","Iacute","Icirc",
	"Iuml","ETH","Ntilde","Ograve","Oacute","Ocirc","Otilde",
	"Ouml","times","Oslash","Ugrave","Uacute","Ucirc","Uuml",
	"Yacute","THORN","szlig","agrave","aacute","acirc",
	"atilde","auml","aring","aelig","ccedil","egrave",
	"eacute","ecirc","euml","igrave","iacute","icirc",
	"iuml","eth","ntilde","ograve","oacute","ocirc","otilde",
	"ouml","divide","oslash","ugrave","uacute","ucirc",
	"uuml","yacute","thorn","yuml"
    };
    static php_extra_ents ExtraEnts[] =
    {
	{ 38, "amp" },  /* this one needs to be first */
	{ 34, "quot" },
	{ 60, "lt" },
	{ 62, "gt" },
	{ 0, "" }
    };
    
    if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
    }

    convert_to_string(arg);

    lookfor[1]='\0';
    work = estrndup(arg->value.strval,arg->strlen);
    i = 0;

    while (ExtraEnts[i].code) {
	if (strchr(work, (char)ExtraEnts[i].code)) {
	    lookfor[0] = (char)ExtraEnts[i].code;
	    sprintf(replace, "&%s;", ExtraEnts[i].str);
	    new = _php3_regreplace(lookfor, replace, work, 0, 0);
	    if (new != work) {
		efree(work);
		work = new;
	    }
	}
	i++;
    }

    for (i = 160; i < 256; i++) {
	if (strchr(work, (char)i)) {
	    lookfor[0] = (char)i;
	    sprintf(replace,"&%s;", EntTable[i-160]);
	    new = _php3_regreplace(lookfor, replace, work, 0, 0);
	    if (new != work) {
		efree(work);
		work = new;
	    }
	}
    }

    RETVAL_STRING(work);
    efree(work);
}


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
