/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   |          Stig S�ther Bakken <ssb@guardian.no>                        |
   |          Zeev Suraski <bourbon@nevision.net.il>                      |
   +----------------------------------------------------------------------+
 */


/* $Id: string.c,v 1.60 1997/11/21 22:15:49 zeev Exp $ */
#include <stdio.h>
#include "parser.h"
#include "internal_functions.h"
#include "reg.h"
#include "post.h"
#include "php3_string.h"

void php3_strlen(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	RETVAL_LONG(str->strlen);
}


void php3_chop(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;
	register int i;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);

	if (str->type == IS_STRING) {
		int len = str->strlen;
		char *c = str->value.strval;
		for (i = len - 1; i >= 0; i--) {
			if (c[i] == ' ' || c[i] == '\n' || c[i] == '\r' ||
				c[i] == '\t' || c[i] == '\v') {
				len--;
			} else {
				break;
			}
		}
		RETVAL_STRINGL(c, len);
		return;
	}
	RETURN_FALSE;
}


void php3_explode(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str, *delim;
	char *work_str, *p1, *p2;
	int i = 0;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &delim, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	convert_to_string(delim);

	if (str->type == IS_STRING && delim->type == IS_STRING) {
		if (array_init(&return_value) == FAILURE) {
			return;
		}
		work_str = p1 = estrndup(str->value.strval,str->strlen);
		p2 = strstr(p1, delim->value.strval);
		if (p2 == NULL) {
			add_index_string(i++, p1);
		}
		else do {
			p2[0] = 0;
			add_index_string(i++, p1);
			p1 = p2 + delim->strlen;
		} while ((p2 = strstr(p1, delim->value.strval)) && p2 != work_str);
		if (p1 != work_str) {
			add_index_string(i++, p1);
		}
		efree(work_str);
	}
}


void php3_implode(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg1, *delim, *tmp, arr;
	int len = 0, count = 0;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &delim) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	arr = *arg1;
	convert_to_string(delim);
	if (arr.type != IS_ARRAY || delim->type != IS_STRING) {
		php3_error(E_WARNING, "Bad arguments to %s()", function_state.function_name);
		return;
	}
	yystype_copy_constructor(arg1);

	/* convert everything to strings, and calculate length */
	hash_internal_pointer_reset(arr.value.ht);
	while (hash_get_current_data(arr.value.ht, (void **) &tmp) == SUCCESS) {
		convert_to_string(tmp);
		if (tmp->type == IS_STRING) {
			len += tmp->strlen;
			len += delim->strlen;
			count++;
		}
		hash_move_forward(arr.value.ht);
	}
	len = len - delim->strlen;

	/* do it */
	return_value.value.strval = (char *) emalloc(len + 1);
	return_value.value.strval[0] = 0;
	hash_internal_pointer_reset(arr.value.ht);
	while (hash_get_current_data(arr.value.ht, (void **) &tmp) == SUCCESS) {
		if (tmp->type == IS_STRING) {
			count--;
			strcat(return_value.value.strval, tmp->value.strval);
			if (count > 0) {
				strcat(return_value.value.strval, delim->value.strval);
			}
		}
		hash_move_forward(arr.value.ht);
	}
	return_value.type = IS_STRING;
	return_value.strlen = len;
	hash_destroy(arr.value.ht);
	efree(arr.value.ht);
}

char *strtok_string = NULL;

void php3_strtok(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str, *tok;

	static char *pos1 = NULL;
	static char *pos2 = NULL;
	char *token = NULL;
	char *first = NULL;
	int argc;

	argc = ARG_COUNT(ht);

	if ((argc == 1 && getParameters(ht, 1, &tok) == FAILURE) ||
		(argc == 2 && getParameters(ht, 2, &str, &tok) == FAILURE) ||
		argc < 1 || argc > 2) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(tok);
	token = tok->value.strval;

	if (argc == 2) {
		convert_to_string(str);

		if (strtok_string) {
			efree(strtok_string);
			strtok_string = NULL;
		}
		strtok_string = estrndup(str->value.strval,str->strlen);
		pos1 = strtok_string;
		pos2 = NULL;
	}
	if (pos1 && *pos1) {
		for ( /* NOP */ ; token && *token; token++) {
			pos2 = strchr(pos1, (int) *token);
			if (!first || (pos2 && pos2 < first)) {
				first = pos2;
			}
		}						/* NB: token is unusable now */
		pos2 = first;
		if (pos2) {
			*pos2 = '\0';
		}
		RETVAL_STRING(pos1);
		if (pos2)
			pos1 = pos2 + 1;
		else
			pos1 = NULL;
	} else {
		RETVAL_FALSE;
	}
}

PHPAPI char *_php3_strtoupper(char *s)
{
	char *c;
	int ch;

	c = s;
	while (*c) {
		ch = toupper(*c);
		*c++ = ch;
	}
	return (s);
}


void php3_strtoupper(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg;
	char *ret;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg)) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg);

	ret = _php3_strtoupper(arg->value.strval);
	RETVAL_STRING(ret);
}


PHPAPI char *_php3_strtolower(char *s)
{
	register int ch;
	char *c;

	c = s;
	while (*c) {
		ch = tolower(*c);
		*c++ = ch;
	}
	return (s);
}


void php3_strtolower(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;
	char *ret;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str)) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);

	ret = _php3_strtolower(str->value.strval);
	RETVAL_STRING(ret);
}

void php3_basename(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;
	char *ret, *c;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str)) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	ret = estrdup(str->value.strval);
	c = ret + strlen(ret) -1;	
	while(*c=='/') c--;
	*(c+1)='\0';	
	c = strrchr(ret,'/');
	if(c) {
		RETVAL_STRING(c+1);
	} else {
		RETVAL_STRING(str->value.strval);
	}
	efree(ret);
}

PHPAPI void _php3_dirname(char *str) {
	register char *c;

	c = str + strlen(str) -1;	
	while(*c=='/') c--;       /* strip trailing /'s */
	*(c+1)='\0';	
	c = strrchr(str,'/');
	if(c) *c='\0';
}

void php3_dirname(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;
	char *ret;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str)) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	ret = estrdup(str->value.strval);
	_php3_dirname(ret);
	RETVAL_STRING(ret);
	efree(ret);
}

void php3_strstr(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *haystack, *needle;
	char *found = NULL;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &haystack, &needle) ==
		FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(haystack);

	if (needle->type == IS_STRING) {
		found = strstr(haystack->value.strval, needle->value.strval);
	} else {
		char b[2];
		convert_to_long(needle);
		sprintf(b, "%c", (char) needle->value.lval);
		found = strstr(haystack->value.strval, b);
	}


	if (found) {
		RETVAL_STRING(found);
	} else {
		RETVAL_FALSE;
	}
}


void php3_strrchr(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *haystack, *needle;
	char *found = NULL;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &haystack, &needle) ==
		FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(haystack);

	if (needle->type == IS_STRING) {
		found = strrchr(haystack->value.strval, *needle->value.strval);
	} else {

		convert_to_long(needle);
		found = strrchr(haystack->value.strval, needle->value.lval);
	}


	if (found) {
		RETVAL_STRING(found);
	} else {
		RETVAL_FALSE;
	}
}


/* args s,m,n */
void php3_substr(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *string, *from, *len;
	int argc, l;
	int f;

	argc = ARG_COUNT(ht);

	if ((argc == 2 && getParameters(ht, 2, &string, &from) == FAILURE) ||
		(argc == 3 && getParameters(ht, 3, &string, &from, &len) == FAILURE) ||
		argc < 2 || argc > 3) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(string);
	convert_to_long(from);
	f = from->value.lval;

	if (argc == 2) {
		l = string->strlen;
	} else {
		convert_to_long(len);
		l = len->value.lval;
	}

	/* if "from" position is negative, count start position from the end
	 * of the string
	 */
	if (f < 0) {
		f = string->strlen + f;
		if (f < 0) {
			f = 0;
		}
	}

	/* if "length" position is negative, set it to the length
	 * needed to stop that many chars from the end of the string
	 */
	if (l < 0) {
		l = (string->strlen - f) + l;
		if (l < 0) {
			l = 0;
		}
	}

	if (f >= (int)string->strlen) {
		RETURN_FALSE;
	}

	if ((f + l) < (int)string->strlen) {
		string->value.strval[f + l] = '\0';
	}
	RETVAL_STRING(string->value.strval + f);
}


void php3_quotemeta(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg;
	register int x, y;
	char *str, *old;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg);

	old = arg->value.strval;

	if (!*old) {
		RETURN_FALSE;
	}
	str = emalloc(2 * strlen(old) + 1);
	for (x = 0, y = 0; old[x]; x++, y++) {
		switch (old[x]) {
			case '.':
			case '\\':
			case '+':
			case '*':
			case '?':
			case '[':
			case '^':
			case ']':
			case '$':
			case '(':
			case ')':
				str[y++] = '\\';
		}
		str[y] = old[x];
	}
	str[y] = '\0';
	RETVAL_STRING(str);
	efree(str);
}


void php3_ord(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	RETVAL_LONG(str->value.strval[0]);
}


void php3_chr(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *num;
	char temp[2];

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &num) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(num);
	temp[0] = (char) num->value.lval;
	temp[1] = '\0';
	RETVAL_STRINGL(temp, 1);
}


void php3_ucfirst(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg);

	if (!*arg->value.strval) {
		RETURN_FALSE;
	}
	*arg->value.strval = toupper(*arg->value.strval);
	RETVAL_STRING(arg->value.strval);
}


void php3_strtr(INTERNAL_FUNCTION_PARAMETERS)
{								/* strtr(STRING,FROM,TO) */
	YYSTYPE *str, *from, *to;
	unsigned char xlat[256];
	unsigned char *str_from, *str_to, *string;
	int i, len1, len2;

	if (ARG_COUNT(ht) != 3 || getParameters(ht, 3, &str, &from, &to) ==
		FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	convert_to_string(from);
	convert_to_string(to);

	string = str->value.strval;
	str_from = from->value.strval;
	str_to = to->value.strval;

	len1 = strlen(str_from);
	len2 = strlen(str_to);

	if (len1 > len2) {
		str_from[len2] = '\0';
		len1 = len2;
	}
	for (i = 0; i < 256; xlat[i] = i, i++);

	for (i = 0; i < len1; i++) {
		xlat[(unsigned char) str_from[i]] = str_to[i];
	}

	for (i = 0; i < str->strlen; i++) {
		string[i] = xlat[(unsigned char) string[i]];
	}

	RETVAL_STRING(string);
}


/* be careful, this edits the string in-place */
PHPAPI void _php3_stripslashes(char *string)
{
	char *s, *t;
	int l;

	l = strlen(string);
	s = string;
	t = string;
	while (l > 0 && *t != '\0') {
		if (*t == '\\') {
			t++;				/* skip the slash */
			l--;
			if (l > 0 && *t != '\0') {
				*s++ = *t++;	/* preserve the next character */
				l--;
			}
		} else {
			if (s != t)
				*s++ = *t++;
			else {
				s++;
				t++;
			}
			l--;
		}
	}
	if (s != t)
		*s = '\0';
}


void php3_addslashes(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);
	return_value.value.strval = _php3_addslashes(str->value.strval,0);
	return_value.strlen = strlen(return_value.value.strval);
	return_value.type = IS_STRING;
}

void php3_stripslashes(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *str;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &str) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(str);

	/* let RETVAL do the estrdup() */
	RETVAL_STRING(str->value.strval);
	_php3_stripslashes(return_value.value.strval);
	/* but don't forget to recalc the strlen! */
	return_value.strlen = strlen(return_value.value.strval);
}

#ifndef HAVE_STRERROR
char *strerror(int errnum) {
	extern int sys_nerr;
	extern char *sys_errlist[];
	static char ebuf[40];

	if((unsigned int)errnum < sys_nerr) return(sys_errlist[errnum]);
	(void)sprintf(ebuf, "Unknown error: %d", errnum);
	return(ebuf);
}
#endif


PHPAPI char *_php3_addslashes(char *str, int should_free)
{
	int string_length = strlen(str);
	char *new_str = (char *) emalloc(string_length*2+1); /* maximum string length, worst case situation */
	register int i,j;
	
	for (i=j=0; i<string_length; i++) {
		switch(str[i]) {
			case '\'':  /* break is missing *intentionally* */
			case '\"':
			case '\\':
				new_str[j++]='\\';
			default:
				new_str[j++]=str[i];
				break;
		}
	}
	new_str[j]=0;
	if (should_free) {
		efree(str);
	}
	return new_str;
}
	
/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
