#ifndef _PROCESS_H
#define _PROCESS_H

extern long _php3_getuid(void);

#endif
