/* $Id: post.h,v 1.12 1997/11/17 19:26:49 shane Exp $ */

#ifndef _POST_H
#define _POST_H

#define PARSE_POST 0
#define PARSE_GET 1
#define PARSE_COOKIE 2
#define PARSE_STRING 3

/* extern int php3_CheckResult(char *res); XXX Not used anywhere */
extern void php3_TreatData(int arg, char *str);
extern void php3_TreatHeaders(void);
extern void _php3_parse_gpc_data(char *, char *, YYSTYPE *track_vars_array);

THREAD_LS extern int php3_track_vars;

extern void php3_parsestr(INTERNAL_FUNCTION_PARAMETERS);

#endif
