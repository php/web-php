/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Author: Jim Winstead (jimw@adventure.com)                            |
   +----------------------------------------------------------------------+
 */

#include "parser.h"

THREAD_LS php3_request_info request_info;

#if CGI_BINARY
int php3_init_request_info(void *conf) {
	char *buf;

	/* We always need to emalloc() filename, since it gets placed into
	   the include file hash table, and gets freed with that table.
	   Notice that this means that we don't need to efree() it in
	   php3_destroy_request_info()! */
	request_info.filename = NULL;
	request_info.path_info = getenv("PATH_INFO");
	request_info.path_translated = getenv("PATH_TRANSLATED");
	request_info.query_string = getenv("QUERY_STRING");
	request_info.current_user = NULL;
	request_info.current_user_length=0;
	request_info.request_method = getenv("REQUEST_METHOD");
	request_info.script_name = getenv("SCRIPT_NAME");
	buf = getenv("CONTENT_LENGTH");
	request_info.content_length = (buf ? atoi(buf) : 0);
	request_info.content_type = getenv("CONTENT_TYPE");
	request_info.cookies = getenv("HTTP_COOKIE");

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	STR_FREE(request_info.current_user);
	return SUCCESS;
}
#endif

#if APACHE
int php3_init_request_info(void *conf) {
	char *buf;

	/* see above for why this has to be estrdup()'d */
	request_info.filename = estrdup(php3_rqst->filename);
	request_info.request_method = php3_rqst->method;
	request_info.query_string = php3_rqst->args;
	request_info.content_type = table_get(php3_rqst->subprocess_env, "CONTENT_TYPE");

	buf = table_get(php3_rqst->subprocess_env, "CONTENT_LENGTH");
	request_info.content_length = (buf ? atoi(buf) : 0);

	request_info.cookies = table_get(php3_rqst->subprocess_env, "HTTP_COOKIE");

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	/* see above for why we don't want to efree() request_info.filename */
	return SUCCESS;
}
#endif

#if NSAPI
int php3_init_request_info(void *conf) {
	Request *nsrq = (Request *)conf;
	
	request_info.path_info = pblock_findval("path-info",nsrq->vars);
	request_info.path_translated = pblock_findval("path",nsrq->vars);
	request_info.filename = estrdup(request_info.path_translated);
	request_info.query_string = pblock_findval("query", nsrq->vars); 
	request_info.request_method = pblock_findval("method",nsrq->reqpb);
	request_info.script_name = pblock_findval("path",nsrq->vars);
	request_info.content_length = atoi(pblock_findval("content-length",nsrq->headers));
	request_info.content_type =  pblock_findval("content-type",nsrq->srvhdrs);
	request_header("cookie", &(request_info.cookies), nssn,nsrq);

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	/* see above for why we don't want to efree() request_info.filename */
	return SUCCESS;
}
#endif

#if PHP_ISAPI
int php3_init_request_info(void *conf) {
	char *buf;
	LPEXTENSION_CONTROL_BLOCK lpecb = (LPEXTENSION_CONTROL_BLOCK)conf;

	request_info.path_info = lpecb->lpszPathInfo;
	request_info.path_translated = lpecb->lpszPathTranslated;
	/* see above for why we have to estrdup() this next one */
	request_info.filename = estrdup(request_info.path_translated);
	request_info.query_string = lpecb->lpszQueryString;
	request_info.request_method = lpecb->lpszMethod;
	request_info.script_name = isapi_getenv(lpecb,"SCRIPT_NAME");

	buf = isapi_getenv(lpecb,"CONTENT_LENGTH");
	request_info.content_length = (buf ? atoi(buf) : 0);

	request_info.content_type = lpecb->lpszContentType;
	request_info.cookies = isapi_getenv(lpecb,"HTTP_COOKIE");

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	/* see above for why we don't want to efree() request_info.filename */
	return SUCCESS;
}
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
