#ifndef _TLS_H_
#define _TLS_H_
#if WIN32|WINNT
#include "win32/pwd.h"
#include "win32/sendmail.h"
#endif

#include "alloc.h"
#include "functions/head.h"
#include <sys/stat.h>

/* this is copied from the flex output */

typedef unsigned int yy_size_t;
typedef int yy_state_type;
#ifndef FLEX_SCANNER
struct yy_buffer_state
	{
	FILE *yy_input_file;
	char *yy_ch_buf;
	char *yy_buf_pos;
	yy_size_t yy_buf_size;
	int yy_n_chars;
	int yy_is_our_buffer;
	int yy_is_interactive;
	int yy_at_bol;
	int yy_fill_buffer;
	int yy_buffer_status;
#define YY_BUFFER_NEW 0
#define YY_BUFFER_NORMAL 1
#define YY_BUFFER_EOF_PENDING 2
	};
#endif
typedef struct yy_buffer_state *YY_BUFFER_STATE;

typedef struct php3_global_struct{
	/*all globals must be here*/
	/*alloc.c*/
	mem_header *head;
	/*debbuger.c*/
	int debug_socket;
	char *myhostname;
#if NSAPI && MSVC5
	int mypid;
#else
	pid_t mypid;
#endif
	char *currenttime;
	char debug_timebuf[50]; /*STATIC VAR*/
	/*getopt.c*/
	char *optarg;
	int optind;
	int opterr;
	int optopt;
	/*file.c*/
	int pclose_ret;
	/*highlite.c*/
	char *phptext;
	int phpleng;
	/*internal_functions.c*/
	HashTable list_destructors;
	HashTable module_registry;
	/*language-parser.tab.c*/
	HashTable symbol_table;
	HashTable function_table;
	HashTable include_names;
	TokenCacheManager token_cache_manager;
	Stack css;
	Stack for_stack;
	Stack input_source_stack;
	Stack function_state_stack;     
	Stack switch_stack;
	Stack variable_unassign_stack; 
	HashTable *active_symbol_table;  
	int Execute;  
	int ExecuteFlag;
	int current_lineno;            
	int include_count;
	FunctionState function_state;
	char *class_name;
	HashTable *class_symbol_table;
	YYSTYPE *data,return_value,globals;
	unsigned int param_index;
	YYSTYPE *array_ptr;
	/*list.c*/
	int le_index_ptr;
	HashTable list;
	HashTable plist;
	/*main.c*/
	int error_reporting;
	int tmp_error_reporting;
	int initialized;
	int module_initialized;
	int shutdown_requested;
	int phplineno;
	int php3_display_source;
	int php3_preprocess;
#if APACHE
	request_rec *php3_rqst;
#endif
#if PHP_ISAPI
	LPEXTENSION_CONTROL_BLOCK lpPHPcb;
#endif
#if WIN32|WINNT
	unsigned int wintimer;
#endif
	char *strtok_string;
	FILE *phpin;
	/*request_info.c*/
	php3_request_info request_info;
	/*token_cache.c*/
	YYSTYPE phplval;
	TokenCache *tc; /*active token cache */
	
	/*Functions*/
	/*dir.c*/
	int dirp_id;
	int le_dirp;
	/*file.c*/
	int fgetss_state;
	int le_fp;
	int le_pp;
	/*filestat.c*/
	char *CurrentStatFile;
#if MSVC5
	unsigned int CurrentStatLength;
#else
	int CurrentStatLength;
#endif
	struct stat sb;
	/*formated_print.c*/
	char cvt_buf[80]; /*STATIC VAR*/
	/*head.c*/
	int php3_HeaderPrinted;
	int php3_PrintHeader;
	CookieList *top;
	char *cont_type;
	int header_called;
	/*info.c*/
#if APACHE
	module *top_module;
#endif
	/*pageinfo.c*/
	long page_uid;
	long page_inode;
	long page_mtime;
	/*post.c*/
	int php3_track_vars;
	/*strings.h*/
	char *strtok_pos1; /*STATIC VAR*/
	char *strtok_pos2; /*STATIC VAR*/
#ifndef HAVE_STRERROR
	char str_ebuf[40]; /*STATIC VAR*/
#endif	
#if WIN32|WINNT
	/*pwd.c*/
	struct passwd pw;	/* should we return a malloc()'d structure   */
	char *home_dir;	/* we feel (no|every)where at home */
	char *login_shell;
	/*sendmail.c*/
	char Buffer[MAIL_BUFFER_SIZE]; 
	SOCKET sc;
	WSADATA Data;
	struct hostent *adr;
	SOCKADDR_IN sin;
	int WinsockStarted;
	char AppName[MAX_APPNAME_LENGHT];
	char MailHost[HOST_NAME_LEN];
	char LocalHost[HOST_NAME_LEN];
	/*winsyslog.c*/
	void *loghandle;
	int lopt;
	int fac;
#endif
	/* these are the flex created globals */
/*	FILE *yyin;  This is defined as phpin in flex */
	FILE *phpout; /*This is defined as phpout in flex*/
/*	int yyleng;  This is phpleng*/
/*	char *yytext;This is phptext*/
	// yy_accept  //this might be ok;
	YY_BUFFER_STATE yy_current_buffer;
	char *yy_c_buf_p;
	int yy_did_buffer_switch_on_eof;
	// yy_ec   //this might be ok;
	char yy_hold_char;
	int yy_init;
	char *yy_last_accepting_cpos;
	yy_state_type yy_last_accepting_state;
	// yy_nxt  //this might be ok;
	int yy_n_chars;
	int yy_start;
	int yy_start_stack_ptr;
	int yy_start_stack_depth;
	int *yy_start_stack;


	
	/*check for each module if it is compiled staticly
	we should include their globals here.*/
} php3_globals_struct;

#ifdef THREAD_SAFE
extern DWORD TlsIndex;

extern int tls_create(void);
extern int tls_destroy(void);
#else
extern php3_globals_struct *php3_globals;


#endif

extern int tls_startup(void);
extern int tls_shutdown(void);

#endif