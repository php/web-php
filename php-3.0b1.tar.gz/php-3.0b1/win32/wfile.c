/* Function borrowed from the Downhill Project */
#include "wfile.h"
#include "direct.h"

int readlink(char* file_Name,char* buf_Mem,int buf_Size)
{
	/* See if the file exists */
	if (access(file_Name,X_OK) == -1)
	{
		errno = ENOENT;
	}
	else
	{
		errno = EINVAL;
	}

	/* Either way, it's not a link */	
	return -1;
}

/* this is not needed
static int curdrive;

int checkroot(char *path){
	int drive;
	
	if(!curdrive){curdrive=3;}
	if((path[1] == ':')&&(!path[0] == (drive + 'A' - 1))){
		drive=(int)(path[0] - 'A' + 1);
		_chdrive(drive);
		curdrive = drive;
		}
	return curdrive;
}
*/