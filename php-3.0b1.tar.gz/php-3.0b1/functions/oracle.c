/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Stig S�ther Bakken <ssb@guardian.no>                        |
   |          Mitch Golden <mgolden@interport.net>                        |
   +----------------------------------------------------------------------+
 */

/*
 *  $Id: oracle.c,v 1.40 1997/12/07 08:15:39 jaakko Exp $
 *
 * TODO:
 *
 * PHP 3.0 stuff:
 *
 * - Rewrite to use 3.0's "resource handler" for connections, cursors
 *   and data.
 *
 * General stuff:
 *
 * - MAGIC_QUOTES  (hard, because you can't escape ' as \', must be ''
 *                  and the routine _php3_addslashes is used for multiple
 *                  things.)
 * - array/table support
 * - persistent connections (migrate this from 2.0)
 *
 * Function wishlist:
 *
 * - Ora_ColumnName
 * - Ora_ColumnType
 * - Ora_Bind (bind PHP variables to SQL placeholders)
 * - Ora_FetchLong (requires proper binary string support in PHP)
 * - Ora_Options (easy, it's just that nobody has needed it so far :)
 *
 */

/* PHP stuff */
#include "parser.h"
#include "internal_functions.h"
#include "oracle.h"

#if HAVE_ORACLE

#include "list.h"
#include "build-defs.h"

function_entry oracle_functions[] = {
	{"ora_close",		php3_Ora_Close,			NULL},
	{"ora_commit",		php3_Ora_Commit,		NULL},
	{"ora_commitoff",	php3_Ora_CommitOff,		NULL},
	{"ora_commiton",	php3_Ora_CommitOn,		NULL},
	{"ora_error",		php3_Ora_Error,			NULL},
	{"ora_errorcode",	php3_Ora_ErrorCode,		NULL},
	{"ora_exec",		php3_Ora_Exec,			NULL},
	{"ora_fetch",		php3_Ora_Fetch,			NULL},
	{"ora_getcolumn",	php3_Ora_GetColumn,		NULL},
	{"ora_logoff",		php3_Ora_Logoff,		NULL},
	{"ora_logon",		php3_Ora_Logon,			NULL},
	{"ora_open",		php3_Ora_Open,			NULL},
	{"ora_parse",		php3_Ora_Parse,			NULL},
	{"ora_rollback",	php3_Ora_Rollback,		NULL},
	{NULL, NULL, NULL}
};

php3_module_entry oracle_module_entry = {
	"Oracle", oracle_functions, php3_minit_oracle, NULL, NULL, NULL, php3_info_oracle, 0, 0, 0, NULL
};


static int le_oraconn, le_oracur;

static void _close_oraconn(oraConnection *conn)
{
	/* XXX TODO FIXME call ologof() here if the connection is open */
	efree(conn);
}


static void _close_oracur(oraCursor *cur)
{
	/* XXX TODO FIXME call oclose() here if the cursor is open */
	if (cur->columns) {
		efree(cur->columns);
	}
	if (cur->current_query) {
		efree(cur->current_query);
	}
	efree(cur);
}


int php3_minit_oracle(INITFUNCARG)
{
	le_oraconn = register_list_destructors(_close_oraconn,NULL);
	le_oracur = register_list_destructors(_close_oracur,NULL);
	return SUCCESS;
}



/* #define TRACE */

static int ora_add_conn(INTERNAL_FUNCTION_PARAMETERS);
static oraConnection *ora_get_conn(INTERNAL_FUNCTION_PARAMETERS,int);
static void ora_del_conn(INTERNAL_FUNCTION_PARAMETERS,int);
static int ora_add_cursor(INTERNAL_FUNCTION_PARAMETERS);
static oraCursor *ora_get_cursor(INTERNAL_FUNCTION_PARAMETERS,int);
static void ora_del_cursor(INTERNAL_FUNCTION_PARAMETERS,int);
static char *ora_error(Cda_Def *);
static int ora_describe_define(oraCursor *);
static int ora_find_column_index(oraCursor *, char *);

static const text *ora_func_tab[] =
{(text *) "unused",
/*  1, 2  */ (text *) "unused", (text *) "OSQL",
/*  3, 4  */ (text *) "unused", (text *) "OEXEC/OEXN",
/*  5, 6  */ (text *) "unused", (text *) "OBIND",
/*  7, 8  */ (text *) "unused", (text *) "ODEFIN",
/*  9, 10 */ (text *) "unused", (text *) "ODSRBN",
/* 11, 12 */ (text *) "unused", (text *) "OFETCH/OFEN",
/* 13, 14 */ (text *) "unused", (text *) "OOPEN",
/* 15, 16 */ (text *) "unused", (text *) "OCLOSE",
/* 17, 18 */ (text *) "unused", (text *) "unused",
/* 19, 20 */ (text *) "unused", (text *) "unused",
/* 21, 22 */ (text *) "unused", (text *) "ODSC",
/* 23, 24 */ (text *) "unused", (text *) "ONAME",
/* 25, 26 */ (text *) "unused", (text *) "OSQL3",
/* 27, 28 */ (text *) "unused", (text *) "OBNDRV",
/* 29, 30 */ (text *) "unused", (text *) "OBNDRN",
/* 31, 32 */ (text *) "unused", (text *) "unused",
/* 33, 34 */ (text *) "unused", (text *) "OOPT",
/* 35, 36 */ (text *) "unused", (text *) "unused",
/* 37, 38 */ (text *) "unused", (text *) "unused",
/* 39, 40 */ (text *) "unused", (text *) "unused",
/* 41, 42 */ (text *) "unused", (text *) "unused",
/* 43, 44 */ (text *) "unused", (text *) "unused",
/* 45, 46 */ (text *) "unused", (text *) "unused",
/* 47, 48 */ (text *) "unused", (text *) "unused",
/* 49, 50 */ (text *) "unused", (text *) "unused",
/* 51, 52 */ (text *) "unused", (text *) "OCAN",
/* 53, 54 */ (text *) "unused", (text *) "OPARSE",
/* 55, 56 */ (text *) "unused", (text *) "OEXFET",
/* 57, 58 */ (text *) "unused", (text *) "OFLNG",
/* 59, 60 */ (text *) "unused", (text *) "ODESCR",
/* 61, 62 */ (text *) "unused", (text *) "OBNDRA"
};

/*
   ** PHP functions
 */

void php3_Ora_Logon(INTERNAL_FUNCTION_PARAMETERS)
{								/* userid, password */
	YYSTYPE *user, *pw;
	oraConnection *conn;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &user, &pw) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(user);
	convert_to_string(pw);

	conn = ora_get_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,ora_add_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU));

	if (conn == NULL || orlon(&conn->lda, conn->hda, user->value.strval, -1,
							  pw->value.strval, -1, 0)) {
		php3_error(E_WARNING, "Unable to connect to ORACLE (%s)",
					ora_error(&conn->lda));
		RETVAL_LONG(-1);
		if (conn != NULL) {
			ora_del_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,conn->ind);
		}
	} else {
		RETVAL_LONG(conn->ind);
	}
}


void php3_Ora_Logoff(INTERNAL_FUNCTION_PARAMETERS)
{								/* conn_index */
	int index;
	oraConnection *conn;
	YYSTYPE *arg;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	index = arg->value.lval;
	conn = ora_get_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,index);

	if (conn == NULL) {
		php3_error(E_WARNING, "No such connection id (%d)", index);
		RETURN_FALSE;
	}
	if (ologof(&conn->lda)) {
		RETVAL_LONG(-1);
		php3_error(E_WARNING, "Error logging off of connection %d",
					index);
	} else {
		RETVAL_LONG(0);
	}

	ora_del_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,index);
}


void php3_Ora_Open(INTERNAL_FUNCTION_PARAMETERS)
{								/* conn_index */
	YYSTYPE *arg;
	oraConnection *conn;
	oraCursor *cursor;
	int conn_ind;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	conn_ind = arg->value.lval;
	conn = ora_get_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,conn_ind);
	if (conn == NULL) {
		php3_error(E_WARNING, "Invalid connection index %d", conn_ind);
		RETURN_FALSE;
	}
	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,ora_add_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU));

	if (cursor == NULL ||
	oopen(&cursor->cda, &conn->lda, (text *) 0, -1, -1, (text *) 0, -1)) {
		php3_error(E_WARNING, "Unable to open new cursor (%s)",
					ora_error(&cursor->cda));
		if (cursor != NULL) {
			ora_del_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,cursor->ind);
		}
		RETVAL_LONG(-1);
	}
	RETVAL_LONG(cursor->ind);
}


void php3_Ora_Close(INTERNAL_FUNCTION_PARAMETERS)
{								/* conn_index */
	YYSTYPE *arg;
	oraCursor *cursor;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,arg->value.lval);

	if (cursor == NULL) {
		php3_error(E_WARNING, "Invalid cursor index %d", arg->value.lval);
		RETURN_FALSE;
	}
	if (oclose(&cursor->cda)) {
		php3_error(E_WARNING, "Unable to close cursor (%s)",
					ora_error(&cursor->cda));
		RETURN_FALSE;
	}
	ora_del_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,cursor->ind);
	RETVAL_LONG(0);
}


void php3_Ora_CommitOff(INTERNAL_FUNCTION_PARAMETERS)
{								/* conn_index */
	YYSTYPE *arg;
	oraConnection *conn;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	conn = ora_get_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,arg->value.lval);
	if (conn == NULL) {
		php3_error(E_WARNING, "Invalid connection index %d",
					arg->value.lval);
		RETURN_FALSE;
	}
	if (ocof(&conn->lda)) {
		php3_error(E_WARNING, "Unable to turn off auto-commit (%s)",
					ora_error(&conn->lda));
		RETURN_FALSE;
	}
	RETVAL_LONG(0);
}


void php3_Ora_CommitOn(INTERNAL_FUNCTION_PARAMETERS)
{								/* conn_index */
	YYSTYPE *arg;
	oraConnection *conn;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	conn = ora_get_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,arg->value.lval);
	if (conn == NULL) {
		php3_error(E_WARNING, "Invalid connection index %d",
					arg->value.lval);
		RETURN_FALSE;
	}
	if (ocon(&conn->lda)) {
		php3_error(E_WARNING, "Unable to turn on auto-commit (%s)",
					ora_error(&conn->lda));
		RETURN_FALSE;
	}
	RETVAL_LONG(0);
}


void php3_Ora_Commit(INTERNAL_FUNCTION_PARAMETERS)
{								/* conn_index */
	YYSTYPE *arg;
	oraConnection *conn;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	conn = ora_get_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,arg->value.lval);
	if (conn == NULL) {
		php3_error(E_WARNING, "Invalid connection index %d",
					arg->value.lval);
		RETURN_FALSE;
	}
	if (ocom(&conn->lda)) {
		php3_error(E_WARNING, "Unable to commit transaction (%s)",
					ora_error(&conn->lda));
		RETURN_FALSE;
	}
	RETVAL_LONG(0);
}


void php3_Ora_Rollback(INTERNAL_FUNCTION_PARAMETERS)
{								/* conn_index */
	YYSTYPE *arg;
	oraConnection *conn;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	conn = ora_get_conn(INTERNAL_FUNCTION_PARAM_PASSTHRU,arg->value.lval);
	if (conn == NULL) {
		php3_error(E_WARNING, "Invalid connection index %d",
					arg->value.lval);
		RETURN_FALSE;
	}
	if (orol(&conn->lda)) {
		php3_error(E_WARNING, "Unable to roll back transaction (%s)",
					ora_error(&conn->lda));
		RETURN_FALSE;
	}
	RETVAL_TRUE;
}


void php3_Ora_Parse(INTERNAL_FUNCTION_PARAMETERS)
{								/* cursor_ind, sql_statement [, defer] */
	int argc;
	YYSTYPE *argv[3];
	oraCursor *cursor;
	sword defer = 0;
	text *query;

	argc = ARG_COUNT(ht);
	if ((argc != 2 && argc != 3) || getParametersArray(ht, argc, argv) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(argv[0]);
	convert_to_string(argv[1]);

	if (argc == 3) {
		convert_to_long(argv[2]);
		if (argv[2]->value.lval != 0) {
			defer = DEFER_PARSE;
		}
	}
	/* XXX use pool 2 instead? */
	query = (text *) estrndup(argv[1]->value.strval,argv[1]->strlen);

	if (query == NULL) {
		php3_error(E_WARNING, "Invalid query");
		RETURN_FALSE;
	}
	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,argv[0]->value.lval);
	if (cursor == NULL) {
		php3_error(E_WARNING, "Invalid cursor index %d",
					argv[0]->value.lval);
		RETURN_FALSE;
	}
	if (cursor->current_query) {
		efree(cursor->current_query);
	}
	cursor->current_query = query;

	if (oparse(&cursor->cda, query, (sb4) - 1, defer, VERSION_7)) {
		php3_error(E_WARNING, "Ora_Parse failed (%s)",
					ora_error(&cursor->cda));
		RETURN_FALSE;
	}
	RETURN_TRUE;
}

/* Returns the number of SELECT-list items for a select, number of
   ** affected rows for UPDATE/INSERT/DELETE, 0 for another successful
   ** statement or -1 on error.
 */
void php3_Ora_Exec(INTERNAL_FUNCTION_PARAMETERS)
{								/* cursor_index */
	YYSTYPE *arg;
	oraCursor *cursor;
	int ncol = 0;
	ub2 sqlfunc;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,arg->value.lval);
	if (cursor == NULL) {
		php3_error(E_WARNING, "Invalid cursor index %d",
					arg->value.lval);
		RETURN_FALSE;
	}
	sqlfunc = cursor->cda.ft;
	if (sqlfunc == FT_SELECT) {
		ncol = ora_describe_define(cursor);
		if (ncol < 0) {
			/* error message is given by ora_describe_define() */
			RETURN_FALSE;
		}
	}
	if (oexec(&cursor->cda)) {
		php3_error(E_WARNING, "Ora_Exec failed (%s)",
					ora_error(&cursor->cda));
		RETURN_FALSE;
	}
	sqlfunc = cursor->cda.ft;
	if (sqlfunc == FT_SELECT) {
		RETVAL_LONG(ncol);
	} else {
		RETVAL_LONG(0);
	}
}


void php3_Ora_Fetch(INTERNAL_FUNCTION_PARAMETERS)
{								/* cursor_index */
	YYSTYPE *arg;
	oraCursor *cursor;
	sword err;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg);

	/* Find the cursor */
	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,arg->value.lval);
	if (cursor == NULL) {
		php3_error(E_WARNING, "Invalid cursor index %d", arg->value.lval);
		RETURN_FALSE;
	}
	/* Get data from Oracle */
	err = ofetch(&cursor->cda);
	if (err) {
		if (cursor->cda.rc == NO_DATA_FOUND) {
			RETURN_LONG(0);
		}
		php3_error(E_WARNING, "Ora_Fetch failed (%s)",
					ora_error(&cursor->cda));
		RETURN_FALSE;
	}
	cursor->curr_column = cursor->column_top;

	RETVAL_LONG(1);
}


void php3_Ora_GetColumn(INTERNAL_FUNCTION_PARAMETERS)
{								/* cursor_index, column_index */
	YYSTYPE *argv[2];
	int column_ind, cursor_ind;
	oraCursor *cursor;
	oraColumn *column;
	sb2 type;

	if (ARG_COUNT(ht) != 2 || getParametersArray(ht, 2, argv) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(argv[0]);
	/* don't convert the column index yet, it might be the column name */

	cursor_ind = argv[0]->value.lval;
	/* Find the cursor */
	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,cursor_ind);
	if (cursor == NULL) {
		php3_error(E_WARNING, "Invalid cursor index %d", cursor_ind);
		RETURN_FALSE;
	}
	if (argv[1]->type == IS_STRING) {
		column_ind = ora_find_column_index(cursor, argv[1]->value.strval);
		if (column_ind == -1) {
			php3_error(E_WARNING, "Unknown column \"%s\"",
						argv[1]->value.strval);
			RETURN_FALSE;
		}
	} else {
		convert_to_long(argv[1]);
		column_ind = argv[1]->value.lval;
	}


	column = cursor->columns[column_ind];

	if (column_ind < 0 || column_ind >= cursor->ncols) {
		php3_error(E_WARNING, "Invalid column index %d (max %d)",
					cursor_ind, cursor->ncols);
		RETURN_FALSE;
	}
	if (column == NULL) {
		php3_error(E_WARNING, "Empty column %d", cursor_ind);
		RETURN_FALSE;
	}
	type = column->dbtype;

	if (column->col_retcode != 0 && column->col_retcode != 1406) {
		/* So error fetching column.  The most common is 1405, a NULL */
		/* was retreived.  1406 is ASCII or string buffer data was */
		/* truncated. The converted data from the database did not fit */
		/* into the buffer.  Since we allocated the buffer to be large */
		/* enough, this should not occur.  Anyway, we probably want to */
		/* return what we did get, in that case */
		RETURN_FALSE;
	} else if (type == FLOAT_TYPE) {
		RETURN_DOUBLE(column->flt_buf);
	} else if (type == INT_TYPE) {
		RETURN_LONG(column->int_buf);
	} else if (type == STRING_TYPE || type == VARCHAR2_TYPE) {
		RETURN_STRINGL(column->buf, column->dsize);
	} else {
		php3_error(E_WARNING,
			   "Ora_GetColumn found invalid type (%d) in column %d",
					type, column_ind);
		RETURN_FALSE;
	}
}

void php3_Ora_Error(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *cursor_index;
	oraCursor *cursor;

	if (ARG_COUNT(ht) != 1 || getParametersArray(ht, 1, &cursor_index) ==
		FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(cursor_index);
	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,cursor_index->value.lval);
	if (!cursor) {
		php3_error(E_WARNING, "Ora_Error: could not find cursor");
		RETURN_FALSE;
	}

	return_value->type = IS_STRING;
	return_value->value.strval = ora_error(&cursor->cda);
	return_value->strlen = strlen(return_value->value.strval);
}


void php3_Ora_ErrorCode(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *cursor_index;
	oraCursor *cursor;

	if (ARG_COUNT(ht) != 1 || getParametersArray(ht, 1, &cursor_index) ==
		FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(cursor_index);
	cursor = ora_get_cursor(INTERNAL_FUNCTION_PARAM_PASSTHRU,cursor_index->value.lval);
	if (!cursor) {
		php3_error(E_WARNING, "Ora_Error: could not find cursor");
		RETURN_FALSE;
	}

	RETURN_LONG(cursor->cda.rc);
}


void php3_info_oracle()
{
	php3_printf("Oracle version: %s<br>\n"
			    "Compile-time ORACLE_HOME: %s<br>\n"
			    "Libraries used: %s",
			    PHP_ORACLE_VERSION, PHP_ORACLE_HOME, PHP_ORACLE_LIBS);
}


/*
** Functions internal to this module.
*/


static int
ora_add_conn(INTERNAL_FUNCTION_PARAMETERS)
{
	int i;
	oraConnection *conn;

	conn = emalloc(sizeof(oraConnection));

	i = php3_list_insert(conn, le_oraconn);
	conn->ind = i;

	return i;
}

static oraConnection *
ora_get_conn(INTERNAL_FUNCTION_PARAMETERS,int ind)
{
	oraConnection *conn;
	int type;

	conn = php3_list_find(ind, &type);
	if (!conn || type != le_oraconn) {
		return NULL;
	}
	return conn;
}

static void
ora_del_conn(INTERNAL_FUNCTION_PARAMETERS,int ind)
{
	/* XXX we don't check that this is really an oracle connection */
	php3_list_delete(ind);
}


int
ora_add_cursor(INTERNAL_FUNCTION_PARAMETERS)
{
	int i;
	oraCursor *cursor;

	cursor = emalloc(sizeof(oraCursor));

	i = php3_list_insert(cursor, le_oracur);
	cursor->ind = i;
	cursor->current_query = NULL;

	return i;
}


static oraCursor *
ora_get_cursor(INTERNAL_FUNCTION_PARAMETERS,int ind)
{
	oraCursor *cursor;
	int type;

	cursor = php3_list_find(ind, &type);
	if (!cursor || type != le_oracur) {
		return NULL;
	}
	return cursor;
}

static void ora_del_cursor(INTERNAL_FUNCTION_PARAMETERS,int ind)
{
	/* XXX we don't check that this is really an oracle cursor */
	php3_list_delete(ind);
}

static char *
ora_error(Cda_Def * cda)
{
	sword n, l;
	text *errmsg;

	errmsg = (text *) emalloc(512);
	n = oerhms(cda, cda->rc, errmsg, 400);

	/* remove the last newline */
	l = strlen(errmsg);
	if (l < 400 && errmsg[l - 1] == '\n') {
		errmsg[l - 1] = '\0';
		l--;
	}
	if (cda->fc > 0) {
		strncat(errmsg, " -- while processing OCI function ", 100);
		strcat(errmsg, ora_func_tab[cda->fc]);
	}
	return (char *) errmsg;
}


static sword
ora_describe_define(oraCursor * cursor)
{
	sword col = 0, len;
	int columns_left = 1, i;
	oraColumn *column, *last_column = NULL;
	ub1 *ptr;
	Cda_Def *cda = &cursor->cda;

	cursor->column_top = NULL;

	while (columns_left) {

		/* Allocate a column structure */
		column = (oraColumn *) emalloc(sizeof(oraColumn));
		if (column == NULL) {
			php3_error(E_ERROR, "Out of memory");
			return -1;
		}
		column->cbufl = ORANAMELEN;

		/* Fetch a select-list item description */
		if (odescr(cda, col + 1, &column->dbsize, &column->dbtype,
				   &column->cbuf[0], &column->cbufl, &column->dsize,
				   &column->prec, &column->scale, &column->nullok)) {
			if (cda->rc == VAR_NOT_IN_LIST) {
				columns_left = 0;
				break;
			} else {
				php3_error(E_WARNING, ora_error(cda));
				return -1;
			}
		}

		/* Determine the data type and length */
		if (column->dbtype == NUMBER_TYPE) {
			column->dbsize = ORANUMWIDTH;
			if (column->scale != 0) {
				/* Handle NUMBER with scale as float. */
				ptr = (ub1 *) & column->flt_buf;
				len = (sword) sizeof(float);
				column->dbtype = FLOAT_TYPE;
			} else {
				ptr = (ub1 *) & column->int_buf;
				len = (sword) sizeof(sword);
				column->dbtype = INT_TYPE;
			}
		} else {
			if (column->dbtype == DATE_TYPE) {
				column->dbsize = 10;
			} else if (column->dbtype == ROWID_TYPE) {
				column->dbsize = 18;
			}
			if (column->dbsize > ORABUFLEN) {
				column->dbsize = ORABUFLEN;
			}
			len = column->dbsize + 1;
			ptr = column->buf = (ub1 *) emalloc(len);
			if (ptr == NULL) {
				php3_error(E_ERROR, "Out of memory");
				return -1;
			}
			column->dbtype = STRING_TYPE;
		}

		/* Define an output variable for the select-list item */
		if (odefin(cda, col + 1, ptr, len, column->dbtype,
				   -1, &column->indp, (text *) 0, -1, -1,
				   &column->col_retlen, &column->col_retcode)) {
			php3_error(E_WARNING, ora_error(cda));
			return -1;
		}
		/* Chain this column into the cursor's column list */
		column->next = NULL;
		if (last_column == NULL) {
			cursor->column_top = column;
		} else {
			last_column->next = column;
		}
		last_column = column;

		col++;
	}

	/* Allocate an array of columns in the cursor for easy indexing. */
	if (col > 0) {
		oraColumn *tmpcol;

		cursor->columns = emalloc(sizeof(oraColumn *) * col);
		if (cursor->columns == NULL) {
			php3_error(E_ERROR, "Out of memory");
			return -1;
		}
		tmpcol = cursor->column_top;
		for (i = 0; i < col; i++) {
			cursor->columns[i] = tmpcol;
			tmpcol = tmpcol->next;
		}
	}
	cursor->ncols = col;
	return col;
}


static int ora_find_column_index(oraCursor *cursor, char *column_name)
{
	int i = 0, ret = -1;

	while (i < cursor->ncols) {
		if (!strncasecmp(cursor->columns[i]->cbuf, column_name, ORANAMELEN)) {
			ret = i;
			break;
		}
		i++;
	}

	return ret;
}

#else

void php3_Ora_Logon(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Logoff(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Open(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Close(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_CommitOff(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_CommitOn(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Commit(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Rollback(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Parse(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Exec(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Fetch(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_GetColumn(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_Error(INTERNAL_FUNCTION_PARAMETERS)
{
}
void php3_Ora_ErrorCode(INTERNAL_FUNCTION_PARAMETERS)
{
}

int php3_minit_oracle(INITFUNCARG)
{
	return FAILURE; /* should never be called if there is no Oracle support */
}

void php3_info_oracle(void)
{
}

#endif							/* HAVE_ORACLE */

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
