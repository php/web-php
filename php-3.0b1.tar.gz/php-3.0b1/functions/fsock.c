/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Paul Panotzki - Bunyip Information Systems                  |
   |          Jim Winstead (jimw@adventure.com)                           |
   +----------------------------------------------------------------------+
*/
/* $Id: fsock.c,v 1.37 1997/12/07 07:09:18 jaakko Exp $ */
#ifdef THREAD_SAFE
#include "tls.h"
#endif
#include "parser.h"
#include "list.h"
#include "internal_functions.h"
#include <stdlib.h>
#if HAVE_UNISTD_H
#include <unistd.h>
#endif
#include "fsock.h"

#include <sys/types.h>
#if HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif
#if MSVC5
#include <winsock.h>
#else
#include <netinet/in.h>
#include <netdb.h>
#endif
#if MSVC5
#undef AF_UNIX
#endif
#if defined(AF_UNIX)
#include <sys/un.h>
#endif

#include <string.h>
#include <errno.h>

#include "base64.h"
#include "file.h"
#include "post.h"
#include "url.h"

#ifndef MSVC5
#include "build-defs.h"
#endif

static int _php3_getftpresult(FILE *fpc);
#ifndef THREAD_SAFE
extern int le_fp;
#endif

/* FIXME: do something about the non-standard return codes from this function */
void php3_fsockopen(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	FILE *fp;
	int id, socketd;
	unsigned short portno;
#if MSVC5
	struct hostent FAR *hostp;
	struct hostent FAR * FAR PASCAL gethostbyname();
#else
	struct hostent *hostp;
#endif
	TLS_VARS;
	
	if (ARG_COUNT(ht)!=2 || getParameters(ht,2,&arg1,&arg2)==FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);
	convert_to_long(arg2);
	portno = (unsigned short) arg2->value.lval;

	if(portno) {
		struct sockaddr_in server;
		socketd = socket(AF_INET, SOCK_STREAM, 0);
		if(socketd < 0) {
			RETURN_LONG(-3); /* FIXME */
		}
  
		server.sin_family = AF_INET;
		hostp = gethostbyname(arg1->value.strval);
		if(hostp == 0) {
			RETURN_LONG(-4); /* FIXME */
		}
  
		memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
		server.sin_port = htons(portno);
  
		if(connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
			RETURN_LONG(-5); /* FIXME */
		}
#if defined(AF_UNIX)
	} else {
		/* Unix domain socket.  s->strval is socket name. */
		struct  sockaddr_un unix_addr;
		socketd = socket(AF_UNIX,SOCK_STREAM,0);
		if (socketd < 0) {
			RETURN_LONG(-3);  /* FIXME */
		}
	  
		memset(&unix_addr,(char)0,sizeof(unix_addr));
		unix_addr.sun_family = AF_UNIX;
		strcpy(unix_addr.sun_path, arg1->value.strval);

		if (connect(socketd, (struct sockaddr *) &unix_addr, sizeof(unix_addr)) < 0) {
			RETURN_LONG(-5);  /* FIXME */
		}
#endif /* AF_UNIX */
	}
	
	if ((fp = fdopen (socketd, "r+")) == NULL){
		RETURN_LONG(-6);  /* FIXME */
	}

#ifdef HAVE_SETVBUF  
	if ((setvbuf(fp, NULL, _IONBF, 0)) != 0){
		RETURN_LONG(-7);  /* FIXME */
	}
#endif
 
	id = php3_list_insert(fp,GLOBAL(le_fp));
	RETURN_LONG(id);
}

/*
 * If the specified path starts with "http://" (insensitive to case),
 * a socket is opened to the specified web server and a file pointer is
 * position at the start of the body of the response (past any headers).
 * This makes a HTTP/1.0 request, and knows how to pass on the username
 * and password for basic authentication.
 *
 * If the specified path starts with "ftp://" (insensitive to case),
 * a pair of sockets are used to request the specified file and a file
 * pointer to the requested file is returned. Passive mode ftp is used,
 * so if the server doesn't suppor this, it will fail!
 *
 * Otherwise, fopen is called as usual and the file pointer is returned.
 */

FILE *php3_fopen_url_wrapper(char *path, char *mode) {
	url *resource;
	int result;
	char *scratch, *tmp;

	char tmp_line[256];
	char *tpath, *ttpath;
	int body = 0;
	int reqok = 0;
	int lineone = 1;
	int i, ch = 0;

	char oldch1 = 0;
	char oldch2 = 0;
	char oldch3 = 0;
	char oldch4 = 0;
	char oldch5 = 0;
	
	FILE *fp;
	FILE *fpc;
	int socketd;
	struct sockaddr_in server;
	unsigned short portno;
#if MSVC5
	struct hostent FAR *hostp;
	struct hostent FAR *FAR PASCAL gethostbyname();
#else
	struct hostent *hostp;
#endif

	if (!strncasecmp(path,"http://",7)) {

		resource = url_parse(path);
		if (resource == NULL) {
			php3_error(E_WARNING, "invalid url specified, %s", path);
			return(NULL);
		}

		/* use port 80 if one wasn't specified */
		if (resource->port == 0) resource->port = 80;

		socketd = socket(AF_INET, SOCK_STREAM, 0);
		if (socketd < 0) {
			free_url(resource);
			return(NULL);
		}

		server.sin_family = AF_INET;
		hostp = gethostbyname(resource->host);
		if (hostp == 0) {
			free_url(resource);
			return(NULL);
		}

		memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
		server.sin_port = htons(resource->port);
 
		if (connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
			free_url(resource);
			return(NULL);
		}

		if ((fp = fdopen (socketd, "r+")) == NULL) {
			free_url(resource);
			return(NULL);
		}

#ifdef HAVE_SETVBUF  
		if ((setvbuf(fp, NULL, _IONBF, 0)) != 0) {
			free_url(resource);
			return(NULL);
		}
#endif

		/* tell remote http which file to get */
		fputs("GET ", fp);
		fputs(resource->path, fp);

		/* append the query string, if any */
		if (resource->query != NULL) {
			fputs ("?", fp);
			fputs (resource->query, fp);
		}
		fputs(" HTTP/1.0\n", fp);

		/* send authorization header if we have user/pass */
		if (resource->user != NULL && resource->pass != NULL) {
			scratch = (char *)emalloc(strlen(resource->user) + strlen(resource->pass) + 2);
			if (!scratch) {
				free_url(resource);
				return NULL;
			}

			strcpy(scratch, resource->user);
			strcat(scratch, ":");
			strcat(scratch, resource->pass);
			tmp = base64_encode(scratch);

			fputs("Authorization: Basic ", fp);
			/* output "user:pass" as base64-encoded string */
			fputs(tmp, fp);
			fputs("\n", fp);
			efree(scratch);
			efree(tmp);
		}

		/* if the user has configured who they are, send a From: line */
		if (cfg_get_string("from", &scratch) == SUCCESS) {
			fputs("From: ", fp);
			fputs(scratch, fp);
			fputs("\n", fp);
		}

		/* send a Host: header so name-based virtual hosts work */
		fputs("Host: ", fp);
		fputs(resource->host, fp);
		fputs("\n", fp);

		/* identify ourselves */
		fputs("User-Agent: PHP/", fp);
		fputs(PHP_VERSION, fp);
		fputs("\n", fp);

		/* end the headers */
		fputs("\n", fp);

		/* Read past http header */
		body = 0;
		while (!body && !feof(fp)) {
			ch = fgetc(fp);
			if (ch == EOF) {
				fclose(fp);
				free_url(resource);
				return(NULL);
			}
			oldch5 = oldch4;
			oldch4 = oldch3;
			oldch3 = oldch2;
			oldch2 = oldch1;
			oldch1 = ch;

			if (lineone && (ch == 10 || ch == 13)) {
				lineone=0;
			}
			if (lineone && oldch5 == ' ' && oldch4 == '2' && oldch3 == '0' &&
				oldch2 == '0' && oldch1 == ' ' ) {
				reqok=1;
			}
			if (oldch4 == 13 && oldch3 == 10 && oldch2 == 13 && oldch1 == 10) {
				body=1;
			}
			if (oldch2 == 10 && oldch1 == 10) {
				body=1;
			}
			if (oldch2 == 13 && oldch1 == 13) {
				body=1;
			}
		}
		if (!reqok) {
			fclose(fp);
			free_url(resource);
			return(NULL);
		}		
		free_url(resource);
		return(fp);
	}
	else if (!strncasecmp(path,"ftp://",6)) {
		resource = url_parse(path);
		if (resource == NULL) {
			php3_error(E_WARNING, "invalid url specified, %s", path);
			return(NULL);
		}

		/* use port 21 if one wasn't specified */
		if (resource->port == 0) resource->port = 21;

		socketd = socket(AF_INET, SOCK_STREAM, 0);
		if(socketd < 0) {
			free_url(resource);
			return(NULL);
		}

		server.sin_family = AF_INET;
		hostp = gethostbyname(resource->host);
		if (hostp == 0) {
			free_url(resource);
			return(NULL);
		}

		memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
		server.sin_port = htons(resource->port);
 
		if (connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
			free_url(resource);
			return(NULL);
		}

		if ((fpc = fdopen (socketd, "r+")) == NULL) {
			free_url(resource);
			return(NULL);
		}

#ifdef HAVE_SETVBUF  
		if ((setvbuf(fpc, NULL, _IONBF, 0)) != 0) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}
#endif

		/* Start talking to ftp server */
		result = _php3_getftpresult(fpc);
		if (result > 299 || result < 200) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		/* send the user name */
		fputs("USER ", fpc);
		if (resource->user != NULL) {
			_php3_urldecode(resource->user);
			fputs(resource->user, fpc);
		} else {
			fputs("anonymous", fpc);
		}
		fputs("\n", fpc);

		/* get the response */
		result = _php3_getftpresult(fpc);

		/* if a password is required, send it */
		if (result >= 300 && result <= 399) {
			fputs("PASS ", fpc);
			if (resource->pass != NULL) {
				_php3_urldecode(resource->pass);
				fputs(resource->pass, fpc);
			} else {
				/* if the user has configured who they are,
				   send that as the password */
				if (cfg_get_string("from", &scratch) == SUCCESS) {
					fputs(scratch, fpc);
				} else {
					fputs("anonymous", fpc);
				}
			}
			fputs("\n", fpc);

			/* read the response */
			result = _php3_getftpresult(fpc);
			if (result > 299 || result < 200) {
				free_url(resource);
				fclose(fpc);
				return(NULL);
			}
		}
		else if (result > 299 || result < 200) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}


		/* find out the size of the file (verifying it exists) */
		fputs("SIZE ", fpc);
		fputs(resource->path, fpc);
		fputs("\n", fpc);

		/* read the response */
		result = _php3_getftpresult(fpc);
		if (result > 299 || result < 200) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		/* set the connection to be binary */
		fputs("TYPE I\n", fpc);
		result = _php3_getftpresult(fpc);
		if (result > 299 || result < 200) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		/* set up the passive connection */
		fputs("PASV\n", fpc);
		while (fgets(tmp_line, 256, fpc) != NULL && 
			   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
				 isdigit(tmp_line[2]) && tmp_line[3] == ' '));

		/* make sure we got a 227 response */
		if (strncmp(tmp_line, "227", 3)) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		/* parse pasv command (129,80,95,25,13,221) */
		tpath = tmp_line;

		/* skip over the "227 Some message " part */
		for (tpath += 4; *tpath && !isdigit(*tpath); tpath++);
		if (!*tpath) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		/* skip over the host ip, we just assume it's the same */
		for (i = 0; i < 4; i++) {
			for (; isdigit(*tpath); tpath++);
			if (*tpath == ',') {
				tpath++;
			} else {
				return(NULL);
			}
		}

		/* pull out the MSB of the port */
		portno = (unsigned short)strtol(tpath, &ttpath, 10) * 256;
		if (ttpath == NULL) {
			/* didn't get correct response from PASV */
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}
		tpath = ttpath;
		if (*tpath == ',') {
			tpath++;
		} else {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		/* pull out the LSB of the port */
		portno += (unsigned short)strtol(tpath, &ttpath, 10);

		if (ttpath == NULL) {
			/* didn't get correct response from PASV */
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		/* finally, send a message to start retrieving the file, and
		   close the command connection */
		fputs("RETR ", fpc);
		fputs(resource->path, fpc);
		fputs("\nQUIT\n", fpc);
		fclose(fpc);

		/* open the data channel */
		socketd = socket(AF_INET, SOCK_STREAM, 0);
		if (socketd < 0) {
			free_url(resource);
			return(NULL);
		}

		server.sin_family = AF_INET;
		hostp = gethostbyname(resource->host);
		if (hostp == 0) {
			free_url(resource);
			fclose(fpc);
			return(NULL);
		}

		memcpy(&server.sin_addr, hostp->h_addr, hostp->h_length);
		server.sin_port = htons(portno);
 
		if(connect(socketd, (struct sockaddr *)&server, sizeof(server)) < 0) {
			free_url(resource);
			return(NULL);
		}


		if ((fp = fdopen (socketd, "r+")) == NULL) {
			free_url(resource);
			return(NULL);
		}

#ifdef HAVE_SETVBUF  
		if ((setvbuf(fp, NULL, _IONBF, 0)) != 0) {
			free_url(resource);
			fclose(fp);
			return(NULL);
		}
#endif

		free_url(resource);
		return(fp);

	} else {
		fp = php3_fopen_with_path(path, mode, php3_ini.include_path);
		return(fp); 
	}
	/* Should never get here. */
	return(NULL);
}

static int _php3_getftpresult(FILE *fpc) {
	char tmp_line[256];

	while (fgets(tmp_line, 256, fpc) != NULL && 
		   !(isdigit(tmp_line[0]) && isdigit(tmp_line[1]) &&
			 isdigit(tmp_line[2]) && tmp_line[3] == ' '));

	return strtol(tmp_line, NULL, 10);
}

int php3_isurl(char *path) 
{
	return(!strncasecmp(path,"http://",7) || !strncasecmp(path,"ftp://",6));
}

char *php3_strip_url_passwd(char *path) 
{
	char *tmppath=NULL;
	if(!strncasecmp(path,"ftp://",6)) {
		tmppath=path; 
		tmppath+=6;
		for(;*tmppath!=':' && *tmppath!='\0' ; tmppath++ );
		tmppath++ ;
		for(;*tmppath!='@' && *tmppath!='\0' ; tmppath++ ) 
			*tmppath='*';
	}
	return(path);
}

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
