#ifndef _TYPE_H
#define _TYPE_H

extern int php3_CheckType(char *str);
extern int php3_CheckIdentType(char *str);
extern char *php3_GetIdentIndex(char *str);

#endif
