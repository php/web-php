#if PHP_DEBUGGER
extern php3_module_entry debugger_module_entry;
#define debugger_module_ptr &debugger_module_entry
#else
#define debugger_module_ptr NULL
#endif