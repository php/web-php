/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors:                                                             |
   |                                                                      |
   +----------------------------------------------------------------------+
 */
/* $Id: mod_php3.h,v 1.16 1997/11/30 05:31:30 shane Exp $ */

#ifndef _MOD_PHP3_H
#define _MOD_PHP3_H

#if !defined(WIN32) && !defined(WINNT)
#ifndef MODULE_VAR_EXPORT
#define MODULE_VAR_EXPORT
#endif
#endif

typedef struct {
    char *smtp;
	char *sendmailpath;
    long errors;
    long magic_quotes_gpc;
    long magic_quotes_runtime;
    long track_errors;
    char *docroot;
    char *userdir;
    long safemode;
    long track_vars;
    char *safemodeexecdir;
    char *cgiext;
    char *isapiext;
    char *nsapiext;
    char *includepath;
    char *autoprependfile;
    char *autoappendfile;
    char *uploadtmpdir;
    char *dldir;
    long  short_open_tag;
    char *debughost;
    long  debugport;
    char *highlight_comment;
    char *highlight_default;
    char *highlight_html;
    char *highlight_string;
    char *highlight_bg;
    char *highlight_keyword;
    long sql_safe_mode;
	long xbithack;
	long engine;
	long lastmodified;
} php3_ini_structure;

#if MSVC5
#define S_IXUSR _S_IEXEC
#endif

#endif							/* _MOD_PHP3_H */
