/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
 */
/* $Id: file.c,v 1.90 1997/12/03 00:35:07 zeev Exp $ */
#include "parser.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#if MSVC5
#define O_RDONLY _O_RDONLY
#include "win32/param.h"
#else
#include <sys/param.h>
#endif
#include "head.h"
#include "internal_functions.h"
#include "safe_mode.h"
#include "list.h"
#include "php3_string.h"
#include "file.h"
#if HAVE_PWD_H
#if MSVC5
#include "win32/pwd.h"
#else
#include <pwd.h>
#endif
#endif

static int fgetss_state = 0;
int le_fp,le_pp;


function_entry php3_file_functions[] = {
	{"pclose",		php3_pclose,	NULL},
	{"popen",		php3_popen,		NULL},
	{"readfile",	php3_readfile,	NULL},
	{"rewind",		php3_rewind,	NULL},
	{"rmdir",		php3_rmdir,		NULL},
	{"umask",		php3_fileumask,	NULL},
	{"fclose",		php3_fclose,	NULL},
	{"feof",		php3_feof,		NULL},
	{"fgets",		php3_fgets,		NULL},
	{"fgetss",		php3_fgetss,	NULL},
	{"fopen",		php3_fopen,		NULL},
	{"fpassthru",	php3_fpassthru,	NULL},
	{"fseek",		php3_fseek,		NULL},
	{"ftell",		php3_ftell,		NULL},
	{"fputs",		php3_fputs,		NULL},
	{"mkdir",		php3_mkdir,		NULL},
	{"rename",		php3_rename,	NULL},
	{"copy",		php3_file_copy,	NULL},
	{"tempnam",		php3_tempnam,	NULL},
	{"file",		php3_file,		NULL},
	{NULL, NULL, NULL}
};

php3_module_entry php3_file_module_entry = {
	"PHP_file", php3_file_functions, php3_minit_file, NULL, NULL, NULL, NULL, 0, 0, 0, NULL
};

/* lots more stuff needs to go in here.  Trivial case for now */
FILE *php3_OpenFile(char *filename)
{
	FILE *fp = NULL;
	char *fn;

#if (!APACHE)
	char *temp = NULL;
#if CGI_BINARY
	int l;
#endif
#if HAVE_PWD_H
	char *s, user[32];
	struct passwd *pw = NULL;
#endif
#endif

	fn = filename;

#if CGI_BINARY
/* CGI is the only case where we're never not given a filename and
   we have to build it from the path_info and the DOCUMENT_ROOT */
	if (!fn) {
		fn = request_info.path_info;
		if (fn) {
			request_info.filename = estrdup(fn);
#if HAVE_PWD_H
			if (*(fn + 1) == '~') {
				s = strchr(fn + 1, '/');
				if (s) {
					*s = '\0';
				}
				strcpy(user, fn + 2);	/* This strcpy is safe, path size is known */
				if (s) {
					*s = '/';
				}
				l = strlen(php3_ini.userdir);
				if (user) {
					pw = getpwnam(user);
					if (pw) {
						temp = emalloc(l + strlen(fn) + strlen(PHP_USER_DIR) + strlen(pw->pw_dir) + 4);
						strcpy(temp, pw->pw_dir);
						strcat(temp, "/");
						strcat(temp, php3_ini.userdir);
						strcat(temp, "/");
						if (s) {
							strcat(temp, s);
						}
						STR_FREE(request_info.filename);
						request_info.filename = fn = temp;
					}
				}
			} else {
#endif
				l = strlen(php3_ini.docroot);
				temp = emalloc(l + strlen(fn) + 2);
				if (temp) {
					strcpy(temp, php3_ini.docroot);
					if ((php3_ini.docroot[l - 1] != '/') && (fn[0] != '/')) {
						strcat(temp, "/");
					}
					strcat(temp, fn);
					STR_FREE(request_info.filename);
					request_info.filename = fn = temp;
				}
#if HAVE_PWD_H
			}
#endif
		}
	}
#endif

	if (!fn) {
		php3_error(E_WARNING, "fn is empty");
		/* we have to free request_info.filename here because
		   php3_destroy_request_info assumes that it will get
		   freed when the include_names hash is emptied, but
		   we're not adding it in this case */
		STR_FREE(request_info.filename);
		return NULL;
	}
	fp = fopen(fn, "r");
	if (!fp) {
		STR_FREE(request_info.filename); /* for same reason as above */
		php3_error(E_ERROR, "Unable to open %s", fn);
	} else {
		hash_index_update(&include_names, 0, (void *) &fn, sizeof(char *),NULL);
	}

#if CGI_BINARY
	temp=strdup(fn);
	_php3_dirname(temp);
	if(strlen(temp)) chdir(temp);
	free(temp);
#endif

	return fp;
}

void php3_file(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *filename;
	FILE *fp;
	char *slashed, buf[8192];
	register int i=0;

	/* check args */
	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &filename) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(filename);

	/* safe mode check */
	if(php3_ini.safemode &&(!_php3_checkuid(filename->value.strval,1))) {
		php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner of file to be read.");
		RETURN_FALSE;
	}

	/* URL support */
	fp = php3_fopen_url_wrapper(filename->value.strval,"r");
	if(!fp) {
		php3_strip_url_passwd(filename->value.strval);
		php3_error(E_WARNING,"File(\"%s\") - %s",filename->value.strval,strerror(errno));
		RETURN_FALSE;
	}

	/* Initialize return array */
	if(array_init(return_value) == FAILURE) {
		RETURN_FALSE;
	}	

	/* Now loop through the file and do the magic quotes thing if needed */
	while(fgets(buf,8191,fp)) {
		if(php3_ini.magic_quotes_runtime) {
			slashed = _php3_addslashes(buf,0); /* 0 = don't free source string */
            add_index_string(return_value, i++,slashed);
			efree(slashed);
		} else {
			add_index_string(return_value, i++,buf);
		}
	}
	fclose(fp);
}

static int pclose_ret;

static void __pclose(FILE *pipe)
{
	pclose_ret = pclose(pipe);
}

int php3_minit_file(INITFUNCARG)
{
	le_fp = register_list_destructors(fclose,NULL);
	le_pp = register_list_destructors(__pclose,NULL);
	return SUCCESS;
}


void php3_tempnam(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	char *d;
	char *t;
	char p[64];

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);
	convert_to_string(arg2);
	d = estrndup(arg1->value.strval,arg1->strlen);
	strncpy(p,arg2->value.strval,sizeof(p));

	t = tempnam(d,p);
	efree(d);
	RETURN_STRING(t);
}

void php3_fopen(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	FILE *fp;
	int id;
	char *p;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);
	convert_to_string(arg2);
	p = estrndup(arg2->value.strval,arg2->strlen);

	if(php3_ini.safemode &&(!_php3_checkuid(arg1->value.strval,2))) {
		php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner of file to be opened.");
		RETURN_FALSE;
	}

	/* CAVEAT
	 *
	 * Does not handle HTTP redirects, so trailing slashes must be
	 * used on directories (also on "site roots" like
	 * "http://php.iquest.net/")
	 *
	 * We need a better way of returning error messages from
	 * php3_fopen_url_wrapper().
	 *
	 */
	fp = php3_fopen_url_wrapper(arg1->value.strval, p);
	if (!fp) {
		php3_strip_url_passwd(arg1->value.strval);
		php3_error(E_WARNING,"fopen(\"%s\",\"%s\") - %s",
					arg1->value.strval, p, strerror(errno));
		efree(p);
		RETURN_FALSE;
	}
	fgetss_state=0;
	id = php3_list_insert(fp,le_fp);
	efree(p);
	RETURN_LONG(id);
}	

void php3_fclose(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	int id, type;
	FILE *fp;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	id=arg1->value.lval;
	fp = php3_list_find(id,&type);
	if(!fp || type!=le_fp) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		RETURN_FALSE;
	}
	php3_list_delete(id);
	RETURN_TRUE;
}

void php3_popen(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	FILE *fp;
	int id;
	char *p;
	char *b, buf[1024];

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);
	convert_to_string(arg2);
	p = estrndup(arg2->value.strval,arg2->strlen);
	if (php3_ini.safemode){
	b = strrchr(arg1->value.strval,'/');
	if(b) {
		sprintf(buf,"%s%s",php3_ini.safemodeexecdir,b);
	} else {
		sprintf(buf,"%s/%s",php3_ini.safemodeexecdir,arg1->value.strval);
	}
	fp = popen(buf,p);
	if(!fp) {
		php3_error(E_WARNING,"popen(\"%s\",\"%s\") - %s",buf,p,strerror(errno));
		RETURN_FALSE;
	}
	}else{
	fp = popen(arg1->value.strval,p);
	if(!fp) {
		php3_error(E_WARNING,"popen(\"%s\",\"%s\") - %s",arg1->value.strval,p,strerror(errno));
		efree(p);
		RETURN_FALSE;
	}
	}
/* #endif */
	id = php3_list_insert(fp,le_pp);
	efree(p);
	RETURN_LONG(id);
}

void php3_pclose(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	int id,type;
	FILE *fp;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	id = arg1->value.lval;

	fp = php3_list_find(id,&type);
	if(!fp || type!=le_pp) {
		php3_error(E_WARNING,"Unable to find pipe identifier %d",id);
		RETURN_FALSE;
	}
	php3_list_delete(id);
	RETURN_LONG(pclose_ret);
}

void php3_feof(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	FILE *fp;
	int id, type;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	id = arg1->value.lval;
	fp = php3_list_find(id,&type);
	if(!fp || (type!=le_fp && type!=le_pp)) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		/* we're at the eof if the file doesn't exist */
		RETURN_TRUE;
	}
	if(feof(fp)) {
		RETURN_TRUE;
	} else {
		RETURN_FALSE;
	}
}

void php3_fgets(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	FILE *fp;
	int id, len, type;
	char *buf;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	convert_to_long(arg2);
	id = arg1->value.lval;
	len = arg2->value.lval;

	fp = php3_list_find(id,&type);
	if(!fp || (type!=le_fp && type!=le_pp)) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		RETURN_FALSE;
	}
	buf = emalloc(sizeof(char) * (len + 1));
	if(!fgets(buf,len,fp)) {
		efree(buf);
		RETVAL_FALSE;
	} else {
		if(php3_ini.magic_quotes_runtime) {
			return_value->value.strval = _php3_addslashes(buf,1);
		} else {
			return_value->value.strval = buf;
		}
		return_value->strlen = strlen(return_value->value.strval);
		return_value->type = IS_STRING;
	}
	return;
}


/* Strip any HTML tags while reading */
void php3_fgetss(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *fd, *bytes;
	FILE *fp;
	int id, len, br, type;
	char *buf, *p, *rbuf, *rp, c, lc;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &fd, &bytes) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(fd);
	convert_to_long(bytes);

	id = fd->value.lval;
	len = bytes->value.lval;

	fp = php3_list_find(id, &type);
	if (!fp || (type != le_fp && type != le_pp)) {
		php3_error(E_WARNING, "Unable to find file identifier %d", id);
		RETURN_FALSE;
	}

	buf = emalloc(sizeof(char) * (len + 1));

	if (!fgets(buf, len, fp)) {
		efree(buf);
		RETURN_FALSE;
	}

	rbuf = estrdup(buf);
	c = *buf;
	lc = '\0';
	p = buf;
	rp = rbuf;
	br = 0;

	while (c) {
		switch (c) {
			case '<':
				if (fgetss_state == 0) {
					lc = '<';
					fgetss_state = 1;
				}
				break;

			case '(':
				if (fgetss_state == 2) {
					if (lc != '\"') {
						lc = '(';
						br++;
					}
				} else if(fgetss_state == 0) {
					*(rp++) = c;
				}
				break;	

			case ')':
				if (fgetss_state == 2) {
					if (lc != '\"') {
						lc = ')';
						br--;
					}
				} else if(fgetss_state == 0) {
					*(rp++) = c;
				}
				break;	

			case '>':
				if (fgetss_state == 1) {
					lc = '>';
					fgetss_state = 0;
				} else if (fgetss_state == 2) {
					if (!br && lc != '\"') {
						fgetss_state = 0;
					}
				}
				break;

			case '\"':
				if (fgetss_state == 2) {
					if (lc == '\"') {
						lc = '\0';
					} else if (lc != '\\') {
						lc = '\"';
					}
				} else if (fgetss_state == 0) {
					*(rp++) = c;
				}
				break;

			case '?':
				if(fgetss_state==1) {
					br=0;
					fgetss_state=2;
					break;
				}
				/* fall-through */

			default:
				if (fgetss_state == 0) {
					*(rp++) = c;
				}	
		}
		c = *(++p);
	}	
	*rp = '\0';
	efree(buf);
	RETVAL_STRING(rbuf);
	efree(rbuf);
}


void php3_fputs(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	FILE *fp;
	int ret,id,type;
	char *buf;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	convert_to_string(arg2);
	buf = estrndup(arg2->value.strval,arg2->strlen);
	id = arg1->value.lval;	

	fp = php3_list_find(id,&type);
	if(!fp || (type!=le_fp && type!=le_pp)) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		RETURN_FALSE;
	}

	if (php3_ini.magic_quotes_runtime) {
		_php3_stripslashes(buf);
	}
	
	ret = fputs(buf,fp);
	efree(buf);
	RETURN_LONG(ret);
}	

void php3_rewind(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	int id,type;
	FILE *fp;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	id = arg1->value.lval;	
	fp = php3_list_find(id,&type);
	if(!fp || (type!=le_fp && type!=le_pp)) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		RETURN_FALSE;
	}
	rewind(fp);
	RETURN_TRUE;
}

void php3_ftell(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	int id, type;
	long pos;
	FILE *fp;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	id = arg1->value.lval;	
	fp = php3_list_find(id,&type);
	if(!fp || (type!=le_fp && type!=le_pp)) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		RETURN_FALSE;
	}
	pos = ftell(fp);
	RETURN_LONG(pos);
}

void php3_fseek(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	int ret,id,type;
	long pos;
	FILE *fp;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	convert_to_long(arg2);
	pos = arg2->value.lval;
	id = arg1->value.lval;
	fp = php3_list_find(id,&type);
	if(!fp || (type!=le_fp && type!=le_pp)) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		RETURN_FALSE;
	}
/*fseek is flaky on windows, use setfilepointer*/
#if WIN32|WINNT
	ret = SetFilePointer (fp, pos, NULL, FILE_BEGIN);
	if (ret != 0xFFFFFFF){ret = 0;} /*success*/
#else
 	ret = fseek(fp,pos,SEEK_SET);
#endif
	RETURN_LONG(ret);
}

void php3_mkdir(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1, *arg2;
	int ret,mode;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);
	convert_to_long(arg2);
	mode = arg2->value.lval;
	if(php3_ini.safemode &&(!_php3_checkuid(arg1->value.strval,3))) {
		php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner of parent directory.");
		RETURN_FALSE;
	}
	ret = mkdir(arg1->value.strval,mode);
	if (ret < 0) {
		php3_error(E_WARNING,"MkDir failed (%s)", strerror(errno));
		RETURN_FALSE;
	}
	RETURN_TRUE;
}	

void php3_rmdir(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	int ret;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);
	if(php3_ini.safemode &&(!_php3_checkuid(arg1->value.strval,1))) {
		php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner of directory to be removed.");
		RETURN_FALSE;
	}
	ret = rmdir(arg1->value.strval);
	if (ret < 0) {
		php3_error(E_WARNING,"RmDir failed (%s)", strerror(errno));
		RETURN_FALSE;
	}
	RETURN_TRUE;
}	

#if 0
void PHPFile(void) {
	Stack *s;
	FILE *fp;
	char buf[8192];
	VarTree *var;
	int l,t;

	s = Pop();
	if(!s) {
		Error("Stack error in file");
		return;
	}
	if(!*(s->strval)) {
		Push("-1",LNUMBER);
		return;
	}

	if(php3_ini.safemode &&(!CheckUid(s->strval,1))) {
		Error("SAFE MODE Restriction in effect.  Invalid owner of file to be read.");
		Push("-1",LNUMBER);
		return;
	}
		
	fp = fopen(s->strval,"r");
	if(!fp) {
		Error("file(\"%s\") - %s",s->strval,strerror(errno));
		Push("-1",LNUMBER);
		return;
	}
	var = GetVar("__filetmp__",NULL,0);
	if(var) deletearray(var);
	while(fgets(buf,8191,fp)) {
#if DEBUG
		Debug("File() read line \"%s\"\n",buf);
#endif
		l = strlen(buf);
		t = l;
		while(l>0 && isspace(buf[--l])); 
		if(l<t) buf[l+1]='\0';	
		Push(AddSlashes(buf,0),STRING);
		SetVar("__filetmp__",1,0);
	}
	Push("__filetmp__",VAR);
	fclose(fp);
}	
#endif

/*
 * Read a file and write the ouput to stdout
 */
void php3_readfile(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	char buf[8192];
	FILE *fp;
	int b,i, size;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(arg1);	
	if(php3_ini.safemode &&(!_php3_checkuid(arg1->value.strval,1))) {
		php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner of file to be read.");
		RETURN_FALSE;
	}
	/* CAVEAT
	 *
	 * Does not handle HTTP redirects, so trailing slashes must be
	 * used on directories (also on "site roots" like
	 * "http://php.iquest.net/")
	 *
	 * We need a better way of returning error messages from
	 * php3_fopen_url_wrapper().
	 *
	 */
	fp = php3_fopen_url_wrapper(arg1->value.strval,"r");
	if(!fp) {
		php3_strip_url_passwd(arg1->value.strval);
		php3_error(E_WARNING,"ReadFile(\"%s\") - %s",arg1->value.strval,strerror(errno));
		RETURN_FALSE;
	}
	size= 0;
	if(php3_header(0,NULL)) {  /* force header if not already sent */
		while((b = fread(buf, 1, sizeof(buf), fp)) > 0) {
			for(i = 0; i < b; i++)
				PUTC(buf [i]);
			size += b ;
		}
	}
	fclose(fp);
	RETURN_LONG(size);
}

/*
 * Return or change the umask.
 */
void php3_fileumask(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	int oldumask;
	int arg_count = ARG_COUNT(ht);

	oldumask = umask(077);

	if(arg_count == 0) {
		umask(oldumask);
	}
	else {
		if (arg_count > 1 || getParameters(ht, 1, &arg1) == FAILURE) {
			WRONG_PARAM_COUNT;
		}
		convert_to_long(arg1);
		umask(arg1->value.lval);
	}
	RETURN_LONG(oldumask);
}

/*
 * Read to EOF on a file descriptor and write the output to stdout.
 */
void php3_fpassthru(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *arg1;
	FILE *fp;
	char buf[8192];
	int id, size, b, i, type;

	if (ARG_COUNT(ht) != 1 || getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	id = arg1->value.lval;
	fp = php3_list_find(id,&type);
	if (!fp || (type!=le_fp && type!=le_pp)) {
		php3_error(E_WARNING,"Unable to find file identifier %d",id);
		RETURN_FALSE;
	}
	size = 0;
	if(php3_header(0,NULL)) { /* force headers if not already sent */
		while((b = fread(buf, 1, sizeof(buf), fp)) > 0) {
			for(i = 0; i < b; i++)
				PUTC(buf [i]);
			size += b ;
		}
	}
	fclose(fp);
	php3_list_delete(id);
	RETURN_LONG(size);
}


void php3_rename(INTERNAL_FUNCTION_PARAMETERS) {
	YYSTYPE *OLD, *NEW;
	char *old, *new;
	int ret;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &OLD, &NEW) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_string(OLD);
	convert_to_string(NEW);

	old = OLD->value.strval;
	new = NEW->value.strval;

	if (php3_ini.safemode &&(!_php3_checkuid(old,2))) {
		php3_error(E_WARNING,
					"SAFE MODE Restriction in effect.  "
					"Invalid owner of file to be renamed.");
		RETURN_FALSE;
	}
	ret = rename(old, new);

	if (ret == -1) {
		php3_error(E_WARNING,
					"Rename failed (%s)", strerror(errno));
		RETURN_FALSE;
	}

	RETVAL_TRUE;
}


void php3_file_copy(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *source, *target;
	char buffer[8192];
	int fd_s,fd_t,read_bytes;

	if (ARG_COUNT(ht) != 2 || getParameters(ht, 2, &source, &target) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_string(source);
	convert_to_string(target);

	if (php3_ini.safemode &&(!_php3_checkuid(source->value.strval,2))) {
		php3_error(E_WARNING,
					"SAFE MODE Restriction in effect.  "
					"Invalid owner of file to be renamed.");
		RETURN_FALSE;
	}
	
	if ((fd_s=open(source->value.strval,O_RDONLY))==-1) {
		php3_error(E_WARNING,"Unable to open '%s' for reading:  %s",source->value.strval,strerror(errno));
		RETURN_FALSE;
	}
	if ((fd_t=creat(target->value.strval,0777))==-1) {
		php3_error(E_WARNING,"Unable to create '%s':  %s", target->value.strval,strerror(errno));
		close(fd_s);
		RETURN_FALSE;
	}

	while ((read_bytes=read(fd_s,buffer,8192))!=-1 && read_bytes!=0) {
		if (write(fd_t,buffer,read_bytes)==-1) {
			php3_error(E_WARNING,"Unable to write to '%s':  %s",target->value.strval,strerror(errno));
			close(fd_s);
			close(fd_t);
			RETURN_FALSE;
		}
	}
	
	close(fd_s);
	close(fd_t);

	RETVAL_TRUE;
}
/*
 * Tries to open a file with a PATH-style list of directories.
 * If the filename starts with "." or "/", the path is ignored.
 */
FILE *php3_fopen_with_path(char *filename, char *mode, char *path)
{
	char *pathbuf, *ptr, *end;
	char trypath[MAXPATHLEN + 1];
	struct stat sb;
	FILE *fp;

	/* Relative path open */
	if (*filename == '.') {
		if(php3_ini.safemode &&(!_php3_checkuid(filename,2))) {
			php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner.");
			return(NULL);
		}
		return fopen(filename, mode);
	}

	/* Absolute path open - prepend document_root in safe mode */
#if WIN32|WINNT
	if ((*filename == '\\')||(*filename == '/')||(filename[1] == ':')) {
#else
	if (*filename == '/') {
#endif
		if(php3_ini.safemode) {
			strcpy(trypath,php3_ini.docroot);
			strcat(trypath,filename);
			if(!_php3_checkuid(trypath,2)) {
				php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner.");
				return(NULL);
			}
			return fopen(trypath, mode);
		} else {
			return fopen(filename, mode);
		}
	}

	if(!path || (path && !*path)) {
		if(php3_ini.safemode &&(!_php3_checkuid(filename,2))) {
			php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner.");
			return(NULL);
		}
		return fopen(filename, mode);
	}

	pathbuf = estrdup(path);

	ptr = pathbuf;

	while (ptr && *ptr) {
#if WIN32|WINNT
		end = strchr(ptr, ';');
#else
		end = strchr(ptr, ':');
#endif
		if (end != NULL) {
			*end = '\0';
			end++;
		}
		snprintf(trypath, MAXPATHLEN, "%s/%s", ptr, filename);
		if(php3_ini.safemode) {
			if(stat(trypath,&sb) == 0 &&(!_php3_checkuid(trypath,2))) {
				php3_error(E_WARNING,"SAFE MODE Restriction in effect.  Invalid owner.");
				return(NULL);
			}
		}
		if ((fp = fopen(trypath, mode)) != NULL) {
			efree(pathbuf);
			return fp;
		}
		ptr = end;
	}
	efree(pathbuf);
	return NULL;
}


/*
 * Local variables:
 * tab-width: 4
 * End:
 */
