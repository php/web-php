/* $Id: post.h,v 1.14 1997/12/02 01:04:17 shane Exp $ */

#ifndef _POST_H
#define _POST_H

#define PARSE_POST 0
#define PARSE_GET 1
#define PARSE_COOKIE 2
#define PARSE_STRING 3

extern void php3_TreatData(int arg, char *str);
extern void php3_TreatHeaders(void);
extern void _php3_parse_gpc_data(char *, char *, YYSTYPE *track_vars_array);

extern int php3_track_vars;

extern void php3_parsestr(INTERNAL_FUNCTION_PARAMETERS);

#endif
