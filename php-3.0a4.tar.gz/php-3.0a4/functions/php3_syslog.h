#if HAVE_SYSLOG
extern php3_module_entry syslog_module_entry;
#define syslog_module_ptr &syslog_module_entry

#else
#define syslog_module_ptr NULL
#endif