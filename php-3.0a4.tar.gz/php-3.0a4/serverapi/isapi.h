#ifndef CHAR /* avoid language-parser conflicts */
#include <httpext.h>
extern LPEXTENSION_CONTROL_BLOCK lpPHPcb;
extern char *isapi_getenv(LPEXTENSION_CONTROL_BLOCK,char *);    
/* these need to be done */
#define BLOCK_INTERRUPTIONS
#define UNBLOCK_INTERRUPTIONS
#endif

extern void isapi_puts(char *string); /* located in isapi.c */
extern void isapi_putc(char character);
#define PUTS(a) isapi_puts(a)
#define PUTC(a) isapi_putc(a)
#define PHPWRITE(a,n) lpPHPcb->WriteClient(lpPHPcb->ConnID,(a),&n,0)
#define WIN32_SERVER_MOD 1
