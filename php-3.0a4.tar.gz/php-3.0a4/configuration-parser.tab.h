#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	STRING	258
#define	TRUE	259
#define	FALSE	260
#define	EXTENSION	261

