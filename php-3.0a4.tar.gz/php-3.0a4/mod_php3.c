/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   | (with helpful hints from Dean Gaudet <dgaudet@arctic.org>            |
   +----------------------------------------------------------------------+
 */
/* $Id: mod_php3.c,v 1.41 1997/12/02 14:03:51 ssb Exp $ */

#include "httpd.h"
#include "http_config.h"
#include "http_core.h"
#include "http_main.h"
#include "http_protocol.h"
#include "http_request.h"
#include "http_log.h"
#include "util_script.h"
#include "mod_php3.h"

module MODULE_VAR_EXPORT php3_module;
int saved_umask;

extern php3_ini_structure php3_ini;  /* active config */
extern php3_ini_structure php3_ini_master;  /* master copy of config */

extern int apache_php3_module_main(request_rec * r, int fd, int display_source_mode);
extern int php3_module_startup();
extern void php3_module_shutdown();

void php3_save_umask()
{
	saved_umask = umask(077);
	umask(saved_umask);
}

void php3_restore_umask()
{
	umask(saved_umask);
}

int send_parsed_php3(request_rec * r)
{
	int fd, retval;
	php3_ini_structure *conf;

	/* Make sure file exists */
	if (r->finfo.st_mode == 0)
		return NOT_FOUND;

	/* grab configuration settings */
	conf = (php3_ini_structure *) get_module_config(r->per_dir_config, &php3_module);
	memcpy(&php3_ini,conf,sizeof(php3_ini_structure)); /* copy to active configuration */

	/* 
	 * If PHP parser engine has been turned off with the phpEngine off directive,
	 * then decline to handle this request
	 */
	if (!conf->engine) {
		r->content_type = "text/html";
		return DECLINED;
	}

	/* Open the file */
	if ((fd = popenf(r->pool, r->filename, O_RDONLY, 0)) == -1) {
		log_reason("file permissions deny server access", r->filename, r);
		return FORBIDDEN;
	}
	/* Apache 1.2+ has a more complex mechanism for reading POST data */
#if MODULE_MAGIC_NUMBER > 19961007
	if ((retval = setup_client_block(r, REQUEST_CHUNKED_ERROR)))
		return retval;
#endif

	if (conf->lastmodified) {
#if MODULE_MAGIC_NUMBER < 19970912
		if (retval = set_last_modified(r, r->finfo.st_mtime)) {
			return retval;
		}
#else
		update_mtime (r, r->finfo.st_mtime);
		set_last_modified(r);
		set_etag(r);
#endif
	}
	/* Assume output will be HTML.  Individual scripts may change this 
	   further down the line */
	r->content_type = "text/html";

	/* Init timeout */
	hard_timeout("send", r);

	php3_save_umask();
	chdir_file(r->filename);
	add_common_vars(r);
	add_cgi_vars(r);
	apache_php3_module_main(r, fd, 0);

	/* Done, restore umask, turn off timeout, close file and return */
	php3_restore_umask();
	kill_timeout(r);
	pclosef(r->pool, fd);
	return OK;
}


int send_parsed_php3_source(request_rec * r)
{
	int fd, retval;
	php3_ini_structure *conf;

	/* Make sure file exists */
	if (r->finfo.st_mode == 0)
		return NOT_FOUND;

	/* grab configuration settings */
	conf = (php3_ini_structure *) get_module_config(r->per_dir_config, &php3_module);
	memcpy(&php3_ini,conf,sizeof(php3_ini_structure)); /* copy to active configuration */

	/* 
	 * If PHP parser engine has been turned off with the phpEngine off directive,
	 * then decline to handle this request
	 */
	if (!conf->engine) {
		r->content_type = "text/html";
		return DECLINED;
	}
	/* Open the file */
	if ((fd = popenf(r->pool, r->filename, O_RDONLY, 0)) == -1) {
		log_reason("file permissions deny server access", r->filename, r);
		return FORBIDDEN;
	}
	/* Apache 1.2 has a more complex mechanism for reading POST data */
#if MODULE_MAGIC_NUMBER > 19961007
	if ((retval = setup_client_block(r, REQUEST_CHUNKED_ERROR)))
		return retval;
#endif

	if (conf->lastmodified) {
#if MODULE_MAGIC_NUMBER < 19970912
		if (retval = set_last_modified(r, r->finfo.st_mtime)) {
			return retval;
		}
#else
		update_mtime (r, r->finfo.st_mtime);
		set_last_modified(r);
		set_etag(r);
#endif
	}
	/* Assume output will be HTML.  Individual scripts may change this 
	   further down the line */
	r->content_type = "text/html";

	/* Init timeout */
	hard_timeout("send", r);

	php3_save_umask();
	chdir_file(r->filename);
	add_common_vars(r);
	add_cgi_vars(r);
	apache_php3_module_main(r, fd, 1);

	/* Done, restore umask, turn off timeout, close file and return */
	php3_restore_umask();
	kill_timeout(r);
	pclosef(r->pool, fd);
	return OK;
}

/*
 * Create the per-directory config structure with defaults from php3_ini_master
 */
static void *php3_create_dir(pool * p, char *dummy)
{
	php3_ini_structure *new;

	php3_module_startup(); /* php3_ini_master is set up here */

	new = (php3_ini_structure *) palloc(p, sizeof(php3_ini_structure));
	memcpy(new,&php3_ini_master,sizeof(php3_ini_structure));

	return new;
}

/*
 * Merge in per-directory .conf directives
 */
static void *php3_merge_dir(pool *p, void *basev, void *addv) 
{
	php3_ini_structure *new = (php3_ini_structure *) palloc(p, sizeof(php3_ini_structure));
	php3_ini_structure *base = (php3_ini_structure *) basev;
	php3_ini_structure *add = (php3_ini_structure *) addv;

	/*
	 * Because of the way things are initialized, addv already contains
	 * the new conf structure at this point, so we can just memcpy it
	 */
	memcpy(new,add,sizeof(php3_ini_structure));

	return new;
}

#if MODULE_MAGIC_NUMBER > 19961007
const char *php3flaghandler(cmd_parms * cmd, php3_ini_structure * conf, int val)
{
#else
char *php3flaghandler(cmd_parms * cmd, php3_ini_structure * conf, int val)
{
#endif
	int c = (int) cmd->info;

	switch (c) {
		case 0:
			conf->track_errors = val;
			break;
		case 1:
			conf->magic_quotes_gpc = val;
			break;
		case 2:
			conf->magic_quotes_runtime = val;
			break;
		case 3:
			conf->short_open_tag = val;
			break;
		case 4:
			conf->safemode = val;
			break;
		case 5:
			conf->track_vars = val;
			break;
		case 6:
			conf->sql_safe_mode = val;
			break;
		case 7:
			conf->engine = val;
			break;
		case 8:
			conf->xbithack = val;
			break;
		case 9:
			conf->lastmodified = val;
			break;
	}
	return NULL;
}

#if MODULE_MAGIC_NUMBER > 19961007
const char *php3take1handler(cmd_parms * cmd, php3_ini_structure * conf, char *arg)
{
#else
char *php3take1handler(cmd_parms * cmd, php3_ini_structure * conf, char *arg)
{
#endif
	int c = (int) cmd->info;

	switch (c) {
		case 0:
			conf->errors = atoi(arg);
			break;
		case 1:
			conf->docroot = pstrdup(cmd->pool, arg);
			break;
		case 2:
			conf->userdir = pstrdup(cmd->pool, arg);
			break;
		case 3:
			conf->safemodeexecdir = pstrdup(cmd->pool, arg);
			break;
		case 4:
			conf->includepath = pstrdup(cmd->pool, arg);
			break;
		case 5:
			conf->autoprependfile = pstrdup(cmd->pool, arg);
			break;
		case 6:
			conf->autoappendfile = pstrdup(cmd->pool, arg);
			break;
		case 7:
			conf->uploadtmpdir = pstrdup(cmd->pool, arg);
			break;
		case 8:
			conf->dldir = pstrdup(cmd->pool, arg);
			break;
	}
	return NULL;
}

int php3_xbithack_handler(request_rec * r)
{
	php3_ini_structure *conf;

	conf = (php3_ini_structure *) get_module_config(r->per_dir_config, &php3_module);
	if (!(r->finfo.st_mode & S_IXUSR))
		return DECLINED;
	if (conf->xbithack == 0)
		return DECLINED;
	return send_parsed_php3(r);
}

void php3_exit_handler(server_rec *s, pool *p)
{
	php3_module_shutdown();
}

void php3_init_handler(server_rec *s, pool *p)
{
	/* For Apache 1.2 try registering a cleanup function for the main server pool */
#if MODULE_MAGIC_NUMBER < 19970728
	register_cleanup(p, NULL, php3_module_shutdown, php3_module_shutdown);
#endif
}

handler_rec php3_handlers[] =
{
	{"application/x-httpd-php3", send_parsed_php3},
	{"application/x-httpd-php3-source", send_parsed_php3_source},
	{"text/html", php3_xbithack_handler},
	{NULL}
};


command_rec php3_commands[] =
{
	{"php3error_reporting", php3take1handler, (void *)0, OR_OPTIONS, TAKE1, "error reporting level"},
	{"php3docroot", php3take1handler, (void *)1, RSRC_CONF, TAKE1, "directory"}, /* not used yet */
	{"php3userdir", php3take1handler, (void *)2, RSRC_CONF, TAKE1, "user directory"}, /* not used yet */
	{"php3safemodeexecdir", php3take1handler, (void *)3, RSRC_CONF, TAKE1, "safe mode executable dir"},
	{"php3includepath", php3take1handler, (void *)4, RSRC_CONF, TAKE1, "colon-separated path"},
	{"php3autoprependfile", php3take1handler, (void *)5, OR_OPTIONS, TAKE1, "file name"},
	{"php3autoappendfile", php3take1handler, (void *)6, OR_OPTIONS, TAKE1, "file name"},
	{"php3uploadtmpdir", php3take1handler, (void *)7,  RSRC_CONF, TAKE1, "directory"},
	{"php3dldir", php3take1handler, (void *)8,  RSRC_CONF, TAKE1, "directory"},

	{"php3track_errors", php3flaghandler, (void *)0, OR_OPTIONS, FLAG, "on|off"},
	{"php3magic_quotes_gpc", php3flaghandler, (void *)1, OR_OPTIONS, FLAG, "on|off"},
	{"php3magic_quotes_runtime", php3flaghandler, (void *)2, OR_OPTIONS, FLAG, "on|off"},
	{"php3short_open_tag", php3flaghandler, (void *)3, OR_OPTIONS, FLAG, "on|off"},
	{"php3safemode", php3flaghandler, (void *)4, RSRC_CONF, FLAG, "on|off"},
	{"php3track_vars", php3flaghandler, (void *)5, RSRC_CONF, FLAG, "on|off"},
	{"php3sql_safe_mode", php3flaghandler, (void *)6,  RSRC_CONF, FLAG, "on|off"},
	{"php3engine", php3flaghandler, (void *)7, RSRC_CONF, FLAG, "on|off"},
	{"php3xbitack", php3flaghandler, (void *)8, OR_OPTIONS, FLAG, "on|off"},
	{"php3lastmodified", php3flaghandler, (void *)9, OR_OPTIONS, FLAG, "on|off"},
	{NULL}
};



module MODULE_VAR_EXPORT php3_module =
{
	STANDARD_MODULE_STUFF,
	php3_init_handler,			/* initializer */
	php3_create_dir,			/* per-directory config creator */
	php3_merge_dir,				/* dir merger */
	NULL,						/* per-server config creator */
	NULL, 						/* merge server config */
	php3_commands,				/* command table */
	php3_handlers,				/* handlers */
	NULL,						/* filename translation */
	NULL,						/* check_user_id */
	NULL,						/* check auth */
	NULL,						/* check access */
	NULL,						/* type_checker */
	NULL,						/* fixups */
	NULL						/* logger */
#if MODULE_MAGIC_NUMBER >= 19970103
	,NULL						/* header parser */
#endif
#if MODULE_MAGIC_NUMBER >= 19970719
	,NULL             			/* child_init */
#endif
#if MODULE_MAGIC_NUMBER >= 19970728
	,php3_exit_handler			/* child_exit */
#endif
#if MODULE_MAGIC_NUMBER >= 19970902
	,NULL						/* post read-request */
#endif
};

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
