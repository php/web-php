#include "tls.h"

#if THREAD_SAFE
/*This is indeed a global!*/
DWORD TlsIndex;
#else
php3_globals *globals; 
#endif

/* just copying from some samples, can replace this with
standard php error messaging */
VOID ErrorExit (LPTSTR lpszMessage) 
{ 
   fprintf(stderr, "%s\n", lpszMessage); 
   ExitProcess(0); 
} 

/*all these functions are called from DllMain()*/
/*called at dll load*/
int tls_startup(void){
#if THREAD_SAFE
	if((TlsIndex=TlsAlloc())==0xFFFFFFFF){
		return FAILURE;
	}
#else
	globals=malloc(sizeof(php3_globals));
#endif
	return SUCCESS;
}
/*called at dll unload*/
int tls_shutdown(void){
#if THREAD_SAFE
	if(!TlsFree(TlsIndex)){
		return FAILURE;
	}
#else
	free(globals);
#endif
	return SUCCESS;
}
 
#if THREAD_SAFE
/*called at start of thread*/
int tls_create(void){
	php3_globals *globals;
	globals = (php3_globals *) LocalAlloc(LPTR, sizeof(php3_globals)); 
	if (! TlsSetValue(TlsIndex, (void *) globals)) 
		ErrorExit("TlsSetValue error"); 

	return SUCCESS;
}

/*called at end of thread*/
int tls_destroy(void){
	php3_globals *globals;
	globals = TlsGetValue(TlsIndex); 
	if (globals != 0) 
		LocalFree((HLOCAL) globals); 
	return SUCCESS;
}

#endif


/*
accessing data inside a thread
This short function shows how the global struct
is accessed in a function.  THREAD_SAFE should
only need to be defined on windows server modules

void thread_safe_access_of_globals(VOID) 
{ 
#if THREAD_SAFE
   php3_globals *globals; 
   globals = TlsGetValue(TlsIndex); 
   if ((lpvData == 0) && (GetLastError() != 0)) 
      ErrorExit("TlsGetValue error"); 
   return globals;
#endif
} 

*/
