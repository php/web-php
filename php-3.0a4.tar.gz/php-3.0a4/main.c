/* 
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Andi Gutmans <andi@vipe.technion.ac.il>                     |
   |          Zeev Suraski <bourbon@netvision.net.il>                     |
   |          Rasmus Lerdorf <rasmus@lerdorf.on.ca>                       |
   +----------------------------------------------------------------------+
 */

/* $Id: main.c,v 1.210 1997/12/02 00:31:56 shane Exp $ */

#include <stdio.h>
#include "parser.h"
#ifndef MSVC5
#include "build-defs.h"
#endif
#include "language-parser.tab.h"
#include "main.h"
#include "control_structures.h"
#include "modules.h"
#include "functions/file.h"
#include "functions/head.h"
#include "functions/post.h"
#include "functions/head.h"
#include "functions/type.h"
#include "highlight.h"
#include "list.h"

#if MSVC5 || !defined(HAVE_GETOPT)
#include "getopt.h"
#endif

extern int php3_header(int, char *);
extern void phprestart(FILE *);
extern void php3_TreatHeaders(void);
extern void _php3_info(void);

int error_reporting,tmp_error_reporting;
int initialized;	/* keep track of which resources were successfully initialized */
static int module_initialized=0;
int shutdown_requested;
php3_ini_structure php3_ini;
php3_ini_structure php3_ini_master;

#if APACHE
request_rec *php3_rqst=NULL;			/* request record pointer for apache module version */
#endif

#if PHP_ISAPI
LPEXTENSION_CONTROL_BLOCK lpPHPcb;
#endif

HashTable configuration_hash;

extern char *strtok_string;
extern FILE *phpin;

void _php3_build_argv(char *);

/* string destructor for hash */
void str_free(void **ptr)
{
	efree(*ptr);
}

/* this SHOULD be compatible with the standard phperror */
void phperror(char *error)
{
	php3_error(E_PARSE, error);
}


#if APACHE
void php3_apache_puts(char *s)
{
	if (php3_rqst) {
		rputs(s,php3_rqst);
	} else {
		fputs(s,stdout);
	}
}

void php3_apache_putc(char c)
{
	if (php3_rqst) {
		rputc(c,php3_rqst);
	} else {
		fputc(c,stdout);
	}
}
#endif


/* is 4K big enough? */
#define PRINTF_BUFFER_SIZE 1024*4

PHPAPI int php3_printf(char *format,...)
{
	va_list args;
	int ret;
#if WIN32_SERVER_MOD
	char buffer[PRINTF_BUFFER_SIZE];
	int size;
#endif

	va_start(args, format);
#if APACHE
	ret = vbprintf(php3_rqst->connection->client, format, args);
#endif

#if PHP_ISAPI
	size = vsprintf(buffer, format, args);
	ret = lpPHPcb->WriteClient(lpPHPcb->ConnID,buffer,&size,0);
#endif

#if NSAPI
	size = vsprintf(buffer, format, args);
	ret = net_write(nssn->csd, buffer, size);
#endif

#if CGI_BINARY
	ret = vfprintf(stdout, format, args);
#endif

	va_end(args);
	return ret;
}


/* extended error handling function */
PHPAPI void php3_error(int type, char *format,...)
{
	va_list args;
	int file_offset = current_lineno / MAX_TOKENS_PER_CACHE;
	void **filename_ptr;
	char *filename = NULL;
#if (WIN32_SERVER_MOD || PHP_DEBUGGER)
	char buffer[1024 *4]; /*is 4k big enough? */
#endif
#if WIN32_SERVER_MOD
	int size;
#endif

	if (!(type & E_CORE)) {
		if (!initialized || shutdown_requested) {/* don't display further errors after php3_request_shutdown() */
			return;
		}
	}
	
	if (error_reporting & type) {
		if(!php3_header(0, NULL)) return;
		PUTS("<br>\n");
		switch (type) {
			case E_ERROR:   /* 0x01 */
			case E_CORE_ERROR:	/* 0x10 */
				PUTS("Fatal error:  ");
				break;
			case E_WARNING: /* 0x02 */
			case E_CORE_WARNING:	/* 0x20 */
				PUTS("Warning:  ");
				break;
			case E_PARSE:   /* 0x04 */
				PUTS("Parse error:  ");
				break;
			case E_NOTICE:  /* 0x08 */
				PUTS("Warning:  ");
				break;
			default:
				PUTS("Unknown error:  ");
				break;
		}
		/* get include file name */
		if (!(type & E_CORE)) {
			if (hash_index_find(&include_names, file_offset, (void **) &filename_ptr) == SUCCESS) {
				filename = *filename_ptr;
			} else {
				filename = "standard input";
			}
		}

		va_start(args, format);
#if APACHE
		if (php3_rqst) {
			vbprintf(php3_rqst->connection->client, format, args);
			if (!(type & E_CORE)) {
				rprintf(php3_rqst, " in %s on line %d", filename, current_lineno % MAX_TOKENS_PER_CACHE);
			}
		} else {
			vfprintf(stdout, format, args);
			if (!(type & E_CORE)) {
				fprintf(stdout, " in %s on line %d", filename, current_lineno % MAX_TOKENS_PER_CACHE);
			}	
		}
#endif
#if PHP_ISAPI
		size = vsnprintf(buffer, sizeof(buffer)-1, format, args);
		lpPHPcb->WriteClient(lpPHPcb->ConnID,buffer,&size,0);
		if (!(type & E_CORE)) {
			size = snprintf(buffer, PRINTF_BUFFER_SIZE, " in %s on line %d", filename, current_lineno % MAX_TOKENS_PER_CACHE);
			lpPHPcb->WriteClient(lpPHPcb->ConnID,buffer,&size,0);
		}
#endif
#if NSAPI
		size = vsnprintf(buffer, sizeof(buffer)-1, format, args);
		net_write(nssn->csd, buffer, size);
		if (!(type & E_CORE)) {
			size = snprintf(buffer, PRINTF_BUFFER_SIZE, " in %s on line %d", filename, current_lineno % MAX_TOKENS_PER_CACHE);
			net_write(nssn->csd, buffer, size);
		}
#endif
#if CGI_BINARY
		vfprintf(stdout, format, args);
		if (!(type & E_CORE)) {
			fprintf(stdout, " in %s on line %d", filename, current_lineno % MAX_TOKENS_PER_CACHE);
		}
#endif
		PUTS("<br>\n");
		va_end(args);
	}

	if (php3_ini.track_errors && (initialized&INIT_SYMBOL_TABLE)) {
		YYSTYPE tmp;
		
		tmp.value.strval = (char *) emalloc(256);
		va_start(args,format);
		tmp.strlen=vsnprintf(tmp.value.strval,255,format,args);
		va_end(args);
		tmp.value.strval[255]=0;
		tmp.type = IS_STRING;
		
		hash_update(&symbol_table,"php_errormsg",sizeof("php_errormsg"),(void *) &tmp,sizeof(YYSTYPE),NULL);
	}
		
#if PHP_DEBUGGER
	/* Send a message to the debugger no matter if we are configured
	 * not to display this error.
	 */
	va_start(args, format);
	vsnprintf(buffer, sizeof(buffer)-1, format, args);
	php3_debugger_error(buffer, type, filename,
						current_lineno % MAX_TOKENS_PER_CACHE);
	va_end(args);
#endif

	switch (type) {
		case E_ERROR:
		case E_PARSE:
			shutdown_requested=1;
			break;
	}
}


/* phpparse()'s front end to the token cache */
int phplex(YYSTYPE *phplval)
{
	Token *token;

	if (!initialized || shutdown_requested) {
		return 0;
	}
	switch (read_next_token(&token_cache_manager, &token, phplval)) {
		case FAILURE:
			php3_error(E_ERROR, "Unable to read next token!\n");
			return 0;
			break;
		case DONE_EVAL:
			return phplex(phplval);
			break;
	}
	*phplval = token->phplval;
	current_lineno = token->lineno;
	return token->token_type;
}



int php3_request_startup(void)
{
	initialized=0;
	
	start_memory_manager();
	initialized |= INIT_MEMORY_MANAGER;

#if APACHE
	/*
	 * For the Apache module version, this bit of code registers a cleanup
	 * function that gets triggered when our request pool is destroyed.
	 * We need this because at any point in our code we can be interrupted
	 * and that may happen before we have had time to free our memory.
	 * The php3_shutdown function needs to free all outstanding allocated
	 * memory.  
	 */
	block_alarms();
	register_cleanup(php3_rqst->pool, NULL, php3_request_shutdown, php3_request_shutdown);
	unblock_alarms();
#endif

	/* initialize global variables */
	{
		ExecuteFlag = EXECUTE;
		Execute = 1;
		php3_display_source = php3_preprocess = 0;
		include_count=0;
		active_symbol_table = &symbol_table;
		function_state.loop_nest_level=function_state.loop_change_level=function_state.loop_change_type=0;
		function_state.returned=function_state.function_type=0;
		function_state.symbol_table=&symbol_table;
		function_state.function_symbol_table=NULL;
		function_state.function_name=NULL;
		function_state.handler=NULL;
		phplineno=1;
		strtok_string = NULL;
		error_reporting=php3_ini.errors;
		shutdown_requested=0;
		php3_track_vars = php3_ini.track_vars;
	}
		
	
	if (php3_init_request_info((void *)&php3_ini)){
		php3_printf("Unable to initialize request info.\n");
		return FAILURE;
	}
	initialized |= INIT_REQUEST_INFO;

	/* prepare general symbol table hash */
	if (hash_init(&symbol_table, 50, NULL, YYSTYPE_DESTRUCTOR, 0) == FAILURE) {
		php3_printf("Unable to initialize symbol table.\n");
		return FAILURE;
	}
	/* this YYSTYPE will be used for the GLOBALS[] array implementation */
	globals.value.ht = &symbol_table;
	globals.type = IS_ARRAY;
	hash_pointer_update(&symbol_table,"GLOBALS",sizeof("GLOBALS"),(void *) &globals);
	initialized |= INIT_SYMBOL_TABLE;


	/* prepare token cache */
	if (tcm_init(&token_cache_manager) == FAILURE) {
		php3_printf("Unable to initialize token cache.\n");
		return FAILURE;
	}
	initialized |= INIT_TOKEN_CACHE;

	/* initialize stacks */
	if (stack_init(&css) == FAILURE) {
		php3_printf("Unable to initialize Control Structure stack.\n");
		return FAILURE;
	}
	initialized |= INIT_CSS;

	if (stack_init(&for_stack) == FAILURE) {
		php3_printf("Unable to initialize for stack.\n");
		return FAILURE;
	}
	initialized |= INIT_FOR_STACK;

	if (stack_init(&switch_stack) == FAILURE) {
		php3_printf("Unable to initialize switch stack.\n");
		return FAILURE;
	}
	initialized |= INIT_SWITCH_STACK;

	if (stack_init(&input_source_stack) == FAILURE) {
		php3_printf("Unable to initialize include stack.\n");
		return FAILURE;
	}
	initialized |= INIT_INCLUDE_STACK;

	if (stack_init(&function_state_stack) == FAILURE) {
		php3_printf("Unable to initialize function state stack.\n");
		return FAILURE;
	}
	initialized |= INIT_FUNCTION_STATE_STACK;
	
	if (stack_init(&variable_unassign_stack) == FAILURE) {
		php3_printf("Unable to initialize variable unassignment stack.\n");
		return FAILURE;
	}
	initialized |= INIT_VARIABLE_UNASSIGN_STACK;

	/* call request startup for modules */
	hash_apply(&module_registry, (int (*)(void *)) module_registry_request_startup);
	
	/* include file names */
	if (hash_init(&include_names, 0, NULL, (void (*)(void *ptr)) str_free, 0) == FAILURE) {
		php3_printf("Unable to start include names stack.\n");
		return FAILURE;
	}
	initialized |= INIT_INCLUDE_NAMES_HASH;

	
	if (init_resource_list()==FAILURE) {
		php3_printf("Unable to start object list hash.\n");
		return FAILURE;
	}
	initialized |= INIT_LIST;
	
	return SUCCESS;
}

void php3_request_shutdown(void *dummy)
{
	if (initialized & INIT_SYMBOL_TABLE) {
		hash_destroy(&symbol_table);
		initialized &= ~INIT_SYMBOL_TABLE;
	}
	
	initialized &= ~INIT_ENVIRONMENT;	/* does not require any special shutdown */

	/* remove classes and user-functions */
	if (module_initialized & INIT_FUNCTION_TABLE) {
		hash_apply(&function_table,(int (*)(void *)) is_not_internal_function);
	}

	if (initialized & INIT_TOKEN_CACHE) {
		tcm_destroy(&token_cache_manager);
		initialized &= ~INIT_TOKEN_CACHE;
	}
	if (initialized & INIT_CSS) {
		stack_destroy(&css);
		initialized &= ~INIT_CSS;
	}
	if (initialized & INIT_FOR_STACK) {
		stack_destroy(&for_stack);
		initialized &= ~INIT_FOR_STACK;
	}
	if (initialized & INIT_SWITCH_STACK) {
		switch_expr *se;
		
		while (stack_top(&switch_stack, (void **) &se) != FAILURE) {
			yystype_destructor(&se->expr);
			stack_del_top(&switch_stack);
		}
		stack_destroy(&switch_stack);
		initialized &= ~INIT_SWITCH_STACK;
	}
	if (initialized & INIT_INCLUDE_STACK) {
		stack_destroy(&input_source_stack);
		initialized &= ~INIT_INCLUDE_STACK;
	}
	if (initialized & INIT_FUNCTION_STATE_STACK) {
		FunctionState *tmp;

		while (stack_top(&function_state_stack, (void **) &tmp) != FAILURE) {
			if (tmp->function_name) {
				efree(tmp->function_name);
				if (tmp->symbol_table) {
					hash_destroy(tmp->symbol_table);
					efree(tmp->symbol_table);
				}
			}
			stack_del_top(&function_state_stack);
		}
		stack_destroy(&function_state_stack);
		initialized &= ~INIT_FUNCTION_STATE_STACK;
	}
	
	if (initialized & INIT_VARIABLE_UNASSIGN_STACK) {
		variable_tracker *tmp;

		while (stack_top(&variable_unassign_stack, (void **) &tmp) != FAILURE) {
			if (tmp->type == IS_STRING) {
				efree(tmp->strval);
			}
			stack_del_top(&variable_unassign_stack);
		}
		stack_destroy(&variable_unassign_stack);
		initialized &= ~INIT_VARIABLE_UNASSIGN_STACK;
	}

	
	if (initialized & INIT_LIST) {
		destroy_resource_list();
		initialized &= ~INIT_LIST;
	}

	/* clean temporary dl's, run request shutdown's for modules */
	hash_apply(&module_registry, (int (*)(void *)) module_registry_cleanup);

	/* do this after the above in case the modules need to access any
	   of the request_info members */
	if (initialized & INIT_REQUEST_INFO) {
		php3_destroy_request_info((void *)&php3_ini);
		initialized &= ~INIT_REQUEST_INFO;
	}


	if (initialized & INIT_INCLUDE_NAMES_HASH) {
		hash_destroy(&include_names);
		initialized &= ~INIT_INCLUDE_NAMES_HASH;
	}

	

	
	if (initialized & INIT_SCANNER) {
		reset_scanner();
		fclose(phpin);
		initialized &= ~INIT_SCANNER;
	}
	
	if (initialized & INIT_MEMORY_MANAGER) {
		shutdown_memory_manager();
		initialized &= ~INIT_MEMORY_MANAGER;
	}

	if (initialized) {
		php3_error(E_WARNING, "Unknown resources in request shutdown function");
	}
	
#if CGI_BINARY
	fflush(stdout);
#endif
}


int php3_module_startup()
{
	error_reporting=E_ALL;
	
	/* prepare function table hash */
	if (hash_init(&function_table, 100, NULL, YYSTYPE_DESTRUCTOR, 1) == FAILURE) {
		php3_printf("Unable to initialize function table.\n");
		return FAILURE;
	}
	module_initialized |= INIT_FUNCTION_TABLE;

	/* prepare the module registry */
	if (hash_init(&module_registry,50,NULL,(void (*)(void *)) module_destructor,1)==FAILURE) {
		php3_printf("Unable to initialize module registry.\n");
		return FAILURE;
	}
	module_initialized |= INIT_MODULE_REGISTRY;

	/* resource-list destructors */
	if (hash_init(&list_destructors, 50, NULL, NULL, 1)==FAILURE) {
		php3_printf("Unable to initialize resource list destructors hash.\n");
		return FAILURE;
	}
	le_index_ptr = register_list_destructors(NULL,NULL);
	module_initialized |= INIT_LIST_DESTRUCTORS;

	/* persistent list */
	if (init_resource_plist()==FAILURE) {
		php3_printf("PHP:  Unable to start persistent object list hash.\n");
		return FAILURE;
	}
	module_initialized |= INIT_PLIST;

	if (php3_init_config()==FAILURE) {
		php3_printf("PHP:  Unable to parse configuration file.\n");
		return FAILURE;
	}
	module_initialized |= INIT_CONFIG;

	/* initialize run-time variables */
	/* I have remarked out some stuff 
	that may or may not be needed */
	{
		char *temp;

		if (cfg_get_string("smtp",&php3_ini.smtp)==FAILURE) {
			php3_ini.smtp = "localhost";
		}
		if (cfg_get_string("sendmailpath",&php3_ini.sendmailpath)==FAILURE) {
#ifdef PHP_PROG_SENDMAIL
			php3_ini.sendmailpath = PHP_PROG_SENDMAIL;
#else
			php3_ini.sendmailpath = NULL;
#endif
		}
		if (cfg_get_string("cgiext",&php3_ini.cgiext)==FAILURE) {
			php3_ini.cgiext = NULL;
		}
		if (cfg_get_string("nsapiext",&php3_ini.cgiext)==FAILURE) {
			php3_ini.nsapiext = NULL;
		}
		if (cfg_get_string("isapiext",&php3_ini.cgiext)==FAILURE) {
			php3_ini.isapiext = NULL;
		}
		if (cfg_get_long("error_reporting",&php3_ini.errors)==FAILURE) {
			php3_ini.errors = E_ALL & ~E_NOTICE;
		}

		error_reporting=php3_ini.errors;

		if (cfg_get_long("track_errors",&php3_ini.track_errors)==FAILURE) {
			php3_ini.track_errors=0;
		}
		if (cfg_get_long("magic_quotes_gpc",&php3_ini.magic_quotes_gpc)==FAILURE) {
			php3_ini.magic_quotes_gpc = MAGIC_QUOTES;
		}
		if (cfg_get_long("magic_quotes_runtime",&php3_ini.magic_quotes_runtime)==FAILURE) {
			php3_ini.magic_quotes_runtime = MAGIC_QUOTES;
		}
		if (cfg_get_string("docroot",&php3_ini.docroot)==FAILURE) {
			php3_ini.docroot = PHP_DOCUMENT_ROOT;
		}
		if (cfg_get_long("shortopentag",&php3_ini.short_open_tag)==FAILURE) {
			php3_ini.short_open_tag = DEFAULT_SHORT_OPEN_TAG;
		}
		if (cfg_get_string("userdir",&php3_ini.userdir)==FAILURE) {
			php3_ini.userdir = PHP_USER_DIR;
		}
		if (cfg_get_long("safemode",&php3_ini.safemode)==FAILURE) {
			php3_ini.safemode = PHP_SAFE_MODE;
		}
		if (cfg_get_long("track_vars",&php3_ini.track_vars)==FAILURE) {
			php3_ini.track_vars = PHP_TRACK_VARS;
		}
		if (cfg_get_string("safemodeexecdir",&php3_ini.safemodeexecdir)==FAILURE) {
#ifdef PHP_SAFE_MODE_EXEC_DIR
			php3_ini.safemodeexecdir = PHP_SAFE_MODE_EXEC_DIR;
#else
			php3_ini.safemodeexecdir = "/";
#endif
		}
		if (cfg_get_string("includepath",&php3_ini.includepath)==FAILURE) {
			if((temp=getenv("PHP_INCLUDE_PATH"))) {
				php3_ini.includepath = estrdup(temp);
			} else {
				php3_ini.includepath = NULL;
			}
		}
		if (cfg_get_string("autoprependfile",&php3_ini.autoprependfile)==FAILURE) {
			if((temp =getenv("PHP_AUTO_PREPEND_FILE"))) {
				php3_ini.autoprependfile = estrdup(temp);
			} else {
				php3_ini.autoprependfile = NULL;
			}
		}
		if (cfg_get_string("autoappendfile",&php3_ini.autoappendfile)==FAILURE) {
			if((temp =getenv("PHP_AUTO_APPEND_FILE"))) {
				php3_ini.autoappendfile = estrdup(temp);
			} else {
				php3_ini.autoappendfile = NULL;
			}	
		}
		if (cfg_get_string("uploadtmpdir",&php3_ini.uploadtmpdir)==FAILURE) {
			/* php3_ini.uploadtmpdir = UPLOAD_TMPDIR; */
			php3_ini.uploadtmpdir = NULL;
		}
		if (cfg_get_string("dldir",&php3_ini.dldir)==FAILURE) {
			php3_ini.dldir = NULL;
		}
			
		/* Debugger */
		if (cfg_get_string("debughost",&php3_ini.debughost)==FAILURE) {
			php3_ini.debughost="localhost";
		}
		if (cfg_get_long("debugport",&php3_ini.debugport)==FAILURE) {
			php3_ini.debugport=7869;
		}
		if (cfg_get_long("sql.safe_mode", &php3_ini.sql_safe_mode)==FAILURE) {
			php3_ini.sql_safe_mode=0;
		}
#if DISPLAY_SOURCE_SUPPORT
		/* Syntax highlighting */
		if (cfg_get_string("highlight.comment",&php3_ini.highlight_comment)==FAILURE) {
			php3_ini.highlight_comment = HL_COMMENT_COLOR;
		}
		if (cfg_get_string("highlight.default",&php3_ini.highlight_default)==FAILURE) {
			php3_ini.highlight_default = HL_DEFAULT_COLOR;
		}
		if (cfg_get_string("highlight.html",&php3_ini.highlight_html)==FAILURE) {
			php3_ini.highlight_html = HL_HTML_COLOR;
		}
		if (cfg_get_string("highlight.string",&php3_ini.highlight_string)==FAILURE) {
			php3_ini.highlight_string = HL_STRING_COLOR;
		}
		if (cfg_get_string("highlight.bg",&php3_ini.highlight_bg)==FAILURE) {
			php3_ini.highlight_bg = HL_BG_COLOR;
		}
		if (cfg_get_string("highlight.keyword",&php3_ini.highlight_keyword)==FAILURE) {
			php3_ini.highlight_keyword = HL_KEYWORD_COLOR;
		}
#endif
		if (cfg_get_long("engine", &php3_ini.engine)==FAILURE) {
			php3_ini.engine=1;
		}
		if (cfg_get_long("lastmodified", &php3_ini.lastmodified)==FAILURE) {
			php3_ini.lastmodified=0;
		}
		if (cfg_get_long("xbithack", &php3_ini.xbithack)==FAILURE) {
			php3_ini.xbithack=0;
		}
		
		/* 
		 * Make a master copy to use as a basis for every per-dir config.
		 * Without two copies we would have a previous requst's per-dir
		 * config carry forward to the next one.
         */
		memcpy(&php3_ini_master,&php3_ini,sizeof(php3_ini));
	}

	if (module_startup_modules()==FAILURE) {
		php3_printf("Unable to start modules\n");
		return FAILURE;
	}
	
	return SUCCESS;
}


void php3_module_shutdown()
{
	if (module_initialized & INIT_MODULE_REGISTRY) {
		hash_destroy(&module_registry);
		module_initialized &= ~INIT_MODULE_REGISTRY;
	}
	if (module_initialized & INIT_PLIST) {
		destroy_resource_plist();
		module_initialized &= ~INIT_PLIST;
	}
	if (module_initialized & INIT_LIST_DESTRUCTORS) {
		hash_destroy(&list_destructors);
		module_initialized &= ~INIT_LIST_DESTRUCTORS;
	}
	if (module_initialized & INIT_CONFIG) {
		php3_shutdown_config();
		module_initialized &= ~INIT_CONFIG;
	}
	if (initialized & INIT_FUNCTION_TABLE) {
		hash_destroy(&function_table);
		module_initialized &= ~INIT_FUNCTION_TABLE;
	}
	if (module_initialized) {
		php3_error(E_WARNING, "Unknown resource in module shutdown");
	}
	
#if CGI_BINARY
	fflush(stdout);
#endif
}


int hash_environment()
{
	char **env,*p,*t;
	YYSTYPE tmp;

	if (request_info.request_method && !strcasecmp(request_info.request_method, "post")) {
		php3_TreatData(PARSE_POST, NULL);	/* POST Data */
	}
	php3_TreatData(PARSE_COOKIE, NULL);	/* Cookie Data */
	php3_TreatData(PARSE_GET, NULL);	/* GET Data */

#if APACHE
	{
		YYSTYPE *tmp_ptr,tmp2;
		register int i;
		table_entry *elts = (table_entry *)php3_rqst->subprocess_env->elts;
		int len;
	
		for (i=0; i<php3_rqst->subprocess_env->nelts; i++) {
			len = strlen(elts[i].key);
			t = estrndup(elts[i].key,len);
			tmp.strlen = strlen(elts[i].val);
			tmp.value.strval = estrndup(elts[i].val,tmp.strlen);
			tmp.type = IS_STRING;
			if (hash_add(&symbol_table,t,len+1,&tmp,sizeof(YYSTYPE),NULL)==FAILURE) {
				efree(tmp.value.strval);
			}
			efree(t);
		}
		/* insert special variables */
		if (hash_find(&symbol_table,"SCRIPT_FILENAME",sizeof("SCRIPT_FILENAME"),(void **) &tmp_ptr)==SUCCESS) {
			tmp2 = *tmp_ptr;
			yystype_copy_constructor(&tmp2);
			hash_update(&symbol_table,"PATH_TRANSLATED",sizeof("PATH_TRANSLATED"),(void *) &tmp2,sizeof(YYSTYPE),NULL);
		}
		tmp.strlen = strlen(php3_rqst->uri);
		tmp.value.strval = estrndup(php3_rqst->uri,tmp.strlen);
		tmp.type = IS_STRING;
		hash_update(&symbol_table,"PHP_SELF",sizeof("PHP_SELF"),(void *) &tmp,sizeof(YYSTYPE),NULL);
	}
#else
	{
		/* Build the special-case PHP_SELF variable for the CGI version */
		char *sn, *pi;
		int l = 0;
	
		sn = request_info.script_name;
		pi = request_info.path_info;
		if (sn)
			l += strlen(sn);
		if (pi)
			l += strlen(pi);
		tmp.value.strval = emalloc(l+1);
		sprintf(tmp.value.strval, "%s%s", (sn ? sn : ""), (pi ? pi : "")); /* SAFE */
		tmp.strlen = strlen(tmp.value.strval);
		tmp.type = IS_STRING;
		hash_update(&symbol_table,"PHP_SELF",sizeof("PHP_SELF"),(void *) &tmp,sizeof(YYSTYPE),NULL);
	}
#endif		

	for (env=environ; env!=NULL && *env !=NULL; env++) {
		p = strchr(*env,'=');
		if (!p) {/* malformed entry? */
			continue;
		}
		t = estrndup(*env,p-*env);
		php3_str_tolower(t,p-*env);
		tmp.strlen = strlen(p+1);
		tmp.value.strval = estrndup(p+1,tmp.strlen);
		tmp.type = IS_STRING;
		if (hash_add(&symbol_table,t,p-*env+1,&tmp,sizeof(YYSTYPE),NULL)==FAILURE) {
			efree(tmp.value.strval);
		}
		efree(t);
	}

	/* need argc/argv support as well */
	_php3_build_argv(request_info.query_string);

	initialized |= INIT_ENVIRONMENT;
	
	return SUCCESS;
}

void _php3_build_argv(char *s) {
	YYSTYPE arr, *arr_ptr, tmp;
	int count=0;
	char *ss, *space;

	/* ok, we have something, create the array */

	/* FIXME - perhaps no need to check if it already exists at this stage? */
	if (hash_find(&symbol_table, "argv", sizeof("argv"), (void **) &arr_ptr) == FAILURE) {
		arr.value.ht = (HashTable *) emalloc(sizeof(HashTable));
		if (!arr.value.ht || hash_init(arr.value.ht, 0, NULL, YYSTYPE_DESTRUCTOR, 0) == FAILURE) {
			php3_error(E_WARNING, "Unable to create argv array");
		} else {
			arr.type = IS_ARRAY;
			hash_update(&symbol_table, "argv", sizeof("argv"), &arr, sizeof(YYSTYPE),NULL);
		}
	} else {
		arr = *arr_ptr;
	}
	/* now pick out individual entries */
	ss=s;
	while(ss) {
		space=strchr(ss,'+');
		if(space) {
			*space='\0';
		}
		/* auto-type */
		tmp.type = IS_STRING;
		tmp.strlen=strlen(ss);
		tmp.value.strval = estrndup(ss,tmp.strlen);
		count++;
		if(hash_next_index_insert(arr.value.ht,&tmp,sizeof(YYSTYPE),NULL)==FAILURE) {
			if(tmp.type==IS_STRING) efree(tmp.value.strval);
		}
		if(space) {
			*space='+';
			ss=space+1;
		} else {
			ss=space;
		}
	}
	tmp.value.lval = count;
	tmp.type = IS_LONG;
	hash_add(&symbol_table,"argc",sizeof("argc"),&tmp,sizeof(YYSTYPE),NULL);
}	

#if DISPLAY_SOURCE_SUPPORT
void html_putc(char c)
{
	switch(c) {
		case '\n':
			PUTS("<br>\n");
			break;
		case '<':
			PUTS("&lt;");
			break;
		case ' ':
			PUTS("&nbsp; ");
			break;
		case '\t':
			PUTS("&nbsp; &nbsp; &nbsp; &nbsp; ");
		default:
			PUTC(c);
			break;
	}
}
#endif


#if CGI_BINARY

static void
_php3_usage(char *argv0)
{
	char *prog;

	prog = strrchr(argv0, '/');
	if (prog) {
		prog++;
	} else {
		prog = "php";
	}

	php3_printf("Usage: %s [-q] [-h]"
#if DISPLAY_SOURCE_SUPPORT
				" [-s]"
#endif
				" [-v] [-i] [-f <file>] | "
				"{<file> [args...]}\n"
				"  -q       Quiet-mode.  Suppress HTTP Header output.\n"
#if DISPLAY_SOURCE_SUPPORT
			 	"  -s       Display colour syntax highlighted source.\n"
#endif
				"  -f<file> Parse <file>.  Implies `-q'\n"
				"  -v       Version number\n"
				"  -p       Pretokenize a script (creates a .php3p file)\n"
				"  -e       Execute a pretokenized (.php3p) script\n"
				"  -i       PHP information\n"
				"  -h       This help\n", prog);
}


int main(int argc, char *argv[])
{
	int cgi = 0, arg = 1, c, i, len;
	FILE *in = NULL;
	char *s;
#if DISPLAY_SOURCE_SUPPORT
	int display_source_mode = 0;
#endif

	if (php3_module_startup()==FAILURE || php3_request_startup()==FAILURE) {
		return FAILURE;
	}

	php3_TreatHeaders();

	while ((c = getopt(argc, argv, "f:qvishpe?v")) != -1) {
		switch (c) {
			case 'f':
				request_info.filename = estrdup(optarg);
				break;
			case 'q':
				php3_noheader();
				break;
			case 'v':
				php3_printf("%s\n", PHP_VERSION);
				exit(1);
				break;
			case 'i':
				_php3_info();
				exit(1);
				break;
			case 'p': /* preprocess */
				php3_preprocess=1;
				php3_noheader();
				break;
			case 'e': /* execute preprocessed script */
				php3_preprocess=2;
				break;
#if DISPLAY_SOURCE_SUPPORT
			case 's':
				display_source_mode = 1;
				break;
#endif
			case 'h':
			case '?':
				_php3_usage(argv[0]);
				exit(1);
				break;
			default:
				php3_printf("Warning: unrecognized option `-%c'\n", c);
				break;
		}
		arg++;
	}

	if (request_info.path_info) {
		cgi = 1;
	} else if(!request_info.query_string) {
		for(i=arg,len=0; i<argc; i++) {
			len+=strlen(argv[i])+1;
		}
		s = malloc(len*sizeof(char)+1); /* leak - but only for command line version, so ok */
		*s='\0';                        /* we are pretending it came from the environment  */
		s[len-1]='\0';
		for(i=arg,len=0; i<argc; i++) {
			strcat(s,argv[i]);
			if(i<(argc-1)) strcat(s,"+");	
		}
		request_info.query_string = s;
	}
	if (request_info.filename != NULL) {
		in = php3_OpenFile(request_info.filename);
	} else if (!cgi && argc > arg) {
		request_info.filename = estrdup(argv[arg]);
		in = php3_OpenFile(request_info.filename);
	} else if (cgi) {
		in = php3_OpenFile(NULL);
	}
	if (cgi && !in) {
		php3_printf("No input file specified.\n");
		php3_request_shutdown((void *)0);
		php3_module_shutdown();
	} else if (in) {
 		/* #!php support */
 		c = fgetc(in);	
 		if (c == '#') {
 			while(c != 10 && c != 13) {
				c = fgetc(in);  /* skip to end of line */
			}
 		} else {
			rewind(in);
		}
		phpin = in;
		initialized |= INIT_SCANNER;
		phprestart(phpin);
	}

#if DISPLAY_SOURCE_SUPPORT
	if (display_source_mode) {
		Execute=0;
		ExecuteFlag=DONT_EXECUTE;
		php3_display_source=1;
		if(!php3_header(0,NULL)) exit(0);
		PUTS("<html><head><title>Source for ");
		PUTS(request_info.filename);
		PUTS("</title></head><body bgcolor=\"");
		PUTS(php3_ini.highlight_bg);
		PUTS("\" text=\"");
		PUTS(php3_ini.highlight_html);
		PUTS("\">\n"); /* color: seashell */
	}
#else
	if (display_source_mode) {
		if(php3_header(0,NULL))
			php3_printf("No display-source support compiled.<br>\n");
		return 0;
	}
#endif

	if (php3_display_source && php3_preprocess==1) {
		php3_printf("Can't preprocess while displaying source.<br>\n");
		return 0;
	}
	
	if (php3_preprocess==2) {
		tcm_load(&token_cache_manager);
		php3_preprocess=0;
	}

	if (!php3_preprocess) {
		(void) phpparse();
	} else {
		YYSTYPE yylval;
		
		while (phplex(&yylval));  /* create the token cache */
		tcm_save(&token_cache_manager);
	}
	
#if DISPLAY_SOURCE_SUPPORT
	if (php3_display_source) {
		php3_printf("\n</html>\n");
	}
#endif
	
	if (initialized) {
		php3_header(0, NULL);	/* Make sure headers have been sent */
		php3_request_shutdown((void *)0);
		php3_module_shutdown();
		return SUCCESS;
	} else {
		return FAILURE;
	}
}
#endif /* CGI_BINARY */


#if APACHE
PHPAPI int apache_php3_module_main(request_rec * r, int fd, int display_source_mode)
{
	FILE *in = NULL;

	php3_rqst = r;

	if (php3_request_startup() == FAILURE) {
		return FAILURE;
	}

	php3_TreatHeaders();	
	in = fdopen(fd, "r");
	if (in) {
		phpin = in;
		phprestart(phpin);
		initialized |= INIT_SCANNER;
		hash_index_update(&include_names, 0, (void *) &request_info.filename, sizeof(char *), NULL);
	}

	
#if DISPLAY_SOURCE_SUPPORT
	if (display_source_mode) {
		Execute=0;
		ExecuteFlag=DONT_EXECUTE;
		php3_display_source=1;
		if(!php3_header(0,NULL)) return(OK);
		PUTS("<html><head><title>Source for ");
		PUTS(r->uri);
		PUTS("</title></head><body bgcolor=\"");
		PUTS(php3_ini.highlight_bg);
		PUTS("\" text=\"");
		PUTS(php3_ini.highlight_html);
		PUTS("\">\n"); /* color: seashell */
	}
#else
	if (display_source_mode) {
		if(php3_header(0,NULL))
			php3_printf("No display-source support compiled.<br>\n");
		return OK;
	}
#endif

	(void) phpparse();

#if DISPLAY_SOURCE_SUPPORT
	if (php3_display_source) {
		php3_printf("\n</html>\n");
	}
#endif
	
	if (initialized) {
		php3_header(0, NULL);	/* Make sure headers have been sent */
	}
	return (OK);
}
#endif  /* APACHE */

#if PHP_ISAPI
int isapi_php3_module_main(LPEXTENSION_CONTROL_BLOCK lpEcb)
{
	int cgi = 1;
	FILE *in = NULL;

	lpPHPcb = lpEcb;

	if (php3_module_startup()==FAILURE) {
		return FAILURE;
	}

	if (php3_request_startup() == FAILURE) {
		return FAILURE;
	}

	in = php3_OpenFile(request_info.filename);
	if (in) {
		phpin = in;
		phprestart(phpin);
		initialized |= INIT_SCANNER;
		hash_index_update(&include_names, 0, (void *) &request_info.filename, sizeof(char *), NULL);
	}

	(void) phpparse();
	
	if (initialized) {
		php3_header(0, NULL);	/* Make sure headers have been sent */
		php3_request_shutdown((void *)lpPHPcb);
		php3_module_shutdown();
		return SUCCESS;
	} else {
		return FAILURE;
	}
}
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */

