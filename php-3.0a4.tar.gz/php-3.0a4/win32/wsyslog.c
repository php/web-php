/*
 * This file maps syslog calls to windows EventLogs
 */

#include "parser.h" /*php specific*/
#include "syslog.h"
#include <stdio.h>
#include <process.h>

void *loghandle;
int lopt, fac;

void	closelog (void)
{
	void *errorbuf;

	if(!DeregisterEventSource(loghandle)){
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		    NULL,
		    GetLastError(),
		    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		    (LPTSTR) &errorbuf,
		    0,
		    NULL 
			);
		fprintf(stderr,"\nClosing Event Log Failed!\nError: %s\n",errorbuf);
	}
}

void	openlog (const char *ident, int logopt, int facility)
{
	void *errorbuf;

	loghandle = RegisterEventSource(NULL, ident);
	if (!loghandle){
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		    NULL,
		    GetLastError(),
		    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		    (LPTSTR) &errorbuf,
		    0,
		    NULL 
			);
		fprintf(stderr,"\nOpening Event Log Failed!\nError: %s\n",errorbuf);
	}
	lopt = logopt;
	fac = facility;
}

void	syslog (int priority, const char *message, ...)
{
	char buffer[1024 * 4];
	void *errorbuf;

	if (lopt & LOG_PID){
		sprintf(buffer,"pid: %d\n%s",getpid(),message);
	} else {
		sprintf(buffer,"%s",message);
	}

	if(!ReportEvent(loghandle, 
		priority,
		0,			//no category
		0, 
		NULL,		// no user security
		1,			// treat message as a single string
		0,			// no date
		(LPCSTR *)buffer,
		(void *)NULL))
	{
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		    NULL,
		    GetLastError(),
		    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		    (LPTSTR) &errorbuf,
		    0,
		    NULL 
			);
		fprintf(stderr,"\nLogging to Event Log Failed!\nError: %s\n",errorbuf);
	}

	if (lopt & LOG_PERROR){
		fprintf(stderr,"%s\n",buffer);
	}

}

