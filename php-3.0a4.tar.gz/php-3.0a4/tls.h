#include "parser.h"

typedef struct php3_globals{
	/*all globals must be here*/
	/*alloc.c*/
	mem_header *head;
	/*debbuger.c*/
	int debug_socket = 0;
	char *myhostname = NULL;
#if NSAPI && MSVC5
	int mypid=0;
#else
	pid_t mypid = 0;
#endif
	char *currenttime = NULL;
	Stack function_state_stack;
	/*getopt.c*/
	char *optarg;
	int optind;
	int opterr;
	int optopt;
	/*highlite.c*/
	char *phptext;
	int phpleng;
	int ExecuteFlag;
	int Execute;
	/*internal_functions.c*/
	HashTable list_destructors;
	HashTable module_registry;
	/*language-parser.tab.c*/
	HashTable symbol_table;
	HashTable function_table;
	HashTable include_names;
	TokenCacheManager token_cache_manager;
	Stack css;
	Stack for_stack;
	Stack input_source_stack;
	Stack function_state_stack;     
	Stack switch_stack;
	Stack variable_unassign_stack; 
	HashTable *active_symbol_table;  
	int Execute;  
	int ExecuteFlag;
	int current_lineno;            
	int include_count;
	FunctionState function_state;
	char *class_name=NULL;
	HashTable *class_symbol_table=NULL;
	YYSTYPE *data,return_value,globals;
	unsigned int param_index;
	YYSTYPE *array_ptr;
	extern int shutdown_requested;
	/*main.c*/
	int error_reporting
	int tmp_error_reporting;
	int shutdown_requested;
#if APACHE
	request_rec *php3_rqst=NULL;
#endif
#if PHP_ISAPI
	LPEXTENSION_CONTROL_BLOCK lpPHPcb;
#endif
	char *strtok_string;
	FILE *phpin;
	/*request_info.c*/
	php3_request_info request_info;
	/*token_cache.c*/
	YYSTYPE phplval;
	TokenCache *tc; /*active token cache */
	
	/*Functions*/
	/*dir.c*/
	int dirp_id = 0;
	int le_dirp;
	/*file.c*/
	int fgetss_state = 0;
	int le_fp;
	int le_pp;
	/*filestat.c*/
	char *CurrentStatFile=NULL;
#if MSVC5
	unsigned int CurrentStatLength=0;
#else
	int CurrentStatLength=0;
#endif
	struct stat sb;
	/*head.c*/
	int php3_HeaderPrinted = 0;
	int php3_PrintHeader = 1;
	CookieList *top = NULL;
	char *cont_type = NULL;
	int header_called = 0;
	/*info.c*/
#if APACHE
extern module *top_module;
#endif
	/*pageinfo.c*/
	long page_uid   = -1;
	long page_inode = -1;
	long page_mtime = -1;
	/*post.c*/
	int php3_track_vars;
#if WIN32|WINNT
	/*pwd.c*/
	struct passwd pw;	/* should we return a malloc()'d structure   */
	char *home_dir = ".";	/* we feel (no|every)where at home */
	char *login_shell = "not command.com!";
	/*sendmail.c*/
	char Buffer[MAIL_BUFFER_SIZE]; 
	SOCKET sc;
	WSADATA Data;
	struct hostent *adr;
	SOCKADDR_IN sin;
	int WinsockStarted;
	char AppName[MAX_APPNAME_LENGHT];
	char MailHost[HOST_NAME_LEN];
	char LocalHost[HOST_NAME_LEN];
	/*winsyslog.c*/
	void *loghandle;
	int lopt;
	intfac;
#endif

} php3_globals;

#if THREAD_SAFE
extern DWORD TlsIndex;

extern int tls_create(void);
extern int tls_destroy(void);
#endif

extern int tls_startup(void);
extern int tls_shutdown(void);
