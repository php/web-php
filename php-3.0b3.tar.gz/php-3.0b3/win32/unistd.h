extern void usleep(unsigned int useconds);
