/* NSAPI INCLUDES */
#ifndef CHAR
#include "base/pblock.h"
#include "base/session.h"
#include "frame/req.h"
#include "base/util.h"       /* is_mozilla, getline */
#include "frame/protocol.h"  /* protocol_start_response */
#include "frame/http.h"
#include "base/file.h"       /* system_fopenRO */
#include "base/buffer.h"     /* filebuf */
#include "frame/log.h"       /* log_error */
#include "base/crit.h"
#include "base/daemon.h"
#define BLOCK_INTERRUPTIONS crit_enter(hLock)
#define UNBLOCK_INTERRUPTIONS crit_exit(hLock)
THREAD_LS extern pblock *nspb;
THREAD_LS extern Session *nssn;
THREAD_LS extern Request *nsrq;
#endif
extern void nsapi_writeclient(char *, int);
extern void nsapi_putc(char c);
#define PUTS(a) nsapi_writeclient(a,strlen(a))
#define PUTC(a) nsapi_putc(a)
#define PHPWRITE(a,n) nsapi_writeclient(a, n)
#define WIN32_SERVER_MOD 1
