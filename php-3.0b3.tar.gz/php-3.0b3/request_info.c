/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997,1998 PHP Development Team (See Credits file)      |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Author: Jim Winstead (jimw@php.net)                                  |
   +----------------------------------------------------------------------+
 */

#ifdef THREAD_SAFE
#include "tls.h"
#endif
#include "parser.h"

#ifndef THREAD_SAFE
php3_request_info request_info;
#endif

#if CGI_BINARY
int php3_init_request_info(void *conf) {
	char *buf;
	TLS_VARS;

	/* We always need to emalloc() filename, since it gets placed into
	   the include file hash table, and gets freed with that table.
	   Notice that this means that we don't need to efree() it in
	   php3_destroy_request_info()! */
	GLOBAL(request_info).filename = NULL;
	GLOBAL(request_info).path_info = getenv("PATH_INFO");
	GLOBAL(request_info).path_translated = getenv("PATH_TRANSLATED");
	GLOBAL(request_info).query_string = getenv("QUERY_STRING");
	GLOBAL(request_info).current_user = NULL;
	GLOBAL(request_info).current_user_length=0;
	GLOBAL(request_info).request_method = getenv("REQUEST_METHOD");
	GLOBAL(request_info).script_name = getenv("SCRIPT_NAME");
	buf = getenv("CONTENT_LENGTH");
	GLOBAL(request_info).content_length = (buf ? atoi(buf) : 0);
	GLOBAL(request_info).content_type = getenv("CONTENT_TYPE");
	GLOBAL(request_info).cookies = getenv("HTTP_COOKIE");

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	TLS_VARS;
	STR_FREE(GLOBAL(request_info).current_user);
	return SUCCESS;
}
#endif

#if APACHE
int php3_init_request_info(void *conf) {
	char *buf;
	TLS_VARS;

	/* see above for why this has to be estrdup()'d */
	GLOBAL(request_info).filename = estrdup(GLOBAL(php3_rqst)->filename);
	GLOBAL(request_info).request_method = GLOBAL(php3_rqst)->method;
	GLOBAL(request_info).query_string = GLOBAL(php3_rqst)->args;
	GLOBAL(request_info).content_type = table_get(GLOBAL(php3_rqst)->subprocess_env, "CONTENT_TYPE");

	buf = table_get(GLOBAL(php3_rqst)->subprocess_env, "CONTENT_LENGTH");
	GLOBAL(request_info).content_length = (buf ? atoi(buf) : 0);

	GLOBAL(request_info).cookies = table_get(GLOBAL(php3_rqst)->subprocess_env, "HTTP_COOKIE");

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	/* see above for why we don't want to efree() request_info.filename */
	return SUCCESS;
}
#endif

#if NSAPI
int php3_init_request_info(void *conf) {
	Request *nsrq = (Request *)conf;
	
	request_info.path_info = pblock_findval("path-info",nsrq->vars);
	request_info.path_translated = pblock_findval("path",nsrq->vars);
	request_info.filename = estrdup(request_info.path_translated);
	request_info.query_string = pblock_findval("query", nsrq->vars); 
	request_info.request_method = pblock_findval("method",nsrq->reqpb);
	request_info.script_name = pblock_findval("path",nsrq->vars);
	request_info.content_length = atoi(pblock_findval("content-length",nsrq->headers));
	request_info.content_type =  pblock_findval("content-type",nsrq->srvhdrs);
	request_header("cookie", &(request_info.cookies), nssn,nsrq);

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	/* see above for why we don't want to efree() request_info.filename */
	return SUCCESS;
}
#endif

#if PHP_ISAPI
int php3_init_request_info(void *conf) {
	char *buf;
	TLS_VARS;

	GLOBAL(request_info).path_info = GLOBAL(lpPHPcb)->lpszPathInfo;
	GLOBAL(request_info).path_translated = GLOBAL(lpPHPcb)->lpszPathTranslated;
	/* see above for why we have to estrdup() this next one */
	GLOBAL(request_info).filename = estrdup(GLOBAL(request_info).path_translated);
	GLOBAL(request_info).query_string = GLOBAL(lpPHPcb)->lpszQueryString;
	GLOBAL(request_info).request_method = GLOBAL(lpPHPcb)->lpszMethod;
	GLOBAL(request_info).script_name = isapi_getenv(GLOBAL(lpPHPcb),"SCRIPT_NAME");

	buf = isapi_getenv(GLOBAL(lpPHPcb),"CONTENT_LENGTH");
	GLOBAL(request_info).content_length = (buf ? atoi(buf) : 0);

	GLOBAL(request_info).content_type = GLOBAL(lpPHPcb)->lpszContentType;
	GLOBAL(request_info).cookies = isapi_getenv(GLOBAL(lpPHPcb),"HTTP_COOKIE");

	return SUCCESS;
}

int php3_destroy_request_info(void *conf) {
	/* see above for why we don't want to efree() request_info.filename */
	return SUCCESS;
}
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
