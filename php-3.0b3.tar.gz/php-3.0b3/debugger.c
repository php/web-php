/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997,1998 PHP Development Team (See Credits file)      |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Stig S�ther Bakken <ssb@guardian.no>                        |
   +----------------------------------------------------------------------+
 */

#if THREAD_SAFE
#include "tls.h"
#endif

#include "parser.h"
#include "internal_functions.h"
#include "modules.h"

#if PHP_DEBUGGER

#include <sys/types.h>
#if MSVC5
#include <winsock.h>
#include <errno.h>
#include <process.h>
#include "win32/time.h"
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/errno.h>
#include <netdb.h>
#endif
#if HAVE_UNISTD_H
#include <unistd.h>
#endif
#if HAVE_SYS_TIME_H
#include <sys/time.h>
#endif
#include <time.h>
#include "php3_debugger.h"

#ifndef THREAD_SAFE
static int debug_socket = 0;
static char *myhostname = NULL;
int debugger_on=0;
#if NSAPI && MSVC5
static int mypid=0;
#else
static pid_t mypid = 0;
#endif
static char *currenttime = NULL;

extern Stack function_state_stack;
#endif
/*
 * Converts a host name to an IP address.
 */
static int lookup_hostname(const char *addr)
{
	uint r;
	struct hostent *host_info;

	r = inet_addr(addr);
	if (r == (uint) - 1) {
		host_info = gethostbyname(addr);
		if (host_info == 0) {
			/* Error: unknown host */
			return -1;
		}
		memcpy((char *) &r, host_info->h_addr, host_info->h_length);
	}
	return r;
}

/*
 * Connects to a specified host and port, and returns a file
 * descriptor for the connection.
 */
static int create_debug_socket(const char *hostname, int dport)
{

	struct sockaddr_in address;
	int err = -1;
	int sockfd;

	memset(&address, 0, sizeof(address));
	address.sin_addr.s_addr = lookup_hostname(hostname);
	address.sin_family = AF_INET;
#if MSVC5
	address.sin_port = htons((unsigned short)dport);
#else
	address.sin_port = htons(dport);
#endif

	sockfd = socket(address.sin_family, SOCK_STREAM, 0);
	if (sockfd < 0) {
#if WIN32|WINNT
		printf("\nUnable to open socket. %d\n",WSAGetLastError());
#else
		perror("socket");
#endif
		return -1;
	}
	while ((err = connect(sockfd, (struct sockaddr *) &address,
						  sizeof(address))) < 0 && errno == EAGAIN);

	if (err < 0) {
		/* LOG(0, ("ERROR: connect %s.%d : %s", addr, dport,
		   strerror(errno))); */
#if WIN32|WINNT
		printf("\nCannot Connect. %d\n",WSAGetLastError());
#else
		perror("connect");
#endif
		close(sockfd);
		return -1;
	}
	return sockfd;
}


static char *
find_hostname(void)
{
	char tmpname[33];
	int err;

	memset(tmpname, 0, sizeof(tmpname));
	err = gethostname(tmpname, sizeof(tmpname) - 1);
	if (err == -1) {
		return NULL;
	}
	return (char *) estrdup(tmpname);
}


static char *
get_current_time(void)
{
	/*THREADX*/
#ifndef THREAD_SAFE
	static char debug_timebuf[50];
#endif
	char microbuf[10];
#if HAVE_GETTIMEOFDAY
	struct timeval tv;
	struct timezone tz;
#endif
	const struct tm *tm;
	size_t len;
	time_t t;
	TLS_VARS;

	memset(STATIC(debug_timebuf), 0, sizeof(STATIC(debug_timebuf)));
	t = time(NULL);
	tm = localtime((const time_t *) &t);
	len = strftime(STATIC(debug_timebuf), (sizeof(STATIC(debug_timebuf)) - sizeof(microbuf) - 1),
				   "%Y-%m-%d %H:%M", tm);

#if HAVE_GETTIMEOFDAY
	gettimeofday(&tv, &tz);
	snprintf(microbuf, sizeof(microbuf) - 1, ":%06d", tv.tv_usec);
	strcat(STATIC(debug_timebuf), microbuf);
#endif
	return STATIC(debug_timebuf);
}


static void debugger_message(char *msg)
{
	TLS_VARS;
	
	if (GLOBAL(debug_socket) > 0) {
#if WIN32|WINNT
		send(GLOBAL(debug_socket), msg, strlen(msg),0);
#else
		write(GLOBAL(debug_socket), msg, strlen(msg));
#endif
	}
}

static void debugger_send_string(char *field, char *data)
{
	char buf[1025];
	TLS_VARS;
	
	snprintf(buf, 1024, "%s %s(%d) %s: %s\n\0", GLOBAL(currenttime),
			 GLOBAL(myhostname), GLOBAL(mypid), field, data);
	debugger_message(buf);
}

static void debugger_send_int(char *field, int data)
{
	char buf[1025];
	TLS_VARS;
	
	snprintf(buf, 1024, "%s %s(%d) %s: %d\n\0", GLOBAL(currenttime),
			 GLOBAL(myhostname), GLOBAL(mypid), field, data);
	debugger_message(buf);
}


/*
 * Functions accessible from other object files:
 */


int php3_start_debugger(char *ip)
{
	TLS_VARS;
	
	if(!ip){
	GLOBAL(debug_socket) = create_debug_socket(php3_ini.debugger_host, php3_ini.debugger_port);
	}else{
	GLOBAL(debug_socket) = create_debug_socket(ip, php3_ini.debugger_port);
	}
    /*printf("php3_init_debugger: debug_socket=%d\n", debug_socket); */

	if (GLOBAL(debug_socket) < 0) {
		return FAILURE;
	}
	GLOBAL(myhostname) = find_hostname();
	GLOBAL(mypid) = getpid();

	return SUCCESS;
}


int php3_shutdown_debugger(void)
{
	TLS_VARS;
	
	if (GLOBAL(debug_socket) > 0) {
#if WIN32|WINNT
		closesocket(GLOBAL(debug_socket));
#else
		close(GLOBAL(debug_socket));
#endif
	}
	if (GLOBAL(myhostname)) {
		efree(GLOBAL(myhostname));
	}
	return SUCCESS;
}


void php3_debugger_error(char *message, int type, char *filename, int lineno)
{
	char label[20];
	char errtype[10];
	Stack *stack_copy;
	FunctionState *funcstate;
	int copysize, depth;
	TLS_VARS;

	GLOBAL(currenttime) = get_current_time();

	if (GLOBAL(debug_socket) <= 0) {
		return;
	}
	switch (type) {
		case E_WARNING:
			strcpy(errtype, "warning");
			break;
		case E_ERROR:
			strcpy(errtype, "error");
			break;
		case E_PARSE:
			strcpy(errtype, "parse");
			break;
		case E_NOTICE:
			strcpy(errtype, "notice");
			break;
		case E_CORE_ERROR:
			strcpy(errtype, "core-error");
			break;
		case E_CORE_WARNING:
			strcpy(errtype, "core-warning");
			break;
		default:
			strcpy(errtype, "unknown");
			break;
	}
	debugger_send_string("start", errtype);
	debugger_send_string("file", filename);
	debugger_send_int("line", lineno);
	debugger_send_string("msg", message);

	/* Copy the function state stack so we can fiddle with in
	 * peace.  If there are any cleaner ways to do this, please
	 * let me know :)
	 * -Stig
	 */
	copysize = GLOBAL(function_state_stack).max * sizeof(FunctionState **);
	stack_copy = emalloc(copysize);
	if (stack_copy) {
		memcpy(stack_copy, &GLOBAL(function_state_stack), copysize);
		stack_push(stack_copy, &GLOBAL(function_state), sizeof(FunctionState));
		depth = stack_copy->top;
		debugger_send_int("depth", depth);
		while (!stack_is_empty(stack_copy) && depth-- > 0) {
			stack_top(stack_copy, (void **) &funcstate);

			if (funcstate->filename) {
				snprintf(label, sizeof(label) - 1, "file-%d", depth);
				debugger_send_string(label, funcstate->filename);
			}
			if (funcstate->lineno) {
				snprintf(label, sizeof(label) - 1, "line-%d", depth);
				debugger_send_int(label, funcstate->lineno);
			}
			snprintf(label, sizeof(label) - 1, "function-%d", depth);
			debugger_send_string(label, funcstate->function_name);

			stack_del_top(stack_copy);
		}
		efree(stack_copy);
	}
	debugger_send_string("end", errtype);
}

/*FIXME
  we also need a way to dissable the cgi timmer so we dont
  time out while debugging.
*/
void flag_debugger_on(INTERNAL_FUNCTION_PARAMETERS){
	YYSTYPE *ip;
	TLS_VARS;
	
	if (ARG_COUNT(ht)!=1 || getParameters(ht,1,&ip) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string(ip);
	if(!GLOBAL(debugger_on)){
		GLOBAL(debugger_on)=1;
		if(php3_start_debugger(ip->value.strval)==FAILURE){
			GLOBAL(debugger_on)=0;
		php3_error(E_ERROR, "Debugger Connect Failed!\n");
		}
	}
}

void flag_debugger_off(INTERNAL_FUNCTION_PARAMETERS){
	TLS_VARS;
	
	if(GLOBAL(debugger_on)){
		GLOBAL(debugger_on)=0;
		php3_shutdown_debugger();
	}
}


/*FIXME
  this function gets called after the execution of each
  line, if the debugger flag is set

  we want to send various info that can be used by a full
  debugger like line number and variable values.

  we will pause and wait for acknowledgement from the
  debugger, so the debugger can do stepping.

*/
void send_debug_info(void){

}

function_entry debugger_functions[] = {
	{"debug_on",flag_debugger_on, NULL},
	{"debug_off",flag_debugger_off, NULL},
	{NULL,NULL,NULL}
};

/*we'll call the shutdown just in case someone
  doesnt do it in their script.  Doesnt hurt eitherway*/
php3_module_entry debugger_module_entry = {
	"Debugger", debugger_functions, NULL, NULL, NULL, php3_shutdown_debugger, NULL, 0, 0, 0, NULL
};

#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
