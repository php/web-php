#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	STRING	258
#define	ENCAPSULATED_STRING	259
#define	SECTION	260
#define	CFG_TRUE	261
#define	CFG_FALSE	262
#define	EXTENSION	263

