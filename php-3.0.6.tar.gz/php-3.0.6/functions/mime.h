#ifndef _MIME_H
#define _MIME_H

extern void php3_mime_split(char *buf, int cnt, char *boundary, pval *http_post_vars);

#endif
