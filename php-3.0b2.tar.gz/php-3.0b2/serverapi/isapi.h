
#include <httpext.h>

#ifndef THREAD_SAFE
extern LPEXTENSION_CONTROL_BLOCK lpPHPcb;
#endif
extern char *isapi_getenv(LPEXTENSION_CONTROL_BLOCK,char *);    
/* these need to be done */
#define BLOCK_INTERRUPTIONS(a)
#define UNBLOCK_INTERRUPTIONS(a)

extern void isapi_puts(char *string,LPEXTENSION_CONTROL_BLOCK lpPHPcb); /* located in isapi.c */
extern void isapi_putc(char character,LPEXTENSION_CONTROL_BLOCK lpPHPcb);
#if !defined(THREAD_SAFE) && !defined(COMPILE_DL)
#define PUTS(a) isapi_puts(a,GLOBAL(lpPHPcb))
#define PUTC(a) isapi_putc(a,GLOBAL(lpPHPcb))
#define PHPWRITE(a,n) GLOBAL(lpPHPcb)->WriteClient(GLOBAL(lpPHPcb)->ConnID,(a),&n,0)
#endif
#define WIN32_SERVER_MOD 1
