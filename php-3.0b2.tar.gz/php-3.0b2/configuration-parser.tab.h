#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	STRING	258
#define	ENCAPSULATED_STRING	259
#define	SECTION	260
#define	TRUE	261
#define	FALSE	262
#define	EXTENSION	263

