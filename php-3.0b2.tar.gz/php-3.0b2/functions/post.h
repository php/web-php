/* $Id: post.h,v 1.15 1997/12/13 01:28:01 zeev Exp $ */

#ifndef _POST_H
#define _POST_H

#define PARSE_POST 0
#define PARSE_GET 1
#define PARSE_COOKIE 2
#define PARSE_STRING 3

extern void php3_treat_data(int arg, char *str);
extern void php3_TreatHeaders(void);
extern void _php3_parse_gpc_data(char *, char *, YYSTYPE *track_vars_array);

extern int php3_track_vars;

extern void php3_parsestr(INTERNAL_FUNCTION_PARAMETERS);

#endif
