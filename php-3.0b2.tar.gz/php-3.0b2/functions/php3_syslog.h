#if HAVE_SYSLOG_H
extern php3_module_entry syslog_module_entry;
#define syslog_module_ptr &syslog_module_entry

extern int php3_init_syslog(INITFUNCARG);
extern void php3_openlog(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_syslog(INTERNAL_FUNCTION_PARAMETERS);
extern void php3_closelog(INTERNAL_FUNCTION_PARAMETERS);

#else
#define syslog_module_ptr NULL
#endif
