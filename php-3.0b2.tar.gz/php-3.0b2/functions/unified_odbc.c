/*
   +----------------------------------------------------------------------+
   | PHP HTML Embedded Scripting Language Version 3.0                     |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997 PHP Development Team (See Credits file)           |
   +----------------------------------------------------------------------+
   | This program is free software; you can redistribute it and/or modify |
   | it under the terms of the GNU General Public License as published by |
   | the Free Software Foundation; either version 2 of the License, or    |
   | (at your option) any later version.                                  |
   |                                                                      |
   | This program is distributed in the hope that it will be useful,      |
   | but WITHOUT ANY WARRANTY; without even the implied warranty of       |
   | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        |
   | GNU General Public License for more details.                         |
   |                                                                      |
   | You should have received a copy of the GNU General Public License    |
   | along with this program; if not, write to the Free Software          |
   | Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.            |
   +----------------------------------------------------------------------+
   | Authors: Stig S�ther Bakken <ssb@guardian.no>                        |
   |          Andreas Karajannis <kara@bibo.met.fu-berlin.de>             |
   +----------------------------------------------------------------------+
 */

/* This file is based on the Adabas D extension.
 *
 * Encountered limitations:
 *
 * - Solid's library does not have SQLExtendedFetch, so the "fetch from
 *   any row" feature from the Adabas D extension has been removed.
 *
 */
#ifdef THREAD_SAFE
#include "tls.h"
#endif
#ifndef MSVC5
#include "config.h"
#include "build-defs.h"
#endif

#include "parser.h"
#include "internal_functions.h"
#include "php3_string.h"
#include "php3_unified_odbc.h"
#include "head.h"

#if HAVE_UODBC

void *uodbc_mutex;

#ifdef THREAD_SAFE
DWORD UODBCTls;
static int numthreads=0;

typedef struct uodbc_global_struct{
uodbc_module php3_uodbc_module;
}uodbc_global_struct;

#define UODBC_GLOBAL(a) uodbc_globals->a

#define UODBC_TLS_VARS \
	uodbc_global_struct *uodbc_globals; \
	uodbc_globals=TlsGetValue(UODBCTls); 

#else
uodbc_module php3_uodbc_module;
#define UODBC_GLOBAL(a) a
#define UODBC_TLS_VARS
#endif

static unsigned char force_ref_2nd_arg[] = { 2, BYREF_NONE, BYREF_FORCE };

function_entry uodbc_functions[] = {
    { "odbc_autocommit",  php3_uodbc_autocommit,    NULL},
    { "odbc_close",       php3_uodbc_close,         NULL},
    { "odbc_close_all",   php3_uodbc_close_all,     NULL},
    { "odbc_commit",      php3_uodbc_commit,        NULL},
    { "odbc_connect",     php3_uodbc_connect,       NULL},
    { "odbc_exec",        php3_uodbc_exec,          NULL},
    { "odbc_fetch_row",   php3_uodbc_fetch_row,     NULL},
	{ "odbc_fetch_into",  php3_uodbc_fetch_into,    force_ref_2nd_arg },
    { "odbc_field_len",   php3_uodbc_field_len,     NULL},
    { "odbc_field_name",  php3_uodbc_field_name,    NULL},
    { "odbc_field_type",  php3_uodbc_field_type,    NULL},
    { "odbc_free_result", php3_uodbc_free_result,   NULL},
    { "odbc_num_fields",  php3_uodbc_num_fields,    NULL},
    { "odbc_num_rows",    php3_uodbc_num_rows,      NULL},
    { "odbc_result",      php3_uodbc_result,        NULL},
    { "odbc_result_all",  php3_uodbc_result_all,    NULL},
    { "odbc_rollback",    php3_uodbc_rollback,      NULL},
    { "odbc_exec_cursor", php3_uodbc_exec_cursor,   NULL},

    { NULL, NULL, NULL }
};

php3_module_entry uodbc_module_entry = {
    "uODBC", uodbc_functions, php3_minit_uodbc, php3_mshutdown_uodbc,
    php3_rinit_uodbc, NULL, php3_info_uodbc, 0, 0, 0, NULL
};

#if COMPILE_DL
php3_module_entry *get_module() { return &uodbc_module_entry; };
#if (WIN32|WINNT) && defined(THREAD_SAFE)

/*NOTE: You should have an odbc.def file where you
export DllMain*/
BOOL WINAPI DllMain(HANDLE hModule, 
                      DWORD  ul_reason_for_call, 
                      LPVOID lpReserved)
{
    switch( ul_reason_for_call ) {
    case DLL_PROCESS_ATTACH:
		if((UODBCTls=TlsAlloc())==0xFFFFFFFF){
			return 0;
		}
		break;    
    case DLL_THREAD_ATTACH:
		break;
    case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		if(!TlsFree(UODBCTls)){
			return 0;
		}
		break;
    }
    return 1;
}
#endif
#endif

#include "list.h"

/* {{{ _free_uodbc_result */

static void
_free_uodbc_result(uodbc_result *res)
{
	if (res) {
		if (res->values) {
			efree(res->values);
			res->values = NULL;
		}
		if (res->stmt) {
			SQLFreeStmt(res->stmt,SQL_DROP);
			res->stmt = NULL;
		}
		if (res->stmtUpdDel) {                                           /*VK*/
			SQLFreeStmt(res->stmtUpdDel,SQL_DROP);                       /*VK*/
			res->stmtUpdDel = NULL;                                      /*VK*/
		}                                                                /*VK*/
		efree(res);
		res = NULL;
	}
}

/* }}} */
/* {{{ _close_uodbc_connection */

static void
_close_uodbc_connection(uodbc_conn *conn)                                /*VK*/
{
	/* FIXME
	 * Closing a connection will fail if there are
	 * pending transactions
	 */
	UODBC_TLS_VARS;
	if ( conn ) {                                                        /*VK*/
		HashTable *list = conn->list;                                    /*VK*/
		uodbc_result *ptr;                                               /*VK*/
		int type;                                                        /*VK*/
		int i, nument = hash_next_free_element(list);                    /*VK*/
		for (i = 1; i < nument; i++) {                                   /*VK*/
			ptr = (uodbc_result *)php3_list_find(i, &type);              /*VK*/
			if(!ptr || type != UODBC_GLOBAL(php3_uodbc_module).le_result || ptr->conn != conn){ /*VK*/
				continue;                                                /*VK*/
			}                                                            /*VK*/
			php3_list_delete(i);                                         /*VK*/
		}                                                                /*VK*/
		SQLDisconnect(conn->hdbc);                                       /*VK*/
		SQLFreeConnect(conn->hdbc);                                      /*VK*/
		efree(conn);                                                     /*VK*/
		conn = NULL;
	}                                                                    /*VK*/
}

/* }}} */

/* {{{ php3_minit_uodbc */

int php3_minit_uodbc(INITFUNCARG) 
{
#ifdef THREAD_SAFE
	uodbc_global_struct *uodbc_globals;
#if !COMPILE_DL
#if WIN32|WINNT
	CREATE_MUTEX(uodbc_mutex,"UODBC_TLS");
#endif
#endif
#if !COMPILE_DL
	SET_MUTEX(uodbc_mutex)
	numthreads++;
	if(numthreads==1){
	if((UODBCTls=TlsAlloc())==0xFFFFFFFF){
		FREE_MUTEX(uodbc_mutex)
		return 0;
	}}
	FREE_MUTEX(uodbc_mutex)
#endif
	uodbc_globals = (uodbc_global_struct *) LocalAlloc(LPTR, sizeof(uodbc_global_struct)); 
	TlsSetValue(UODBCTls, (void *) uodbc_globals);
#endif
	SQLAllocEnv(&UODBC_GLOBAL(php3_uodbc_module).henv);
	
	cfg_get_string("uodbc.default_db",&UODBC_GLOBAL(php3_uodbc_module).defDB);
	cfg_get_string("uodbc.default_user",&UODBC_GLOBAL(php3_uodbc_module).defUser);
	cfg_get_string("uodbc.default_pw",&UODBC_GLOBAL(php3_uodbc_module).defPW);
	UODBC_GLOBAL(php3_uodbc_module).le_result = register_list_destructors(_free_uodbc_result, NULL);
	UODBC_GLOBAL(php3_uodbc_module).le_conn = register_list_destructors(_close_uodbc_connection, NULL);
	return SUCCESS;
}

/* }}} */
/* {{{ php3_rinit_uodbc */

int php3_rinit_uodbc(INITFUNCARG)
{
	UODBC_TLS_VARS;

	UODBC_GLOBAL(php3_uodbc_module).defConn = 0;
	return SUCCESS;
}

/* }}} */
/* {{{ php3_mshutdown_uodbc */

int php3_mshutdown_uodbc(void)
{
#ifdef THREAD_SAFE
	uodbc_global_struct *uodbc_globals;
	uodbc_globals = TlsGetValue(UODBCTls); 
#endif
	SQLFreeEnv(UODBC_GLOBAL(php3_uodbc_module).henv);
#ifdef THREAD_SAFE
	if (uodbc_globals != 0) 
		LocalFree((HLOCAL) uodbc_globals); 
#if !COMPILE_DL
	SET_MUTEX(uodbc_mutex)
	numthreads--;
	if(!numthreads){
	if(!TlsFree(UODBCTls)){
		FREE_MUTEX(uodbc_mutex)
		return 0;
	}}
	FREE_MUTEX(uodbc_mutex)
#endif
#endif
	return SUCCESS;
}

/* }}} */
/* {{{ php3_info_uodbc */

void php3_info_uodbc(void)
{
#if !defined(COMPILE_DL) && defined(THREAD_SAFE)
	TLS_VARS;
#endif
#if HAVE_SOLID
	PUTS("Unified ODBC Support active (compiled with Solid)");
#elif HAVE_ADABAS
	PUTS("Unified ODBC Support active (compiled with Adabas D)");
#elif HAVE_IODBC && !(WIN32|WINNT)
	PUTS("Unified ODBC Support active (compiled with iODBC)");
#elif WIN32|WINNT
	PUTS("Unified ODBC Support active (compiled with win32 ODBC)");
#else
	PUTS("Unified ODBC Support active (compiled with unknown library)");
#endif
}

/* }}} */

/*
 * List management functions
 */

int uodbc_add_result(HashTable *list,uodbc_result *result)
{
	UODBC_TLS_VARS;
	return php3_list_insert(result, UODBC_GLOBAL(php3_uodbc_module).le_result);
}

uodbc_result *uodbc_get_result(HashTable *list, int ind)
{
	uodbc_result *res;
	int type;
	UODBC_TLS_VARS;

	res = (uodbc_result*)php3_list_find(ind, &type);
	if (!res || type != UODBC_GLOBAL(php3_uodbc_module).le_result) {
		return NULL;
	}
	return res;
}

void uodbc_del_result(HashTable *list, int ind)
{
	uodbc_result *res;
	int type;
	UODBC_TLS_VARS;

	res = (uodbc_result *)php3_list_find(ind, &type);
	if (!res || type != UODBC_GLOBAL(php3_uodbc_module).le_result) {
		php3_error(E_WARNING,"Can't find result %d",ind);
		return;
	}
	php3_list_delete(ind);
}

int uodbc_add_conn(HashTable *list, uodbc_conn *conn)
{
	UODBC_TLS_VARS;
	conn->list = list;
	return php3_list_insert(conn, UODBC_GLOBAL(php3_uodbc_module).le_conn);
}

void uodbc_make_def_conn(HashTable *list)
{
	uodbc_conn *new_conn;
	RETCODE rc;
	UODBC_TLS_VARS;

	new_conn = (uodbc_conn *)emalloc(sizeof(uodbc_conn));
	if(new_conn == NULL) {
		php3_error(E_WARNING, "uodbc_make_def_conn - Out of memory");
		return;
	}

	SQLAllocConnect(UODBC_GLOBAL(php3_uodbc_module).henv, &(new_conn->hdbc));
	rc = SQLConnect(new_conn->hdbc, UODBC_GLOBAL(php3_uodbc_module).defDB,
					SQL_NTS, UODBC_GLOBAL(php3_uodbc_module).defUser, 
					SQL_NTS, UODBC_GLOBAL(php3_uodbc_module).defPW, SQL_NTS);

	if (rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO) {
		uodbc_sql_error(new_conn->hdbc, SQL_NULL_HSTMT, "SQLConnect");
	} else {
		UODBC_GLOBAL(php3_uodbc_module).defConn = uodbc_add_conn(list, new_conn);
	}
}

uodbc_conn *uodbc_get_conn(HashTable *list, int ind)
{
	uodbc_conn *conn;
	int type;
	UODBC_TLS_VARS;

	if(ind == 0){
    	if(UODBC_GLOBAL(php3_uodbc_module).defConn == 0){
			uodbc_make_def_conn(list);
		}
		ind = UODBC_GLOBAL(php3_uodbc_module).defConn;
	}

	conn = (uodbc_conn *)php3_list_find(ind, &type);
	if (!conn || type != UODBC_GLOBAL(php3_uodbc_module).le_conn) {
		return NULL;
	}
	return conn;
}

void uodbc_del_conn(HashTable *list, int ind)
{
	uodbc_conn *conn;
	int type;
	UODBC_TLS_VARS;

	conn = (uodbc_conn *)php3_list_find(ind, &type);
	if (!conn || type != UODBC_GLOBAL(php3_uodbc_module).le_conn) {
		return;
	}
	php3_list_delete(ind);	
}

void uodbc_sql_error(HDBC conn, HSTMT stmt, char *func)
{
    char	state[6];     /* Not used */
	SDWORD	error;        /* Not used */
	char	errormsg[SQL_MAX_MESSAGE_LENGTH];
	SWORD	errormsgsize; /* Not used */
	UODBC_TLS_VARS;
	
	SQLError(UODBC_GLOBAL(php3_uodbc_module).henv, conn, stmt, state, &error,
			 errormsg, SQL_MAX_MESSAGE_LENGTH-1, &errormsgsize);
	
	if (func) {
		php3_error(E_WARNING, "Function %s", func);
	}
	php3_error(E_WARNING, "SQL error: %s, SQL state %s", errormsg, state);	
}

/* Main User Functions */

void php3_uodbc_close_all(INTERNAL_FUNCTION_PARAMETERS)
{
	void *ptr;
	int type;
	int i, nument = hash_next_free_element(list);
	UODBC_TLS_VARS;

	for (i = 1; i < nument; i++) {
		ptr = php3_list_find(i, &type);
		if(!ptr || type != UODBC_GLOBAL(php3_uodbc_module).le_result){
			continue;
		}
		php3_list_delete(i);
	}

	for (i = 1; i < nument; i++) {
		ptr = php3_list_find(i, &type);
		if(!ptr || type != UODBC_GLOBAL(php3_uodbc_module).le_conn){
			continue;
		}
		php3_list_delete(i);
	}
}

/* Change single quote to two single quotes */
static void changeSingleQuote( char *query )
{
	if ( php3_ini.magic_quotes_runtime ) {
		char *s,*t;
		int l;
		l = strlen(query);
		s = query;
		while ( *s && l > 0 ) {
			if ( *s == '\\' ) {
				t = s + 1;
				if ( *t == '\'' )
					*s = '\'';
			}
			s++;
			l--;
		}
		_php3_stripslashes(query);
	}
}

void php3_uodbc_exec_common(INTERNAL_FUNCTION_PARAMETERS, char *cursor)
{
	YYSTYPE 	*arg1, *arg2;
	int         conn;
	char        *query;
	int         i;
	uodbc_result   *result=NULL;
	uodbc_conn  *curr_conn=NULL;
	short       resultcols;
	SWORD       colnamelen; /* Not used */
	SDWORD      displaysize;
	RETCODE     rc;

	if(getParameters(ht, 2, &arg1, &arg2) == FAILURE){
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	convert_to_string(arg2);
	conn = arg1->value.lval;
	query = arg2->value.strval;
	
	curr_conn = (uodbc_conn *)uodbc_get_conn(list, conn);
	if(curr_conn == NULL){
		php3_error(E_WARNING, "uodbc_exec - Bad ODBC connection number");
		RETURN_ZERO;
	}

	if ( !strcasecmp( curr_conn->dbms_name, "SOLID Server" ) )
	{
		changeSingleQuote( query );
	}
	else if ( php3_ini.magic_quotes_runtime ) {
		_php3_stripslashes(query);
	}
	
	result = (uodbc_result *)emalloc(sizeof(uodbc_result));
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_exec 1 - Out of memory");
		RETURN_ZERO;
	}

	rc = SQLAllocStmt(curr_conn->hdbc, &(result->stmt));
	if(rc == SQL_INVALID_HANDLE){
		php3_error(E_WARNING, "SQLAllocStmt error 'Invalid Handle'");
		RETURN_ZERO;
	}

	if(rc == SQL_ERROR){
		uodbc_sql_error(curr_conn->hdbc, SQL_NULL_HSTMT, "SQLAllocStmt");
		RETURN_ZERO;
	}

	result->stmtUpdDel = NULL;
	if ( cursor ) {
		rc = SQLSetCursorName( result->stmt, cursor, SQL_NTS );
		if(rc == SQL_ERROR){
			uodbc_sql_error(curr_conn->hdbc, SQL_NULL_HSTMT, "SQLSetCursorName");
			RETURN_ZERO;
		}
		rc = SQLAllocStmt(curr_conn->hdbc, &(result->stmtUpdDel));
		if(rc == SQL_INVALID_HANDLE){
			php3_error(E_WARNING, "SQLAllocStmt Upd/Del error 'Invalid Handle'");
			RETURN_ZERO;
		}
		if(rc == SQL_ERROR){
			uodbc_sql_error(curr_conn->hdbc, SQL_NULL_HSTMT, "SQLAllocStmt Upd/Del");
			RETURN_ZERO;
		}
	}

	if((rc = SQLExecDirect(result->stmt, query, SQL_NTS)) != SQL_SUCCESS){
		uodbc_sql_error(curr_conn->hdbc, result->stmt, "SQLExecDirect");
		SQLFreeStmt(result->stmt, SQL_DROP);
		RETURN_ZERO;
	}
	result->values = NULL;
	SQLNumResultCols(result->stmt, &resultcols);
	/* For insert, update etc. cols == 0 */
	if((result->numcols = resultcols)== 0){
		SQLFreeStmt(result->stmt,SQL_DROP);
		if(result->stmtUpdDel){
			SQLFreeStmt(result->stmtUpdDel,SQL_DROP);
		}
		efree(result);
		RETURN_LONG(1);
	}
	else {
		result->values = (uodbc_result_value *)emalloc(sizeof(uodbc_result_value)*resultcols);

		if(result->values == NULL){
			php3_error(E_WARNING, "uodbc_exec 2 -Out of memory");
			SQLFreeStmt(result->stmt, SQL_DROP);
			RETURN_ZERO;
		}

		for(i = 0; i < resultcols; i++){
			SQLColAttributes(result->stmt, i+1, SQL_COLUMN_NAME,
							 result->values[i].name,
							 sizeof(result->values[i].name),
							 &colnamelen,
							 NULL);
			SQLColAttributes(result->stmt, i+1, SQL_COLUMN_DISPLAY_SIZE,
							 NULL,
							 0,
							 NULL,
							 &displaysize);
			/* Any column that can have more than 255 bytes of data
			   will be output directly in odbc_result() instead of
			   being returned into a PHP variable.  This is due to a)
			   Memory restrictions b) Binary data can contain 0x0h
			   values.
			 */   
			/*			if (displaysize > 255){                            VK
				displaysize = 255;                                         VK
				result->values[i].isblob = 1;                              VK
			} else {                                                       VK
				SDWORD coltype;                                            VK
				SQLColAttributes(result->stmt, i+1, SQL_COLUMN_TYPE,       VK
								NULL, 0, NULL, &coltype);                  VK
				if(coltype == SQL_VARBINARY)                               VK
					displaysize = displaysize * 2;                         VK
				result->values[i].isblob = 0;                              VK
			}                                                              VK*/
			if (displaysize > 255){
				result->values[i].isblob = 1;
			} else {
				result->values[i].isblob = 0;
			}
			{
				SDWORD coltype;
				SQLColAttributes(result->stmt, i+1, SQL_COLUMN_TYPE,
								NULL, 0, NULL, &coltype);
				if(coltype == SQL_VARBINARY)
					displaysize = displaysize * 2;
			}
			result->values[i].value = NULL;
			if ( result->values[i].isblob == 0 ) {
				result->values[i].value = (char *)emalloc(displaysize + 1);
				if (result->values[i].value)
					SQLBindCol(result->stmt, i+1, SQL_C_CHAR, result->values[i].value,
							   displaysize + 1, &result->values[i].vallen);
			}
		}
	}
	result->conn = curr_conn;
	result->fetched = 0;
	RETURN_LONG(uodbc_add_result(list, result));
}

void php3_uodbc_exec(INTERNAL_FUNCTION_PARAMETERS)
{
	php3_uodbc_exec_common(INTERNAL_FUNCTION_PARAM_PASSTHRU, NULL);
}

void php3_uodbc_fetch_into(INTERNAL_FUNCTION_PARAMETERS)
{
	int         res_ind, numArgs, i;
	uodbc_result   *result;
	RETCODE     rc;
	YYSTYPE     *arg1, *arr, tmp;

	numArgs = ARG_COUNT(ht);
	
	if (numArgs != 2 || getParameters(ht, 2, &arg1, &arr) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	if (!ParameterPassedByReference(ht, numArgs)){
		php3_error(E_WARNING, "Array not passed by reference in call to odbc_afetch()");
		return;
	}
	
	convert_to_long(arg1);
	res_ind = arg1->value.lval;

	/* check result */
	result = uodbc_get_result(list, res_ind);
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_fetch_into - Unable to find result index %s", res_ind);
		RETURN_FALSE;
	}

	if(result->numcols == 0){
		php3_error(E_WARNING, "uodbc_fetch_into - No tuples available at this result index");
		RETURN_FALSE;
	}
	
	if(arr->type != IS_ARRAY){
		if (array_init(arr) == FAILURE){
			php3_error(E_WARNING, "uodbc_fetch_into - Can't convert to type Array");
			return;
		}
	}

	rc = SQLFetch(result->stmt);
	if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO)
		RETURN_FALSE;

	result->fetched++;

	for(i = 0; i < result->numcols; i++){
		if(result->values[i].value != NULL &&
		   /*			result->values[i].vallen != SQL_NO_TOTAL &&        VK*/
			result->values[i].isblob == 0){
			tmp.type = IS_STRING;
			tmp.strlen = strlen(result->values[i].value);
			tmp.value.strval = estrndup(result->values[i].value,tmp.strlen);
		}else{
			tmp.type = IS_STRING;
			tmp.strlen = 0;
			tmp.value.strval = empty_string;
		}
		hash_index_update(arr->value.ht, i, (void *) &tmp, sizeof(YYSTYPE), NULL);
	}
	RETURN_LONG(result->numcols);	
}

void php3_uodbc_fetch_row(INTERNAL_FUNCTION_PARAMETERS)
{
	int         res_ind, numArgs;
	SDWORD      rownum = 1;
	uodbc_result   *result;
	RETCODE     rc;
	YYSTYPE		*arg1, *arg2;
	
	numArgs = ARG_COUNT(ht);
	if(numArgs ==  1){
		if(getParameters(ht, 1, &arg1) == FAILURE)
			WRONG_PARAM_COUNT;
	}else{
		if(getParameters(ht, 2, &arg1, &arg2) == FAILURE)
			WRONG_PARAM_COUNT;
		convert_to_long(arg2);
		rownum = arg2->value.lval;
	}
	
	convert_to_long(arg1);
	res_ind = arg1->value.lval;
	
	/* check result */
	result = uodbc_get_result(list, res_ind);
	if (result == NULL) {
		php3_error(E_WARNING, "uodbc_fetch_row - Unable to find result index %s", res_ind);
		RETURN_FALSE;
	}
	
	if (result->numcols == 0) {
		php3_error(E_WARNING, "uodbc_fetch_row - No tuples available at this result index");
		RETURN_FALSE;
	}

	rc = SQLFetch(result->stmt);

	if (rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO) {
		RETURN_FALSE;
	}
	
	if (numArgs > 1) {
		result->fetched = rownum;
	} else {
		result->fetched++;
	}
	
	RETURN_TRUE;
}	

void php3_uodbc_result(INTERNAL_FUNCTION_PARAMETERS)
{
	char        *field;
	int         res_ind;
	int         field_ind;
	uodbc_result   *result;
	int         i;
	RETCODE     rc;
	YYSTYPE		*arg1, *arg2;
#if !defined(COMPILE_DL) && defined(THREAD_SAFE)
	TLS_VARS;
#endif

	field_ind = -1;
	field = NULL;

	if(ARG_COUNT(ht) != 2 || getParameters(ht, 2 , &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	
	convert_to_long(arg1);
	res_ind = arg1->value.lval;

	if(arg2->type == IS_STRING)
		field = arg2->value.strval;
	else{
		convert_to_long(arg2);
		field_ind = arg2->value.lval - 1;
	}
	
	/* check result */
	result = uodbc_get_result(list, res_ind);
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_result - Unable to find result index %d", res_ind);
		RETURN_FALSE;
	}
	
	if((result->numcols == 0)){
		php3_error(E_WARNING, "uodbc_result - No tuples available at this result index");
		RETURN_FALSE;
	}
	
	/* get field index if the field parameter was a string */
	if(field != NULL){
		for(i = 0; i < result->numcols; i++){
			if(!strcasecmp(result->values[i].name, field)){
				field_ind = i;
				break;
			}
		}

		if(field_ind < 0){
			php3_error(E_WARNING, "uodbc_result - Field %s not found", field);
			RETURN_FALSE;
		}
	}else{
		/* check for limits of field_ind if the field parameter was an int */
		if(field_ind >= result->numcols || field_ind < 0){
			php3_error(E_WARNING, "uodbc_result - Field index is larger than the number of fields");
			RETURN_FALSE;
		}
	}

	if(result->fetched == 0){
		/* User forgot to call odbc_fetchrow(), let's do it here */
		rc = SQLFetch(result->stmt);

		if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO)
			RETURN_FALSE;
		
		result->fetched++;
	}
       
	if (result->values[field_ind].vallen == SQL_NULL_DATA){
		RETURN_FALSE;
	} else {
/*VK	if (result->values[field_ind].value != NULL &&
  VK	result->values[field_ind].vallen != SQL_NO_TOTAL &&
  VK		result->values[field_ind].isblob == 0){
  VK		RETURN_STRING(result->values[field_ind].value);	
  VK	} else {
  VK		char buf[4096];
  VK		SDWORD fieldsize = 256;
  VK
  VK		/ * Make sure that the Header is sent * / 
  VK		if (!php3_header(0, NULL))
  VK			RETURN_TRUE;  / * don't output anything on a HEAD request * /
  VK
  VK		if (result->values[field_ind].vallen != SQL_NO_TOTAL) {
  VK			fieldsize = result->values[field_ind].vallen;
  VK		}
  VK		/ * Output what's already in the field * /
  VK		PHPWRITE(result->values[field_ind].value, fieldsize - 1);
  VK			
  VK		if (result->values[field_ind].vallen != SQL_NO_TOTAL) {
  VK			RETURN_TRUE;
  VK		}
  VK
  VK		/ * Call SQLGetData until SQL_SUCCESS is returned * /
  VK		while (1) {
  VK			rc = SQLGetData(result->stmt, field_ind + 1, SQL_C_CHAR,
  VK							buf, 4096, &fieldsize);
  VK
  VK			if (rc == SQL_ERROR) {
  VK				uodbc_sql_error(result->conn->hdbc, result->stmt, "SQLGetData");
  VK				RETURN_FALSE;
  VK			}
  VK
  VK			if (rc == SQL_SUCCESS_WITH_INFO) {
  VK				fieldsize = 4096;
  VK			}
  VK			PHPWRITE(buf, fieldsize - 1);
  VK				
  VK			if (rc == SQL_SUCCESS) { / * no more data avail * /
  VK				break;
  VK			}
  VK		}
  VK		RETURN_TRUE;
  VK	}
  VK	*/

		if (result->values[field_ind].value != NULL &&
            result->values[field_ind].isblob == 0) {
			RETURN_STRING(result->values[field_ind].value);	
		} else if (result->values[field_ind].isblob) {
			char c, *realval = &c;
			SDWORD fieldsize = 12345;
			/* This first SQLGetData is used just to
			 * find out the exact size of the field - 
			 * that is why we only get one char
			 */
			if (SQLGetData(result->stmt, field_ind + 1, SQL_C_CHAR,
					   realval, 1, &fieldsize) == SQL_ERROR) {
				RETURN_FALSE;
			} else if (fieldsize > 0) {
				result->values[field_ind].value = emalloc(fieldsize + 2);
				if (result->values[field_ind].value == NULL ||
				SQLGetData(result->stmt,
						   field_ind + 1, SQL_C_CHAR,
						   result->values[field_ind].value, fieldsize + 1,
						   &fieldsize) == SQL_ERROR) 
				{
					php3_error(E_WARNING, "Out of memory");
				} else {
					RETURN_STRING(result->values[field_ind].value);
				}
			} else {
				RETURN_STRING(realval);
			}
		} else {
			RETURN_FALSE;
		}
	}
}

void php3_uodbc_result_all(INTERNAL_FUNCTION_PARAMETERS)
{
	int         res_ind, numArgs;
	uodbc_result   *result;
	int         i;
	RETCODE     rc;
	YYSTYPE     *arg1, *arg2;

	numArgs = ARG_COUNT(ht);
	if(numArgs ==  1){
		if(getParameters(ht, 1, &arg1) == FAILURE)
			WRONG_PARAM_COUNT;
	}else{
		if(getParameters(ht, 2, &arg1, &arg2) == FAILURE)
			WRONG_PARAM_COUNT;
	}
				
	convert_to_long(arg1);
	res_ind = arg1->value.lval;
	
	/* check result */
	result = uodbc_get_result(list, res_ind);
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_result_all - Unable to find result index %d", res_ind);
		RETURN_FALSE;
	}
	
	if(result->numcols == 0){
		php3_error(E_WARNING, "uodbc_result_all - No tuples available at this result index");
		RETURN_FALSE;
	}
	
	rc = SQLFetch(result->stmt);

	if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO){
		php3_printf("<h2>uodbc_result_all - No rows found</h2>\n");
		RETURN_LONG(0);
	}
	
	/* Start table tag */
	if(numArgs == 1){
		php3_printf("<table><tr>");
	}else{
		convert_to_string(arg2);	
		php3_printf("<table %s ><tr>",arg2->value.strval); 
	}
	
	for(i = 0; i < result->numcols; i++)
		php3_printf("<th>%s</th>", result->values[i].name);

	php3_printf("</tr>\n");

	while(rc == SQL_SUCCESS || rc == SQL_SUCCESS_WITH_INFO){
		result->fetched++;
		php3_printf("<tr>");
		for(i = 0; i < result->numcols; i++){
			if(result->values[i].vallen == SQL_NULL_DATA)
				php3_printf("<td> </td>");
			else{
				if(result->values[i].isblob == 0)
					php3_printf("<td>%s</td>", result->values[i].value);
					/* _php3_addslashes(result->values[i].value,0)); */
							
				else 
					php3_printf("<td>Unsupp. data type</td>");
			}
		}
		php3_printf("</tr>\n");

		rc = SQLFetch(result->stmt);		
	}
	php3_printf("</table>\n");
	RETURN_LONG(result->fetched);
}

void php3_uodbc_free_result(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg1;
	
	if( getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_long(arg1);
	uodbc_del_result(list, arg1->value.lval);
	RETURN_TRUE;
}

void php3_uodbc_connect(INTERNAL_FUNCTION_PARAMETERS)
{
	uodbc_conn *new_conn;
	char    *db = NULL;
	char    *uid = NULL;
	char    *pwd = NULL;
	RETCODE rc;
	YYSTYPE *arg1, *arg2, *arg3;
	UODBC_TLS_VARS;
	
	if(getParameters(ht, 3, &arg1, &arg2, &arg3) == FAILURE)
		WRONG_PARAM_COUNT;
	
	convert_to_string(arg1);
	convert_to_string(arg2);
	convert_to_string(arg3);

	db = arg1->value.strval;
	uid = arg2->value.strval;
	pwd = arg3->value.strval;

	new_conn = (uodbc_conn *)emalloc(sizeof(uodbc_conn));
	if(new_conn == NULL) {
		php3_error(E_WARNING, "uodbc_connect - Out of memory");
		RETURN_ZERO;
	}

	SQLAllocConnect(UODBC_GLOBAL(php3_uodbc_module).henv, &(new_conn->hdbc));
	
	rc = SQLConnect(new_conn->hdbc, db, SQL_NTS, uid, SQL_NTS, pwd, SQL_NTS);

	if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO){
		uodbc_sql_error(new_conn->hdbc, SQL_NULL_HSTMT, "SQLConnect");
		RETURN_FALSE;
	}else{
#ifndef SQL_DBMS_NAME
#define SQL_DBMS_NAME 17
#endif
		new_conn->dbms_name[0] = 0;
		SQLGetInfo( new_conn->hdbc, SQL_DBMS_NAME, new_conn->dbms_name, 15, NULL );
		RETURN_LONG(uodbc_add_conn(list, new_conn));
	}
}

void php3_uodbc_close(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE *arg1;
	uodbc_conn *new_conn;

    if(getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(arg1);
	new_conn = (uodbc_conn *)uodbc_get_conn(list, arg1->value.lval);
	if(new_conn == NULL){
		php3_error(E_WARNING, "uodbc_close - Bad ODBC connection number");
		return;
	}
	uodbc_del_conn(list, arg1->value.lval);
}

void php3_uodbc_num_rows(INTERNAL_FUNCTION_PARAMETERS)
{
	uodbc_result   *result;
	SDWORD      rows;
	YYSTYPE 	*arg1;
	
	if( getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}            

	convert_to_long(arg1);

	result = uodbc_get_result(list, arg1->value.lval);
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_num_rows - Bad result index in odbc_numrows");
		RETURN_FALSE;
	}

	SQLRowCount(result->stmt, &rows);
	RETURN_LONG(rows);
}

void php3_uodbc_num_fields(INTERNAL_FUNCTION_PARAMETERS)
{
	uodbc_result   *result;
	YYSTYPE     *arg1;

 	if( getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}                            
 
    convert_to_long(arg1);
	 
	result = uodbc_get_result(list, arg1->value.lval);
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_num_fields - Bad result index in odbc_numfields");
		RETURN_FALSE;
	}
	RETURN_LONG(result->numcols);
}

void php3_uodbc_field_name(INTERNAL_FUNCTION_PARAMETERS)
{
	uodbc_result       *result;
	YYSTYPE     *arg1, *arg2;
	
	if(getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
		
	convert_to_long(arg1);
	convert_to_long(arg2);
	
    result = uodbc_get_result(list, arg1->value.lval);
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_field_name - Bad result index");
		RETURN_FALSE;
	}
	
	if(result->numcols == 0){
		php3_error(E_WARNING, "uodbc_field_name - No tuples available at this result index");
		RETURN_FALSE;
	}
	
	if(arg2->value.lval > result->numcols){
		php3_error(E_WARNING, "uodbc_field_name - Field index larger than number of fields");
		RETURN_FALSE;
	}
	
	if(arg2->value.lval < 1){
		php3_error(E_WARNING, "uodbc_field_name - Field numbering starts at 1");
		RETURN_FALSE;
	}
	
	RETURN_STRING(result->values[arg2->value.lval - 1].name)
}

void php3_uodbc_field_type(INTERNAL_FUNCTION_PARAMETERS)
{
	uodbc_result	*result;
	char    	tmp[32];
	SWORD   	tmplen;
	YYSTYPE     *arg1, *arg2;

	if(getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(arg1);
	convert_to_long(arg2);

	result = uodbc_get_result(list, arg1->value.lval);
	if(result == NULL){
		php3_error(E_WARNING, "uodbc_field_type - Bad result index");
		RETURN_FALSE;
	}               

	if(result->numcols == 0){
		php3_error(E_WARNING, "uodbc_field_type - No tuples available at this result index");
		RETURN_FALSE;
	}

	if(arg2->value.lval > result->numcols){
		php3_error(E_WARNING, "uodbc_field_type - Field index larger than number of fields");
		RETURN_FALSE;
	}

	SQLColAttributes(result->stmt, (UWORD)arg2->value.lval,
					 SQL_COLUMN_TYPE_NAME, tmp, 31, &tmplen, NULL);
	RETURN_STRING(tmp)
}

void php3_uodbc_field_len(INTERNAL_FUNCTION_PARAMETERS)
{
	uodbc_result       *result;
	SDWORD  len;
	YYSTYPE     *arg1, *arg2;

	if(getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(arg1);
	convert_to_long(arg2);
	
	result = uodbc_get_result(list, arg1->value.lval);

	if(result == NULL){
		php3_error(E_WARNING, "uodbc_field_len - Bad result index");
		RETURN_FALSE;
	}

	if(result->numcols == 0){
		php3_error(E_WARNING, "uodbc_field_len - No tuples available at this result index");
		RETURN_FALSE;
	}
	
	if(arg2->value.lval > result->numcols){
		php3_error(E_WARNING, "uodbc_field_len - Field index larger than number of fields");
		RETURN_FALSE;
	}
	SQLColAttributes(result->stmt, (UWORD)arg2->value.lval, 
					 SQL_COLUMN_PRECISION, NULL, 0, NULL, &len);
	
	RETURN_LONG(len)
}

#if 0 /* XXX not used anywhere -jaakko */
void php3_uodbc_field_num(INTERNAL_FUNCTION_PARAMETERS)
{
	int         field_ind;
	char        *fname;
	uodbc_result *result;
	int         i;
	YYSTYPE     *arg1, *arg2;

	if(getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}

	convert_to_long(arg1);
	convert_to_string(arg2);
	fname = arg2->value.strval;
	
	if(arg1->value.lval == 1){
		php3_error(E_WARNING, "No tuples available at this result index");
		RETURN_FALSE;
	}
	result = uodbc_get_result(list, arg1->value.lval);
	if(result == NULL){
		php3_error(E_WARNING, "Bad result index");
		RETURN_FALSE;
	}
	
	field_ind = -1;
	for(i = 0; i < result->numcols; i++){
		if(strcasecmp(result->values[i].name, fname) == 0)
			field_ind = i + 1;
		}
	if(field_ind == -1)
		RETURN_FALSE;
	RETURN_LONG(field_ind);
}
#endif /* XXX */

void php3_uodbc_autocommit(INTERNAL_FUNCTION_PARAMETERS)
{
	uodbc_conn	*curr_conn;
	RETCODE rc;
	YYSTYPE *arg1, *arg2;

 	if( getParameters(ht, 2, &arg1, &arg2) == FAILURE) {
		WRONG_PARAM_COUNT;
	}                            
 
    convert_to_long(arg1);
	convert_to_long(arg2);

	curr_conn = (uodbc_conn *)uodbc_get_conn(list, arg1->value.lval);
	if(curr_conn == NULL){
		php3_error(E_WARNING, "uodbc_autocommit - Bad ODBC connection number");
		RETURN_FALSE;
	}

	rc = SQLSetConnectOption(curr_conn->hdbc, SQL_AUTOCOMMIT, (arg2->value.lval)?
							 SQL_AUTOCOMMIT_ON:SQL_AUTOCOMMIT_OFF);	
	if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO){
		uodbc_sql_error(curr_conn->hdbc, SQL_NULL_HSTMT, "Autocommit");
		RETURN_FALSE;
	}

	RETURN_TRUE;
}

void php3_uodbc_transact(INTERNAL_FUNCTION_PARAMETERS, int type)
{
	uodbc_conn	*curr_conn;
	RETCODE rc;
	YYSTYPE *arg1;
	UODBC_TLS_VARS;

 	if( getParameters(ht, 1, &arg1) == FAILURE) {
		WRONG_PARAM_COUNT;
	}                            
 
    convert_to_long(arg1);

	curr_conn = (uodbc_conn *)uodbc_get_conn(list, arg1->value.lval);
	if(curr_conn == NULL){
		php3_error(E_WARNING, "uodbc_transact - Bad ODBC connection number");
		RETURN_FALSE;
	}

	rc = SQLTransact(UODBC_GLOBAL(php3_uodbc_module).henv, curr_conn->hdbc, (type)?SQL_COMMIT:SQL_ROLLBACK);
	if(rc != SQL_SUCCESS && rc != SQL_SUCCESS_WITH_INFO){
		uodbc_sql_error(curr_conn->hdbc, SQL_NULL_HSTMT, "SQLTransact");
		RETURN_FALSE;
	}

	RETURN_TRUE;
}

void php3_uodbc_commit(INTERNAL_FUNCTION_PARAMETERS)
{
	php3_uodbc_transact(INTERNAL_FUNCTION_PARAM_PASSTHRU, 1);
}

void php3_uodbc_rollback(INTERNAL_FUNCTION_PARAMETERS)
{
	php3_uodbc_transact(INTERNAL_FUNCTION_PARAM_PASSTHRU, 0);
}

/*
  ODBC_exec_cursor sample:

  $cursor = "c1";
  $result = ODBC_exec_cursor( $connectionID, "select ...", $cursor );
  ODBC_autocommit( $connectionID, 0 );
  while ( ODBC_fetch_row( $result ) ) {
    ... processing statemenets ...
	ODBC_exec_cursor( $result, "update ... where current of $cursor" );
  }
  ODBC_commit( $connID );
  ODBC_exec_cursor( $result );  // free results

 */
void php3_uodbc_exec_cursor(INTERNAL_FUNCTION_PARAMETERS)
{
	YYSTYPE 	*arg1, *arg2, *arg3;
	int         argc;
	uodbc_result   *result=NULL;
	RETCODE     rc;

	argc = ARG_COUNT(ht);
	if (argc > 3 || getParameters(ht, argc, &arg1, &arg2, &arg3) == FAILURE) {
		WRONG_PARAM_COUNT;
	}
	switch (argc) {
		case 1:  /* free results */
			if ( arg1->type != IS_LONG ) {
				php3_error(E_WARNING, "uodbc_exec_cursor 1 - Bad 'result' type");
				RETURN_ZERO;
			}
			result = uodbc_get_result(list, arg1->value.lval);
			if(result == NULL){
				php3_error(E_WARNING, "uodbc_exec_cursor 1 - Bad result index");
				RETURN_FALSE;
			}
			if ( result->stmtUpdDel ) {
				php3_uodbc_free_result(INTERNAL_FUNCTION_PARAM_PASSTHRU);
			}
			RETURN_TRUE;
		case 2:  /* SQL Update/Delete stmt with "where current of" */
			if ( arg1->type != IS_LONG ) {
				php3_error(E_WARNING, "uodbc_exec_cursor 2 - Bad 'result' type");
				RETURN_ZERO;
			}
			result = uodbc_get_result(list, arg1->value.lval);
			if(result == NULL){
				php3_error(E_WARNING, "uodbc_exec_cursor 2 - Bad result index");
				RETURN_FALSE;
			}
			if ( !strcasecmp( result->conn->dbms_name, "SOLID Server" ) ) {
				changeSingleQuote( arg2->value.strval );
			}
			else if ( php3_ini.magic_quotes_runtime ) {
				_php3_stripslashes(arg2->value.strval);
			}
			if ( result->stmtUpdDel ) {
				if((rc = SQLExecDirect(result->stmtUpdDel, arg2->value.strval, SQL_NTS)) != SQL_SUCCESS){
					uodbc_sql_error(result->conn->hdbc, result->stmtUpdDel, "uodbc_exec_cursor 2 - SQLExecDirect");
					RETURN_ZERO;
				}
			}
			RETURN_TRUE;
		case 3:  /* SQL select */
			php3_uodbc_exec_common(INTERNAL_FUNCTION_PARAM_PASSTHRU, arg3->value.strval);
			break;
	}
}

#endif /* HAVE_UODBC */



/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
