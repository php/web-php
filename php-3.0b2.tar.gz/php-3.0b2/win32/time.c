/*****************************************************************************
 *                                                                           *
 * DH_TIME.C                                                                 *
 *                                                                           *
 * Freely redistributable and modifiable.  Use at your own risk.             *
 *                                                                           *
 * Copyright 1994 The Downhill Project                                       *
 * 
 * Modified by Shane Caraveo for use with PHP
 *
 *****************************************************************************/


/* Include stuff *************************************************************/
#include "time.h"
#include <winbase.h>

int gettimeofday(struct timeval* time_Info,struct timezone* timezone_Info)
{
	_int64 mstimer, freq;
	/* Get the time, if they want it */
	if (time_Info != NULL)
	{
		time_Info->tv_sec = time(NULL);
		/* get ticks-per-second of the performance counter
		   Note the necessary typecast to a LARGE_INTEGER structure 
		*/
		if (!QueryPerformanceFrequency((LARGE_INTEGER*)&freq))
		{
			time_Info->tv_usec = 0;
		}else{
			QueryPerformanceCounter((LARGE_INTEGER*)&mstimer);
			mstimer = (__int64)(mstimer * .8);
			time_Info->tv_usec = (long)(mstimer % 0x0FFFFFFF);
		}
	}

	/* Get the timezone, if they want it */
	if (timezone_Info != NULL)
	{
		_tzset();
		timezone_Info->tz_minuteswest = _timezone;
		timezone_Info->tz_dsttime = _daylight;
	}

	/* And return */
	return 0;
}
