Place files located in the system directory into your system directory.
!!DO NOT place any additional files into your system directory other than
the couple dlls that are under the system directory in this archive.!!

Make a directory, such as c:\php3, and place all the rest of the dlls there.

If you are not using Apache NT server, you can set an environment
variable in your autoexec.bat file, add this line:

SET PHPRC=\windows\php3.ini

and place your php3.ini file in whatever directory you specify.
Otherwise, be sure to place php3.ini in your os directory 
(typicaly c:\windows or c:\winnt).

msql1.dll, calendar.dll and msql2.dll must be located in the
same directory as php3.exe, or you must specify where these files
are located either in your php3.ini file, or in the php3 script.

You can load modules at startup via the ini file by placing a line like:
extension=dbase.dll
in your ini file,
OR
To use a loadable module in your script you must have the following
command:

dl("dbase.dll");

For further instructions, html manual, reporting bugs, etc., 
see www.php.net

PHP and Apache CGI
PHP will look under your os directory (\windows or \winnt) for php3.ini
See the PHP2 docs for more information on redirection under apache

PHP and Microsoft Servers
You need to edit the registry.  DO THIS AT YOUR OWN RISK!  We will not
be held responsible for damaged registry files.  Back up your registry!
Future releases will have an installation program.
To edit your registry, go to the start button and select "run".  Type in
regedit and press enter.
Go to: 
HKEY_LOCAL_MACHINE:System:CurrentControlSet:Services:W3Svc:Parameters:ScriptMap
Go to the edit menu and select new->string value
type in the EXTENSION you wish to use for your php scripts '.php3'
Double click on the new key and enter the path to php.exe in the
value data field 'c:\php3\php.exe'.
Now, you must make the directory containing your php scripts both browsable
and executable.  See your server documentation on how to do this.

PHP ISAPI Module
This module IS NOT THREAD SAFE.  Do not use in any production environment.
It is included here for experimental purposes only!  Setting up this module
for MSPWS or IIS is the same as setting up the cgi module in the registry.
See the php email list archives for details.

External Modules:
snmp.dll	SNMP Get and Walk functions (NT ONLY!)
msql2.dll	mSQL 2 client
dbase.dll	DBASE functions
ldap.dll	LDAP functions
gd.dll		GD Library functions for gif manipulation
dbm.dll		GDBM emulation via Berkely DB2 library
filepro.dll	READ ONLY access to filepro databases
calendar.dll	Calendar conversion functions
mysql.dll       MySQL functions (currently compiled into php.exe)

For a full list of functions available, see FUNCTION_LIST.txt.  This file
is not a manual, but may be handy to have until we finish the new documentation.

CONVERT.EXE

This is the php/fi 2 to php 3 converter.  See the php3 website for more
information on its limitations.  Generaly, there will still be converting
work to be done after using this program on a script, but this will get
a lot of dirty work done.

PHPWATCH.EXE

This is a sample application that reads the debugger output from PHP.
